/*
 * AT_Logic_LED.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_LED()
{
    ////////////////////////////////////
    // External Power LED
    ////////////////////////////////////
    {
        CMF_BOOL _LEDAC; //AC POWER
        _LEDAC = (GET_TAG_AI_F(ALS_AI_AICHV) > 30.0 ) ? 1 : 0 ;

        CMF_BOOL _EXPOWER;
        _EXPOWER = GET_TAG_MMI(ALS_MMI_LEDAC);

        // Set tag phase
        SET_TAG_MMI(ALS_MMI_LEDAC, _LEDAC);
        SET_TAG_MMI(ALS_MMI_LEDAC, _EXPOWER);
    }

    ////////////////////////////////////
    // Fault Indicator Reset
    ////////////////////////////////////
//    {
//        // Define phase
//
//        CMF_BOOL TARR;
//        TARR = GET_TAG_RCM(ALS_RCM_CTARR);
//
//        // Process phase
//        SET_TAG_BV(ALS_BV_TARR, TARR);
//    }

    ////////////////////////////////////
    // Handle Lock LEDD
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL LEDHLOCK;
        LEDHLOCK = GET_TAG_DI(ALS_DI_HLOCK);

        // Process phase
        SET_TAG_MMI(ALS_MMI_LEDHLOCK, LEDHLOCK);
    }

    ////////////////////////////////////
    // Sequence LED Lamp
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL LED79RS;
        CMF_BOOL LED79CY;
        CMF_BOOL LED79LO;
        CMF_BOOL LEDV79RS;
        CMF_BOOL LEDV79CY;

        LED79RS = GET_TAG_BV(ALS_BV_79RS);
        LED79CY = GET_TAG_BV(ALS_BV_79CY);
        LED79LO = GET_TAG_BV(ALS_BV_79LO);
        LEDV79RS = GET_TAG_BV(ALS_BV_V79RS);
        LEDV79CY = GET_TAG_BV(ALS_BV_V79CY);

        // Process phase
        SET_TAG_MMI(ALS_MMI_LED79RS, LED79RS);
        SET_TAG_MMI(ALS_MMI_LED79CY, LED79CY);
        SET_TAG_MMI(ALS_MMI_LED79LO, LED79LO);
        SET_TAG_MMI(ALS_MMI_LEDV79RS, LEDV79RS);
        SET_TAG_MMI(ALS_MMI_LEDV79CY, LEDV79CY);
    }

    //////////////////////////
    // Phase Rotation Display & Setting
    //////////////////////////
    {
     // Adjust Angle
     CMF_BOOL ANG_VB, ANG_VC;
     ANG_VB = GET_TAG_AI_F(ALS_AI_ANG_VB);
     ANG_VC = GET_TAG_AI_F(ALS_AI_ANG_VC);

     SFB_DEF_FIT_ANG_RANGE(ANG1);
     ANG_VB = SFB_USE_FIT_ANG_RANGE(ANG1, ANG_VB);
     SFB_DEF_FIT_ANG_RANGE(ANG2);
     ANG_VC = SFB_USE_FIT_ANG_RANGE(ANG2, ANG_VC);

     CMF_BOOL temp1_b;
     temp1_b = (( 180.0 > ANG_VB) ? 1 : 0 ) & (( 180.0 < ANG_VC) ? 1: 0 );
     CMF_BOOL temp2_b;
     temp2_b = GET_TAG_BV(ALS_BV_3P59P1AND) & !temp1_b & !GET_TAG_BV(ALS_BV_FPU);
     CMF_BOOL temp3_b;
     temp3_b = GET_TAG_BV(ALS_BV_3P59P1AND) & temp1_b & !GET_TAG_BV(ALS_BV_FPU);

     SFB_DEF_GBTV(_ROTATION, CMF_BOOL, CMF_FALSE);
     _ROTATION = (_ROTATION | temp3_b) & !temp2_b;

     CMF_BOOL _LEDABC, _LEDCBA;
     _LEDABC = !_ROTATION;
     _LEDCBA = _ROTATION;

     // Set Tag data
     SET_TAG_MMI(ALS_MMI_LEDABC, _LEDABC);
     SET_TAG_MMI(ALS_MMI_LEDCBA, _LEDCBA);
     }

    //////////////////////////
    // LED_BLINKCONTROL
    //////////////////////////
    {
        SFB_DEF_PD_TIMER(pd0, PDTT_SEC, 2.0, PDTT_SEC, 2.0);
        CMF_BOOL pd0out_ = CMF_FALSE;
//        SFB_USE_PD_TIMER(pd0, !GET_TAG_MMI(ALS_MMI_LEDCPU), NULL, &pd0out_);
        SFB_USE_PD_TIMER(pd0, !GET_TAG_BV(ALS_BV_CPULED), NULL, &pd0out_);


        // Set Tag data
        SET_TAG_BV_WO_EV(ALS_BV_CPULED, pd0out_);
        SET_TAG_MMI(ALS_MMI_LEDCPU, GET_TAG_BV(ALS_BV_CPULED));
    }

    //////////////////////////
    // LED_Setting Group
    //////////////////////////

    if(GET_TAG_SC_SCFG_UI(ALS_SC_STGRP)){
        SET_TAG_MMI(ALS_MMI_LEDSG1, 0);
        SET_TAG_MMI(ALS_MMI_LEDSG2, 1);
    } else{
        SET_TAG_MMI(ALS_MMI_LEDSG1, 1);
        SET_TAG_MMI(ALS_MMI_LEDSG2, 0);
    }

}
