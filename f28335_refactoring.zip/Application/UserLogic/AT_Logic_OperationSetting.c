/*
 * AT_Logic_OperationSetting.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_OperationSetting()
{
    //OCP
    {
    CMF_BOOL TEMP0, TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP0 = (GET_TAG_LS_UI(ALS_LS_OPPH) == 0) ? 1 : 0;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_OPPH) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_OPPH) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_OPPH) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_OPPH) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8, TEMP9;
    TEMP5 = (!(GET_TAG_BV(ALS_BV_79RS) | GET_TAG_BV(ALS_BV_79CY) | GET_TAG_BV(ALS_BV_79LO)) & !TEMP0);
    TEMP6 = GET_TAG_BV(ALS_BV_SH0) & (TEMP1 | TEMP2 | TEMP3 | TEMP4);
    TEMP7 = GET_TAG_BV(ALS_BV_SH1) & (TEMP2 | TEMP3 | TEMP4);
    TEMP8 = GET_TAG_BV(ALS_BV_SH2) & (TEMP3 | TEMP4);
    TEMP9 = GET_TAG_BV(ALS_BV_SH3) & TEMP4;

    CMF_BOOL _OCP;
    _OCP = TEMP5 | TEMP6 | TEMP7 | TEMP8 | TEMP9;

    //set tag data
    SET_TAG_BV(ALS_BV_OCP, _OCP);
    }

    //OCG
    {
    CMF_BOOL TEMP10, TEMP11, TEMP12, TEMP13, TEMP14;
    TEMP10 = (GET_TAG_LS_UI(ALS_LS_OPGR) == 0) ? 1 : 0;
    TEMP11 = (GET_TAG_LS_UI(ALS_LS_OPGR) == 1) ? 1 : 0;
    TEMP12 = (GET_TAG_LS_UI(ALS_LS_OPGR) == 2) ? 1 : 0;
    TEMP13 = (GET_TAG_LS_UI(ALS_LS_OPGR) == 3) ? 1 : 0;
    TEMP14 = (GET_TAG_LS_UI(ALS_LS_OPGR) == 4) ? 1 : 0;

    CMF_BOOL TEMP15, TEMP16, TEMP17, TEMP18, TEMP19;
    TEMP15 = (!(GET_TAG_BV(ALS_BV_79RS) | GET_TAG_BV(ALS_BV_79CY) | GET_TAG_BV(ALS_BV_79LO)) & !TEMP10);
    TEMP16 = GET_TAG_BV(ALS_BV_SH0) & (TEMP11 | TEMP12 | TEMP13 | TEMP14);
    TEMP17 = GET_TAG_BV(ALS_BV_SH1) & (TEMP12 | TEMP13 | TEMP14);
    TEMP18 = GET_TAG_BV(ALS_BV_SH2) & (TEMP13 | TEMP14);
    TEMP19 = GET_TAG_BV(ALS_BV_SH3) & TEMP14;

    CMF_BOOL _OCG;
    _OCG = TEMP15 | TEMP16 | TEMP17 | TEMP18 | TEMP19;

    //set tag data
    SET_TAG_BV(ALS_BV_OCG, _OCG);
    }

    ////////////////////////////////////
    // OLP
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_OPLKPH) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_OPLKPH) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_OPLKPH) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_OPLKPH) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = GET_TAG_BV(ALS_BV_SH0) & TEMP1;
    TEMP6 = GET_TAG_BV(ALS_BV_SH1) & (TEMP1 | TEMP2);
    TEMP7 = GET_TAG_BV(ALS_BV_SH2) & (TEMP3 | TEMP2 | TEMP1);
    TEMP8 = GET_TAG_BV(ALS_BV_SH3) & (TEMP4 | TEMP3 | TEMP2 | TEMP1);

    CMF_BOOL _OLP;
    _OLP = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_OLP, _OLP);
    }

    ////////////////////////////////////
    // OLG
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_OPLKGR) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_OPLKGR) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_OPLKGR) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_OPLKGR) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = GET_TAG_BV(ALS_BV_SH0) & TEMP1;
    TEMP6 = GET_TAG_BV(ALS_BV_SH1) & (TEMP1 | TEMP2);
    TEMP7 = GET_TAG_BV(ALS_BV_SH2) & (TEMP1 | TEMP2 | TEMP3);
    TEMP8 = GET_TAG_BV(ALS_BV_SH3) & (TEMP1 | TEMP2 | TEMP3 | TEMP4);

    CMF_BOOL _OLG;
    _OLG = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_OLG, _OLG);
    }

    ////////////////////////////////////
    // HLP
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_HILKPH) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_HILKPH) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_HILKPH) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_HILKPH) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = GET_TAG_BV(ALS_BV_SH0) & TEMP1;
    TEMP6 = GET_TAG_BV(ALS_BV_SH1) & (TEMP1 | TEMP2);
    TEMP7 = GET_TAG_BV(ALS_BV_SH2) & (TEMP1 | TEMP2 | TEMP3);
    TEMP8 = GET_TAG_BV(ALS_BV_SH3) & (TEMP1 | TEMP2 | TEMP3 | TEMP4);

    CMF_BOOL _HLP;
    _HLP = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_HLP, _HLP);
    }

    ////////////////////////////////////
    // HLG
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_HILKGR) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_HILKGR) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_HILKGR) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_HILKGR) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = GET_TAG_BV(ALS_BV_SH0) & TEMP1;
    TEMP6 = GET_TAG_BV(ALS_BV_SH1) & (TEMP1 | TEMP2);
    TEMP7 = GET_TAG_BV(ALS_BV_SH2) & (TEMP1 | TEMP2 | TEMP3);
    TEMP8 = GET_TAG_BV(ALS_BV_SH3) & (TEMP1 | TEMP2 | TEMP3 | TEMP4);

    CMF_BOOL _HLG;
    _HLG = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_HLG, _HLG);
    }

    ////////////////////////////////////
    // OLS
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_OPLKSF) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_OPLKSF) == 2) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_OPLKSF) == 3) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_OPLKSF) == 4) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = GET_TAG_BV(ALS_BV_SH0) & TEMP1;
    TEMP6 = GET_TAG_BV(ALS_BV_SH1) & (TEMP1 | TEMP2);
    TEMP7 = GET_TAG_BV(ALS_BV_SH2) & (TEMP1 | TEMP2 | TEMP3);
    TEMP8 = GET_TAG_BV(ALS_BV_SH3) & (TEMP1 | TEMP2 | TEMP3 | TEMP4);

    CMF_BOOL _OLS;
    _OLS = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_OLS, _OLS);
    }

    ////////////////////////////////////
    // HTP
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_HITRPH1) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_HITRPH2) == 1) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_HITRPH3) == 1) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_HITRPH4) == 1) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = TEMP1 & GET_TAG_BV(ALS_BV_SH0);
    TEMP6 = TEMP2 & GET_TAG_BV(ALS_BV_SH1);
    TEMP7 = TEMP3 & GET_TAG_BV(ALS_BV_SH2);
    TEMP8 = TEMP4 & GET_TAG_BV(ALS_BV_SH3);

    CMF_BOOL _HTP;
    _HTP = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_HTP, _HTP);
    }

    ////////////////////////////////////
    // HTG
    ////////////////////////////////////
    {
    CMF_BOOL  TEMP1, TEMP2, TEMP3, TEMP4;
    TEMP1 = (GET_TAG_LS_UI(ALS_LS_HITRGR1) == 1) ? 1 : 0;
    TEMP2 = (GET_TAG_LS_UI(ALS_LS_HITRGR2) == 1) ? 1 : 0;
    TEMP3 = (GET_TAG_LS_UI(ALS_LS_HITRGR3) == 1) ? 1 : 0;
    TEMP4 = (GET_TAG_LS_UI(ALS_LS_HITRGR4) == 1) ? 1 : 0;

    CMF_BOOL TEMP5, TEMP6, TEMP7, TEMP8;
    TEMP5 = TEMP1 & GET_TAG_BV(ALS_BV_SH0);
    TEMP6 = TEMP2 & GET_TAG_BV(ALS_BV_SH1);
    TEMP7 = TEMP3 & GET_TAG_BV(ALS_BV_SH2);
    TEMP8 = TEMP4 & GET_TAG_BV(ALS_BV_SH3);

    CMF_BOOL _HTG;
    _HTG = TEMP5 | TEMP6 | TEMP7 | TEMP8;

    //set tag data
    SET_TAG_BV(ALS_BV_HTG, _HTG);
    }

}
