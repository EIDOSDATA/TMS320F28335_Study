/*
 * AT_Logic_Trip.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

#define CODE_TCCTRIP 0x01
#define CODE_DEFTRIP 0x02
#define CODE_FCN1 0x04
#define CODE_FCN2 0x08
#define CODE_FCN3 0x10
#define CODE_FCN4 0x20


CMF_VOID AT_Logic_Trip()
{
    CMF_BOOL VITTR = ((GET_TAG_BV(ALS_BV_TR2) | GET_TAG_BV(ALS_BV_TR3) | GET_TAG_BV(ALS_BV_TR4) | GET_TAG_BV(ALS_BV_TR9) | GET_TAG_BV(ALS_BV_TR10)) & GET_TAG_BV(ALS_BV_VITEN));
    CMF_BOOL CPTR = GET_TAG_BV(ALS_BV_81P1T) | GET_TAG_BV(ALS_BV_81P2T) | GET_TAG_BV(ALS_BV_81P3T) | GET_TAG_BV(ALS_BV_27P2T) | GET_TAG_BV(ALS_BV_59P2T) | GET_TAG_BV(ALS_BV_59N1T) | GET_TAG_BV(ALS_BV_32P1T) | GET_TAG_BV(ALS_BV_47P1T) | GET_TAG_BV(ALS_BV_BFT);
    CMF_BOOL TCCTRIP = GET_TAG_BV(ALS_BV_51P1TF) | GET_TAG_BV(ALS_BV_51N1TF) | GET_TAG_BV(ALS_BV_51P1TD) | GET_TAG_BV(ALS_BV_51N1TD);
    CMF_BOOL DEFTRIP = GET_TAG_BV(ALS_BV_50P1T) | GET_TAG_BV(ALS_BV_50N1T) | GET_TAG_BV(ALS_BV_50N6T);

    CMF_BOOL LOCKTRIP;
    CMF_BOOL _ED0OUT;
    CMF_BOOL _ED01OUT;
     SFB_DEF_EDGE_DETR(ED0, EDT_RISING, 0);
     SFB_USE_EDGE_DETR(ED0, GET_TAG_RCM(ALS_RCM_CTRIP), &_ED0OUT);
     /* Push Button -> MMI task will do */
     SFB_DEF_EDGE_DETR(ED01, EDT_RISING, 0);
     SFB_USE_EDGE_DETR(ED01, GET_TAG_MMI(ALS_MMI_PBTR), &_ED01OUT);


     LOCKTRIP = GET_TAG_BV(ALS_BV_CPTR) | _ED01OUT | ( GET_TAG_NVV_UI(ALS_NVV_ENRT) & (_ED0OUT | GET_TAG_DI(ALS_DI_RTRIP)) );


     SET_TAG_BV(ALS_BV_VITTR, VITTR);
     SET_TAG_BV(ALS_BV_CPTR, CPTR);
     SET_TAG_BV(ALS_BV_TCCTRIP, TCCTRIP);
     SET_TAG_BV(ALS_BV_DEFTRIP, DEFTRIP);
     SET_TAG_BV(ALS_BV_LOCKTRIP, LOCKTRIP);

     CMF_BOOL _TEMP1;
     _TEMP1 = GET_TAG_BV(ALS_BV_TCCTRIP) | GET_TAG_BV(ALS_BV_DEFTRIP) | GET_TAG_BV(ALS_BV_VITTR) | GET_TAG_BV(ALS_BV_LOCKTRIP);

     CMF_BOOL TR;
     TR = _TEMP1 & !GET_TAG_DI(ALS_DI_HLOCK);
     SET_TAG_BV(ALS_BV_TR, TR);

     CMF_BOOL _ED1OUT;
     SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0); // need check whether EDT_rising
     SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_TR), &_ED1OUT);

     CMF_BOOL _PD1OUT;
   //  SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC, 0, 0, PDTT_SEC_VAR_F, 0, ALS_SC_TDURD);
     SFB_DEF_PD_TIMER_EX(PD1, N_A, N_A, N_A, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_TDURD)
     SFB_USE_PD_TIMER(PD1, _ED1OUT, NULL, &_PD1OUT);

     CMF_BOOL _PD2OUT;
     CMF_BOOL PD2IN;
     PD2IN = GET_TAG_BV(ALS_BV_TRF);
     SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 10, PDTT_SEC, 0);
     SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_PD2OUT);

     CMF_BOOL _LT1RS;
     SFB_DEF_GBTV(_LT1OUT, CMF_BOOL, CMF_FALSE);
     _LT1RS = !GET_TAG_BV(ALS_BV_52A) | GET_TAG_BV(ALS_BV_TARR) | _PD2OUT;
     _LT1OUT = GET_TAG_BV(ALS_BV_TR) | _PD1OUT | (!_LT1RS & _LT1OUT);

     CMF_BOOL _PD3OUT;
     SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 20, PDTT_CYCLE, 0); //
     SFB_USE_PD_TIMER(PD3, _LT1OUT, NULL, &_PD3OUT);
     SET_TAG_BV(ALS_BV_TRF, _PD3OUT);

     SFB_DEF_GBTV(_PD4OUT, CMF_BOOL, CMF_FALSE);
     CMF_BOOL _PD4IN;
     _PD4IN = _LT1OUT & !_PD4OUT;
     SFB_DEF_PD_TIMER(PD4, PDTT_CYCLE, 7, PDTT_CYCLE, 5);
     SFB_USE_PD_TIMER(PD4, _PD4IN, NULL, &_PD4OUT);

     CMF_BOOL TRIP;
     TRIP = (!GET_TAG_BV(ALS_BV_TRF) & _LT1OUT & !_PD4OUT);
     SET_TAG_BV(ALS_BV_TRIP, TRIP);

     // Set Tag data
     SET_TAG_DO(ALS_DO_TRIP, TRIP);

     ///////////////////////////////
     // Fault Event / Wave Trigger
     ///////////////////////////////
     {
         CMF_BOOL OR0;
         OR0 = GET_TAG_BV(ALS_BV_TCCTRIP) | GET_TAG_BV(ALS_BV_DEFTRIP);

         CMF_BOOL OR1;

         CMF_BOOL ED_FCN1_OUT, ED_FCN2_OUT, ED_FCN3_OUT, ED_FCN4_OUT;
         SFB_DEF_EDGE_DETR(ED_FCN1, EDT_RISING, CMF_FALSE);
         SFB_DEF_EDGE_DETR(ED_FCN2, EDT_RISING, CMF_FALSE);
         SFB_DEF_EDGE_DETR(ED_FCN3, EDT_RISING, CMF_FALSE);
         SFB_DEF_EDGE_DETR(ED_FCN4, EDT_RISING, CMF_FALSE);

         SFB_USE_EDGE_DETR(ED_FCN1, GET_TAG_BV(ALS_BV_FCN1), &ED_FCN1_OUT);
         SFB_USE_EDGE_DETR(ED_FCN2, GET_TAG_BV(ALS_BV_FCN2), &ED_FCN2_OUT);
         SFB_USE_EDGE_DETR(ED_FCN3, GET_TAG_BV(ALS_BV_FCN3), &ED_FCN3_OUT);
         SFB_USE_EDGE_DETR(ED_FCN4, GET_TAG_BV(ALS_BV_FCN4), &ED_FCN4_OUT);

         OR1 = ED_FCN1_OUT | ED_FCN2_OUT | ED_FCN3_OUT | ED_FCN4_OUT;

         // TO BE REMOVED AFTER CHECK
         // change: Removed OR1's edge detector.
         // reason: When FCN1 changes into FCN2 immediately without FCN1 to be 0, it could behave wrongly.

         CMF_BOOL AND0;
         AND0 = (!OR0) & OR1;

         CMF_BOOL EWT = CMF_FALSE;
         SFB_DEF_EDGE_DETR(ED_EWT, EDT_RISING, CMF_FALSE);
         SFB_USE_EDGE_DETR(ED_EWT, OR0 | AND0, &EWT);
         SET_TAG_BV(ALS_BV_EWT, EWT);

         if (EWT) {
             CMF_UINT16 FLT_TYPE = 0;

             FLT_TYPE |=  (GET_TAG_BV(ALS_BV_TCCTRIP) << 0);
             FLT_TYPE |=  (GET_TAG_BV(ALS_BV_DEFTRIP) << 1);

             if(!FLT_TYPE){
                 FLT_TYPE = GET_TAG_BV(ALS_BV_FCN1) ? CODE_FCN1 : CMF_FALSE;
                 FLT_TYPE = GET_TAG_BV(ALS_BV_FCN2) ? CODE_FCN2 : FLT_TYPE;
                 FLT_TYPE = GET_TAG_BV(ALS_BV_FCN3) ? CODE_FCN3 : FLT_TYPE;
                 FLT_TYPE = GET_TAG_BV(ALS_BV_FCN4) ? CODE_FCN4 : FLT_TYPE;
             }

             //SFB_DEF_EVM(EVM0);   //  Kyejeong
             if (OR0) {
                 SFB_USE_EVM_PUSH_FLTEV_EX(FLT_TYPE, /*0,*/
                                           GET_TAG_AI_F(ALS_AI_RMS_VA),
                                           GET_TAG_AI_F(ALS_AI_RMS_VB),
                                           GET_TAG_AI_F(ALS_AI_RMS_VC),
                                           GET_TAG_AI_F(ALS_AI_RMS_IA),
                                           GET_TAG_AI_F(ALS_AI_RMS_IB),
                                           GET_TAG_AI_F(ALS_AI_RMS_IC),
                                           GET_TAG_AI_F(ALS_AI_RMS_IN));
             }
             else {
                 SFB_USE_EVM_PUSH_FLTEV_EX(FLT_TYPE, /*0,*/
                                           GET_TAG_NMV_F(ALS_NMV_VA_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_VB_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_VC_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_IA_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_IB_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_IC_MAX),
                                           GET_TAG_NMV_F(ALS_NMV_IN_MAX));
             }

             SFB_USE_EVM_PUSH_FLTWVEV_EX(EVM0, FLT_TYPE, GET_TAG_SC_UCFG_UI(ALS_SC_TRIG_WAVE));
         }
     }
}
