/*
 * AT_Logic_DriveToLockout.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_DriveToLockout()
{
    ////////////////////////////////////
    // Drive to Lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1, _OR2, _OR3, _OR4, _OR5, _OR6, _OR7, _OR8, _OR9;
        CMF_BOOL _AND1, _AND2, _AND3, _AND4, _AND5, _AND6, _AND7, _AND8, _AND_OLS, _AND9, _AND10, _AND11, _ED1OUT;
        CMF_BOOL _SV13, _SV15, _SV16, _79DTL, _OLG, _51P1, _OLP;
        CMF_UINT16 _GTP;

        // Process phase
        _OR1 = GET_TAG_BV(ALS_BV_51P1TF) | GET_TAG_BV(ALS_BV_51P1TD) | GET_TAG_BV(ALS_BV_51N1TF) | GET_TAG_BV(ALS_BV_51N1TD) | GET_TAG_BV(ALS_BV_50P1T) | GET_TAG_BV(ALS_BV_50N1T);
        _SV13 = _OR1;

        _OR2 = GET_TAG_BV(ALS_BV_51N1) | GET_TAG_BV(ALS_BV_51N1F) | GET_TAG_BV(ALS_BV_51N1D);

        _GTP = GET_TAG_LS_UI(ALS_LS_GTP);
        _OLG = GET_TAG_BV(ALS_BV_OLG);
        _51P1 = GET_TAG_BV(ALS_BV_51P1);
        _OLP = GET_TAG_BV(ALS_BV_OLP);

        _AND1 = _GTP & _OR2 & _OLG;
        _AND2 = _OLG & _OR2 & !_GTP & !_51P1;
        _AND3 = !_OR2 & _GTP & _51P1 & _OLP;
        _AND4 = _OLP & _51P1 & !_GTP;

        _AND5 = _OLG & _OLP;

        _OR3 = _AND1 | _AND2 | _AND3 | _AND4;

        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _SV13, &_ED1OUT);
        _AND6 = _OR3 & _ED1OUT;
        _SV15 = _AND6;

        _AND7 = _SV13 & _AND5;

        _OR4 = _SV15 | _AND7;
        _SV16 = _OR4;

        _AND8 = GET_TAG_BV(ALS_BV_VITEN) & GET_TAG_BV(ALS_BV_V79LO);
        _OR5 = GET_TAG_DI(ALS_DI_HLOCK) | _AND8;

        _AND_OLS = GET_TAG_BV(ALS_BV_50N6T) & GET_TAG_BV(ALS_BV_OLS);
        _AND9 = GET_TAG_BV(ALS_BV_50P1T) & GET_TAG_BV(ALS_BV_HLP);
        _AND10 = GET_TAG_BV(ALS_BV_50N1T) & GET_TAG_BV(ALS_BV_HLG);
        _OR6 = _AND_OLS | _AND9 | _AND10;

        _OR7 = GET_TAG_BV(ALS_BV_TRIP) | !GET_TAG_BV(ALS_BV_52A);
        _AND11 = _OR7 & !GET_TAG_NVV_UI(ALS_NVV_ENRC) & !GET_TAG_BV(ALS_BV_VITEN);

        _OR8 = GET_TAG_BV(ALS_BV_LOCKTRIP) | !GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT);

        _OR9 = _OR5 | _OR6 | _AND11 | _OR8 | _SV16;
        _79DTL = _OR9;

        // Set tag phase
        SET_TAG_BV(ALS_BV_SV13, _SV13);
        SET_TAG_BV(ALS_BV_SV15, _SV15);
        SET_TAG_BV(ALS_BV_SV16, _SV16);
        SET_TAG_BV(ALS_BV_79DTL, _79DTL);
    }
}
