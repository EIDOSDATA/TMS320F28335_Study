/*
 * AT_Logic_Pickup.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_Pickup() {
    // Minimum Pickup Current - Phase, Ground
       {
           CMF_BOOL _51P1A, _51P1B, _51P1C;
           _51P1A = ( GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_51P1P)) ) ? 1 : 0;
           _51P1B = ( GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_51P1P)) ) ? 1 : 0;
           _51P1C = ( GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_51P1P)) ) ? 1 : 0;

           CMF_BOOL _51P1;
           _51P1 = (_51P1A | _51P1B | _51P1C);

           SET_TAG_BV(ALS_BV_51P1A, _51P1A);
           SET_TAG_BV(ALS_BV_51P1B, _51P1B);
           SET_TAG_BV(ALS_BV_51P1C, _51P1C);

           CMF_BOOL _51N1;
           _51N1 = ( GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_51N1P)) ) ? 1 : 0;

           CMF_BOOL _50P1A, _50P1B, _50P1C;
           _50P1A = ( GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_50P1P)) ) ? 1 : 0;
           _50P1B = ( GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_50P1P)) ) ? 1 : 0;
           _50P1C = ( GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_50P1P)) ) ? 1 : 0;

           CMF_BOOL _50P1;
           _50P1 = (_50P1A | _50P1B | _50P1C);

           SET_TAG_BV(ALS_BV_50P1A, _50P1A);
           SET_TAG_BV(ALS_BV_50P1B, _50P1B);
           SET_TAG_BV(ALS_BV_50P1C, _50P1C);

           CMF_BOOL _50N1;
           _50N1 = ( GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(GET_TAG_LS_UI(ALS_LS_50N1P)) ) ? 1 : 0;

           SET_TAG_BV(ALS_BV_51P1, _51P1);
           SET_TAG_BV(ALS_BV_51N1, _51N1);
           SET_TAG_BV(ALS_BV_50P1, _50P1);
           SET_TAG_BV(ALS_BV_50N1, _50N1);
       }

       // Pickup Multiplier for Inrush Restraint - Phase, Ground
       {
           CMF_UINT _51P3P;
           _51P3P = (GET_TAG_LS_UI(ALS_LS_51P1P)) * (GET_TAG_LS_UI(ALS_LS_51P3M));
           CMF_BOOL _COMP1, _COMP2, _COMP3;
           _COMP1 = ( GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(_51P3P)) ? 1 : 0;
           _COMP2 = ( GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(_51P3P)) ? 1 : 0;
           _COMP3 = ( GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(_51P3P)) ? 1 : 0;
           CMF_BOOL _51P3;
           _51P3 = (_COMP1 | _COMP2 | _COMP3) & !( ((GET_TAG_LS_UI(ALS_LS_51P3M)) == 0) ? 1 : 0);

           CMF_UINT _51N3P;
           _51N3P = (GET_TAG_LS_UI(ALS_LS_51N1P)) * (GET_TAG_LS_UI(ALS_LS_51N3M));
           CMF_BOOL _COMP4;
           _COMP4 = ( GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(_51N3P)) ? 1 : 0;
           CMF_BOOL _51N3;
           _51N3 = _COMP4 & !(((GET_TAG_LS_UI(ALS_LS_51N3M)) == 0) ? 1 : 0);

           CMF_BOOL _COMP5, _COMP6, _COMP7;
           CMF_UINT _50P3P;
           _50P3P = (GET_TAG_LS_UI(ALS_LS_50P1P)) * GET_TAG_LS_UI(ALS_LS_50P3M);
           _COMP5 = (GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(_50P3P)) ? 1 : 0;
           _COMP6 = (GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(_50P3P)) ? 1 : 0;
           _COMP7 = (GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(_50P3P)) ? 1 : 0;

           CMF_BOOL _50P3;
           _50P3 = (_COMP5 | _COMP6 | _COMP7) & !((GET_TAG_LS_UI(ALS_LS_50P3M) == 0) ? 1 : 0);

           CMF_BOOL _COMP8;
           CMF_UINT _50N3P;
           _50N3P = (GET_TAG_LS_UI(ALS_LS_50N1P)) * (GET_TAG_LS_UI(ALS_LS_50N3M));
           _COMP8 = (GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(_50N3P)) ? 1 : 0;
           CMF_BOOL _50N3;
           _50N3 = _COMP8 & !((GET_TAG_LS_UI(ALS_LS_50N3M) == 0) ? 1 : 0);

           SET_TAG_BV(ALS_BV_51P3, _51P3);
           SET_TAG_BV(ALS_BV_51N3, _51N3);
           SET_TAG_BV(ALS_BV_50P3, _50P3);
           SET_TAG_BV(ALS_BV_50N3, _50N3);
       }

       // Pickup Multiplier for Cold Load Pickup - Phase, Ground
       {
           CMF_BOOL _COMP9, _COMP10, _COMP11;
           CMF_UINT _51P4P;
           _51P4P = (GET_TAG_LS_UI(ALS_LS_51P1P)) * (GET_TAG_LS_UI(ALS_LS_51P4M));
           _COMP9 = (GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(_51P4P)) ? 1 : 0;
           _COMP10 = (GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(_51P4P)) ? 1 : 0;
           _COMP11 = (GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(_51P4P)) ? 1 : 0;
           CMF_BOOL _51P4;
           _51P4 = (_COMP9 | _COMP10 | _COMP11) & !(((GET_TAG_LS_UI(ALS_LS_51P4M)) == 0) ? 1 : 0);

           CMF_BOOL _COMP12;
           CMF_UINT _51N4P;
           _51N4P  = (GET_TAG_LS_UI(ALS_LS_51N1P) * GET_TAG_LS_UI(ALS_LS_51N4M) );
           _COMP12 = (GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(_51N4P)) ? 1 : 0;
           CMF_BOOL _51N4;
           _51N4 = _COMP12 & (!(GET_TAG_LS_UI(ALS_LS_51N4M) == 0) ? 1 : 0);

           CMF_BOOL _COMP13, _COMP14, _COMP15;
           CMF_UINT _50P4P;
           _50P4P = GET_TAG_LS_UI(ALS_LS_50P1P) * GET_TAG_LS_UI(ALS_LS_50P4M);
           _COMP13 = (GET_TAG_AI_F(ALS_AI_RMS_IA) > (CMF_FLOAT32)(_50P4P)) ? 1 : 0;
           _COMP14 = (GET_TAG_AI_F(ALS_AI_RMS_IB) > (CMF_FLOAT32)(_50P4P)) ? 1 : 0;
           _COMP15 = (GET_TAG_AI_F(ALS_AI_RMS_IC) > (CMF_FLOAT32)(_50P4P)) ? 1 : 0;
           CMF_BOOL _50P4;
           _50P4 = (_COMP13 | _COMP14 | _COMP15) & !((GET_TAG_LS_UI(ALS_LS_50P4M) == 0) ? 1 : 0);

           CMF_BOOL _COMP16;
           CMF_UINT _50N4P;
           _50N4P = GET_TAG_LS_UI(ALS_LS_50N1P) * GET_TAG_LS_UI(ALS_LS_50N4M);
           _COMP16 = (GET_TAG_AI_F(ALS_AI_RMS_IN) > (CMF_FLOAT32)(_50N4P)) ? 1 : 0;
           CMF_BOOL _50N4;
           _50N4 = _COMP16 & !((GET_TAG_LS_UI(ALS_LS_50N4M) == 0) ? 1 : 0);

           SET_TAG_BV(ALS_BV_51P4, _51P4);
           SET_TAG_BV(ALS_BV_51N4, _51N4);
           SET_TAG_BV(ALS_BV_50P4, _50P4);
           SET_TAG_BV(ALS_BV_50N4, _50N4);
       }
}
