/*
 * AT_Logic_DGProtection.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_DGProtection()
{
    ////////////////////////////////////
    // Under Frequency Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL PD1IN, PD1OUT, PD2IN, PD2OUT, PD3IN, PD3OUT, PD4IN;
        CMF_BOOL temp1;
        CMF_BOOL _81P1T;

        // Process phase
        PD1IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P1P) > GET_TAG_AI_F(ALS_AI_FREQ_VA)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59A1);
        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &PD1OUT);

        PD2IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P1P) > GET_TAG_AI_F(ALS_AI_FREQ_VB)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59B1);
        SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &PD2OUT);

        PD3IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P1P) > GET_TAG_AI_F(ALS_AI_FREQ_VC)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59C1);
        SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &PD3OUT);

        temp1 = PD1OUT | PD2OUT | PD3OUT;

        PD4IN =  temp1 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_3P27P1AND) & !((GET_TAG_SC_UCFG_F(ALS_SC_81P1P) == 0) ? 1 : 0);
   //     SFB_DEF_PD_TIMER_EX(PD4, PDTT_SEC_VAR_F, 0, ALS_SC_81P1D, PDTT_SEC, 0 , 0);
        SFB_DEF_PD_TIMER_EX(PD4, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_81P1D, N_A, N_A, N_A);
        SFB_USE_PD_TIMER(PD4, PD4IN, NULL, &_81P1T);

        // Set tag phase
        SET_TAG_BV(ALS_BV_81P1T, _81P1T);
    }

    ////////////////////////////////////
    // Over Frequency Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL PD5IN, PD5OUT, PD6IN, PD6OUT, PD7IN, PD7OUT, PD8IN;
        CMF_BOOL _81P2T;
        CMF_BOOL temp2;

        // Process phase
        PD5IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P2P) < GET_TAG_AI_F(ALS_AI_FREQ_VA)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59A1);
        SFB_DEF_PD_TIMER(PD5, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD5, PD5IN, NULL, &PD5OUT);

        PD6IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P2P) < GET_TAG_AI_F(ALS_AI_FREQ_VB)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59B1);
        SFB_DEF_PD_TIMER(PD6, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD6, PD6IN, NULL, &PD6OUT);

        PD7IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P2P) < GET_TAG_AI_F(ALS_AI_FREQ_VC)) ? 1 : 0) & GET_TAG_BV(ALS_BV_59C1);
        SFB_DEF_PD_TIMER(PD7, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD7, PD7IN, NULL, &PD7OUT);

        temp2 = PD5OUT | PD6OUT | PD7OUT;

        PD8IN =  temp2 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_3P27P1AND) & !(( GET_TAG_SC_UCFG_F(ALS_SC_81P2P) == 0 ) ? 1: 0);
    //    SFB_DEF_PD_TIMER_EX(PD8, PDTT_SEC_VAR_F, 0, ALS_SC_81P2D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD8, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_81P2D, N_A, N_A, N_A);
        SFB_USE_PD_TIMER(PD8, PD8IN, NULL, &_81P2T);

        // Set tag phase
        SET_TAG_BV(ALS_BV_81P2T, _81P2T);
    }

    ////////////////////////////////////
    // Under Voltage Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 RT1IN, RT1OUT, _27P2P;
        CMF_BOOL PDUV1IN, PDUV1OUT, PDUV2IN, PDUV2OUT, PDUV3IN, PDUV3OUT, PDUV4IN;
        CMF_BOOL temp3;
        CMF_BOOL _27P2T;

        // Process phase
        RT1IN = 3.0;
        SFB_DEF_SQRT_F(RT1);
        SFB_USE_SQRT_F(RT1, RT1IN, &RT1OUT);

        _27P2P = ((CMF_FLOAT32)GET_TAG_SC_UCFG_UI(ALS_SC_27P2P0))/100.0 * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;

        PDUV1IN =  (_27P2P > GET_TAG_AI_F(ALS_AI_RMS_VA))? 1 : 0;
        SFB_DEF_PD_TIMER(PDUV1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDUV1, PDUV1IN, NULL, &PDUV1OUT);

        PDUV2IN =  (_27P2P > GET_TAG_AI_F(ALS_AI_RMS_VB)) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDUV2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDUV2, PDUV2IN, NULL, &PDUV2OUT);

        PDUV3IN =  (_27P2P > GET_TAG_AI_F(ALS_AI_RMS_VC)) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDUV3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDUV3, PDUV3IN, NULL, &PDUV3OUT);

        temp3 = PDUV1OUT | PDUV2OUT | PDUV3OUT;

        PDUV4IN =  temp3 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_3P27P1AND) & !((GET_TAG_SC_UCFG_UI(ALS_SC_27P2P0) == 0 ) ? 1 : 0);
   //     SFB_DEF_PD_TIMER_EX(PDUV4, PDTT_SEC_VAR_F, 0, ALS_SC_27P2D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PDUV4, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_27P2D, N_A, N_A, N_A);
        SFB_USE_PD_TIMER(PDUV4, PDUV4IN, NULL, &_27P2T);

        // Set tag phase
        SET_TAG_NMV_F(ALS_NMV_27P2P, _27P2P);
        SET_TAG_BV(ALS_BV_27P2T, _27P2T);
    }

    ////////////////////////////////////
    // Over Voltage Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 RT1IN, RT1OUT, _59P2P;
        CMF_BOOL PDOV1IN, PDOV1OUT, PDOV2IN, PDOV2OUT, PDOV3IN, PDOV3OUT, PDOV4IN;
        CMF_BOOL _59P2T;
        CMF_BOOL temp4;

        // Process phase
        RT1IN = 3.0;
        SFB_DEF_SQRT_F(RT1);
        SFB_USE_SQRT_F(RT1, RT1IN, &RT1OUT);

        _59P2P = ((CMF_FLOAT32)GET_TAG_SC_UCFG_UI(ALS_SC_59P2P0))/100.0 * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;

        PDOV1IN =  (_59P2P < GET_TAG_AI_F(ALS_AI_RMS_VA)) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDOV1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDOV1, PDOV1IN, NULL, &PDOV1OUT);

        PDOV2IN =  (_59P2P < GET_TAG_AI_F(ALS_AI_RMS_VB)) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDOV2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDOV2, PDOV2IN, NULL, &PDOV2OUT);

        PDOV3IN =  (_59P2P < GET_TAG_AI_F(ALS_AI_RMS_VC)) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDOV3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDOV3, PDOV3IN, NULL, &PDOV3OUT);

        temp4 = PDOV1OUT | PDOV2OUT | PDOV3OUT;

        PDOV4IN =  temp4 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !(( GET_TAG_SC_UCFG_UI(ALS_SC_59P2P0) == 0 ) ? 1 : 0);
    //    SFB_DEF_PD_TIMER_EX(PDOV4, PDTT_SEC_VAR_F, 0, ALS_SC_59P2D, PDTT_SEC , 0, 0)
        SFB_DEF_PD_TIMER_EX(PDOV4, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_59P2D, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PDOV4, PDOV4IN, NULL, &_59P2T);

        // Set tag phase
        SET_TAG_NMV_F(ALS_NMV_59P2P, _59P2P);
        SET_TAG_BV(ALS_BV_59P2T, _59P2T);
    }

    ////////////////////////////////////
    // df / dt Protection
    ////////////////////////////////////
    {
        CMF_BOOL PDD1IN;
        CMF_BOOL PDD1OUT;
        CMF_FLOAT32 TEMP1;
        TEMP1 = GET_TAG_AI_F(ALS_AI_FREQ_P_VA) - GET_TAG_AI_F(ALS_AI_FREQ_VA);
        if(TEMP1 < 0.0){
           TEMP1 *= -1.0;
        }

        PDD1IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P3P) < TEMP1) ? 1: 0 ) & GET_TAG_BV(ALS_BV_59A1);
        SFB_DEF_PD_TIMER(PDD1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDD1, PDD1IN, NULL, &PDD1OUT);
        CMF_BOOL PDD2IN;
        CMF_BOOL PDD2OUT;
        CMF_FLOAT32 TEMP2;
        TEMP2 = GET_TAG_AI_F(ALS_AI_FREQ_P_VB) - GET_TAG_AI_F(ALS_AI_FREQ_VB);
        if(TEMP2 < 0.0){
           TEMP2 *= -1.0;
        }

        PDD2IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P3P) < TEMP2) ? 1: 0 ) & GET_TAG_BV(ALS_BV_59B1);
        SFB_DEF_PD_TIMER(PDD2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDD2, PDD2IN, NULL, &PDD2OUT);
        CMF_BOOL PDD3IN;
        CMF_BOOL PDD3OUT;
        CMF_FLOAT32 TEMP3;
        TEMP3 = GET_TAG_AI_F(ALS_AI_FREQ_P_VC) - GET_TAG_AI_F(ALS_AI_FREQ_VC);
        if(TEMP3 < 0.0){
           TEMP3 *= -1.0;
        }

        PDD3IN = ((GET_TAG_SC_UCFG_F(ALS_SC_81P3P) < TEMP3) ? 1: 0 ) & GET_TAG_BV(ALS_BV_59C1);
        SFB_DEF_PD_TIMER(PDD3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDD3, PDD3IN, NULL, &PDD3OUT);
        CMF_BOOL temp5 = PDD1OUT | PDD2OUT | PDD3OUT;
        CMF_BOOL PDD4IN;
        CMF_BOOL _81P3T;
        PDD4IN = temp5 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !(( GET_TAG_SC_UCFG_F(ALS_SC_81P3P) == 0 ) ? 1 : 0);
    //    SFB_DEF_PD_TIMER_EX(PDD4, PDTT_SEC_VAR_F, 0, ALS_SC_81P3D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PDD4, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_81P3D, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PDD4, PDD4IN, NULL, &_81P3T);

        //Set Tag Phase
        SET_TAG_BV(ALS_BV_81P3T, _81P3T);
    }

    ////////////////////////////////////
    // Neutral Voltage Displacement
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 RT1IN, RT1OUT, _59N1P;
        CMF_BOOL PDNV1IN, PDNV1OUT, PDNV2IN;
        CMF_BOOL _59N1T;

        // Process phase
        RT1IN = 3.0;
        SFB_DEF_SQRT_F(RT1);
        SFB_USE_SQRT_F(RT1, RT1IN, &RT1OUT);

        _59N1P = ((CMF_FLOAT32)GET_TAG_SC_UCFG_UI(ALS_SC_59N1P0))/100.0 * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;

        PDNV1IN = (GET_TAG_AI_F(ALS_AI_RMS_V0) > _59N1P) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDNV1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDNV1, PDNV1IN, NULL, &PDNV1OUT);

        PDNV2IN = PDNV1OUT & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !(( GET_TAG_SC_UCFG_UI(ALS_SC_59N1P0) == 0 ) ? 1 : 0);
    //    SFB_DEF_PD_TIMER_EX(PDNV2, PDTT_SEC_VAR_F, 0, ALS_SC_59N1D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PDNV2, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_59N1D, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PDNV2, PDNV2IN, NULL, &_59N1T);

        // Set tag phase
        SET_TAG_NMV_F(ALS_NMV_59N1P,_59N1P);
        SET_TAG_BV(ALS_BV_59N1T, _59N1T);
    }

    ////////////////////////////////////
    // Unbalance Voltage Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL PDUB1IN, PDUB1OUT, PDUB2IN;
        CMF_BOOL _47P1T;

        // Process phase
        if (GET_TAG_AI_F(ALS_AI_RMS_V1) != 0.0)
        {
            PDUB1IN = (GET_TAG_SC_UCFG_UI(ALS_SC_47P1P) / 100.0 < GET_TAG_AI_F(ALS_AI_RMS_V0) / GET_TAG_AI_F(ALS_AI_RMS_V1)) ? 1: 0;
        }
        else
        {
            PDUB1IN = (GET_TAG_SC_UCFG_UI(ALS_SC_47P1P) / 100.0 < GET_TAG_AI_F(ALS_AI_RMS_V0) / 0.001) ? 1: 0;
        }

        SFB_DEF_PD_TIMER(PDUB1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDUB1, PDUB1IN, NULL, &PDUB1OUT);

        PDUB2IN = PDUB1OUT & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_3P27P1AND) & !(( GET_TAG_SC_UCFG_UI(ALS_SC_47P1P) == 0 ) ? 1 : 0);
    //    SFB_DEF_PD_TIMER_EX(PDUB2, PDTT_SEC_VAR_UI, 0 ,ALS_SC_47P1D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PDUB2, PDTT_TAG, TAG_GRP_SC_UI, ALS_SC_47P1D, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PDUB2, PDUB2IN, NULL, &_47P1T);

        // Set tag phase
        SET_TAG_BV(ALS_BV_47P1T, _47P1T);
    }

    ////////////////////////////////////
    // Reverse Power Protection
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 _APR;
        CMF_BOOL PDRP1IN;
        CMF_BOOL PDRP1OUT;
        CMF_BOOL PDRP2IN;
        CMF_BOOL _32P1T;

        // Process phase
        _APR = 100.0 * (GET_TAG_AI_F(ALS_AI_ACTIVE_A) + GET_TAG_AI_F(ALS_AI_ACTIVE_B) + GET_TAG_AI_F(ALS_AI_ACTIVE_C)) / GET_TAG_SC_UCFG_F(ALS_SC_GCAP);

        PDRP1IN =  (GET_TAG_SC_UCFG_F(ALS_SC_32P1P) * -1.0 > _APR) ? 1 : 0;
        SFB_DEF_PD_TIMER(PDRP1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PDRP1, PDRP1IN, NULL, &PDRP1OUT);

        PDRP2IN = PDRP1OUT & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_52A) & !(( GET_TAG_SC_UCFG_F(ALS_SC_32P1P) == 0 ) ? 1: 0);
     //   SFB_DEF_PD_TIMER_EX(PDRP2, PDTT_SEC_VAR_F, 0, ALS_SC_32P1D, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PDRP2, PDTT_TAG, TAG_GRP_SC_F, ALS_SC_32P1D, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PDRP2, PDRP2IN, NULL, &_32P1T);

        // Set tag phase
        SET_TAG_BV(ALS_BV_32P1T, _32P1T);
        SET_TAG_NMV_F(ALS_NMV_APR,_APR);
    }

}
