/*
 * AT_Logic_OpenConductor.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_OpenConductor()
{
    //Source Side
    {
        CMF_BOOL _CP1OUT, _CP2OUT, _CP3OUT, _CP4OUT;
        CMF_BOOL _OR1, _OR2, _OR3;
        CMF_BOOL _AND1, _AND2, _AND3, _AND4;
        CMF_BOOL _PD1OUT, _PD2OUT;
        CMF_FLOAT32 UNBCR_tmp_f = (CMF_FLOAT32)GET_TAG_SC_UCFG_UI(ALS_SC_UNBCR);
        if (GET_TAG_AI_F(ALS_AI_RMS_I1) != 0)
        {
            _CP1OUT = (GET_TAG_AI_F(ALS_AI_RMS_I2)/GET_TAG_AI_F(ALS_AI_RMS_I1) > UNBCR_tmp_f*0.01) ? 1 : 0;
            _CP2OUT = (GET_TAG_AI_F(ALS_AI_RMS_I2)/GET_TAG_AI_F(ALS_AI_RMS_I1) < UNBCR_tmp_f*0.009) ? 1 : 0;
        }
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        _OR1 = GBTV1 | _CP1OUT;
        _AND1 = _OR1 & !_CP2OUT;
        GBTV1 = _AND1;
        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 1.5, PDTT_CYCLE, 0.0);
        SFB_USE_PD_TIMER(PD1, _AND1, NULL, &_PD1OUT);
        _AND2 = _PD1OUT & !GET_TAG_SC_UCFG_UI(ALS_SC_ENDELTAI2_I1);
        if (GET_TAG_AI_F(ALS_AI_RMS_I1) !=0.0)
        {
            _CP3OUT = ((GET_TAG_AI_F(ALS_AI_RMS_I2)/GET_TAG_AI_F(ALS_AI_RMS_I1) - GET_TAG_NMV_F(ALS_NMV_BGI2_I1)) > UNBCR_tmp_f*0.01) ? 1 : 0;
            _CP4OUT = ((GET_TAG_AI_F(ALS_AI_RMS_I2)/GET_TAG_AI_F(ALS_AI_RMS_I1) - GET_TAG_NMV_F(ALS_NMV_BGI2_I1)) < UNBCR_tmp_f*0.009) ? 1 : 0;
        }
        else
        {
            _CP3OUT = ((GET_TAG_AI_F(ALS_AI_RMS_I2)*1000.0 - GET_TAG_NMV_F(ALS_NMV_BGI2_I1)) > UNBCR_tmp_f*0.01) ? 1 : 0;
            _CP4OUT = ((GET_TAG_AI_F(ALS_AI_RMS_I2)*1000.0 - GET_TAG_NMV_F(ALS_NMV_BGI2_I1)) < UNBCR_tmp_f*0.009) ? 1 : 0;
        }
        SFB_DEF_GBTV(GBTV2, CMF_BOOL, CMF_FALSE);
        _OR2 = GBTV2 | _CP3OUT;
        _AND3 = _OR2 & !_CP4OUT;
        GBTV2 = _AND3;
        SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 1.5, PDTT_CYCLE, 0.0);
        SFB_USE_PD_TIMER(PD2, _AND3, NULL, &_PD2OUT);
        _AND4 = _PD2OUT & GET_TAG_SC_UCFG_UI(ALS_SC_ENDELTAI2_I1);
        _OR3 = _AND2 | _AND4;
        //power on initial value
        CMF_BOOL _AND5, _AND6, _AND7, _AND8;
        _AND5 = GET_TAG_SC_UCFG_UI(ALS_SC_ENOC) & GET_TAG_BV(ALS_BV_VAND) & GET_TAG_BV(ALS_BV_50L) & !GET_TAG_BV(ALS_BV_FPU);
        //// The Condition
        _AND6 = !GET_TAG_BV(ALS_BV_UNBC) & GET_TAG_SC_UCFG_UI(ALS_SC_ENDELTAI2_I1) & _AND5;
        // if the condition is met
        SFB_DEF_HV_F(HV_F1, 48, 0.1); // 4 per 1cycle. 48 is for 12 cycles, initial value is 0.1
        CMF_FLOAT32 _BGI2_I1;

        SFB_USE_HV_GET_PREV_F(HV_F1, &_BGI2_I1, 40); // 4 per 1cycle. 40 is for 10 cycles

        if (_AND6) {
            if (GET_TAG_AI_F(ALS_AI_RMS_I1) != 0.0)
            {
                _BGI2_I1 = _BGI2_I1 * 0.997 + GET_TAG_AI_F(ALS_AI_RMS_I2)/GET_TAG_AI_F(ALS_AI_RMS_I1) * 0.003;
                SFB_USE_HV_PUSH_F(HV_F1, _BGI2_I1);
            }
            else
            {
                _BGI2_I1 = _BGI2_I1 * 0.997 + GET_TAG_AI_F(ALS_AI_RMS_I2)*3.0;
                    SFB_USE_HV_PUSH_F(HV_F1, _BGI2_I1);
            }
        }
        SET_TAG_NMV_F(ALS_NMV_BGI2_I1, _BGI2_I1);
        /////
        _AND7 = _AND5 & _OR3;
        SET_TAG_BV(ALS_BV_UNBC, _AND7);
        _AND8 = _AND7 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT);
        CMF_BOOL _PD3OUT;
//        CMF_BOOL PD3RS;
//        PD3RS = GET_TAG_BV(ALS_BV_TR9);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_SC_UI, ALS_SC_UNBCD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, _AND8, NULL, &_PD3OUT);
        CMF_BOOL _BUF;
        _BUF = _PD3OUT;
        // Set tag phase
        SET_TAG_BV(ALS_BV_TR9, _PD3OUT);
        SET_TAG_BV(ALS_BV_DTL15, _BUF);
    }

    //Load Side
    {
        CMF_BOOL _CP1OUT, _CP2OUT;
        CMF_BOOL _OR1;
        CMF_BOOL _PD1OUT;
        CMF_BOOL _AND1, _AND2;
        CMF_FLOAT32 UNBVR_tmp_f = (CMF_FLOAT32)GET_TAG_SC_UCFG_UI(ALS_SC_UNBVR);
        if (GET_TAG_AI_F(ALS_AI_RMS_V1) != 0.0)
        {
            _CP1OUT = (GET_TAG_AI_F(ALS_AI_RMS_V0) / GET_TAG_AI_F(ALS_AI_RMS_V1)) > (UNBVR_tmp_f * 0.01) ? 1 : 0;
        }
        else
        {
            _CP1OUT = (GET_TAG_AI_F(ALS_AI_RMS_V0) * 1000.0) > (UNBVR_tmp_f * 0.01) ? 1 : 0;
        }

        if (GET_TAG_AI_F(ALS_AI_RMS_VR1) != 0.0)
        {
            _CP2OUT = (GET_TAG_AI_F(ALS_AI_RMS_VR0) / GET_TAG_AI_F(ALS_AI_RMS_VR1)) > (UNBVR_tmp_f * 0.01) ? 1 : 0;
        }
        else
        {
            _CP2OUT = (GET_TAG_AI_F(ALS_AI_RMS_VR0) * 1000.0) > (UNBVR_tmp_f * 0.01) ? 1 : 0;
        }
        _OR1 = _CP1OUT | _CP2OUT;
        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 1.5, PDTT_CYCLE, 0.0);
        SFB_USE_PD_TIMER(PD1, _OR1, NULL, &_PD1OUT);
        //SET UNBV
        _AND1 = GET_TAG_SC_UCFG_UI(ALS_SC_ENOC) &GET_TAG_BV(ALS_BV_VAND) &_PD1OUT & !GET_TAG_BV(ALS_BV_FPU);
        SET_TAG_BV(ALS_BV_UNBV, _AND1);
        _AND2 = _AND1 & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT);

        CMF_BOOL _OR2;
        CMF_BOOL _NOT;
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(GBTV2, CMF_BOOL, CMF_FALSE);
        _OR2 = GBTV1 | GBTV2;
        _NOT = !GET_TAG_BV(ALS_BV_UNBV);
        GBTV1 = _OR2 & !_NOT;
        CMF_BOOL _AND4;
        _AND4 = _AND2 & !GBTV1;

        CMF_BOOL _PD2OUT;
        CMF_FLOAT32 UVD_PD_Timer, temp_f_;
        temp_f_ = (CMF_FLOAT32) GET_TAG_SC_UCFG_UI(ALS_SC_UNBCD);
        UVD_PD_Timer = temp_f_ + 1.5;
        SET_TAG_NMV_F(ALS_NMV_UVD, UVD_PD_Timer);
    //    SFB_DEF_PD_TIMER_EX(PD2, PDTT_SEC_VAR_F, 0, ALS_NMV_UVD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD2, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_UVD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD2, _AND4, NULL, &_PD2OUT);

        //SET UNBVDO
        CMF_BOOL _PD3OUT;
    //    SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_UI, 0, ALS_SC_UNBVD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_SC_UI, ALS_SC_UNBVD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, _AND2, NULL, &_PD3OUT);
        SET_TAG_BV(ALS_BV_UNBVDO, _PD3OUT);
        CMF_BOOL _AND5;
        CMF_BOOL _OR3, _OR4;
        _AND5 = _PD3OUT & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_79LO);
        SFB_DEF_GBTV(GBTV3, CMF_BOOL, CMF_FALSE);
        _OR3 = GBTV3 | _AND5;
        _OR4 = GET_TAG_BV(ALS_BV_DTL16) | GET_TAG_BV(ALS_BV_DTL19) | !GET_TAG_BV(ALS_BV_52A);
        GBTV3 = _OR3 & !_OR4;
        //SET UNBVTR
        SET_TAG_BV(ALS_BV_UNBVTR, GBTV3);

        CMF_BOOL _OR5, _OR6;
        SFB_DEF_GBTV(GBTV4, CMF_BOOL, CMF_FALSE);
        _OR5 = _PD2OUT | GBTV4;
        _OR6 = GET_TAG_BV(ALS_BV_DTL16) | GET_TAG_BV(ALS_BV_DTL19) | GET_TAG_BV(ALS_BV_DTL27) | GET_TAG_BV(ALS_BV_79NCRS) | GET_TAG_BV(ALS_BV_79NORS) | GBTV2;
        GBTV4 = _OR5 & !_OR6;
        SFB_DEF_PD_TIMER(PD4, PDTT_SEC, 1, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD4, GBTV4, NULL, &GBTV2);

        CMF_BOOL _OR8;
        CMF_BOOL _ED1OUT;
        CMF_BOOL _AND8;
        _OR8 = GBTV4 | GET_TAG_BV(ALS_BV_UNBVDO);
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_VEXOR), &_ED1OUT);
        _AND8 = _OR8 & GET_TAG_BV(ALS_BV_OP40) & _ED1OUT;
        SET_TAG_BV(ALS_BV_DTL27, _AND8);

        CMF_BOOL _AND9, _AND10, _AND11, _AND12;
        CMF_BOOL _ED2OUT;
        CMF_BOOL _OR9, _OR10;
        _AND9 = GET_TAG_BV(ALS_BV_3P27Q1AND) & GET_TAG_BV(ALS_BV_3P27P1AND);
        SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED2, _AND9, &_ED2OUT);
        _AND10 = GBTV4 & GET_TAG_BV(ALS_BV_52A) & _ED2OUT;
        _AND11 = _AND10 & GET_TAG_BV(ALS_BV_OP30);
        _OR9 = GET_TAG_BV(ALS_BV_OP30) | GET_TAG_NVV_UI(ALS_NVV_OP2);
        _AND12 = _OR9 & GET_TAG_BV(ALS_BV_UNBVTR);
        _OR10 = _AND11 | _AND12;
        SET_TAG_BV(ALS_BV_DTL16, _OR10);

        CMF_BOOL _OR11;
        //SET TR10
        _OR11 = GBTV3 | _AND10;
        SET_TAG_BV(ALS_BV_TR10, _OR11);
    }
}
