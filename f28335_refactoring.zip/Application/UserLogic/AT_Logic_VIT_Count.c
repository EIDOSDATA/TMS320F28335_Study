/*
 * AT_Logic_VITCount.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_VIT_Count()
{
    //Fault Pick Up
    {
        CMF_BOOL temp1, temp2, temp3, temp4, temp5;
        temp1 = GET_TAG_BV(ALS_BV_50PTC) & (GET_TAG_BV(ALS_BV_50P1) | GET_TAG_BV(ALS_BV_50P3) |GET_TAG_BV(ALS_BV_50P4));
        temp2 = GET_TAG_BV(ALS_BV_50NTC) & (GET_TAG_BV(ALS_BV_50N1) | GET_TAG_BV(ALS_BV_50N3) |GET_TAG_BV(ALS_BV_50N4));
        temp3 = GET_TAG_BV(ALS_BV_51PTC) & (GET_TAG_BV(ALS_BV_51P1) | GET_TAG_BV(ALS_BV_51P3) |GET_TAG_BV(ALS_BV_51P4));
        temp4 = GET_TAG_BV(ALS_BV_51NTC) & (GET_TAG_BV(ALS_BV_51N1) | GET_TAG_BV(ALS_BV_51N3) |GET_TAG_BV(ALS_BV_51N4));
        temp5 = GET_TAG_BV(ALS_BV_50N6) & GET_TAG_BV(ALS_BV_67NTC) & GET_TAG_SC_UCFG_UI(ALS_SC_ENSEF) & !(GET_TAG_BV(ALS_BV_INRG) | GET_TAG_BV(ALS_BV_CLPGR));
        CMF_BOOL _FPU;
        _FPU = temp1 | temp2 | temp3 | temp4 | temp5;
        SET_TAG_BV(ALS_BV_FPU, _FPU);

        CMF_BOOL ED_FPU_OUT_FALLING;
        SFB_DEF_EDGE_DETR(ED_FPU_RISING, EDT_FALLING, CMF_FALSE);
        SFB_USE_EDGE_DETR(ED_FPU_RISING, GET_TAG_BV(ALS_BV_FPU), &ED_FPU_OUT_FALLING);

        if(ED_FPU_OUT_FALLING){
            //SET TAG DATA
            SET_TAG_NMV_F(ALS_NMV_VA_MAX, GET_TAG_AI_F(ALS_AI_RMS_VA_MAX));
            SET_TAG_NMV_F(ALS_NMV_VB_MAX, GET_TAG_AI_F(ALS_AI_RMS_VB_MAX));
            SET_TAG_NMV_F(ALS_NMV_VC_MAX, GET_TAG_AI_F(ALS_AI_RMS_VC_MAX));
            SET_TAG_NMV_F(ALS_NMV_IA_MAX, GET_TAG_AI_F(ALS_AI_RMS_IA_MAX));
            SET_TAG_NMV_F(ALS_NMV_IB_MAX, GET_TAG_AI_F(ALS_AI_RMS_IB_MAX));
            SET_TAG_NMV_F(ALS_NMV_IC_MAX, GET_TAG_AI_F(ALS_AI_RMS_IC_MAX));
            SET_TAG_NMV_F(ALS_NMV_IN_MAX, GET_TAG_AI_F(ALS_AI_RMS_IN_MAX));
        }
    }
    //Fault Count Pulse
    {
//        CMF_BOOL _PD1OUT;
//        CMF_BOOL PD1IN;
//        PD1IN = GET_TAG_BV(ALS_BV_FCP);
//        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 0 , PDTT_SEC, 0.3);
//        SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &_PD1OUT);

        CMF_BOOL _PD2OUT;
        CMF_BOOL PD2IN;
        PD2IN = GET_TAG_BV(ALS_BV_FPU);
        SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 2 , PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL , &_PD2OUT);

        CMF_BOOL _PD3OUT;
        SFB_DEF_PD_TIMER(PD3, PDTT_SEC, 3 , PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD3, !_PD2OUT, NULL , &_PD3OUT);

        SFB_DEF_GBTV(_FLT, CMF_BOOL, CMF_FALSE);
        _FLT = (_PD2OUT | _FLT) & !(GET_TAG_BV(ALS_BV_FCP) | _PD3OUT);
        SET_TAG_BV(ALS_BV_FLT, _FLT);

        CMF_BOOL _ED1OUT;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_NON), &_ED1OUT);

        CMF_BOOL _FCP;
        _FCP = _ED1OUT & GET_TAG_BV(ALS_BV_FLT) & GET_TAG_BV(ALS_BV_52A);
        SET_TAG_BV(ALS_BV_FCP, _FCP);
    }


    // Radial N.C Fault Count
    {
        CMF_BOOL _AND;
        _AND = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_FCP) & GET_TAG_NVV_UI(ALS_NVV_OP2) &GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_BLT);

        CMF_BOOL _FCN1 = GET_TAG_BV(ALS_BV_FCN1);
        CMF_BOOL _FCN2 = GET_TAG_BV(ALS_BV_FCN2);
        CMF_BOOL _FCN3 = GET_TAG_BV(ALS_BV_FCN3);
        CMF_BOOL _FCN4 = GET_TAG_BV(ALS_BV_FCN4);

        CMF_BOOL _OR;
        _OR = GET_TAG_BV(ALS_BV_79NCRS) | GET_TAG_BV(ALS_BV_79FRS) | GET_TAG_BV(ALS_BV_MLRS);

        CMF_BOOL _ED5OUT;
        SFB_DEF_EDGE_DETR(_EDOUT, EDT_RISING,0);
        SFB_USE_EDGE_DETR(_EDOUT, _OR, &_ED5OUT);

        CMF_BOOL _NCOPCNRS;
        _NCOPCNRS = GET_TAG_BV(ALS_BV_TRIP) | !GET_TAG_BV(ALS_BV_52A) | GET_TAG_BV(ALS_BV_V79LO) | _ED5OUT;

        SET_TAG_BV(ALS_BV_NCOPCNRS, _NCOPCNRS);

        _FCN1 =  (_AND | _FCN1)  & !_NCOPCNRS;
        _FCN2 =  ((GET_TAG_BV(ALS_BV_FCN1) & _AND) | _FCN2) & !_NCOPCNRS;
        _FCN3 =  ((GET_TAG_BV(ALS_BV_FCN2) & _AND) | _FCN3) & !_NCOPCNRS;
        _FCN4 =  ((GET_TAG_BV(ALS_BV_FCN3) & _AND) | _FCN4) & !_NCOPCNRS;
        // Set Tag data
        SET_TAG_BV(ALS_BV_FCN1, _FCN1);
        SET_TAG_BV(ALS_BV_FCN2, _FCN2);
        SET_TAG_BV(ALS_BV_FCN3, _FCN3);
        SET_TAG_BV(ALS_BV_FCN4, _FCN4);


        CMF_BOOL _FCC;
        CMF_UINT _OPCN;
        _OPCN = GET_TAG_LS_UI(ALS_LS_OPCN);
        _FCC = (_FCN1 & (_OPCN == 1)) | (_FCN2 & ((_OPCN == 1)|(_OPCN == 2)))
                | (_FCN3 & ((_OPCN == 1) | (_OPCN == 2) | (_OPCN == 3)))
                | (_FCN4 & ((_OPCN == 1) | (_OPCN == 2) | (_OPCN == 3) | (_OPCN == 4)));
        // Set Tag data
        SET_TAG_BV(ALS_BV_FCC, _FCC);
    }

    //Loop N.C Voltage Count
    {
        CMF_BOOL _AND = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_NCVCP) & GET_TAG_BV(ALS_BV_OP30) & GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_BLT);

        CMF_BOOL _CNCV1 = GET_TAG_BV(ALS_BV_CNCV1);
        CMF_BOOL _CNCV2 = GET_TAG_BV(ALS_BV_CNCV2);
        CMF_BOOL _CNCV3 = GET_TAG_BV(ALS_BV_CNCV3);
        CMF_BOOL _CNCV4 = GET_TAG_BV(ALS_BV_CNCV4);

        _CNCV1 = (_AND | _CNCV1) & !GET_TAG_BV(ALS_BV_NCOPCNRS);
        _CNCV2 = (_AND & GET_TAG_BV(ALS_BV_CNCV1) | _CNCV2) & !GET_TAG_BV(ALS_BV_NCOPCNRS);
        _CNCV3 = (_AND & GET_TAG_BV(ALS_BV_CNCV2) | _CNCV3) & !GET_TAG_BV(ALS_BV_NCOPCNRS);
        _CNCV4 = (_AND & GET_TAG_BV(ALS_BV_CNCV3) | _CNCV4) & !GET_TAG_BV(ALS_BV_NCOPCNRS);

        //Set Tag Phase
        SET_TAG_BV(ALS_BV_CNCV1, _CNCV1);
        SET_TAG_BV(ALS_BV_CNCV2, _CNCV2);
        SET_TAG_BV(ALS_BV_CNCV3, _CNCV3);
        SET_TAG_BV(ALS_BV_CNCV4, _CNCV4);

        CMF_BOOL _OVCN;
        CMF_UINT _OPCN;
        _OPCN = GET_TAG_LS_UI(ALS_LS_OPCN);

        _OVCN = (_CNCV1 & (_OPCN == 1)) | (_CNCV2 & ((_OPCN == 1)|(_OPCN == 2)))
                | (_CNCV3 & ((_OPCN == 1) | (_OPCN == 2) | (_OPCN == 3)))
                | (_CNCV4 & ((_OPCN == 1) | (_OPCN == 2) | (_OPCN == 3) | (_OPCN == 4)));

        SET_TAG_BV(ALS_BV_OVCN, _OVCN);
    }


    //LOOP N.O Voltage Count
    {
        CMF_BOOL _AND = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_NOVCP) & GET_TAG_BV(ALS_BV_OP40) & !GET_TAG_BV(ALS_BV_52A);
        CMF_BOOL _CNOV1 = GET_TAG_BV(ALS_BV_CNOV1);
        CMF_BOOL _CNOV2 = GET_TAG_BV(ALS_BV_CNOV2);
        CMF_BOOL _CNOV3 = GET_TAG_BV(ALS_BV_CNOV3);
        CMF_BOOL _CNOV4 = GET_TAG_BV(ALS_BV_CNOV4);
        CMF_BOOL _CNOV5 = GET_TAG_BV(ALS_BV_CNOV5);

        CMF_BOOL _OR = GET_TAG_BV(ALS_BV_79NORS) | GET_TAG_BV(ALS_BV_79FRS) | GET_TAG_BV(ALS_BV_MLRS) ;
        CMF_BOOL _ED1OUT;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING,0);
        SFB_USE_EDGE_DETR(ED1, _OR, &_ED1OUT);

        CMF_BOOL _OR1 = GET_TAG_BV(ALS_BV_CLOSE) | GET_TAG_BV(ALS_BV_52A) | GET_TAG_BV(ALS_BV_V79LO) | _ED1OUT;

//        CMF_BOOL _temp1, _temp2, _temp3, _temp4, _temp5;
        _CNOV1 = (_AND | _CNOV1) & !_OR1;
        _CNOV2 = (_AND & GET_TAG_BV(ALS_BV_CNOV1) | _CNOV2) & !_OR1;
        _CNOV3 = (_AND & GET_TAG_BV(ALS_BV_CNOV2) | _CNOV3) & !_OR1;
        _CNOV4 = (_AND & GET_TAG_BV(ALS_BV_CNOV3) | _CNOV4) & !_OR1;
        _CNOV5 = (_AND & GET_TAG_BV(ALS_BV_CNOV4) | _CNOV5) & !_OR1;

        SET_TAG_BV(ALS_BV_CNOV1, _CNOV1);
        SET_TAG_BV(ALS_BV_CNOV2, _CNOV2);
        SET_TAG_BV(ALS_BV_CNOV3, _CNOV3);
        SET_TAG_BV(ALS_BV_CNOV4, _CNOV4);
        SET_TAG_BV(ALS_BV_CNOV5, _CNOV5);

        CMF_BOOL _NOCN;
        CMF_UINT _OPCN;
        _OPCN = GET_TAG_LS_UI(ALS_LS_OPCN);

        _NOCN = (_CNOV2 & (_OPCN == 1)) | (_CNOV3 & (_OPCN == 2))
                | (_CNOV4 & (_OPCN == 3))
                | (_CNOV5 & (_OPCN == 4));

        SET_TAG_BV(ALS_BV_NOCN, _NOCN);


        CMF_BOOL _ED2OUT;
        SFB_DEF_EDGE_DETR(ED2, EDT_RISING,0);
        SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_VAND), &_ED2OUT);

        CMF_BOOL AND_TEMP;
        AND_TEMP = !GET_TAG_BV(ALS_BV_NOCN) & _ED2OUT;

        CMF_BOOL _PD1OUT;
     //   SFB_DEF_PD_TIMER_EX(PD1_EX, PDTT_SEC, 0, 0, PDTT_SEC_VAR_F, 0, ALS_LS_BCD);
        SFB_DEF_PD_TIMER_EX(PD1_EX, N_A, N_A, N_A, PDTT_TAG, TAG_GRP_LS_F, ALS_LS_BCD)
        SFB_USE_PD_TIMER(PD1_EX, AND_TEMP, NULL, &_PD1OUT);

        CMF_BOOL _DTL26;
        _DTL26 = ( (GET_TAG_BV(ALS_BV_LOCKTRIP) & GET_TAG_NVV_UI(ALS_NVV_OP4)) | (_PD1OUT & _NOCN) );
        SET_TAG_BV(ALS_BV_DTL26, _DTL26);
    }
    // NC. COUNT Trip & DCL
    {
        CMF_BOOL _TR2;

        _TR2 = (GET_TAG_BV(ALS_BV_FCC) | GET_TAG_BV(ALS_BV_OVCN))
            & GET_TAG_BV(ALS_BV_3P27Q1AND)
            & GET_TAG_BV(ALS_BV_3P27Q1AND) ;

        SET_TAG_BV(ALS_BV_TR2, _TR2);

        CMF_BOOL _AND1;
        _AND1 = GET_TAG_BV(ALS_BV_52A) & GET_TAG_BV(ALS_BV_79CY) & GET_TAG_BV(ALS_BV_3P27Q1AND) & GET_TAG_BV(ALS_BV_3P27Q1AND) ;

        CMF_BOOL _ED1OUT;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _AND1, &_ED1OUT);

        SFB_DEF_GBTV(_DCL, CMF_BOOL, CMF_FALSE);

        CMF_BOOL _ED2OUT;
        SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_52A), &_ED2OUT);

        CMF_BOOL _NCTRS;
        _NCTRS = _ED2OUT | GET_TAG_BV(ALS_BV_NCCL) | GET_TAG_BV(ALS_BV_VAND) | GET_TAG_BV(ALS_BV_V79LO);
        SET_TAG_BV(ALS_BV_NCTRS, _NCTRS);

        _DCL = ((_ED1OUT | _TR2 | GET_TAG_BV(ALS_BV_LOVCP)) | _DCL) & !_NCTRS;
        SET_TAG_BV(ALS_BV_DCL, _DCL);
    }
}
