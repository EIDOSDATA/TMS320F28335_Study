/*
 * AT_Logic_CurrentCheck.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"


CMF_VOID AT_Logic_CurrentCheck()
{
    ////////////////////////////////////
    // Current check
    ////////////////////////////////////
    {
        ////////////////////////////////////
        // Current check
        ////////////////////////////////////
        CMF_BOOL PD1IN;
        PD1IN = (GET_TAG_AI_F(ALS_AI_RMS_IA) > 3.0) ? 1 : 0;
        CMF_BOOL _50LA;
        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 2, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &_50LA);

        CMF_BOOL PD2IN;
        PD2IN = (GET_TAG_AI_F(ALS_AI_RMS_IB) > 3.0) ? 1 : 0;
        CMF_BOOL _50LB;
        SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 2, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_50LB);

        CMF_BOOL PD3IN;
        PD3IN = (GET_TAG_AI_F(ALS_AI_RMS_IC) > 3.0) ? 1 : 0;
        CMF_BOOL _50LC;
        SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 2, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &_50LC);

        CMF_BOOL _50L;
        CMF_BOOL _3P50L;
        _50L = _50LA | _50LB | _50LC;
        _3P50L = _50LA & _50LB & _50LC;

    // Set Tag data
        SET_TAG_BV(ALS_BV_50LA, _50LA);
        SET_TAG_BV(ALS_BV_50LB, _50LB);
        SET_TAG_BV(ALS_BV_50LC, _50LC);
        SET_TAG_BV(ALS_BV_50L, _50L);
        SET_TAG_BV(ALS_BV_3P50L, _3P50L);
    }
}
