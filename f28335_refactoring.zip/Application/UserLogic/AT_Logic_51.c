/*
 * AT_Logic_51.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_51()
{
    ////////////////////////////////////
    // High Current Trip - Phase
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL PD1_OUT, _50P1T;

        // Process phase
        CMF_BOOL PD1_IN;
        PD1_IN = GET_TAG_BV(ALS_BV_50PTC) & ( GET_TAG_BV(ALS_BV_50P1) | GET_TAG_BV(ALS_BV_50P3) | GET_TAG_BV(ALS_BV_50P4) );

        SFB_DEF_PD_TIMER_EX(PD1, PDTT_TAG, TAG_GRP_LS_F, ALS_LS_50P1D, PDTT_SEC, N_A, N_A)

        SFB_USE_PD_TIMER(PD1, PD1_IN, NULL, &PD1_OUT);

        CMF_BOOL PD1_HP_IN;
        CMF_BOOL PD1_HP_OUT;
        PD1_HP_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & PD1_OUT ;

        SFB_DEF_PD_TIMER(PD1_HP, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_HP, PD1_HP_IN, NULL, &PD1_HP_OUT);

        _50P1T = PD1_HP_OUT | (PD1_OUT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));


        // Set tag phase
        SET_TAG_BV(ALS_BV_50P1T, _50P1T);
    }

    ////////////////////////////////////
    // High Current Trip - Ground
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL PD1_OUT, _50N1T;

        // Process phase
        CMF_BOOL PD1_IN;
        PD1_IN = GET_TAG_BV(ALS_BV_50NTC) & ( GET_TAG_BV(ALS_BV_50N1) | GET_TAG_BV(ALS_BV_50N3) | GET_TAG_BV(ALS_BV_50N4) );

      //SFB_DEF_PD_TIMER_EX(PD2_EX, PDTT_SEC_VAR_F, 0, ALS_LS_50N1D, PDTT_SEC, 0, 0)
        SFB_DEF_PD_TIMER_EX(PD2_EX, PDTT_TAG, TAG_GRP_LS_F, ALS_LS_50N1D, PDTT_SEC, N_A, N_A)



        SFB_USE_PD_TIMER(PD2_EX, PD1_IN, NULL, &PD1_OUT);

        CMF_BOOL PD1_HG_IN;
        CMF_BOOL PD1_HG_OUT;
        PD1_HG_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & PD1_OUT ;

        SFB_DEF_PD_TIMER(PD1_HG, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_HG, PD1_HG_IN, NULL, &PD1_HG_OUT);

        _50N1T = PD1_HG_OUT | (PD1_OUT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));



        // Set tag phase
        SET_TAG_BV(ALS_BV_50N1T, _50N1T);
    }

    ////////////////////////////////////
    //1. Inverse Time Current Trip - Phase Fast
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 IA_IB_1 = 0.0;
        CMF_FLOAT32 MAX_IABC1= 0.0;
        CMF_BOOL _51P1F = 0; //Check pick up
        CMF_BOOL _51P1TF, _51P1RF;
        CMF_BOOL PFT;
        CMF_BOOL AND1;

        // Process phase
        AND1 = GET_TAG_BV(ALS_BV_51PTC) & GET_TAG_BV(ALS_BV_51P1TCF);
        if (AND1) {
            IA_IB_1 = (GET_TAG_AI_F(ALS_AI_RMS_IA) >= GET_TAG_AI_F(ALS_AI_RMS_IB)) ? GET_TAG_AI_F(ALS_AI_RMS_IA) : GET_TAG_AI_F(ALS_AI_RMS_IB) ;
            MAX_IABC1 = (IA_IB_1 >= GET_TAG_AI_F(ALS_AI_RMS_IC)) ? IA_IB_1 : GET_TAG_AI_F(ALS_AI_RMS_IC);
        }
        else {
            MAX_IABC1 = 0.0;
        }

        SFB_DEF_TCC_EX(TCC1_2,
                       TAG_GRP_LS_UI, ALS_LS_51P1C,  TAG_GRP_LS_F,  ALS_LS_51P1TD,
                       TAG_GRP_LS_F,  ALS_LS_51P1FD, TAG_GRP_LS_UI, ALS_LS_51P1RS,
                       TAG_GRP_LS_F , ALS_LS_51P1CT, TAG_GRP_LS_F,  ALS_LS_51P1MR,
                       N_A,           N_A,           N_A,           N_A,
                       N_A,           N_A);

        SFB_USE_TCC(TCC1_2, (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_51P1P), MAX_IABC1, &_51P1F, &PFT, &_51P1RF);

        CMF_BOOL PD1_PF_IN;
        CMF_BOOL PD1_PF_OUT;
        PD1_PF_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & PFT ;

        SFB_DEF_PD_TIMER(PD1_PF, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_PF, PD1_PF_IN, NULL, &PD1_PF_OUT);


        _51P1TF = PD1_PF_OUT | (PFT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));

        //Set tag Phase
        SET_TAG_BV(ALS_BV_51P1F, _51P1F);
        SET_TAG_BV(ALS_BV_PFT, PFT);
        SET_TAG_BV(ALS_BV_51P1TF, _51P1TF);
        SET_TAG_BV(ALS_BV_51P1RF, _51P1RF);
    }

    ////////////////////////////////////
    //2. Inverse Time Current Trip - Ground Fast
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 TCC2IN = 0.0;
        CMF_BOOL _51N1F = 0; //Check pick up
        CMF_BOOL _51N1TF, _51N1RF;
        CMF_BOOL NFT;
        CMF_BOOL AND1;

        // Process phase
        AND1 = GET_TAG_BV(ALS_BV_51NTC) & GET_TAG_BV(ALS_BV_51N1TCF);
        if (AND1)
        {
            TCC2IN = GET_TAG_AI_F(ALS_AI_RMS_IN);
        }
        else
        {
            TCC2IN = 0.0;
        }

        SFB_DEF_TCC_EX(TCC2_2,
                       TAG_GRP_LS_UI, ALS_LS_51N1C,  TAG_GRP_LS_F,  ALS_LS_51N1TD,
                       TAG_GRP_LS_F,  ALS_LS_51N1FD, TAG_GRP_LS_UI, ALS_LS_51N1RS,
                       TAG_GRP_LS_F,  ALS_LS_51N1CT, TAG_GRP_LS_F,  ALS_LS_51N1MR,
                       N_A,           N_A,           N_A,           N_A,
                       N_A,           N_A);

        SFB_USE_TCC(TCC2_2, (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_51N1P), TCC2IN, &_51N1F, &NFT, &_51N1RF);

        CMF_BOOL PD1_GF_IN;
        CMF_BOOL PD1_GF_OUT;
        PD1_GF_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & NFT ;

        SFB_DEF_PD_TIMER(PD1_GF, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_GF, PD1_GF_IN, NULL, &PD1_GF_OUT);


        _51N1TF = PD1_GF_OUT | (NFT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));

        //Set tag Phase
        SET_TAG_BV(ALS_BV_51N1F, _51N1F);
        SET_TAG_BV(ALS_BV_NFT, NFT);
        SET_TAG_BV(ALS_BV_51N1TF, _51N1TF);
        SET_TAG_BV(ALS_BV_51N1RF, _51N1RF);
    }

    ////////////////////////////////////
    //3. Inverse Time Current Trip - Phase delay
    ////////////////////////////////////
    {
        // Define phase
        CMF_FLOAT32 IA_IB_3= 0.0;
        CMF_FLOAT32 MAX_IABC3 = 0.0;
        CMF_BOOL _51P1D; //Check Pick up
        CMF_BOOL _51P1TD, _51P1RD;
        CMF_BOOL PDT;
        CMF_BOOL AND1;

        // Process phase
        AND1 = GET_TAG_BV(ALS_BV_51PTC) & GET_TAG_BV(ALS_BV_51P1TCD);
        if (AND1)
        {
            IA_IB_3 = (GET_TAG_AI_F(ALS_AI_RMS_IA) >= GET_TAG_AI_F(ALS_AI_RMS_IB)) ? GET_TAG_AI_F(ALS_AI_RMS_IA) : GET_TAG_AI_F(ALS_AI_RMS_IB) ;
            MAX_IABC3 = (IA_IB_3 >= GET_TAG_AI_F(ALS_AI_RMS_IC)) ? IA_IB_3 : GET_TAG_AI_F(ALS_AI_RMS_IC);
        }
        else
        {
            MAX_IABC3 = 0.0;
        }

        SFB_DEF_TCC_EX(TCC3_2,
                       TAG_GRP_LS_UI, ALS_LS_51P2C,  TAG_GRP_LS_F,  ALS_LS_51P2TD,
                       TAG_GRP_LS_F,  ALS_LS_51P1DD, TAG_GRP_LS_UI, ALS_LS_51P2RS,
                       TAG_GRP_LS_F,  ALS_LS_51P2CT, TAG_GRP_LS_F,  ALS_LS_51P2CT,
                       N_A,           N_A,           N_A,           N_A,
                       N_A,           N_A);

        SFB_USE_TCC(TCC3_2, (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_51P1P), MAX_IABC3, &_51P1D, &PDT, &_51P1RD);

        CMF_BOOL PD1_PD_IN;
        CMF_BOOL PD1_PD_OUT;
        PD1_PD_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & PDT ;

        SFB_DEF_PD_TIMER(PD1_PD, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_PD, PD1_PD_IN, NULL, &PD1_PD_OUT);


        _51P1TD = PD1_PD_OUT | (PDT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));

        //Set tag Phase
        SET_TAG_BV(ALS_BV_51P1D, _51P1D);
        SET_TAG_BV(ALS_BV_PDT, PDT);
        SET_TAG_BV(ALS_BV_51P1TD, _51P1TD);
        SET_TAG_BV(ALS_BV_51P1RD, _51P1RD);
    }

    ////////////////////////////////////
    //4. Inverse Time Current Trip - Ground delay
    ////////////////////////////////////
    {
        CMF_FLOAT32 TCC4IN = 0.0;
        CMF_BOOL _51N1D; //Check Pick up
        CMF_BOOL _51N1TD, _51N1RD;
        CMF_BOOL NDT;
        CMF_BOOL AND1;

        AND1 = GET_TAG_BV(ALS_BV_51NTC) & GET_TAG_BV(ALS_BV_51N1TCD);
        if (AND1)
        {
            TCC4IN = GET_TAG_AI_F(ALS_AI_RMS_IN);
        }
        else
        {
            TCC4IN = 0.0;
        }

        SFB_DEF_TCC_EX(TCC4_2,
                       TAG_GRP_LS_UI, ALS_LS_51N2C,  TAG_GRP_LS_F,  ALS_LS_51N2TD,
                       TAG_GRP_LS_F,  ALS_LS_51N1DD, TAG_GRP_LS_UI, ALS_LS_51N2RS,
                       TAG_GRP_LS_F,  ALS_LS_51N2CT, TAG_GRP_LS_F,  ALS_LS_51N2MR,
                       N_A,           N_A,           N_A,           N_A,
                       N_A,           N_A);

        SFB_USE_TCC(TCC4_2, (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_51N1P), TCC4IN, &_51N1D, &NDT, &_51N1RD);

        CMF_BOOL PD1_GD_IN;
        CMF_BOOL PD1_GD_OUT;
        PD1_GD_IN = GET_TAG_NVV_UI(ALS_NVV_ENRC) & GET_TAG_BV(ALS_BV_BLT) & NDT ;

        SFB_DEF_PD_TIMER(PD1_GD, PDTT_SEC, 0.1, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1_GD, PD1_GD_IN, NULL, &PD1_GD_OUT);


        _51N1TD = PD1_GD_OUT | (NDT & !(GET_TAG_BV(ALS_BV_BLT) | GET_TAG_BV(ALS_BV_BLT1)));

        //Set tag Phase
        SET_TAG_BV(ALS_BV_51N1D, _51N1D);
        SET_TAG_BV(ALS_BV_NDT, NDT);
        SET_TAG_BV(ALS_BV_51N1TD, _51N1TD);
        SET_TAG_BV(ALS_BV_51N1RD, _51N1RD);
    }
}
