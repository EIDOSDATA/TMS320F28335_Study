/*
 * AT_Logic_BlownFuseDetection.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_BlownFuseDetection()
{
    CMF_FLOAT32 temp1_f = 0.0;
    CMF_FLOAT32 MAX_IABC = 0.0;
    CMF_FLOAT32 IA_IB = 0.0;
    IA_IB = (GET_TAG_AI_F(ALS_AI_RMS_IA) >= GET_TAG_AI_F(ALS_AI_RMS_IB)) ? GET_TAG_AI_F(ALS_AI_RMS_IA) : GET_TAG_AI_F(ALS_AI_RMS_IB) ;
    MAX_IABC = (IA_IB >= GET_TAG_AI_F(ALS_AI_RMS_IC)) ? IA_IB : GET_TAG_AI_F(ALS_AI_RMS_IC);

    if ( !( (GET_TAG_SC_UCFG_UI(ALS_SC_51P5P) == 0) ? 1 : 0 ) & ( (CMF_FLOAT32)(GET_TAG_SC_UCFG_UI(ALS_SC_51P5P) * 2.0) < MAX_IABC ) ? 1 : 0 ){
        temp1_f = MAX_IABC;
    }
    CMF_FLOAT32 TCC1IN;
    CMF_BOOL _51P5T, _51P5RS;
    CMF_BOOL _51P5PP; //Check User curve Pick up
    TCC1IN = temp1_f;

    SFB_DEF_TCC_EX(TCC1,
                   TAG_GRP_SC_UI, ALS_SC_USERC,     TAG_GRP_SC_F,  ALS_SC_USERTD,
                   N_A,           N_A,              TAG_GRP_SC_UI, ALS_SC_USERRS,
                   TAG_GRP_SC_F,  ALS_SC_USERCT,    TAG_GRP_SC_F,  ALS_SC_USERMR,
                   TAG_GRP_SC_F,  ALS_SC_TCC_FAC_A, TAG_GRP_SC_F,  ALS_SC_TCC_FAC_B,
                   TAG_GRP_SC_F,  ALS_SC_TCC_FAC_P);

    SFB_USE_TCC(TCC1, (CMF_FLOAT32) GET_TAG_SC_UCFG_UI(ALS_SC_51P5P), TCC1IN, &_51P5PP, &_51P5T, &_51P5RS);

    CMF_BOOL PD1IN;
    CMF_BOOL PD1OUT;
    CMF_BOOL temp1_b;
    temp1_b = (GET_TAG_SC_UCFG_UI(ALS_SC_ENBFD) == 0) ? 0 : 1;
    PD1IN = temp1_b & _51P5T;
    SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 0, PDTT_CYCLE, 3.0); //for test, need change 3cycle --> 600cycle
    SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &PD1OUT);

    CMF_BOOL ED1OUT;
    SFB_DEF_EDGE_DETR(ED1, EDT_FALLING, 1);
    SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_50LA), &ED1OUT);

    CMF_BOOL ED2OUT;
    SFB_DEF_EDGE_DETR(ED2, EDT_FALLING, 1);
    SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_50LB), &ED2OUT);

    CMF_BOOL ED3OUT;
    SFB_DEF_EDGE_DETR(ED3, EDT_FALLING, 1);
    SFB_USE_EDGE_DETR(ED3, GET_TAG_BV(ALS_BV_50LC), &ED3OUT);

    CMF_BOOL temp2_b;
    temp2_b = GET_TAG_BV(ALS_BV_BFT) | GET_TAG_BV(ALS_BV_3P50L) | !GET_TAG_BV(ALS_BV_50L) | !GET_TAG_BV(ALS_BV_52A);

    CMF_BOOL temp3_b, BFA;
    temp3_b = ( PD1OUT & ED1OUT & GET_TAG_BV(ALS_BV_50L) ) | GET_TAG_BV(ALS_BV_BFA);
    BFA = temp3_b & !temp2_b;
    SET_TAG_BV(ALS_BV_BFA, BFA);

    CMF_BOOL temp4_b, BFB;
    temp4_b = ( PD1OUT & ED2OUT & GET_TAG_BV(ALS_BV_50L) ) | GET_TAG_BV(ALS_BV_BFB);
    BFB = temp4_b & !temp2_b;
    SET_TAG_BV(ALS_BV_BFB, BFB);

    CMF_BOOL temp5_b, BFC;
    temp5_b = PD1OUT & ED3OUT & GET_TAG_BV(ALS_BV_50L) | GET_TAG_BV(ALS_BV_BFC);
    BFC = temp5_b & !temp2_b;
    SET_TAG_BV(ALS_BV_BFC, BFC);

    CMF_BOOL PD2IN;
    CMF_BOOL PD2OUT, BFT;
    PD2IN = temp3_b | temp4_b | temp5_b;
    SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 15, PDTT_CYCLE, 0);
    SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &PD2OUT);

    BFT = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & PD2OUT;
    SET_TAG_BV(ALS_BV_BFT, BFT);

// Set Tag data
    SET_TAG_BV(ALS_BV_51P5T, _51P5T);
    SET_TAG_BV(ALS_BV_51P5RS, _51P5RS);
}

