/*
 * AT_Logic_SequenceCoordination.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_SequenceCoordination()
{
    CMF_BOOL temp0, temp1, temp2;
//    CMF_UINT _79OI1 = (CMF_UINT)GET_TAG_LS_F(ALS_LS_79OI1);
    temp0 = (GET_TAG_LS_F(ALS_LS_79OI1) == 0) ? 1 : 0;
    temp1 = (GET_TAG_LS_UI(ALS_LS_79OI2) == 0) ? 1 : 0;
    temp2 = (GET_TAG_LS_UI(ALS_LS_79OI3) == 0) ? 1 : 0;

    CMF_BOOL _79E1, _79E2, _79E3;
    _79E1 = !temp0;
    _79E2 = _79E1 & !temp1;
    _79E3 = _79E2 & !temp2;
    CMF_BOOL DLS0, DLS1, DLS2, DLS3;
    //_79EN = _79E1;
    DLS0 = !_79E1;
    DLS1 = _79E1 & !_79E2;
    DLS2 = _79E2 & !_79E3;
    DLS3 = _79E3;
    CMF_BOOL ED0OUT, ED1OUT, _79DLS;
    SFB_DEF_EDGE_DETR(ED0, EDT_RISING, 0);
    SFB_USE_EDGE_DETR(ED0, GET_TAG_BV(ALS_BV_79LO), &ED0OUT);
    SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
    SFB_USE_EDGE_DETR(ED1, GET_TAG_SC_SCFG_UI(ALS_SC_CFG_UPDATED), &ED1OUT);
    _79DLS = ED0OUT | ED1OUT;
    CMF_BOOL LSH0, LSH1, LSH2, LSH3;
    LSH0 = DLS0 & _79DLS;
    LSH1 = DLS1 & _79DLS;
    LSH2 = DLS2 & _79DLS;
    LSH3 = DLS3 & _79DLS;
    CMF_BOOL _79SEQ, PD0OUT;
    _79SEQ = GET_TAG_BV(ALS_BV_79RS) & (GET_TAG_BV(ALS_BV_51P1F) | GET_TAG_BV(ALS_BV_51N1F)) & GET_TAG_LS_UI(ALS_LS_ENSEQ);
    SFB_DEF_PD_TIMER(PD0, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
    SFB_USE_PD_TIMER(PD0, _79SEQ, NULL, &PD0OUT);
    CMF_BOOL ED2OUT;
    SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0);
    SFB_USE_EDGE_DETR(ED2, !PD0OUT, &ED2OUT);
    CMF_BOOL temp3, temp3_0, temp3_1;
    temp3_0 = !GET_TAG_BV(ALS_BV_TRIP) & GET_TAG_BV(ALS_BV_52A) & ED2OUT;
    CMF_BOOL ED3OUT;
    SFB_DEF_EDGE_DETR(ED3, EDT_RISING, 0);
    SFB_USE_EDGE_DETR(ED3, GET_TAG_BV(ALS_BV_CLOSE), &ED3OUT);
    temp3_1 = ED3OUT & (GET_TAG_BV(ALS_BV_79CY) & !GET_TAG_BV(ALS_BV_52A));
    temp3 = temp3_0 | temp3_1;


    CMF_BOOL temp4_0, temp4_1, temp4_2, temp4_3, temp4_OR;
    temp4_0 = LSH0 | GET_TAG_BV(ALS_BV_79RSTO);
    temp4_1 = LSH1 | (temp3 & GET_TAG_BV(ALS_BV_SH0));
    temp4_2 = LSH2 | (temp3 & GET_TAG_BV(ALS_BV_SH1));
    temp4_3 = LSH3 | (temp3 & GET_TAG_BV(ALS_BV_SH2));
    temp4_OR = temp4_0 | temp4_1 | temp4_2 | temp4_3;


//    CMF_BOOL PD1OUT, PD2OUT, PD3OUT, PD4OUT;
//    SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 0.25, PDTT_CYCLE, 1.0);
//    SFB_USE_PD_TIMER(PD1, temp4_0, NULL, &PD1OUT);
//    SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 0.25, PDTT_CYCLE, 1.0);
//    SFB_USE_PD_TIMER(PD2, temp4_1, NULL, &PD2OUT);
//    SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 0.25, PDTT_CYCLE, 1.0);
//    SFB_USE_PD_TIMER(PD3, temp4_2, NULL, &PD3OUT);
//    SFB_DEF_PD_TIMER(PD4, PDTT_CYCLE, 0.25, PDTT_CYCLE, 1.0);
//    SFB_USE_PD_TIMER(PD4, temp4_3, NULL, &PD4OUT);

    SFB_DEF_GBTV(temp5_0, CMF_BOOL, CMF_FALSE);
    temp5_0 = temp4_0 | (!temp4_OR & temp5_0);
    SFB_DEF_GBTV(temp5_1, CMF_BOOL, CMF_FALSE);
    temp5_1 = temp4_1 | (!temp4_OR & temp5_1);
    SFB_DEF_GBTV(temp5_2, CMF_BOOL, CMF_FALSE);
    temp5_2 = temp4_2 | (!temp4_OR & temp5_2);
    SFB_DEF_GBTV(temp5_3, CMF_BOOL, CMF_FALSE);
    temp5_3 = temp4_3 | (!temp4_OR & temp5_3);

    CMF_BOOL temp6;
    temp6 = GET_TAG_BV(ALS_BV_79RS) | GET_TAG_BV(ALS_BV_79CY) | GET_TAG_BV(ALS_BV_79LO);

    //Set Tag Phase
    SET_TAG_BV(ALS_BV_79E1, _79E1);
    SET_TAG_BV(ALS_BV_79E2, _79E2);
    SET_TAG_BV(ALS_BV_79E3, _79E3);
    SET_TAG_BV(ALS_BV_79EN, _79E1);
    SET_TAG_BV(ALS_BV_DLS0, DLS0);
    SET_TAG_BV(ALS_BV_DLS1, DLS1);
    SET_TAG_BV(ALS_BV_DLS2, DLS2);
    SET_TAG_BV(ALS_BV_DLS3, DLS3);
    SET_TAG_BV(ALS_BV_79DLS, _79DLS);
    SET_TAG_BV(ALS_BV_LSH0, LSH0);
    SET_TAG_BV(ALS_BV_LSH1, LSH1);
    SET_TAG_BV(ALS_BV_LSH2, LSH2);
    SET_TAG_BV(ALS_BV_LSH3, LSH3);

    CMF_BOOL SH0 = temp5_0 & temp6;
    CMF_BOOL SH1 = temp5_1 & temp6;
    CMF_BOOL SH2 = temp5_2 & temp6;
    CMF_BOOL SH3 = temp5_3 & temp6;

    //Set Tag Phase
    SET_TAG_BV(ALS_BV_SH0, SH0);
    SET_TAG_BV(ALS_BV_SH1, SH1);
    SET_TAG_BV(ALS_BV_SH2, SH2);
    SET_TAG_BV(ALS_BV_SH3, SH3);

    SET_TAG_NMV_UI(ALS_NMV_SH0, SH0);
    SET_TAG_NMV_UI(ALS_NMV_SH1, SH1);
    SET_TAG_NMV_UI(ALS_NMV_SH2, SH2);
    SET_TAG_NMV_UI(ALS_NMV_SH3, SH3);

    //For Shot Counter MMI(LCD)
    CMF_BOOL SH;
    if (SH0) {
        SH=0;
    }
    else if (SH1) {
        SH=1;
    }
    else if (SH2) {
        SH=2;
    }
    else if (SH3) {
        SH=3;
    }

    //Set Tag Phase
    SET_TAG_NMV_UI(ALS_NMV_SH_COUNT, SH);


}
