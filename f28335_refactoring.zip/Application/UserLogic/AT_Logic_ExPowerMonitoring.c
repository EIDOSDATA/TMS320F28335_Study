/*
 * AT_Logic_ExPowerMonitoring.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_ExPowerMonitoring()
{
    ////////////////////////////////////
    // External Power Monitoring (1)
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _TEMP1, _TEMP2, _TEMP3;
        CMF_BOOL _TEMP4, _TEMP5, _TEMP6, _TEMP7;
        CMF_BOOL _PD1OUT, _PD2OUT, _PD3OUT, _PD4OUT;

        // Process phase
        _TEMP1 = (42.0 > GET_TAG_AI_F(ALS_AI_AICHV)) ? 1 : 0;
        _TEMP2 = (GET_TAG_AI_F(ALS_AI_AICHV) > 30.0) ? 1 : 0;
        _TEMP3 = (GET_TAG_AI_F(ALS_AI_AICHV) > 25.0) ? 1 : 0;
        _TEMP4 = !_TEMP1;
        _TEMP5 = _TEMP1 & _TEMP2;
        _TEMP6 = !_TEMP2 & _TEMP3;
        _TEMP7 = !_TEMP3;

        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD1, _TEMP4, NULL, &_PD1OUT);

        SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD2, _TEMP5, NULL, &_PD2OUT);

        SFB_DEF_PD_TIMER(PD3, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD3, _TEMP6, NULL, &_PD3OUT);

        SFB_DEF_PD_TIMER(PD4, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD4, _TEMP7, NULL, &_PD4OUT);

        // Set tag phase
        SET_TAG_BV(ALS_BV_OVCHV, _PD1OUT);
        SET_TAG_BV(ALS_BV_CHVNORMAL, _PD2OUT);
        SET_TAG_BV(ALS_BV_UVCHV, _PD3OUT);
        SET_TAG_BV(ALS_BV_NONCHV, _PD4OUT);
    }

    ////////////////////////////////////
    // External Power Monitoring (2)
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _TEMP8;
        CMF_BOOL _PD5OUT;

        // Process phase
        _TEMP8 = !GET_TAG_BV(ALS_BV_NONCHV) & !GET_TAG_BV(ALS_BV_CHVNORMAL);

        SFB_DEF_PD_TIMER(PD5, PDTT_SEC, 10, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD5, _TEMP8, NULL, &_PD5OUT);

        // Set tag phase
        SET_TAG_BV(ALS_BV_CHVFAIL, _PD5OUT);
    }


    ////////////////////////////////////
    // External Power Monitoring (3)
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _TEMP1_1, _TEMP2_1, _TEMP3_1;
        CMF_BOOL _TEMP4_1, _TEMP5_1, _TEMP6_1, _TEMP7_1;
        CMF_BOOL _PD6OUT, _PD7OUT, _PD8OUT, _PD9OUT;

        // Process phase
        _TEMP1_1 = (41.0 > GET_TAG_AI_F(ALS_AI_AIOPV)) ? 1 : 0;
        _TEMP2_1 = (GET_TAG_AI_F(ALS_AI_AIOPV) > 18.0) ? 1 : 0;
        _TEMP3_1 = (GET_TAG_AI_F(ALS_AI_AIOPV) > 10.0) ? 1 : 0;
        _TEMP4_1 = !_TEMP1_1;
        _TEMP5_1 = _TEMP1_1 & _TEMP2_1;
        _TEMP6_1 = !_TEMP2_1 & _TEMP3_1;
        _TEMP7_1 = !_TEMP3_1;

        SFB_DEF_PD_TIMER(PD6, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD6, _TEMP4_1, NULL, &_PD6OUT);

        SFB_DEF_PD_TIMER(PD7, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD7, _TEMP5_1, NULL, &_PD7OUT);

        SFB_DEF_PD_TIMER(PD8, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD8, _TEMP6_1, NULL, &_PD8OUT);

        SFB_DEF_PD_TIMER(PD9, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD9, _TEMP7_1, NULL, &_PD9OUT);

        // Set tag phase
        SET_TAG_BV(ALS_BV_OVOPV, _PD6OUT);
        SET_TAG_BV(ALS_BV_OPVNORMAL, _PD7OUT);
        SET_TAG_BV(ALS_BV_UVOPV, _PD8OUT);
        SET_TAG_BV(ALS_BV_NONOPV, _PD9OUT);
    }

    ////////////////////////////////////
    // External Power Monitoring (4)
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _TEMP8_1;
        CMF_BOOL _PD10OUT;

        // Process phase
        _TEMP8_1 = !GET_TAG_BV(ALS_BV_NONOPV) & !GET_TAG_BV(ALS_BV_OPVNORMAL);

        SFB_DEF_PD_TIMER(PD10, PDTT_SEC, 10, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD10, _TEMP8_1, NULL, &_PD10OUT);

        // Set tag phase
        SET_TAG_BV(ALS_BV_OPVFAIL, _PD10OUT);
    }

    ////////////////////////////////////
    // External Power Monitoring (5)
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _TEMP9;

        // Process phase
        _TEMP9 = (GET_TAG_AI_F(ALS_AI_AICHV) > 30.0) ? 1 : 0;

        // Set tag phase
        SET_TAG_MMI(ALS_MMI_LEDAC, _TEMP9);
        SET_TAG_BV(ALS_BV_EXPOWER, _TEMP9);
    }
}
