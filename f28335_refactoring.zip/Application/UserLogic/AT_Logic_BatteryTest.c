/*
 * AT_Logic_BatteryTest.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_BatteryTest()
{
    ///////////////////////////////////
    // Battery test
    ////////////////////////////////////
    {
        CMF_BOOL _ED1OUT, _OR1, _OR2, _AND1, _PD1OUT, _PD2OUT, _AND2; //FB
        CMF_BOOL _DOBT, _BATTEST; //SET TAG
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(GBTV2, CMF_BOOL, CMF_FALSE);

        CMF_BOOL _ED1IN, HR_MAT, MN_MAT;
        CMF_UINT16 p_hour, p_min;
        SFB_DEF_RTC(RTC1);
        SFB_USE_RTC(RTC1, NULL, NULL, NULL, &p_hour, &p_min, NULL, NULL);

        // check if hour and minutes are met
        HR_MAT = (GET_TAG_SC_UCFG_UI(ALS_SC_SBT_HOUR) == p_hour) ? 1 : 0 ;
        MN_MAT = (GET_TAG_SC_UCFG_UI(ALS_SC_SBT_MIN) == p_min) ? 1 : 0 ;
        _ED1IN = HR_MAT & MN_MAT ;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _ED1IN, &_ED1OUT);
        if (_ED1OUT)
        {
            CMF_BOOL BATT_INTV_CNT;
            BATT_INTV_CNT = GET_TAG_NVV_UI(ALS_NVV_BATT_INTV_CNT) + 1;
            SET_TAG_NVV_UI_WO_EV(ALS_NVV_BATT_INTV_CNT, BATT_INTV_CNT);
        }
        // check if interval is met
        CMF_BOOL _BATT_INTV_MAT;
        _BATT_INTV_MAT = ((GET_TAG_NVV_UI(ALS_NVV_BATT_INTV_CNT) == GET_TAG_SC_UCFG_UI(ALS_SC_SBT_INTERVAL)) ? 1 : 0) ;
        if (_BATT_INTV_MAT)
        {
            SET_TAG_NVV_UI_WO_EV(ALS_NVV_BATT_INTV_CNT, 0);
        }
        /* Push Button -> MMI task will do */
        CMF_BOOL _EDPB1OUT;
        SFB_DEF_EDGE_DETR(EDPB1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(EDPB1, GET_TAG_MMI(ALS_MMI_PBBATTEST), &_EDPB1OUT);

        _OR1 = _BATT_INTV_MAT | GET_TAG_RCM(ALS_RCM_CBT) | _EDPB1OUT;
        _OR2 = _OR1 | GBTV1;
        _AND1 = _OR2 & !GBTV2;
        GBTV1 = _AND1;
        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 5, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD1, _AND1, NULL, &_PD1OUT);
        GBTV2 = _PD1OUT;
        SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 0, PDTT_SEC, 0.5);
        SFB_USE_PD_TIMER(PD2, _AND1, NULL, &_PD2OUT);
        _DOBT = _PD2OUT;
        _AND2 = _PD2OUT & !_AND1;
        _BATTEST = _AND2;
        // Set tag phase
        SET_TAG_DO(ALS_DO_DOBT, _DOBT);
        SET_TAG_BV(ALS_BV_BATTEST, _BATTEST);
    }

    ////////////////////////////////////
    // Battery test LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _CP1, _PD1OUT, _AND1, _AND2, _OR1, _AND3;
        CMF_BOOL _BATLOW, _BATTB, _LEDBATTB;
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);

        // Process phase
        _CP1 = (GET_TAG_SC_UCFG_F(ALS_SC_BLV) > GET_TAG_AI_F(ALS_AI_AIBATV)) ? 1 : 0;

        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 3.0, PDTT_SEC, 0.0);
        SFB_USE_PD_TIMER(PD1, _CP1, NULL, &_PD1OUT);

        _BATLOW = _PD1OUT;
        _AND1 = GET_TAG_BV(ALS_BV_BATTEST) & _BATLOW;
        _AND2 = GET_TAG_BV(ALS_BV_BATTEST) & !_BATLOW;
        _OR1 = GBTV1 | _AND1;
        _AND3 = _OR1 & !_AND2;
        GBTV1 = _AND3;
        _BATTB = _AND3;
        _LEDBATTB = _BATTB;

        // Set tag phase
        SET_TAG_BV(ALS_BV_BATLOW, _BATLOW);
        SET_TAG_BV(ALS_BV_BATTB, _BATTB);
        SET_TAG_MMI(ALS_MMI_LEDBATTB, _LEDBATTB);
    }

}

