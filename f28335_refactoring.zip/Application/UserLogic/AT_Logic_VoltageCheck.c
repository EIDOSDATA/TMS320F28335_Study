/*
 * AT_Logic_VITVoltageCheck.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"


CMF_VOID AT_Logic_VoltageCheck()
{
        CMF_FLOAT32 RT1OUT;
        CMF_FLOAT32 RT1IN = 3.0;
        SFB_DEF_SQRT_F(RT1);
        SFB_USE_SQRT_F(RT1, RT1IN, &RT1OUT);

        // SubLogic 1 _3P59P1AND
        {
            CMF_FLOAT32 _59P1P = ((CMF_FLOAT32)(GET_TAG_SC_UCFG_UI(ALS_SC_59P1P0))/100.0) * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;
            SET_TAG_NMV_F(ALS_NMV_59P1P, _59P1P);

            CMF_BOOL _59A1;
            CMF_BOOL PD1_1IN = (GET_TAG_AI_F(ALS_AI_RMS_VA) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_1, PD1_1IN, NULL, &_59A1);
            SET_TAG_BV(ALS_BV_59A1, _59A1);

            CMF_BOOL _59B1;
            CMF_BOOL PD1_2IN = (GET_TAG_AI_F(ALS_AI_RMS_VB) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_2, PD1_2IN, NULL, &_59B1);
            SET_TAG_BV(ALS_BV_59B1, _59B1);

            CMF_BOOL _59C1;
            CMF_BOOL PD1_3IN = (GET_TAG_AI_F(ALS_AI_RMS_VC) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_3, PD1_3IN, NULL, &_59C1);
            SET_TAG_BV(ALS_BV_59C1, _59C1);

            CMF_BOOL _59R1;
            CMF_BOOL PD1_4IN = (GET_TAG_AI_F(ALS_AI_RMS_VR) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_4, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_4, PD1_4IN, NULL, &_59R1);
            SET_TAG_BV(ALS_BV_59R1, _59R1);

            CMF_BOOL _59S1;
            CMF_BOOL PD1_5IN = (GET_TAG_AI_F(ALS_AI_RMS_VS) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_5, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_5, PD1_5IN, NULL, &_59S1);
            SET_TAG_BV(ALS_BV_59S1, _59S1);

            CMF_BOOL _59T1;
            CMF_BOOL PD1_6IN = (GET_TAG_AI_F(ALS_AI_RMS_VT) > GET_TAG_NMV_F(ALS_NMV_59P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD1_6, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD1_6, PD1_6IN, NULL, &_59T1);
            SET_TAG_BV(ALS_BV_59T1, _59T1);

            CMF_BOOL _3P59P1OR = GET_TAG_BV(ALS_BV_59A1) | GET_TAG_BV(ALS_BV_59B1) | GET_TAG_BV(ALS_BV_59C1);
            SET_TAG_BV(ALS_BV_3P59P1OR, _3P59P1OR);

            CMF_BOOL _3P59P1AND = GET_TAG_BV(ALS_BV_59A1) & GET_TAG_BV(ALS_BV_59B1) & GET_TAG_BV(ALS_BV_59C1);
            SET_TAG_BV(ALS_BV_3P59P1AND, _3P59P1AND);

            CMF_BOOL _3P59Q1OR = GET_TAG_BV(ALS_BV_59R1) | GET_TAG_BV(ALS_BV_59S1) | GET_TAG_BV(ALS_BV_59T1);
            SET_TAG_BV(ALS_BV_3P59Q1OR, _3P59Q1OR);
        }

        // SubLogic 2 _3P27P1AND
        {
            CMF_FLOAT32 _27P1P = ((CMF_FLOAT32)(GET_TAG_SC_UCFG_UI(ALS_SC_27P1P0))/100.0) * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;
            SET_TAG_NMV_F(ALS_NMV_27P1P, _27P1P);

            CMF_BOOL _27A1;
            CMF_BOOL PD2_1IN = (GET_TAG_AI_F(ALS_AI_RMS_VA) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_1, PD2_1IN, NULL, &_27A1);
            SET_TAG_BV(ALS_BV_27A1, _27A1);

            CMF_BOOL _27B1;
            CMF_BOOL PD2_2IN = (GET_TAG_AI_F(ALS_AI_RMS_VB) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_2, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_2, PD2_2IN, NULL, &_27B1);
            SET_TAG_BV(ALS_BV_27B1, _27B1);

            CMF_BOOL _27C1;
            CMF_BOOL PD2_3IN = (GET_TAG_AI_F(ALS_AI_RMS_VC) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_3, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_3, PD2_3IN, NULL, &_27C1);
            SET_TAG_BV(ALS_BV_27C1, _27C1);

            CMF_BOOL _27R1;
            CMF_BOOL PD2_4IN = (GET_TAG_AI_F(ALS_AI_RMS_VR) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_4, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_4, PD2_4IN, NULL, &_27R1);
            SET_TAG_BV(ALS_BV_27R1, _27R1);

            CMF_BOOL _27S1;
            CMF_BOOL PD2_5IN = (GET_TAG_AI_F(ALS_AI_RMS_VS) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_5, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_5, PD2_5IN, NULL, &_27S1);
            SET_TAG_BV(ALS_BV_27S1, _27S1);

            CMF_BOOL _27T1;
            CMF_BOOL PD2_6IN = (GET_TAG_AI_F(ALS_AI_RMS_VT) < GET_TAG_NMV_F(ALS_NMV_27P1P)) ? 1 : 0;
            SFB_DEF_PD_TIMER(PD2_6, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD2_6, PD2_6IN, NULL, &_27T1);
            SET_TAG_BV(ALS_BV_27T1, _27T1);


            CMF_BOOL _3P27P1AND = GET_TAG_BV(ALS_BV_27A1)& GET_TAG_BV(ALS_BV_27B1) & GET_TAG_BV(ALS_BV_27C1);
            CMF_BOOL _3P27Q1AND = GET_TAG_BV(ALS_BV_27R1)& GET_TAG_BV(ALS_BV_27S1) & GET_TAG_BV(ALS_BV_27T1);

            SET_TAG_BV(ALS_BV_3P27P1AND, _3P27P1AND);
            SET_TAG_BV(ALS_BV_3P27Q1AND, _3P27Q1AND);
        }

        // SubLogic 3 _VAND
        {
            CMF_BOOL _3P59P1OR, _3P59Q1OR, _3P27Q1AND, _3P27P1AND;
            _3P59P1OR = GET_TAG_BV(ALS_BV_3P59P1OR);
            _3P59Q1OR = GET_TAG_BV(ALS_BV_3P59Q1OR);

            CMF_BOOL _VAND = _3P59P1OR & _3P59Q1OR;
            SET_TAG_BV(ALS_BV_VAND, _VAND);

            _3P59P1OR = GET_TAG_BV(ALS_BV_3P59P1OR);
            _3P27Q1AND = GET_TAG_BV(ALS_BV_3P27Q1AND);

            CMF_BOOL AND3_1 = _3P59P1OR & _3P27Q1AND;

            _3P59Q1OR = GET_TAG_BV(ALS_BV_3P59Q1OR);
            _3P27P1AND = GET_TAG_BV(ALS_BV_3P27P1AND);

            CMF_BOOL AND3_2 = _3P59Q1OR & _3P27P1AND;
            CMF_BOOL OR3_1 = AND3_1 | AND3_2;


            CMF_BOOL _VEXOR = OR3_1 & !GET_TAG_BV(ALS_BV_VAND);
            SET_TAG_BV(ALS_BV_VEXOR, _VEXOR);
        }

        //Voltage Count Pulse
        {
            CMF_BOOL PD4IN, _PD4OUT;
            CMF_BOOL _RESET;
            PD4IN = GET_TAG_BV(ALS_BV_VAND);
            _RESET = GET_TAG_BV(ALS_BV_NCVCP) | GET_TAG_BV(ALS_BV_NOVCP);
            SFB_DEF_PD_TIMER(PD4, PDTT_CYCLE, 1.5 , PDTT_SEC, 3);
            SFB_USE_PD_TIMER(PD4, PD4IN, _RESET, &_PD4OUT);

            CMF_BOOL _PD5IN;
            CMF_BOOL _PD5OUT;
            _PD5IN = GET_TAG_BV(ALS_BV_3P27Q1AND) & GET_TAG_BV(ALS_BV_3P27P1AND);
            SFB_DEF_PD_TIMER(PD5, PDTT_CYCLE, 5.0, PDTT_CYCLE,0);
            SFB_USE_PD_TIMER(PD5, _PD5IN, NULL, &_PD5OUT);

            CMF_BOOL _PD6OUT;
            CMF_BOOL PD6IN;
            PD6IN = GET_TAG_BV(ALS_BV_VEXOR);
            SFB_DEF_PD_TIMER(PD6,PDTT_CYCLE,5.0, PDTT_CYCLE, 0);
            SFB_USE_PD_TIMER(PD6, PD6IN, NULL, &_PD6OUT);

            CMF_BOOL _NCVCP;
            CMF_BOOL _ED3OUT;
            SFB_DEF_EDGE_DETR(ED3, EDT_RISING, 0);
            SFB_USE_EDGE_DETR(ED3, _PD5OUT, &_ED3OUT);
            _NCVCP = _PD4OUT & _ED3OUT;
            SET_TAG_BV(ALS_BV_NCVCP, _NCVCP);

            CMF_BOOL _NOVCP;
            CMF_BOOL _ED4OUT;
            SFB_DEF_EDGE_DETR(ED4, EDT_RISING, 0);
            SFB_USE_EDGE_DETR(ED4, _PD6OUT, &_ED4OUT);
            _NOVCP = _PD4OUT & _ED4OUT;
            SET_TAG_BV(ALS_BV_NOVCP, _NOVCP);

            CMF_BOOL _PD7OUT;
            SFB_DEF_PD_TIMER(PD7,PDTT_CYCLE,0, PDTT_CYCLE, 3);
            SFB_USE_PD_TIMER(PD7, _NCVCP, NULL, &_PD7OUT);

            CMF_BOOL _NON;
            CMF_BOOL _ED5IN;
            _ED5IN = _PD7OUT & ! GET_TAG_BV(ALS_BV_50L);
            SFB_DEF_EDGE_DETR(ED5, EDT_RISING, 0);
            SFB_USE_EDGE_DETR(ED5, _ED5IN, &_NON);

            SET_TAG_BV(ALS_BV_NON, _NON);
        }
}
