/*
 * AT_Logic_PowerSealin.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_PowerSealin()
{
    // Implement user logic
    CMF_BOOL ED1OUT;
    SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
    SFB_USE_EDGE_DETR(ED1, GET_TAG_SC_SCFG_UI(ALS_SC_PWR_ON), &ED1OUT);

    CMF_BOOL PD1IN;
    CMF_BOOL PD1OUT;
    PD1IN = GET_TAG_BV(ALS_BV_BATLOW) & !GET_TAG_MMI(ALS_MMI_LEDAC);
    SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 180, PDTT_SEC, 0);
    SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &PD1OUT);

    SFB_DEF_GBTV(_DOSL, CMF_BOOL, CMF_FALSE);
    _DOSL = (_DOSL | ED1OUT) & !PD1OUT;

    CMF_BOOL _PWSEALIN;
    _PWSEALIN = _DOSL;

    // Set Tag data
    SET_TAG_DO(ALS_DO_DOSL, _DOSL);
    SET_TAG_DO(ALS_DO_PWSEALIN, _PWSEALIN);
}


