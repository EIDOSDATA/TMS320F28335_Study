/*
 * AT_Logic_VITLockout.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_VIT_Lockout()
{



    ////////////////////////////////////
    // VIT Lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1_OUT, _OR2_OUT, _OR3_OUT, _OR4_OUT, _OR6_OUT, _OR7_OUT, _OR8_OUT,
             _OR9_OUT, _OR10_OUT, _OR11_OUT, _OR12_OUT, _OR13_OUT, _OR14_OUT, _OR15_OUT, _OR16_OUT;
        CMF_BOOL _AND1_OUT, _AND2_OUT;
        CMF_BOOL _ED1_OUT; /* LOCAL VARs */

        SFB_DEF_GBTV(_79LO1, CMF_BOOL, 0);
        SFB_DEF_GBTV(_79LO3, CMF_BOOL, 0);
        SFB_DEF_GBTV(_79LO4, CMF_BOOL, 0);
        SFB_DEF_GBTV(_79LO5, CMF_BOOL, 0);
        SFB_DEF_GBTV(_79LO6, CMF_BOOL, 0);
        SFB_DEF_GBTV(_79LO8, CMF_BOOL, 0);

        // Process phase
        _OR1_OUT = GET_TAG_BV(ALS_BV_LOCKTRIP) | GET_TAG_BV(ALS_BV_MTR) | GET_TAG_BV(ALS_BV_CF) | GET_TAG_BV(ALS_BV_TRF);
        _OR2_OUT = _79LO1 | _OR1_OUT;
        _OR3_OUT = GET_TAG_BV(ALS_BV_MRS) | GET_TAG_BV(ALS_BV_RS) | GET_TAG_BV(ALS_BV_79RSLT);
        _AND1_OUT = GET_TAG_BV(ALS_BV_79NORS) & GET_TAG_BV(ALS_BV_OP40);
        _OR4_OUT = _AND1_OUT | _OR3_OUT;
        _79LO1 = _OR2_OUT & !_OR4_OUT;
        SET_TAG_BV(ALS_BV_79LO1, _79LO1);


        //79LO2 has moved to VIT_Reset (Automatic close after reset)

        _OR6_OUT = _79LO3 | GET_TAG_BV(ALS_BV_DTL25);
        _79LO3 = _OR6_OUT & !_OR3_OUT;

        //Set Tag Phase
        SET_TAG_BV(ALS_BV_79LO3, _79LO3);

//        79LO3 = _79LO3;

        _OR7_OUT = GET_TAG_BV(ALS_BV_DTL15) | GET_TAG_BV(ALS_BV_DTL16) | GET_TAG_BV(ALS_BV_DTL23);
        _OR8_OUT = _79LO4 | _OR7_OUT;
        _OR9_OUT = GET_TAG_BV(ALS_BV_79NORS) | _OR3_OUT;
        _79LO4 = _OR8_OUT & !_OR9_OUT;
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_79LO4, _79LO4);


        _OR10_OUT = _79LO5 | GET_TAG_BV(ALS_BV_DTL14);
        _79LO5 = _OR10_OUT & !_OR9_OUT;
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_79LO5, _79LO5);

        _OR11_OUT = _79LO6 | GET_TAG_BV(ALS_BV_DTL17);
        _79LO6 = _OR11_OUT & !_OR3_OUT;
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_79LO6, _79LO6);

        _OR12_OUT = GET_TAG_BV(ALS_BV_DTL26) | GET_TAG_BV(ALS_BV_DTL27);
        _OR13_OUT = _79LO8 | _OR12_OUT;
        _OR14_OUT = _OR9_OUT | GET_TAG_BV(ALS_BV_NONCCL);
        _79LO8 = _OR13_OUT & !_OR14_OUT;
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_79LO8, _79LO8);

        _AND2_OUT = GET_TAG_BV(ALS_BV_79LO) & !GET_TAG_BV(ALS_BV_52A) & !GET_TAG_BV(ALS_BV_RS);
        _OR15_OUT = !GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) | !GET_TAG_BV(ALS_BV_VITEN);
        _OR16_OUT = _79LO6 | _79LO8 | GET_TAG_DI(ALS_DI_HLOCK) | _AND2_OUT | _OR15_OUT;


        CMF_BOOL _V79LO;
        _V79LO = _79LO1 | GET_TAG_BV(ALS_BV_79LO2) | _79LO3 | _79LO4 | _79LO5 | _OR16_OUT;

        // Set tag phase
        SET_TAG_BV(ALS_BV_V79LO, _V79LO);
    }

}
