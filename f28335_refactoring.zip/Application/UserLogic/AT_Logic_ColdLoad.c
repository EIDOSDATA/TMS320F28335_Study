/*
 * AT_Logic_ColdLoad.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_ColdLoad()
{
    ////////////////////////////////////
    // Cold Load Pickup - Restore Minimum Pickup
    ////////////////////////////////////
    {
        // Define phase
         CMF_BOOL _CLPSL, _RMTG, _RMTP;
         CMF_BOOL _OR1;
         CMF_BOOL PD1IN, PD2IN, PD3IN;

         // Process phase
         _OR1 = !( GET_TAG_LS_UI(ALS_LS_51P4M) ? 0 : 1 ) | !( GET_TAG_LS_UI(ALS_LS_51N4M) ? 0 : 1);
         PD1IN = !GET_TAG_BV(ALS_BV_52A) & _OR1 & GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP);
    //     SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC_VAR_UI, 0, ALS_LS_LLDD, PDTT_SEC, 0, 0);
         SFB_DEF_PD_TIMER_EX(PD1,
                             /*Pickup Timer*/
                             PDTT_TAG,      TAG_GRP_LS_UI,   ALS_LS_LLDD,
                             /*Dropout Timer*/
                             PDTT_NULL,     N_A,            N_A);

         SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &_CLPSL);

         PD2IN = !( GET_TAG_LS_F(ALS_LS_RMTPD) ? 0 : 1 ) & GET_TAG_BV(ALS_BV_CLPPH) & GET_TAG_BV(ALS_BV_52A);
    //     SFB_DEF_PD_TIMER_EX(PD2,PDTT_SEC_VAR_F, 0, ALS_LS_RMTPD, PDTT_SEC, 0, 0);
         SFB_DEF_PD_TIMER_EX(PD2,
                             /*Pickup Timer*/
                             PDTT_TAG,      TAG_GRP_LS_F,   ALS_LS_RMTPD,
                             /*Dropout Timer*/
                             PDTT_NULL,     N_A,            N_A);

         SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_RMTP);

         PD3IN = !( GET_TAG_LS_F(ALS_LS_RMTGD) ? 0 : 1 ) & GET_TAG_BV(ALS_BV_CLPGR) & GET_TAG_BV(ALS_BV_52A);
   //      SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_F, 0, ALS_LS_RMTGD, PDTT_SEC, 0, 0);
         SFB_DEF_PD_TIMER_EX(PD3,
                             /*Pickup Timer*/
                             PDTT_TAG,      TAG_GRP_LS_F,   ALS_LS_RMTGD,
                             /*Dropout Timer*/
                             PDTT_NULL,     N_A,            N_A);

         SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &_RMTG);

         // Set tag phase
         SET_TAG_BV(ALS_BV_CLPSL, _CLPSL);
         SET_TAG_BV(ALS_BV_RMTP, _RMTP);
         SET_TAG_BV(ALS_BV_RMTG, _RMTG);
    }

    //  Cold Load Pickup - Phase
    {
         CMF_BOOL PD4OUT;
         CMF_BOOL _AND2_1 = GET_TAG_BV(ALS_BV_3P59P1OR) & GET_TAG_BV(ALS_BV_50L);
         CMF_BOOL _OR2_1 = GET_TAG_BV(ALS_BV_51P1) | GET_TAG_BV(ALS_BV_51P3) | GET_TAG_BV(ALS_BV_50P1);
         CMF_BOOL _AND2_2 =  _AND2_1  & GET_TAG_BV(ALS_BV_52A) & !_OR2_1 ;

         CMF_BOOL PD4IN = _AND2_2 & GET_TAG_BV(ALS_BV_CLPPH);
     //    SFB_DEF_PD_TIMER_EX(PD4, PDTT_SEC_VAR_F, 0, ALS_LS_CLPPRS, PDTT_SEC, 0, 0);
         SFB_DEF_PD_TIMER_EX(PD4,
                             /*Pickup Timer*/
                             PDTT_TAG,      TAG_GRP_LS_F,   ALS_LS_CLPPRS,
                             /*Dropout Timer*/
                             PDTT_NULL,     N_A,            N_A);
         SFB_USE_PD_TIMER(PD4, PD4IN, NULL, &PD4OUT);

         CMF_BOOL _AND2_3 = GET_TAG_BV(ALS_BV_CLPSL) & !(GET_TAG_LS_UI(ALS_LS_51P4M) ? 0 : 1);
         CMF_BOOL _OR2_2 = _AND2_3 | GET_TAG_BV(ALS_BV_CLPPH);
         CMF_BOOL _OR2_3 = ( !GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP) | PD4OUT );
         CMF_BOOL _CLPPH = _OR2_2 & !_OR2_3;
         SET_TAG_BV(ALS_BV_CLPPH, _CLPPH);
    }

    // Cold Load Pickup - Ground
    {
         CMF_BOOL PD5OUT;
         CMF_BOOL _AND3_1 = GET_TAG_BV(ALS_BV_3P59P1OR) & GET_TAG_BV(ALS_BV_50L);
         CMF_BOOL _OR3_1 = GET_TAG_BV(ALS_BV_51N1) | GET_TAG_BV(ALS_BV_51N3) | GET_TAG_BV(ALS_BV_50N1);
         CMF_BOOL _AND3_2 = _AND3_1 & GET_TAG_BV(ALS_BV_52A) & !_OR3_1;
         CMF_BOOL PD5IN = _AND3_2 & GET_TAG_BV(ALS_BV_CLPGR);
    //     SFB_DEF_PD_TIMER_EX(PD5, PDTT_SEC_VAR_F, 0, ALS_LS_CLPGRS, PDTT_SEC, 0, 0);
         SFB_DEF_PD_TIMER_EX(PD5, PDTT_TAG, TAG_GRP_LS_F, ALS_LS_CLPGRS, N_A, N_A, N_A);
         SFB_USE_PD_TIMER(PD5, PD5IN, NULL, &PD5OUT);

         CMF_BOOL _AND3_3 = GET_TAG_BV(ALS_BV_CLPSL) & !(GET_TAG_LS_UI(ALS_LS_51N4M) ? 0 : 1);
         CMF_BOOL _OR3_2 = _AND3_3 | GET_TAG_BV(ALS_BV_CLPGR);
         CMF_BOOL _OR3_3 = (!GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP) | PD5OUT );
         CMF_BOOL _CLPGR = _OR3_2 & !_OR3_3;
         SET_TAG_BV(ALS_BV_CLPGR, _CLPGR);
    }
}
