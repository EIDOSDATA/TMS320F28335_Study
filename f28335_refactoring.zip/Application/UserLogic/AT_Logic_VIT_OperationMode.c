/*
 * AT_Logic_VITOperationMode.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"
CMF_VOID AT_Logic_VIT_OperationMode()
{
    ////////////////////////////////////
    // OP30 <--> OP40 ��ȯ
    ////////////////////////////////////
    {
    CMF_BOOL _ED4OUT;
    SFB_DEF_EDGE_DETR(ED4, EDT_RISING, 0); // or EDT_FALLING
    SFB_USE_EDGE_DETR(ED4, GET_TAG_NVV_UI(ALS_NVV_OP4), &_ED4OUT);

    CMF_BOOL _LT1RS;
    _LT1RS = !GET_TAG_NVV_UI(ALS_NVV_OP4) | GET_TAG_NVV_UI(ALS_NVV_OP3) | GET_TAG_NVV_UI(ALS_NVV_OP2) | GET_TAG_BV(ALS_BV_79NORS)
            | GET_TAG_BV(ALS_BV_LOCKTRIP) | (!GET_TAG_BV(ALS_BV_52A) & _ED4OUT);

    CMF_BOOL _ED0IN, _ED0OUT;
    _ED0IN = GET_TAG_BV(ALS_BV_52A) & GET_TAG_BV(ALS_BV_OP40) & !GET_TAG_BV(ALS_BV_TRIP);
    SFB_DEF_EDGE_DETR(ED0, EDT_RISING, 0); // or EDT_FALLING
    SFB_USE_EDGE_DETR(ED0, _ED0IN, &_ED0OUT);

    CMF_BOOL _PD0OUT;
    SFB_DEF_PD_TIMER(PD0, PDTT_CYCLE, 0, PDTT_CYCLE, 0.5);
    SFB_USE_PD_TIMER(PD0, _ED0OUT, NULL, &_PD0OUT);

    SFB_DEF_GBTV(_LT1OUT, CMF_BOOL, CMF_FALSE);
    _LT1OUT = ( _LT1OUT | _PD0OUT )  & !_LT1RS;

    CMF_BOOL _OP30 = GET_TAG_NVV_UI(ALS_NVV_OP3) | _LT1OUT;
    CMF_BOOL _OP40 = !GET_TAG_BV(ALS_BV_OP30) & GET_TAG_NVV_UI(ALS_NVV_OP4) | _ED4OUT;

    //set tag data
    SET_TAG_BV(ALS_BV_OP30, _OP30);
    SET_TAG_BV(ALS_BV_OP40, _OP40);
    }

    ////////////////////////////////////
    // Manual Lockout Reset for VIT Sequence
    ////////////////////////////////////

    CMF_BOOL _PD1OUT;
    SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 0, PDTT_CYCLE, 10);
    SFB_USE_PD_TIMER(PD1, GET_TAG_BV(ALS_BV_TRIP), NULL, &_PD1OUT);

    CMF_BOOL _ED1OUT;
    SFB_DEF_EDGE_DETR(ED1, EDT_FALLING, 0); // or EDT_FALLING
    SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_52A), &_ED1OUT);

    CMF_BOOL _MTR;
    _MTR = !_PD1OUT & _ED1OUT;

    //set tag data
    SET_TAG_BV(ALS_BV_MTR, _MTR);

    ////////////////////////////////////
    // Operation mode change
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1_OUT; /* LOCAL VARs */
        CMF_BOOL _OPC; /* SET TAG TARGET */

        // Process phase
        _OR1_OUT = GET_TAG_BV(ALS_BV_SOP2) | GET_TAG_BV(ALS_BV_SOP3) | GET_TAG_BV(ALS_BV_SOP4);

        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _OR1_OUT, &_OPC);

        // Set tag phase
        SET_TAG_BV(ALS_BV_OPC, _OPC);
    }

    ////////////////////////////////////
    // VIT Operation Mode
    ////////////////////////////////////

    CMF_BOOL _VITEN;
    _VITEN = GET_TAG_NVV_UI(ALS_NVV_OP2) | GET_TAG_NVV_UI(ALS_NVV_OP3) | GET_TAG_NVV_UI(ALS_NVV_OP4);
    //set tag data
    SET_TAG_BV(ALS_BV_VITEN, _VITEN);


    ////////////////////////////////////
    // Manual Close Reset for VIT Sequence
    ////////////////////////////////////

    CMF_BOOL _PD2OUT;
    SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 0, PDTT_CYCLE, 10);
    SFB_USE_PD_TIMER(PD2, GET_TAG_BV(ALS_BV_CLOSE), NULL, &_PD2OUT);

    CMF_BOOL _ED2OUT;
    SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0); // or EDT_FALLING
    SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_52A), &_ED2OUT);
    CMF_BOOL _MRS;
    _MRS = !_PD2OUT & _ED2OUT;

    //set tag data
    SET_TAG_BV(ALS_BV_MRS, _MRS);



}
