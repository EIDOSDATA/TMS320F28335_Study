/*
 * AT_Logic_Close.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_Close()
{
    ////////////////////////////////////
    //COMMAND CLOSE
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1, _OR2, _AND1, _AND2, _AND3, _AND4; //FB
        CMF_BOOL _CL; //SET TAG

        // Process phase
        _OR1 = GET_TAG_NVV_UI(ALS_NVV_ENHT) | GET_TAG_DI(ALS_DI_HLOCK);
        _AND1 = GET_TAG_NVV_UI(ALS_NVV_ENRT) & ( GET_TAG_RCM(ALS_RCM_CCLOSE) | GET_TAG_DI(ALS_DI_RCLOSE) );
        _AND2 = GET_TAG_MMI(ALS_MMI_PBCL) & !_OR1;

        _AND3 = !_OR1 & _AND1;
        _OR2 = _AND2 | _AND3;
        _AND4 = _OR2 & GET_TAG_DI(ALS_DI_SCH);
        _CL = _AND4;

        // Set tag phase
        SET_TAG_BV(ALS_BV_CL, _CL);
    }

    ////////////////////////////////////
    // SPRING CHARGE FAIL
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _AND1, _PD1OUT; //FB
        CMF_BOOL _SCHF; //SET TAG

        // Process phase
        //Added LEDSCH Logic
        CMF_BOOL LEDSCH;
        LEDSCH = GET_TAG_DI(ALS_DI_SCH);
        SET_TAG_MMI(ALS_MMI_LEDSCH, LEDSCH);

        _AND1 = !GET_TAG_DI(ALS_DI_SCH) & !GET_TAG_BV(ALS_BV_52A);

        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 10, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD1, _AND1, NULL, &_PD1OUT);

        _SCHF = _PD1OUT;

        // Set tag phase
        SET_TAG_BV(ALS_BV_SCHF, _SCHF);
    }

    ////////////////////////////////////
    // UNLATCH CLOSE
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _AND1, _OR1; //FB
        CMF_BOOL _ULCL; //SET TAG

        // Process phase
        _AND1 = GET_TAG_NVV_UI(ALS_NVV_ENHT) & !GET_TAG_BV(ALS_BV_CLOSE);
        _OR1 = GET_TAG_BV(ALS_BV_TRIP) | GET_TAG_BV(ALS_BV_52A) | _AND1 | GET_TAG_DI(ALS_DI_HLOCK) | GET_TAG_BV(ALS_BV_SCHF);
        _ULCL = _OR1;

        // Set tag phase
        SET_TAG_BV(ALS_BV_ULCL, _ULCL);
    }

    ////////////////////////////////////
    // RECLOSE SUPERVISION
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1, _OR2, _OR3, _OR4, _OR5, _OR5_1, _OR6, _OR7, _AND1, _AND2, _AND3, _AND4, _AND4_1, _AND4_2, _AND5, _AND6;
        CMF_BOOL _PD1OUT, _PD2OUT, _PD3OUT, _ED1OUT;

        CMF_BOOL _RCSF, _CLF, _CLOSE; //SET TAG
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(GBTV2, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(GBTV3, CMF_BOOL, CMF_FALSE);

        // Process phase
        _OR1 = GET_TAG_BV(ALS_BV_79OITO) | GBTV1;
        _OR2 = GET_TAG_BV(ALS_BV_CLOSE) | GET_TAG_BV(ALS_BV_79LO) | GET_TAG_BV(ALS_BV_52A) | GET_TAG_BV(ALS_BV_TRIP) | GBTV2 | GBTV3;
        _AND1 = _OR1 & !_OR2;
        GBTV1 = _AND1;

        _OR3 = GET_TAG_BV(ALS_BV_79OITO) | _AND1;
        _AND2 = _AND1 & !GET_TAG_DI(ALS_DI_SCH);

        _AND3 = GET_TAG_BV(ALS_BV_NONCCL) & GET_TAG_DI(ALS_DI_SCH);
        _AND4 = GET_TAG_DI(ALS_DI_SCH) & _OR3;
        GBTV3 = _AND4;

        //SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC_VAR_UI, 0, ALS_SC_79CLSD, PDTT_SEC, 0,0);
       SFB_DEF_PD_TIMER_EX(PD1, PDTT_TAG, TAG_GRP_SC_UI, ALS_SC_79CLSD, PDTT_SEC, N_A, N_A)

       SFB_USE_PD_TIMER(PD1, _AND2, NULL, &_PD1OUT);
       GBTV2 = _PD1OUT;
       _RCSF = _PD1OUT;

       _OR4 = _AND3 | _AND4;
       _OR5 = GET_TAG_BV(ALS_BV_CL) | _OR4;

       CMF_FLOAT32 ANG1, ANG2, ANG3;
       CMF_FLOAT32 ANG1_1, ANG2_1, ANG3_1;
       CMF_UINT16 ANG1_2, ANG2_2, ANG3_2;

       SFB_DEF_DIFF_ABS_ANGLE(ANG1);
       ANG1_1 = SFB_USE_DIFF_ABS_ANGLE(ANG1, GET_TAG_AI_F(ALS_AI_ANG_VA), GET_TAG_AI_F(ALS_AI_ANG_VR));
       ANG1_2 = (CMF_UINT16)((ANG1_1 > 15.0) ? 1 : 0);

       SFB_DEF_DIFF_ABS_ANGLE(ANG2);
       ANG2_1 = SFB_USE_DIFF_ABS_ANGLE(ANG2, GET_TAG_AI_F(ALS_AI_ANG_VB), GET_TAG_AI_F(ALS_AI_ANG_VS));
       ANG2_2 = (CMF_UINT16)((ANG2_1 > 15.0) ? 1 : 0);

       SFB_DEF_DIFF_ABS_ANGLE(ANG3);
       ANG3_1 = SFB_USE_DIFF_ABS_ANGLE(ANG3, GET_TAG_AI_F(ALS_AI_ANG_VC), GET_TAG_AI_F(ALS_AI_ANG_VT));
       ANG3_2 = (CMF_UINT16)((ANG3_1 > 15.0) ? 1 : 0);

       _OR5_1 = ANG1_2 | ANG2_2 | ANG3_2 ;

       _AND4_1 =  _OR5_1 & GET_TAG_BV(ALS_BV_VAND);

       _AND4_2 = !_AND4_1 & _OR5;

       SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED1, _AND4_2, &_ED1OUT);

       SFB_DEF_GBTV(GBTV4, CMF_BOOL, CMF_FALSE);
       _OR6 = GBTV4 | _ED1OUT;

       CMF_BOOL PD2IN;
       PD2IN = GET_TAG_BV(ALS_BV_CLF);
       SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 10, PDTT_SEC, 0);
       SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_PD2OUT);
       _OR7 = GET_TAG_BV(ALS_BV_ULCL) |  _PD2OUT;

       _AND5 =  _OR6 & !_OR7;
       GBTV4 = _AND5;

       SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 20, PDTT_CYCLE, 0);
       SFB_USE_PD_TIMER(PD3, _AND5, NULL, &_PD3OUT);
       _CLF = _PD3OUT;

       _AND6 = !_CLF & _AND5;
       _CLOSE = _AND6;

       // Set tag phase
       SET_TAG_BV(ALS_BV_RCSF, _RCSF);
       SET_TAG_BV(ALS_BV_CLF, _CLF);
       SET_TAG_BV(ALS_BV_CLOSE, _CLOSE);
       SET_TAG_DO(ALS_DO_CLOSE, _CLOSE);

    }
}
