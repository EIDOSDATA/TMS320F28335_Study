/*
 * AT_Logic_Directional.c
 *
 *  Created on: 2022. 4. 4.
 *      Author: yonga
 */

#include "Plaffom_Interface.h"


CMF_VOID AT_Logic_Directional()
{
// Directional
//67PTC
    CMF_FLOAT32 RT1OUT;
    SFB_DEF_SQRT_F(RT1);
    SFB_USE_SQRT_F(RT1, 3.0, &RT1OUT);

    CMF_FLOAT32 _V1P_F;
    _V1P_F = ((CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_V1P0)/100.0) * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;
    SET_TAG_NMV_F(ALS_NMV_V1P, _V1P_F);

    CMF_BOOL temp14, temp15, temp17, temp18;
    temp14 = (( GET_TAG_AI_F(ALS_AI_RMS_V1) > GET_TAG_NMV_F(ALS_NMV_V1P) ) ? 1 : 0);

    CMF_FLOAT32 _TAWP_POS, _TAWP_NEG, _ANGP;

    _TAWP_POS = (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_MTAP) + GET_TAG_LS_F(ALS_LS_TAWP);
    SFB_DEF_FIT_ANG_RANGE(ANG1);
    _TAWP_POS = SFB_USE_FIT_ANG_RANGE(ANG1, _TAWP_POS);

    _ANGP = GET_TAG_AI_F(ALS_AI_ANG_I1) - GET_TAG_AI_F(ALS_AI_ANG_V1);
    SFB_DEF_FIT_ANG_RANGE(ANG2);
    _ANGP = SFB_USE_FIT_ANG_RANGE(ANG2, _ANGP);

    _TAWP_NEG = (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_MTAP) - GET_TAG_LS_F(ALS_LS_TAWP);
    SFB_DEF_FIT_ANG_RANGE(ANG3);
    _TAWP_NEG = SFB_USE_FIT_ANG_RANGE(ANG3, _TAWP_NEG);

    if(_TAWP_NEG < _TAWP_POS)
        {
            temp15 = (((_TAWP_NEG < _ANGP) && (_TAWP_POS > _ANGP))) ? 1 : 0;
        }
    else
        {
            temp15 = (((_TAWP_NEG < _ANGP) || (_TAWP_POS > _ANGP))) ? 1 : 0;
        }

    temp17 = temp14 & temp15;
    temp18 = ((GET_TAG_LS_UI(ALS_LS_E67P) == 1) ? 1 : 0) & temp17;

    CMF_BOOL _67PTC;
    _67PTC = ((GET_TAG_LS_UI(ALS_LS_E67P) == 0) ? 1 : 0) | temp18;
    //Set tag Phase
    SET_TAG_BV(ALS_BV_67PTC, _67PTC);


    ///////////////////////////////////////////////
    //67NTC
    ///////////////////////////////////////////////
    CMF_FLOAT32 _3V0P_F;
    _3V0P_F = ((CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_3V0P0) / 100.0 ) * GET_TAG_SC_UCFG_F(ALS_SC_SVOL) / RT1OUT;
    SET_TAG_NMV_F(ALS_NMV_3V0P, _3V0P_F);

    CMF_BOOL temp19, temp20, temp22, temp23;
    temp19 = (( 3.0 * GET_TAG_AI_F(ALS_AI_RMS_V0) > GET_TAG_NMV_F(ALS_NMV_3V0P) ) ? 1 : 0);

    CMF_FLOAT32 _TAWN_POS, _TAWN_NEG, _ANGN;

    _TAWN_NEG = (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_MTAN) - GET_TAG_LS_F(ALS_LS_TAWN);
    SFB_DEF_FIT_ANG_RANGE(ANG4);
    _TAWN_NEG = SFB_USE_FIT_ANG_RANGE(ANG4, _TAWN_NEG);

    _ANGN = GET_TAG_AI_F(ALS_AI_ANG_I0) - GET_TAG_AI_F(ALS_AI_ANG_V0);
    SFB_DEF_FIT_ANG_RANGE(ANG5);
    _ANGN = SFB_USE_FIT_ANG_RANGE(ANG5, _ANGN);

    _TAWN_POS = (CMF_FLOAT32)GET_TAG_LS_UI(ALS_LS_MTAN) + GET_TAG_LS_F(ALS_LS_TAWN);
    SFB_DEF_FIT_ANG_RANGE(ANG6);
    _TAWN_POS = SFB_USE_FIT_ANG_RANGE(ANG6, _TAWN_POS);

    if(_TAWN_POS < _TAWN_NEG)
         {
             temp20 = (((_TAWN_POS < _ANGN) && (_TAWN_NEG > _ANGN))) ? 1 : 0;
         }
     else
         {
             temp20 = (((_TAWN_POS < _ANGN) || (_TAWN_NEG > _ANGN))) ? 1 : 0;
         }

     temp22 = temp19 & temp20 ;
     temp23 = ((GET_TAG_LS_UI(ALS_LS_E67N) == 1) ? 1 : 0) & !temp22;

     CMF_BOOL _67NTC;
     _67NTC = ((GET_TAG_LS_UI(ALS_LS_E67N) == 0) ? 1 : 0) | temp23 ;
     //Set tag Phase
     SET_TAG_BV(ALS_BV_67NTC, _67NTC);

}
