/*
 * AT_Logic_VITReset.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_VIT_Reset()
{
    ////////////////////////////////////
    // VIT Reset (Sequence / Count)
    ////////////////////////////////////
    {
        CMF_BOOL _TEMP1;
        CMF_BOOL _TEMP1_1;
        _TEMP1 = GET_TAG_BV(ALS_BV_VAND) & (!(GET_TAG_BV(ALS_BV_FPU) | GET_TAG_BV(ALS_BV_TRIP)));
        _TEMP1_1 = GET_TAG_BV(ALS_BV_VAND) & (!(GET_TAG_BV(ALS_BV_FPU) | GET_TAG_BV(ALS_BV_TRIP))) & GET_TAG_BV(ALS_BV_52A);

        CMF_BOOL _79NCRS;
     //   SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC_VAR_UI, 0, ALS_LS_NCRD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD1, PDTT_TAG, TAG_GRP_LS_UI, ALS_LS_NCRD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD1, _TEMP1_1, NULL, &_79NCRS);

        CMF_BOOL _TEMP2;
        _TEMP2 = (GET_TAG_NVV_UI(ALS_NVV_OP4) | GET_TAG_BV(ALS_BV_OP40)) & (_TEMP1 & !GET_TAG_BV(ALS_BV_52A));

        CMF_BOOL _79NORS;
        CMF_UINT16 NORD_PD_Timer; //Define NORD_PD_Timer
        NORD_PD_Timer = GET_TAG_LS_UI(ALS_LS_NCRD); //NORD PD Timer = NCRD PD Timer
        SET_TAG_NMV_UI(ALS_NMV_NORD, NORD_PD_Timer);

     //   SFB_DEF_PD_TIMER_EX(PD2, PDTT_SEC_VAR_UI, 0, ALS_NMV_NORD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD2, PDTT_TAG, TAG_GRP_NMV_UI, ALS_NMV_NORD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD2, _TEMP2, NULL, &_79NORS);

        CMF_BOOL _TEMP3;
        _TEMP3 = (_TEMP1 & !GET_TAG_BV(ALS_BV_52A)) & GET_TAG_BV(ALS_BV_OP30) & GET_TAG_LS_UI(ALS_LS_ENARS) & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT);

        CMF_BOOL _79ARS;
        CMF_UINT16 ARD_PD_Timer; //Define ARD_PD_Timer
        ARD_PD_Timer = GET_TAG_NMV_UI(ALS_NMV_NORD); //ARD PD Timer = NORD PD Timer
        SET_TAG_NMV_UI(ALS_NMV_ARD, ARD_PD_Timer);

    //    SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_UI, 0, ALS_NMV_ARD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_NMV_UI, ALS_NMV_ARD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, _TEMP3, NULL, &_79ARS);

        CMF_BOOL _TEMP4;
        _TEMP4 = (GET_TAG_BV(ALS_BV_CNCV1) | GET_TAG_BV(ALS_BV_CNOV1) | GET_TAG_BV(ALS_BV_FCN1)) & GET_TAG_BV(ALS_BV_VAND);

        CMF_BOOL _79FRS;
    //    SFB_DEF_PD_TIMER_EX(PD4, PDTT_SEC_VAR_UI, 0, ALS_LS_FRD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD4, PDTT_TAG, TAG_GRP_LS_UI, ALS_LS_FRD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD4, _TEMP4, NULL, &_79FRS);

        //set tag data
        SET_TAG_BV(ALS_BV_79NCRS, _79NCRS);
        SET_TAG_BV(ALS_BV_79NORS, _79NORS);
        SET_TAG_BV(ALS_BV_79ARS, _79ARS);
        SET_TAG_BV(ALS_BV_79FRS, _79FRS);
    }
    ////////////////////////////////////
    // Automatic close after reset
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED5_OUT, _ED6_OUT, _OR5_OUT, _OR6_OUT, _AND3_OUT, _AND4_OUT, _PD3_OUT; /* LOCAL VARs */
        CMF_BOOL _PORS, _RS, _RSCL; /* SET TAG TARGET */
        SFB_DEF_GBTV(GBTV2, CMF_BOOL, 0);

        // Process phase
        //// VIT Lockout_79LO2 Condition
        {
            // Define phase
            CMF_BOOL _79LO2;
            CMF_BOOL ED0_1IN, ED0_2IN, ED0_3IN;
            CMF_BOOL ED0_1OUT, ED0_2OUT, ED0_3OUT;

            // Process phase
            SFB_DEF_EDGE_DETR(ED0_1, EDT_RISING, 0);
            SFB_DEF_EDGE_DETR(ED0_2, EDT_RISING, 0);
            SFB_DEF_EDGE_DETR(ED0_3, EDT_RISING, 0);

            ED0_1IN = (CMF_BOOL) (GET_TAG_SC_SCFG_UI(ALS_SC_PWR_ON) ? CMF_TRUE : CMF_FALSE);
            ED0_2IN = (CMF_BOOL) (GET_TAG_SC_SCFG_UI(ALS_SC_CFG_UPDATED) ? CMF_TRUE : CMF_FALSE);
            ED0_3IN = (CMF_BOOL) (GET_TAG_BV(ALS_BV_OPC) ? CMF_TRUE : CMF_FALSE);
            SFB_USE_EDGE_DETR(ED0_1, ED0_1IN, &ED0_1OUT);
            SFB_USE_EDGE_DETR(ED0_2, ED0_2IN, &ED0_2OUT);
            SFB_USE_EDGE_DETR(ED0_3, ED0_3IN, &ED0_3OUT);

            CMF_BOOL _PD0IN;
            _PD0IN = ED0_1OUT | ED0_2OUT | ED0_3OUT;

            SFB_DEF_PD_TIMER(PD0, PDTT_CYCLE, 0, PDTT_CYCLE, 0.5);
            SFB_USE_PD_TIMER(PD0, _PD0IN, NULL, &_79LO2);

            SET_TAG_BV(ALS_BV_79LO2, _79LO2);

        }

        SFB_DEF_EDGE_DETR(ED5, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED5, GET_TAG_BV(ALS_BV_79ARS), &_ED5_OUT);

        CMF_BOOL PD2IN;
        PD2IN = GET_TAG_BV(ALS_BV_79LO2);
        SFB_DEF_PD_TIMER(PD2, PDTT_CYCLE, 0.5, PDTT_CYCLE, 0.5);
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_PORS);

        _RS = _ED5_OUT | GET_TAG_BV(ALS_BV_MLRS) | _PORS;

        _AND3_OUT = GET_TAG_LS_UI(ALS_LS_ENACL) & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_OP30) & _RS;

        _OR5_OUT = _AND3_OUT | GBTV2;

        SFB_DEF_EDGE_DETR(ED6, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED6, GET_TAG_BV(ALS_BV_V79LO), &_ED6_OUT);

        _OR6_OUT = GET_TAG_BV(ALS_BV_52A) | GET_TAG_BV(ALS_BV_NCCL) | _ED6_OUT | GET_TAG_BV(ALS_BV_RSCL) | !GET_TAG_BV(ALS_BV_VITEN);

        _AND4_OUT = _OR5_OUT & !_OR6_OUT;
        GBTV2 = _AND4_OUT;

        CMF_BOOL PD3IN;
        PD3IN = GET_TAG_BV(ALS_BV_VAND);
        SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 0, PDTT_CYCLE, 20.0);
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &_PD3_OUT);

        _RSCL = _AND4_OUT & _PD3_OUT & GET_TAG_BV(ALS_BV_VEXOR);

        // Set tag phase
        SET_TAG_BV(ALS_BV_PORS, _PORS);
        SET_TAG_BV(ALS_BV_RS, _RS);
        SET_TAG_BV(ALS_BV_RSCL, _RSCL);
    }

}
