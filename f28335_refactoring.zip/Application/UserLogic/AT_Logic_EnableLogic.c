/*
 * AT_Logic_EnableLogic.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"


CMF_VOID AT_Logic_EnableLogic()
{
    ////////////////////////////////////
    // Remote Control Enable / Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED5OUT;
        CMF_BOOL _OR5_1, _AND5_1, _ENRT, _LEDRT;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED5, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED5, GET_TAG_MMI(ALS_MMI_PBRT), &_ED5OUT);

        _OR5_1 = (_ED5OUT & !GET_TAG_NVV_UI(ALS_NVV_ENRT)) | GET_TAG_NVV_UI(ALS_NVV_ENRT);
        _AND5_1 = _ED5OUT & GET_TAG_NVV_UI(ALS_NVV_ENRT);
        _ENRT = _OR5_1 & !_AND5_1;
        _LEDRT = _OR5_1 & !_AND5_1;

        //Set tag phase
        SET_TAG_NVV_UI_WO_EV(ALS_NVV_ENRT, _ENRT);
        SET_TAG_MMI(ALS_MMI_LEDRT, _LEDRT);
    }

    ////////////////////////////////////
    // Protection Enable / Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED1OUT, _ED1_1OUT;
        CMF_BOOL _OR1_1, _AND1_1, _OR1_2, _AND1_2;
        CMF_BOOL _ENPROT;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, GET_TAG_MMI(ALS_MMI_PBPT), &_ED1OUT);

        SFB_DEF_EDGE_DETR(ED1_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1_1, GET_TAG_RCM(ALS_RCM_CPT), &_ED1_1OUT);

        _OR1_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED1_1OUT) | _ED1OUT;

        _AND1_1 = !GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & _OR1_1;
        _OR1_2 = _AND1_1 | GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT);
        _AND1_2 = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & _OR1_1;

        _ENPROT = _OR1_2 & !_AND1_2;

        // Set tag phase
//        SET_TAG_BV(ALS_BV_ENPROT, _ENPROT);
        SET_TAG_SC_UCFG_UI(ALS_SC_ENPROT, _ENPROT);
        SET_TAG_MMI(ALS_MMI_LEDPROT, _ENPROT);
    }

    ////////////////////////////////////
    // Reclose Enable / Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED2OUT;
        CMF_BOOL _ED2_1OUT;
        CMF_BOOL _OR2_1, _79EN, _OR2_2, _AND2_1, _AND2_2, _AND2_3;
        CMF_BOOL _OR2_3, _OR2_4, _OR2_5, _ENRC, _LEDRC;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED2, GET_TAG_MMI(ALS_MMI_PBRC), &_ED2OUT);

        SFB_DEF_EDGE_DETR(ED2_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED2_1, GET_TAG_RCM(ALS_RCM_CRC), &_ED2_1OUT);

        _OR2_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED2_1OUT) | _ED2OUT;
        _79EN = GET_TAG_BV(ALS_BV_79EN);

//        if(_OR2_1)
//            _79EN=1;
        _OR2_2 = GET_TAG_BV(ALS_BV_79RS) | GET_TAG_BV(ALS_BV_79CY) | GET_TAG_BV(ALS_BV_79LO);
        _AND2_1 = _OR2_1 & _79EN;
        _AND2_2 = _AND2_1 & !GET_TAG_NVV_UI(ALS_NVV_ENRC);
        _AND2_3 = _AND2_1 & GET_TAG_NVV_UI(ALS_NVV_ENRC);

        _OR2_3 = _AND2_2 |  GET_TAG_NVV_UI(ALS_NVV_ENRC);
        _OR2_4 = _79EN | !_OR2_2;
        _OR2_5 = _AND2_3 | !_OR2_4;

        _ENRC = _OR2_3 & !_OR2_5;
        _LEDRC = _OR2_3 & !_OR2_5;

        // Set tag phase
        SET_TAG_NVV_UI_WO_EV(ALS_NVV_ENRC, _ENRC);
        SET_TAG_MMI(ALS_MMI_LEDRC, _LEDRC);
    }

    ////////////////////////////////////
    // Ground Protection Enable / Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED3OUT, _ED3_1OUT;
        CMF_BOOL _OR3_1, _OR3_2, _AND3_1, _ENGND, _LEDGND;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED3, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED3, GET_TAG_MMI(ALS_MMI_PBGND), &_ED3OUT);

        SFB_DEF_EDGE_DETR(ED3_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED3_1, GET_TAG_RCM(ALS_RCM_CGND), &_ED3_1OUT);

        _OR3_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED3_1OUT) | _ED3OUT;
        _OR3_2 = (!GET_TAG_SC_UCFG_UI(ALS_SC_ENGND) & _OR3_1) | GET_TAG_SC_UCFG_UI(ALS_SC_ENGND);
        _AND3_1 = GET_TAG_SC_UCFG_UI(ALS_SC_ENGND) & _OR3_1;
        _ENGND = _OR3_2 & !_AND3_1;
        _LEDGND = _OR3_2 & !_AND3_1;

        // Set tag phase
        SET_TAG_SC_UCFG_UI(ALS_SC_ENGND, _ENGND);
        SET_TAG_MMI(ALS_MMI_LEDGND, _LEDGND);
    }

    ////////////////////////////////////
    // SEF Protection Enable / Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED4OUT, _ED4_1OUT;
        CMF_BOOL _OR4_1, _OR4_2, _AND4_1;
        CMF_BOOL _ENSEF, _LEDSEF;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED4, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED4, GET_TAG_MMI(ALS_MMI_PBSEF), &_ED4OUT);

        SFB_DEF_EDGE_DETR(ED4_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED4_1, GET_TAG_RCM(ALS_RCM_CSEF), &_ED4_1OUT);

        _OR4_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED4_1OUT) | _ED4OUT;

        _OR4_2 = (!GET_TAG_SC_UCFG_UI(ALS_SC_ENSEF) & _OR4_1) | GET_TAG_SC_UCFG_UI(ALS_SC_ENSEF);
        _AND4_1 = GET_TAG_SC_UCFG_UI(ALS_SC_ENSEF) & _OR4_1;

        _ENSEF = _OR4_2 & !_AND4_1;
        _LEDSEF = _OR4_2 & !_AND4_1;

        // Set tag phase
        SET_TAG_SC_UCFG_UI(ALS_SC_ENSEF, _ENSEF);
        SET_TAG_MMI(ALS_MMI_LEDSEF, _LEDSEF);
    }



    ////////////////////////////////////
    // Cold Load Enable/Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED6OUT, _ED6_1OUT;
        CMF_BOOL _OR6_1, _OR6_2, _AND6_1, _ENCLP, _LEDCLP;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED6, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED6, GET_TAG_MMI(ALS_MMI_PBCLP), &_ED6OUT);

        SFB_DEF_EDGE_DETR(ED6_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED6_1, GET_TAG_RCM(ALS_RCM_CCLP), &_ED6_1OUT);

        _OR6_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED6_1OUT) | _ED6OUT;

        _OR6_2 = (!GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP) & _OR6_1) | GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP);
        _AND6_1 = GET_TAG_SC_UCFG_UI(ALS_SC_ENCLP) & _OR6_1;

        _ENCLP = _OR6_2 & !_AND6_1;
        _LEDCLP = _OR6_2 & !_AND6_1;

        // Set tag phase
        SET_TAG_SC_UCFG_UI(ALS_SC_ENCLP, _ENCLP);
        SET_TAG_MMI(ALS_MMI_LEDCLP, _LEDCLP);
    }

    ////////////////////////////////////
    // Radial N/C Mode Enable/Disable & LED
    ////////////////////////////////////
    {
            // Define phase
       CMF_BOOL _ED7OUT;
       CMF_BOOL _ED7_1OUT;
       CMF_BOOL OR7_1, OR7_2, OR7_3, _SOP2, _OP2, _LEDRNC;

       //CMF_BOOL AND7_1;
       CMF_BOOL AND7_2;

       // Process phase
       /* Push Button -> MMI task will do */
       SFB_DEF_EDGE_DETR(ED7, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED7, GET_TAG_MMI(ALS_MMI_PBRNC), &_ED7OUT);
       SFB_DEF_EDGE_DETR(ED7_1, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED7_1, GET_TAG_RCM(ALS_RCM_CRNC), &_ED7_1OUT);
       OR7_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED7_1OUT) | _ED7OUT;
       _SOP2 = OR7_1 & !GET_TAG_NVV_UI(ALS_NVV_OP2);
       AND7_2 = OR7_1 & GET_TAG_NVV_UI(ALS_NVV_OP2);
       OR7_2 = _SOP2 | GET_TAG_NVV_UI(ALS_NVV_OP2);
       OR7_3 = AND7_2 | GET_TAG_BV(ALS_BV_SOP3) | GET_TAG_BV(ALS_BV_SOP4);
       _OP2 = OR7_2 & !OR7_3;
       _LEDRNC = OR7_2 & !OR7_3;
       // Set tag phase
       SET_TAG_BV(ALS_BV_SOP2, _SOP2);
       SET_TAG_NVV_UI(ALS_NVV_OP2, _OP2);
       SET_TAG_MMI(ALS_MMI_LEDRNC, _LEDRNC);
    }
   ////////////////////////////////////
   // Loop N/C Mode Enable/Disable & LED(1)
   ////////////////////////////////////
    {
       // Define phase
       CMF_BOOL _ED8OUT, _ED8_1OUT;
       CMF_BOOL OR8_1, OR8_2, OR8_3,  AND8_2;
       CMF_BOOL _SOP2, _SOP3, _SOP4, _OP3, _LEDLNC;

       // Process phase
       /* Push Button -> MMI task will do */
       SFB_DEF_EDGE_DETR(ED8, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED8, GET_TAG_MMI(ALS_MMI_PBLNC), &_ED8OUT);
       SFB_DEF_EDGE_DETR(ED8_1, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED8_1, GET_TAG_RCM(ALS_RCM_CLNC), &_ED8_1OUT);
       OR8_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED8_1OUT) | _ED8OUT;
       _SOP3 = OR8_1 & !GET_TAG_NVV_UI(ALS_NVV_OP3);
       AND8_2 = OR8_1 & GET_TAG_NVV_UI(ALS_NVV_OP3);
       _SOP2 = GET_TAG_BV(ALS_BV_SOP2);
       _SOP4 = GET_TAG_BV(ALS_BV_SOP4);
       OR8_2 = _SOP3 | GET_TAG_NVV_UI(ALS_NVV_OP3);
       OR8_3 = AND8_2 | _SOP2 | _SOP4;
       _OP3 = OR8_2 & !OR8_3;
       _LEDLNC = (OR8_2 & !OR8_3) | GET_TAG_BV(ALS_BV_OP30);
       SET_TAG_BV(ALS_BV_SOP3, _SOP3);
       SET_TAG_NVV_UI(ALS_NVV_OP3, _OP3);
       SET_TAG_MMI(ALS_MMI_LEDLNC, _LEDLNC);
    }
   ////////////////////////////////////
   // Loop N/O Mode Enable/Disable & LED(2)
   ////////////////////////////////////
    {
       // Define phase
       CMF_BOOL _ED9OUT, _ED9_1OUT ;
       CMF_BOOL OR9_1, OR9_2, OR9_3, OR9_4,  AND9_2, AND9_3, AND9_4, AND9_5;
       CMF_BOOL _SOP2, _SOP3, _SOP4, _OP4, _OP30_1;

       SFB_DEF_GBTV(GBTV9_2, CMF_BOOL, CMF_FALSE);
       // Process phase
       /* Push Button -> MMI task will do */
       SFB_DEF_EDGE_DETR(ED9, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED9, GET_TAG_MMI(ALS_MMI_PBLNO), &_ED9OUT);
       SFB_DEF_EDGE_DETR(ED9_1, EDT_RISING, 0);
       SFB_USE_EDGE_DETR(ED9_1, GET_TAG_RCM(ALS_RCM_CLNO), &_ED9_1OUT);
       OR9_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED9_1OUT) | _ED9OUT;
       _SOP4 = OR9_1 & !GET_TAG_NVV_UI(ALS_NVV_OP4);
       AND9_2 = OR9_1 & GET_TAG_NVV_UI(ALS_NVV_OP4);
       _SOP2 = GET_TAG_BV(ALS_BV_SOP2);
       _SOP3 = GET_TAG_BV(ALS_BV_SOP3);
       OR9_2 = _SOP4 | GET_TAG_NVV_UI(ALS_NVV_OP4);
       OR9_3 = AND9_2 | _SOP2 | _SOP3;
       _OP4 = OR9_2 & !OR9_3;
       _OP30_1 = GET_TAG_BV(ALS_BV_OP30);
       AND9_3 = _OP4 & !_OP30_1;
       AND9_4 = _OP4 & _OP30_1;
       AND9_5 = AND9_4 & !GBTV9_2;
       SFB_DEF_PD_TIMER(PD9_2, PDTT_SEC, 1.0, PDTT_SEC, 1.0);
       SFB_USE_PD_TIMER(PD9_2, AND9_5, NULL, &GBTV9_2);
       OR9_4 = AND9_3 | GBTV9_2;

       // Set tag phase
       SET_TAG_BV(ALS_BV_SOP4, _SOP4);
       SET_TAG_NVV_UI(ALS_NVV_OP4, _OP4);
       SET_TAG_MMI(ALS_MMI_LEDLNO, OR9_4);
    }

    ////////////////////////////////////
    // Hot Line Tag Enable/Disable & LED
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED10OUT;
        CMF_BOOL _ED10_1OUT;
        CMF_BOOL OR10_1, OR10_2, AND10_1, AND10_2, AND10_3;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED10, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED10, GET_TAG_MMI(ALS_MMI_PBHT), &_ED10OUT);

        SFB_DEF_EDGE_DETR(ED10_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED10_1, GET_TAG_RCM(ALS_RCM_CHT), &_ED10_1OUT);

        OR10_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED10_1OUT) | _ED10OUT;

        AND10_1 = OR10_1 & !GET_TAG_NVV_UI(ALS_NVV_ENHT);
        AND10_2 = OR10_1 & GET_TAG_NVV_UI(ALS_NVV_ENHT);

        OR10_2 = AND10_1 | GET_TAG_NVV_UI(ALS_NVV_ENHT);
        AND10_3 = OR10_2 & !AND10_2;

        // Set tag phase
        SET_TAG_NVV_UI_WO_EV(ALS_NVV_ENHT, AND10_3);
        SET_TAG_MMI(ALS_MMI_LEDHT, AND10_3);
    }

    ////////////////////////////////////
    // Power Flow (CT Direction) Setting
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED11_1OUT, _ED11_2OUT, _ED11_3OUT, _ED11_4OUT;
        CMF_BOOL OR11_1, OR11_2, OR11_3, OR11_4, AND11_1, AND11_2;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED11_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_1, GET_TAG_MMI(ALS_MMI_PBA2R), &_ED11_1OUT);

        SFB_DEF_EDGE_DETR(ED11_2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_2, GET_TAG_RCM(ALS_RCM_CA2R), &_ED11_2OUT);

        OR11_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED11_2OUT) | _ED11_1OUT;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED11_3, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_3, GET_TAG_MMI(ALS_MMI_PBR2A), &_ED11_3OUT);

        SFB_DEF_EDGE_DETR(ED11_4, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_4, GET_TAG_RCM(ALS_RCM_CR2A), &_ED11_4OUT);
        OR11_2 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED11_4OUT) | _ED11_3OUT;

        OR11_3 = GET_TAG_BV(ALS_BV_ENA2R) | OR11_1;
        OR11_4 = GET_TAG_BV(ALS_BV_ENR2A) | OR11_2;

        AND11_1 = OR11_3 & !OR11_2;
        AND11_2 = !OR11_1 & OR11_4;

        // Set tag phase
        SET_TAG_BV(ALS_BV_ENA2R, AND11_1);
        SET_TAG_BV(ALS_BV_ENR2A, AND11_2);

        CMF_BOOL _ED11_5OUT;

        SFB_DEF_EDGE_DETR(ED11_5, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_5, AND11_1, &_ED11_5OUT);

        if (_ED11_5OUT)
            SET_TAG_SC_SCFG_UI(ALS_SC_FLOWDIR, CMF_FALSE);

        CMF_BOOL _ED11_6OUT;

        SFB_DEF_EDGE_DETR(ED11_6, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED11_6, AND11_2, &_ED11_6OUT);

        if (_ED11_6OUT)
            SET_TAG_SC_SCFG_UI(ALS_SC_FLOWDIR, CMF_TRUE);

        CMF_BOOL flowtemp;
        flowtemp = GET_TAG_SC_SCFG_UI(ALS_SC_FLOWDIR);

        SET_TAG_MMI(ALS_MMI_LEDA2R, !flowtemp);
        SET_TAG_MMI(ALS_MMI_LEDR2A, flowtemp);

    }

    ////////////////////////////////////
    // Target Reset & Lamp Test
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED12_1OUT;
        CMF_BOOL _ED12_2OUT;
        CMF_BOOL _PD12_2OUT;
        CMF_BOOL OR12_1;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED12_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED12_1, GET_TAG_MMI(ALS_MMI_PBTARR), &_ED12_1OUT);

        SFB_DEF_EDGE_DETR(ED12_2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED12_2, GET_TAG_RCM(ALS_RCM_CTARR), &_ED12_2OUT);

        OR12_1 = (GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED12_2OUT) | _ED12_1OUT;

        SFB_DEF_PD_TIMER(PD12_2, PDTT_SEC, 0, PDTT_SEC, 3.0);
        SFB_USE_PD_TIMER(PD12_2, OR12_1, NULL, &_PD12_2OUT);

        // Set tag phase
        SET_TAG_BV(ALS_BV_TARR, OR12_1);
        SET_TAG_BV(ALS_BV_LAMPTEST, _PD12_2OUT);
    }

    ////////////////////////////////////
    // Manual Lockout Reset for VIT Sequence
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _ED13_1OUT, _ED13_2OUT;
        CMF_BOOL OR13_1;

        // Process phase
        /* Push Button -> MMI task will do */
        SFB_DEF_EDGE_DETR(ED13_1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED13_1, GET_TAG_MMI(ALS_MMI_PBLRS), &_ED13_1OUT);

        CMF_BOOL _ED13IN;
        _ED13IN = GET_TAG_RCM(ALS_RCM_CLRS) | GET_TAG_DI(ALS_DI_RRESET);
        SFB_DEF_EDGE_DETR(ED13_2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED13_2, _ED13IN, &_ED13_2OUT);

        OR13_1 = _ED13_1OUT | ( GET_TAG_NVV_UI(ALS_NVV_ENRT) & _ED13_2OUT );

        if(OR13_1)
            OR13_1=1;
        // Set tag phase
        SET_TAG_BV(ALS_BV_MLRS, OR13_1);
    }
}
