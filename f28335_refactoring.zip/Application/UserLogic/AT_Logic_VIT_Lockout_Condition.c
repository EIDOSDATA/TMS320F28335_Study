/*
 * AT_Logic_VITLockoutCondition.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_VIT_Lockout_Condition()
{
    ////////////////////////////////////
    // VIT Lockout_79LO2 Condition
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _79LO2;
        CMF_BOOL ED0_1IN, ED0_2IN, ED0_3IN;
        CMF_BOOL ED0_1OUT, ED0_2OUT, ED0_3OUT;

        // Process phase
        SFB_DEF_EDGE_DETR(ED0_1, EDT_RISING, 0);
        SFB_DEF_EDGE_DETR(ED0_2, EDT_RISING, 0);
        SFB_DEF_EDGE_DETR(ED0_3, EDT_RISING, 0);

        ED0_1IN = (CMF_BOOL) (GET_TAG_SC_SCFG_UI(ALS_SC_PWR_ON) ? CMF_TRUE : CMF_FALSE);
        ED0_2IN = (CMF_BOOL) (GET_TAG_SC_SCFG_UI(ALS_SC_CFG_UPDATED) ? CMF_TRUE : CMF_FALSE);
        ED0_3IN = (CMF_BOOL) (GET_TAG_BV(ALS_BV_OPC) ? CMF_TRUE : CMF_FALSE);
        SFB_USE_EDGE_DETR(ED0_1, ED0_1IN, &ED0_1OUT);
        SFB_USE_EDGE_DETR(ED0_2, ED0_2IN, &ED0_2OUT);
        SFB_USE_EDGE_DETR(ED0_3, ED0_3IN, &ED0_3OUT);

        CMF_BOOL _PD0IN;
        _PD0IN = ED0_1OUT | ED0_2OUT | ED0_3OUT;

        SFB_DEF_PD_TIMER(PD0, PDTT_CYCLE, 0, PDTT_CYCLE, 0.5);
        SFB_USE_PD_TIMER(PD0, _PD0IN, NULL, &_79LO2);

        SET_TAG_BV(ALS_BV_79LO2, _79LO2);

    }

    ////////////////////////////////////
    // N/C N/O Close & Open-Lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1_OUT, _OR2_OUT, _OR4_OUT, _OR5_OUT;
        CMF_BOOL _AND1_OUT, _AND2_OUT, _AND3_OUT, _AND5_OUT, _AND6_OUT, _AND7_OUT;
        CMF_BOOL _ENCLACNT, _XLD_OFF;
        CMF_BOOL _ED1_OUT, _ED2_OUT, _ED3_OUT; /* LOCAL VARs */
        CMF_BOOL _NCTRS, _OLT, _DTL23, _NCT, _NCCL, _NOCL, _NONCCL; /* SET TAG TARGET */

        // Process phase
        _OR1_OUT = GET_TAG_BV(ALS_BV_DCL) | GET_TAG_BV(ALS_BV_RSCL);
        _OR2_OUT = GET_TAG_NVV_UI(ALS_NVV_OP2) | GET_TAG_BV(ALS_BV_OP30);
        _AND1_OUT = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_VEXOR) & !GET_TAG_BV(ALS_BV_52A);
        _AND2_OUT = _OR1_OUT & _OR2_OUT & _AND1_OUT;

        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _AND2_OUT, &_ED1_OUT);

        CMF_FLOAT32 OLD_PD_Timer; //Define OLD_PD_Timer
        OLD_PD_Timer = GET_TAG_LS_F(ALS_LS_BCD);

        SET_TAG_NMV_F(ALS_NMV_OLD, OLD_PD_Timer);

   //     SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC, 0, 0, PDTT_SEC_VAR_F, 0, ALS_NMV_OLD);
        SFB_DEF_PD_TIMER_EX(PD1, N_A, N_A, N_A, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_OLD)
        SFB_USE_PD_TIMER(PD1, _ED1_OUT, NULL, &_OLT);

        _AND3_OUT = GET_TAG_BV(ALS_BV_3P27Q1AND) & GET_TAG_BV(ALS_BV_3P27P1AND);

        SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED2, _AND3_OUT, &_ED2_OUT);

        _DTL23 = !GET_TAG_BV(ALS_BV_52A) & _OLT & GET_TAG_BV(ALS_BV_OP30) & _ED2_OUT;

       //need GBTV logic
        SFB_DEF_EDGE_DETR(ED3, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED3, GET_TAG_BV(ALS_BV_52A), &_ED3_OUT);

        _NCTRS = _ED3_OUT | GET_TAG_BV(ALS_BV_NCCL) | GET_TAG_BV(ALS_BV_VAND) | GET_TAG_BV(ALS_BV_V79LO);

        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        GBTV1 = (GBTV1 | _AND2_OUT) & !_NCTRS;

        _NCT = GBTV1 & GET_TAG_BV(ALS_BV_VEXOR);

    //    SFB_DEF_PD_TIMER_EX(PD2, PDTT_SEC_VAR_F, 0, ALS_LS_XDD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD2, PDTT_TAG, TAG_GRP_LS_F, ALS_LS_XDD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD2, _NCT, NULL, &_NCCL);

        _ENCLACNT = GET_TAG_LS_UI(ALS_LS_ENCLACNT);
        _XLD_OFF = GET_TAG_LS_UI(ALS_LS_XLD) == 0 ? 1 : 0;

        _OR4_OUT = _ENCLACNT | _XLD_OFF;
        _AND5_OUT = _ENCLACNT & !_XLD_OFF & GET_TAG_BV(ALS_BV_CNOV2);

        _OR5_OUT = !_OR4_OUT | _AND5_OUT;

        _AND6_OUT = GET_TAG_BV(ALS_BV_OP40) & GET_TAG_BV(ALS_BV_VEXOR) & !GET_TAG_BV(ALS_BV_52A);

        _AND7_OUT = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_VITEN) & _AND6_OUT & _OR5_OUT & !GET_TAG_BV(ALS_BV_V79LO);

   //     SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_UI, 0, ALS_LS_XLD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_LS_UI, ALS_LS_XLD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, _AND7_OUT, NULL, &_NOCL);

        _NONCCL = _NCCL | _NOCL;

        // Set tag phase
        SET_TAG_BV(ALS_BV_NCTRS, _NCTRS);
        SET_TAG_BV(ALS_BV_OLT, _OLT);
        SET_TAG_BV(ALS_BV_DTL23, _DTL23);
        SET_TAG_BV(ALS_BV_NCT, _NCT);
        SET_TAG_BV(ALS_BV_NCCL, _NCCL);
        SET_TAG_BV(ALS_BV_NOCL, _NOCL);
        SET_TAG_BV(ALS_BV_NONCCL, _NONCCL);

    }
    // Blocking Timer for Close to Open Lockout

    {
        //VIT Sequence
        CMF_BOOL _ED1OUT;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0); // or EDT_FALLING
        SFB_USE_EDGE_DETR(ED1, GET_TAG_BV(ALS_BV_52A), &_ED1OUT);

        SFB_DEF_GBTV(_CLT, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(_YCT, CMF_BOOL, CMF_FALSE);
        _CLT = (_CLT | _ED1OUT) & !(!GET_TAG_BV(ALS_BV_52A) | (GET_TAG_BV(ALS_BV_V79LO) | GET_TAG_BV(ALS_BV_MLRS)) | _YCT);

        CMF_BOOL PD2IN;
        PD2IN = !GET_TAG_BV(ALS_BV_FPU) & _CLT;

        CMF_FLOAT32 YCD_PD_Timer;
        YCD_PD_Timer = GET_TAG_LS_F(ALS_LS_BCD);

        SET_TAG_NMV_F(ALS_NMV_YCD, YCD_PD_Timer);

   //     SFB_DEF_PD_TIMER_EX(PD2, PDTT_SEC_VAR_F, 0, ALS_NMV_YCD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD2, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_YCD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_YCT);

        SFB_DEF_GBTV(_LT1OUT, CMF_BOOL, CMF_FALSE);
        SFB_DEF_GBTV(_LT2OUT, CMF_BOOL, CMF_FALSE);
        _LT1OUT = (_LT1OUT | GET_TAG_BV(ALS_BV_NONCCL) | GET_TAG_BV(ALS_BV_V79OITO)) & !(_LT2OUT | GET_TAG_BV(ALS_BV_TRIP) | GET_TAG_BV(ALS_BV_V79LO));
        _LT2OUT = GET_TAG_BV(ALS_BV_YCT) & _LT1OUT;


        CMF_BOOL _BLT;
        _BLT = GET_TAG_BV(ALS_BV_BLT);
        SFB_DEF_GBTV(_LT3OUT, CMF_BOOL, CMF_FALSE);

        _BLT = (_BLT | _LT2OUT) & GET_TAG_BV(ALS_BV_52A) & (GET_TAG_NVV_UI(ALS_NVV_OP2) | GET_TAG_BV(ALS_BV_OP30)) & !(GET_TAG_BV(ALS_BV_V79LO) | GET_TAG_BV(ALS_BV_MLRS)) & !_LT3OUT;

        CMF_UINT16 BLD_PD_Timer; //Define BLD_PD_Timer
        BLD_PD_Timer = GET_TAG_LS_UI(ALS_LS_XLD); //BLD PD Timer = XLD PD Timer

        SET_TAG_NMV_UI(ALS_NMV_BLD, BLD_PD_Timer);

    //    SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_UI, 0, ALS_NMV_BLD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_NMV_UI, ALS_NMV_BLD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, _BLT, NULL, &_LT3OUT);

        CMF_BOOL _BLT1;
        _BLT1 = GET_TAG_BV(ALS_BV_VITEN) & !GET_TAG_NVV_UI(ALS_NVV_ENRC) & !GET_TAG_BV(ALS_BV_51TCF);

        // set tag data

        SET_TAG_BV(ALS_BV_CLT, _CLT);
        SET_TAG_BV(ALS_BV_YCT, _YCT);
        SET_TAG_BV(ALS_BV_BLT1, _BLT1);
        SET_TAG_BV(ALS_BV_BLT, _BLT);
    }
    ////// Loss of Voltage Lockout
    {
        CMF_BOOL AND1, AND2, OR1, OR2, OR3;
        AND1 = GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_OP30) & GET_TAG_BV(ALS_BV_NCVCP);
        OR1 = !GET_TAG_BV(ALS_BV_3P27Q1AND) | !GET_TAG_BV(ALS_BV_3P27P1AND);
        OR2 = GET_TAG_BV(ALS_BV_V79LO) | GET_TAG_BV(ALS_BV_LOVCP) | OR1;

        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);
        OR3 = GBTV1 | AND1;
        AND2 = OR3 & !OR2;
        GBTV1 = AND2;

        CMF_BOOL LOVCP;

        CMF_UINT16 temp_;
        temp_ = GET_TAG_LS_UI(ALS_LS_XLD) - 2 ;

        CMF_FLOAT32 LOVD_PD_Timer;
        LOVD_PD_Timer = (CMF_FLOAT32) temp_;
        SET_TAG_NMV_F(ALS_NMV_LOVD, LOVD_PD_Timer);

    //    SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC_VAR_F, 0, ALS_NMV_LOVD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD1, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_LOVD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD1, GBTV1, NULL, &LOVCP);

        SET_TAG_BV(ALS_BV_LOVCP, LOVCP);

        CMF_BOOL TR4;
        TR4 = GET_TAG_BV(ALS_BV_52A) & LOVCP;
        SET_TAG_BV(ALS_BV_TR4, TR4);

    }

    ////////////////////////////////////
    // N.C Close Lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _OR1_OUT, _OR2_OUT, _OR3_0_OUT, _OR3_OUT, _OR4_OUT, _ED1_OUT, _ED2_OUT, _ED3_OUT,
             _ED4_OUT, _AND1_OUT, _AND2_OUT, _PD1_OUT; /* LOCAL VARs */
        CMF_BOOL _51TCF, _TR3, _DTL14; /* SET TAG TARGET */
        SFB_DEF_GBTV(GBTV1, CMF_BOOL, CMF_FALSE);

        // Process phase
        //51TCF
        _OR1_OUT = GET_TAG_BV(ALS_BV_79NCRS) | GET_TAG_BV(ALS_BV_79FRS) | GET_TAG_BV(ALS_BV_MLRS);

        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED1, _OR1_OUT, &_ED1_OUT);

        SFB_DEF_EDGE_DETR(ED2, EDT_FALLING, 0);
        SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_52A), &_ED2_OUT);

        SFB_DEF_EDGE_DETR(ED3, EDT_FALLING, 0);
        SFB_USE_EDGE_DETR(ED3, GET_TAG_BV(ALS_BV_CLT), &_ED3_OUT);

        _OR2_OUT = _ED1_OUT | _ED2_OUT | GET_TAG_BV(ALS_BV_V79LO) | _ED3_OUT;

        CMF_BOOL _V79OITO;
        _V79OITO = (GET_TAG_BV(ALS_BV_VITEN) & ((GET_TAG_LS_UI(ALS_LS_OPCN) == 1) ? 1 :0)  & GET_TAG_BV(ALS_BV_79OI1T)) |
                (GET_TAG_BV(ALS_BV_VITEN) & ((GET_TAG_LS_UI(ALS_LS_OPCN) == 2) ? 1 :0) & GET_TAG_BV(ALS_BV_79OI2T));

        _OR3_0_OUT = _V79OITO | GET_TAG_BV(ALS_BV_NONCCL);

        _OR3_OUT = GBTV1 | _OR3_0_OUT;

        _51TCF = _OR3_OUT & !_OR2_OUT;
        GBTV1 = _51TCF;

        //
        _AND1_OUT = GET_TAG_BV(ALS_BV_CLT) & _51TCF;
        _AND2_OUT = GET_TAG_BV(ALS_BV_TRIP) & _AND1_OUT;

        _OR4_OUT = GET_TAG_BV(ALS_BV_FCN1) | GET_TAG_BV(ALS_BV_CNCV1);

        SFB_DEF_EDGE_DETR(ED4, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED4, _OR4_OUT, &_ED4_OUT);

        CMF_FLOAT32 BCD_ADD_PD_Timer;
        BCD_ADD_PD_Timer = GET_TAG_LS_F(ALS_LS_BCD) + 0.5 ;

        SET_TAG_NMV_F(ALS_NMV_BCD_ADD, BCD_ADD_PD_Timer);


    //    SFB_DEF_PD_TIMER_EX(PD1, PDTT_SEC, 0, 0, PDTT_SEC_VAR_F, 0, ALS_NMV_BCD_ADD);
        SFB_DEF_PD_TIMER_EX(PD1, N_A, N_A, N_A, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_BCD_ADD)
        SFB_USE_PD_TIMER(PD1, GET_TAG_BV(ALS_BV_NOCL), NULL, &_PD1_OUT);

        _TR3 = _AND1_OUT & _ED4_OUT & !_PD1_OUT;
        _DTL14 = _AND2_OUT | _TR3;

        // Set tag phase
        SET_TAG_BV(ALS_BV_51TCF, _51TCF);
        SET_TAG_BV(ALS_BV_TR3, _TR3);
        SET_TAG_BV(ALS_BV_DTL14, _DTL14);
    }




    ////////////////////////////////////
    // Loss of voltage trip & lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _AND5_OUT, _ENLOVLO, _AND6_OUT, _PD5_OUT; /* LOCAL VARs */
        CMF_BOOL _DTL17; /* SET TAG TARGET */

        // Process phase
        _ENLOVLO = GET_TAG_LS_UI(ALS_LS_ENLOVLO);
        _AND5_OUT = _ENLOVLO & GET_TAG_BV(ALS_BV_LOVCP);

        _AND6_OUT = _ENLOVLO & GET_TAG_SC_UCFG_UI(ALS_SC_ENPROT) & GET_TAG_BV(ALS_BV_OP40) & GET_TAG_BV(ALS_BV_VEXOR) & GET_TAG_BV(ALS_BV_CNOV1);

    //    SFB_DEF_PD_TIMER_EX(PD5, PDTT_SEC_VAR_F, 0, ALS_NMV_LOVD, PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD5, PDTT_TAG, TAG_GRP_NMV_F, ALS_NMV_LOVD, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD5, _AND6_OUT, NULL, &_PD5_OUT);

        _DTL17 = _AND5_OUT | _PD5_OUT;

        // Set tag phase
        SET_TAG_BV(ALS_BV_DTL17, _DTL17);
    }

    ////////////////////////////////////
    // Bump prevention lockout
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL _PD4_OUT, _ED7_OUT; /* LOCAL VARs */
        CMF_BOOL _BPL; /* SET TAG TARGET */

        // Process phase
        SFB_DEF_PD_TIMER(PD4, PDTT_CYCLE, 0, PDTT_CYCLE, 3);
        SFB_USE_PD_TIMER(PD4, GET_TAG_BV(ALS_BV_NCT), NULL, &_PD4_OUT);

        SFB_DEF_EDGE_DETR(ED7, EDT_RISING, 0);
        SFB_USE_EDGE_DETR(ED7, GET_TAG_BV(ALS_BV_VAND), &_ED7_OUT);

        _BPL = _PD4_OUT & _ED7_OUT;

        // Set tag phase
        SET_TAG_BV(ALS_BV_BPL, _BPL);
        SET_TAG_BV(ALS_BV_DTL25, _BPL);
    }
}

