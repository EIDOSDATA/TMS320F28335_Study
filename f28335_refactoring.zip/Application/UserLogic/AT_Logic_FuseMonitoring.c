/*
 * AT_Logic_FuseMonitoring.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_FuseMonitoring()
{
    ////////////////////////////////////
    // Fuse Monitoring
    //
    // @ New coding convention reference
    //   It will be applied when dev by using IDE.
    ////////////////////////////////////
    {
        // [Define phase]
        // VARs
        CMF_BOOL _TEMP1, _TEMP2, _TEMP3, _TEMP4, _TEMP5, _TEMP6, _TEMP7;
        CMF_BOOL _PD1OUT, _PD2OUT, _PD3OUT;
        // FBs
        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 3, PDTT_SEC, 0);
        SFB_DEF_PD_TIMER(PD3, PDTT_SEC, 3, PDTT_SEC, 0);

        // [Process phase]
        _TEMP1 = (GET_TAG_AI_F(ALS_AI_AICHV) > 25.0) ? 1 : 0;
        _TEMP2 = (GET_TAG_AI_F(ALS_AI_AIOPV) > 10.0) ? 1 : 0;
        _TEMP3 = (GET_TAG_AI_F(ALS_AI_AIBATV) > 10.0) ? 1 : 0;
        _TEMP4 = _TEMP1 | _TEMP2 | _TEMP3;
        _TEMP5 = 7.0 > GET_TAG_AI_F(ALS_AI_AIOPFB) ? 1 : 0;
        _TEMP6 = 7.0 > GET_TAG_AI_F(ALS_AI_AICPFB) ? 1 : 0;
        _TEMP7 = 7.0 > GET_TAG_AI_F(ALS_AI_AIMODFB) ? 1 : 0;

        CMF_BOOL PD1IN;
        PD1IN = _TEMP4 & _TEMP5;

        SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &_PD1OUT);
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_OPFB, _PD1OUT);
        SET_TAG_MMI(ALS_MMI_LEDOPFB, _PD1OUT);

        CMF_BOOL PD2IN;
        PD2IN = _TEMP4 & _TEMP6;
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_PD2OUT);
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_CPFB, _PD2OUT);
        SET_TAG_MMI(ALS_MMI_LEDCPFB, _PD2OUT);

        CMF_BOOL PD3IN;
        PD3IN = _TEMP4 & _TEMP7;
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &_PD3OUT);
        //Set Tag Phase
        SET_TAG_BV(ALS_BV_MODFB, _PD3OUT);
        SET_TAG_MMI(ALS_MMI_LEDMODFB, _PD3OUT);
    }
}
