/*
 * AT_Logic_SettingGroup.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_SettingGroup()
{

    ////////////////////////////////////
    // Main Contact Status
    ////////////////////////////////////
    {
        // Define phase
        CMF_BOOL MSA, MSB, _52A;

        // Process phase
        MSA = GET_TAG_DI(ALS_DI_MSA);
        MSB = GET_TAG_DI(ALS_DI_MSB);
        _52A = MSA & !MSB;

        SET_TAG_BV(ALS_BV_52A, _52A);
        SET_TAG_RCM(ALS_RCM_POLY_CLOSE, !_52A);

        CMF_BOOL LEDCLOSE = _52A | (MSA & MSB);
        CMF_BOOL LEDTRIP = (!MSA & MSB) | (MSA & MSB);

        SET_TAG_MMI(ALS_MMI_LEDCLOSE, LEDCLOSE);
        SET_TAG_MMI(ALS_MMI_LEDTRIP, LEDTRIP);
    }

    ////// setting group change//////
    {

        CMF_BOOL _TEMP1;
        _TEMP1 = (-0.03 > GET_TAG_AI_F(ALS_AI_ACTIVE_A)) ? 1 : 0;

        CMF_BOOL _PD1OUT;
        CMF_BOOL PD1IN;
        PD1IN = _TEMP1 & GET_TAG_BV(ALS_BV_52A);
        SFB_DEF_PD_TIMER(PD1, PDTT_CYCLE, 1.25, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD1, PD1IN, NULL, &_PD1OUT);

        CMF_BOOL _WMP;
        CMF_BOOL PD2IN;
        PD2IN = _PD1OUT & !GET_TAG_BV(ALS_BV_79BRS);
        SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 15, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD2, PD2IN, NULL, &_WMP);
        CMF_BOOL _PD3OUT;
        CMF_BOOL PD3IN;
        PD3IN = GET_TAG_BV(ALS_BV_3P59P1OR) & GET_TAG_BV(ALS_BV_VEXOR);
        SFB_DEF_PD_TIMER(PD3, PDTT_CYCLE, 1, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL, &_PD3OUT);
        CMF_BOOL _PD4OUT;
        CMF_BOOL PD4IN;
        PD4IN = GET_TAG_BV(ALS_BV_3P59Q1OR) & GET_TAG_BV(ALS_BV_VEXOR);
        SFB_DEF_PD_TIMER(PD4, PDTT_CYCLE, 1, PDTT_CYCLE, 0);
        SFB_USE_PD_TIMER(PD4, PD4IN, NULL, &_PD4OUT);
        CMF_BOOL _ED1OUT;
        SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0); // or EDT_FALLING
        SFB_USE_EDGE_DETR(ED1, GET_TAG_SC_SCFG_UI(ALS_SC_PWR_ON), &_ED1OUT);

        CMF_BOOL _ED2OUT;
        SFB_DEF_EDGE_DETR(ED2, EDT_RISING, 0); // or EDT_FALLING
        SFB_USE_EDGE_DETR(ED2, GET_TAG_BV(ALS_BV_WMP), &_ED2OUT);

        CMF_BOOL _TEMP2, _TEMP3;
        _TEMP2 = _ED1OUT | (GET_TAG_BV(ALS_BV_ENA2R) & _PD3OUT) | (_PD4OUT & GET_TAG_BV(ALS_BV_ENR2A));
        _TEMP3 = (GET_TAG_BV(ALS_BV_ENA2R) & _PD4OUT) | (_PD3OUT & GET_TAG_BV(ALS_BV_ENR2A));

        CMF_BOOL _TEMP4, _TEMP4_1, _TEMP5, _TEMP6, _TEMP6_1;
        _TEMP5 = GET_TAG_SC_UCFG_UI(ALS_SC_STGRP_AT_MODE_ON); //AUTO

        _TEMP4 = (GET_TAG_SC_SCFG_UI(ALS_SC_STGRP) == 0) ? 1 : 0; //SG1
        _TEMP4_1 = _TEMP4 & !_TEMP5;

        _TEMP6 = (GET_TAG_SC_SCFG_UI(ALS_SC_STGRP) == 1) ? 1 : 0; //SG2
        _TEMP6_1 = _TEMP6 & !_TEMP5;


        CMF_BOOL _TEMP7, _TEMP8;
        _TEMP7 = _TEMP4_1 | (GET_TAG_BV(ALS_BV_SG1) & GET_TAG_BV(ALS_BV_SG2)) | (!GET_TAG_BV(ALS_BV_SG1) & !GET_TAG_BV(ALS_BV_SG2)) | (!GET_TAG_BV(ALS_BV_52A) & GET_TAG_BV(ALS_BV_VAND) & _TEMP5) | (_TEMP2 & _TEMP5) | (GET_TAG_BV(ALS_BV_SG2) & _ED2OUT & _TEMP5) ;
        _TEMP8 = (GET_TAG_BV(ALS_BV_SG1) & _ED2OUT & _TEMP5) | (_TEMP3 & _TEMP5) | _TEMP6_1;


        CMF_BOOL _SG1, _SG2;
        _SG1 = (GET_TAG_BV(ALS_BV_SG1) | _TEMP7) & !_TEMP8;
        _SG2 = (GET_TAG_BV(ALS_BV_SG2) | _TEMP8) & !_TEMP7;

        //set tag data
        SET_TAG_BV(ALS_BV_WMP, _WMP);
        SET_TAG_BV(ALS_BV_SG1, _SG1);
        SET_TAG_BV(ALS_BV_SG2, _SG2);


        if (_SG1)
        {
            SET_TAG_SC_SCFG_UI(ALS_SC_STGRP, 0);
        }
        else if (_SG2)
        {
            SET_TAG_SC_SCFG_UI(ALS_SC_STGRP, 1);
        }


        SET_TAG_MMI(ALS_MMI_LEDSG1, _SG1);
        SET_TAG_MMI(ALS_MMI_LEDSG2, _SG2);
    }
}
