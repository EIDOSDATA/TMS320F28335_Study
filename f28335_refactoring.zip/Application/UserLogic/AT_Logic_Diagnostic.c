/*
 * AT_Logic_Diagnostic.c
 *
 *  Created on: 2022. 01. 11.
 */

#include "Plaffom_Interface.h"

CMF_VOID AT_Logic_Diagnostic()
{
    // CWF
 {
    CMF_BOOL COND, ED1IN ;
    SFB_DEF_EDGE_DETR(ED1, EDT_RISING, 0);
    ED1IN = GET_TAG_BV(ALS_BV_TCCTRIP) | GET_TAG_BV(ALS_BV_FCCTRIP) | GET_TAG_BV(ALS_BV_DEFTRIP);
    SFB_USE_EDGE_DETR(ED1, ED1IN, &COND);

    SFB_DEF_GBTV(max_current_A, CMF_FLOAT32, 0.0);
    SFB_DEF_GBTV(max_current_B, CMF_FLOAT32, 0.0);
    SFB_DEF_GBTV(max_current_C, CMF_FLOAT32, 0.0);
    SFB_DEF_GBTV(Cyc_Cnt, CMF_UINT16, 0);

    if (COND)
    {
        Cyc_Cnt += 1;
    }

    if (Cyc_Cnt > 0 && Cyc_Cnt <= 6)
    {
        if (max_current_A < GET_TAG_AI_F(ALS_AI_RMS_IA))
        {
            max_current_A = GET_TAG_AI_F(ALS_AI_RMS_IA);
        }
        if (max_current_B < GET_TAG_AI_F(ALS_AI_RMS_IB))
        {
            max_current_B = GET_TAG_AI_F(ALS_AI_RMS_IB);
        }
        if (max_current_C < GET_TAG_AI_F(ALS_AI_RMS_IC))
        {
            max_current_C = GET_TAG_AI_F(ALS_AI_RMS_IC);
        }
        Cyc_Cnt += 1;
    }
    if (Cyc_Cnt == 6)
    {
        // Compute Contact Wear
        // Phase A
        if(max_current_A < 630.0)
        {
            CMF_UINT16 temp;
            temp = GET_TAG_NVV_F(ALS_NVV_CWFA) + 1.0;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFA, temp);
        }
        else if(max_current_A >= 16000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFA, 10000.0);
        }
        else
        {
            CMF_FLOAT32 temp_log;
            temp_log = (CMF_FLOAT32)(-2.8474*(log(max_current_A)-2.79934) + 4.0);
            temp_log = (CMF_FLOAT32)pow(10.0, temp_log);
            SFB_DEF_POW_F(POW1);
            temp_log = (CMF_FLOAT32)264670.0/(SFB_USE_POW_F(POW1, max_current_A/100.0, 1.8) - 1.0);
            temp_log = GET_TAG_NVV_F(ALS_NVV_CWFA) + 10000.0/temp_log;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFA, temp_log);
        }
        if(GET_TAG_NVV_F(ALS_NVV_CWFA) > 10000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFA, 10000.0);
        }
        // Compute Contact Wear
        // Phase B
        if(max_current_B < 630.0)
        {
            CMF_UINT16 temp;
            temp = GET_TAG_NVV_F(ALS_NVV_CWFB) + 1.0;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFB, temp);
        }
        else if(max_current_B >= 16000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFB, 10000.0);
        }
        else
        {
            CMF_FLOAT32 temp_log;
            SFB_DEF_POW_F(POW2);
            temp_log = (CMF_FLOAT32)264670.0/(SFB_USE_POW_F(POW2, max_current_B/100.0, 1.8) - 1.0);
            temp_log = GET_TAG_NVV_F(ALS_NVV_CWFB) + 10000.0/temp_log;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFB, temp_log);
        }
        if(GET_TAG_NVV_F(ALS_NVV_CWFB) > 10000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFB, 10000.0);
        }
        // Compute Contact Wear
        // Phase C
        if(max_current_C < 630.0)
        {
            CMF_UINT16 temp;
            temp = GET_TAG_NVV_F(ALS_NVV_CWFC) + 1.0;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFC, temp);
        }
        else if(max_current_C >= 16000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFC, 10000.0);
        }
        else
        {
            CMF_FLOAT32 temp_log;
            SFB_DEF_POW_F(POW3);
            temp_log = 264670.0/(SFB_USE_POW_F(POW3, max_current_C/100.0, 1.8) - 1.0);
            temp_log = GET_TAG_NVV_F(ALS_NVV_CWFC) + 10000.0/temp_log;
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFC, temp_log);
        }
        if(GET_TAG_NVV_F(ALS_NVV_CWFC) > 10000.0)
        {
            SET_TAG_NVV_F_WO_EV(ALS_NVV_CWFC, 10000.0);
        }
        Cyc_Cnt = 0;
        max_current_A = 0.0;
        max_current_B = 0.0;
        max_current_C = 0.0;
    }

        //LED Indication
        CMF_BOOL COMP1, COMP2, COMP3;
        CMF_BOOL CWF;
        COMP1 = (GET_TAG_NVV_F(ALS_NVV_CWFA) > 8000.0 ) ? 1 : 0;
        COMP2 = (GET_TAG_NVV_F(ALS_NVV_CWFB) > 8000.0 ) ? 1 : 0;
        COMP3 = (GET_TAG_NVV_F(ALS_NVV_CWFC) > 8000.0 ) ? 1 : 0;
        CWF = COMP1 | COMP2 | COMP3;
        SET_TAG_BV(ALS_BV_CWF, CWF);
        SET_TAG_MMI(ALS_MMI_LEDCWF, CWF);
}

    // CFB
    {
        CMF_BOOL CFB;
        CFB = GET_TAG_BV(ALS_BV_OPFB) | GET_TAG_BV(ALS_BV_CPFB) | GET_TAG_BV(ALS_BV_MODFB) ;
        SET_TAG_BV(ALS_BV_CFB, CFB);
        SET_TAG_MMI(ALS_MMI_LEDCFB, CFB);
    }

    // COCT
    {
        CMF_BOOL AND1, AND2, COCT;
        AND1 = !GET_TAG_DI(ALS_DI_MSA) & !GET_TAG_DI(ALS_DI_MSB);
        AND2 = GET_TAG_DI(ALS_DI_MSA) & GET_TAG_DI(ALS_DI_MSB);

        CMF_BOOL PD1OUT;
        SFB_DEF_PD_TIMER(PD1, PDTT_SEC, 0.5, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD1, AND1, NULL, &PD1OUT);

        CMF_BOOL PD2OUT;
        SFB_DEF_PD_TIMER(PD2, PDTT_SEC, 0.5, PDTT_SEC, 0);
        SFB_USE_PD_TIMER(PD2, AND2, NULL, &PD2OUT);

        COCT = PD1OUT | PD2OUT | GET_TAG_BV(ALS_BV_TRF) | GET_TAG_BV(ALS_BV_CLF);
        SET_TAG_BV(ALS_BV_COCT, COCT);
        SET_TAG_MMI(ALS_MMI_LEDCOCT, COCT);
    }

    // CPT
    {
        CMF_BOOL CPT;
        CPT = GET_TAG_BV(ALS_BV_CHVFAIL) | GET_TAG_BV(ALS_BV_OPVFAIL);
        SET_TAG_BV(ALS_BV_CPT, CPT);
        SET_TAG_MMI(ALS_MMI_LEDCPT, CPT);
    }

    // CTT
    {
        CMF_BOOL CTT, COMP3, COMP4;
        COMP3 = (GET_TAG_AI_F(ALS_AI_CTEMP) < -30.0 ) ? 1 : 0;
        COMP4 = (GET_TAG_AI_F(ALS_AI_CTEMP) > 70.0 ) ? 1 : 0;
        CTT = COMP3 | COMP4;
        SET_TAG_BV(ALS_BV_CTT, CTT);
        SET_TAG_MMI(ALS_MMI_LEDCTT, CTT);
    }

    // IPT
    {
        CMF_BOOL IPT, COMP5, COMP6, COMP7, COMP8, COMP9, COMP10;
        CMF_BOOL OR1, OR2, OR3;
        COMP5 = (GET_TAG_AI_F(ALS_AI_12VAP) < 4.0 ) ? 1 : 0;
        COMP6 = (GET_TAG_AI_F(ALS_AI_12VAP) > 6.0 ) ? 1 : 0;
        OR1 = COMP5 | COMP6;
        COMP7 = (GET_TAG_AI_F(ALS_AI_12VAN) < -6.0 ) ? 1 : 0;
        COMP8 = (GET_TAG_AI_F(ALS_AI_12VAN) > -4.0 ) ? 1 : 0;
        OR2 = COMP7 | COMP8;
        COMP9 = (GET_TAG_AI_F(ALS_AI_REF_DP) < 600.0 ) ? 1 : 0;
        COMP10 = (GET_TAG_AI_F(ALS_AI_REF_DP) > 900.0 ) ? 1 : 0;
        OR3 = COMP9 | COMP10;
        IPT = OR1| OR2 | OR3;

        SET_TAG_BV(ALS_BV_IPT, IPT);
        SET_TAG_MMI(ALS_MMI_LEDIPT, IPT);
    }

    //EMOL
    {
        CMF_BOOL EMOL;
        EMOL = (GET_TAG_NVV_UI(ALS_NVV_TOP_CNT) > 5000 ) ? 1 : 0;
        SET_TAG_BV(ALS_BV_EMOL, EMOL);
        SET_TAG_MMI(ALS_MMI_LEDEMOL, EMOL);
    }

    //MODEM COMMUNICATION
    {
        CMF_BOOL MODEM;
        CMF_BOOL PD3IN;
        CMF_BOOL PD3OUT = CMF_FALSE;

        MODEM = GET_TAG_SC_SCFG_UI(ALS_DNP232_USEMODEM) ? 1 : 0;

        if (MODEM) {
        PD3IN = GET_TAG_DG_UI(ALS_DG_DNP_SR1) ? 0 : 1;
   //     SFB_DEF_PD_TIMER_EX(PD3, PDTT_SEC_VAR_UI, 0, ALS_MODEM_POWER , PDTT_SEC, 0, 0);
        SFB_DEF_PD_TIMER_EX(PD3, PDTT_TAG, TAG_GRP_SC_UI, ALS_MODEM_POWER, N_A, N_A, N_A)
        SFB_USE_PD_TIMER(PD3, PD3IN, NULL , &PD3OUT);
        SET_TAG_DO(ALS_DO_MODEM, PD3OUT);
        SET_TAG_MMI(ALS_MMI_LEDMODEM, PD3OUT);
        }
    }

    //Polymer product organic voltage treatment
    {
//      Note: polymer condition check is processed in platform.
//      Todo: polymer status needs to be implemented in platform on DEMAND

        CMF_BOOL POLYMER_SRC;
        CMF_BOOL POLYMER_LOAD;
        CMF_BOOL LEDPOLY;
        POLYMER_SRC = GET_TAG_DG_UI(ALS_DG_LEDPOLY_SRC);
        POLYMER_LOAD = GET_TAG_DG_UI(ALS_DG_LEDPOLY_LOAD) ;
        LEDPOLY = GET_TAG_DG_UI(ALS_DG_LEDPOLY_SRC) | GET_TAG_DG_UI(ALS_DG_LEDPOLY_LOAD) ;

        //Set tag phase
//        SET_TAG_BV(ALS_BV_POLYMER_SRC, POLYMER_SRC);
//        SET_TAG_BV(ALS_BV_POLYMER_LOAD, POLYMER_LOAD);
        SET_TAG_MMI(ALS_MMI_LEDPOLY, LEDPOLY);
    }


    //LEDDIAGNOSFAIL
    {
        CMF_BOOL LEDDIAGNOSFAIL;
        LEDDIAGNOSFAIL = GET_TAG_BV(ALS_BV_CWF) | GET_TAG_BV(ALS_BV_CFB) | GET_TAG_BV(ALS_BV_COCT) | GET_TAG_BV(ALS_BV_CPT)
                | GET_TAG_BV(ALS_BV_CTT)| GET_TAG_BV(ALS_BV_IPT) | GET_TAG_BV(ALS_BV_EMOL) | GET_TAG_MMI(ALS_MMI_LEDMODEM);

        SET_TAG_MMI(ALS_MMI_LEDDIAGNOSFAIL, LEDDIAGNOSFAIL);
    }

}




