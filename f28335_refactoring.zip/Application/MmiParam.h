/*
 * MmiParam.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: ShinSung Industrial Electric
 */

#ifndef APPLICATION_MMIPARAM_H_
#define APPLICATION_MMIPARAM_H_

#include <src/app/mmi/mmi_display.h>
#include <stdint.h>

#include "Plaffom_Interface.h"
#include "src/app/tag/tag_db.h"

#define N_A                     NULL

typedef enum
{
    PAGE_NONE,

    MAIN_VIEW,      MAIN_MENU,
    SAVE_SETTING,
          AUTHORITY,
    BATTERY_TEST,

    SETTING_TAB,
        GLOABAL,
        GLOBAL_SYSTEMCONFIG,        GLOBAL_SYSTEM_FREQUENCY,        GLOBAL_PHASE_ROTATION,      GLOBAL_FI_RESET,                GLOBAL_VOLTAGE_DETECT,
        GLOBAL_DEMAND_METER,        GLOBAL_LOAD_PROFILE_TIME,       GLOBAL_FAULT_WAVE_PRECYCLE, GLOBAL_SETTING_GROUP_CHANGE,   GLOBAL_RECLOSE_SUPERVISION,
        GLOBAL_MIN_TRIP_TIME,       GLOBAL_BATTERY_MANAGE,

        CB,
        CB_GROUP1,                  CB_GROUP2,                      CB_GROUP_COPY,
        PICKUP_CURRENT,             TCC_CURVE,                      SEF_DELAY,                  ACTIVATE_FAST_CURVE,            OPERATION_TO_LOCK,
        RECLOSING_INTERVAL,         RESET_TIME,                     HIGH_TRIP_P,                HIGH_TRIP_G,                    HIGH_LOCK_P,
        HIGH_LOCK_G,                COLD_LOAD,                      SEQ_COORDINATION,           GROUND_TRIP_PREC,               INRUSH_RESTRAINT,
        DIRE_RELAY_P,               DIRE_RELAY_G,

            /*TCC*/
            TCC_FAST_PHASE,         TCC_FAST_GROUND,                DELAY_PHASE,                DELAY_GROUND,

            /*COLD LOAD*/
            CL_PICKUP_MULTIPLIER,   LOSS_OF_LOAD_DIVERSITY,         RESTORE_MIN_PICKUP,         CL_RESET_TIME,

            /*INRUSH RESTRAINT*/
            IR_PICKUP_MULTIPLIER,   IR_RESET_TIME,

        VIT_MODE,
        VIT_GROUP1,                 VIT_GROUP2,                     VIT_GROUP_COPY,

            /*VIT GROUP*/
            VIT_COUNT,              VIT_NC_CLOSE_TIME,              VIT_NO_CLOSE_TIME,          VIT_RESET_TIME,             VIT_ADDITIONAL_FUNC,


        OPEN_CONDUCTOR,
        OC_OPEN_CONDUCTOR,          OC_DELTA,                       OC_UNBALANCE_CURRENT,       OC_UNBALANCE_VOLTAGE,

        CUSTOMER_PROTECTION,
        CP_UNDER_FREQUENCY,         CP_OVER_FREQUENCY,              CP_ROCOF,                   CP_UNDER_VOLTAGE,           CP_OVER_VOLTAGE,
        CP_REVERSE_POWER,           CP_V0_DISPLACEMENT,             CP_UNBALANCE_V,             CP_BLOWN_FUSE_DETECTION,

        COMMUNICATION,
            COMM_SCADA0,
                SCADA0_DNP,             SCADA0_SERIAL,
            COMM_SCADA1,
                SCADA1_DNP,             SCADA1_TCP_IP,

        TIME,

        PASSWORD,
            VIEWER,                 OPERATOR,                       ENGINEER,                   ADMIN,

    METERING_TAB,
        VOLTAGE_CURRENT,            LL_VOLTAGE,                     POWER_ACT_RCT,              POWER_APP_FACT,             SYM_COMPONENT,
        ENERGY,                     DEMAND_POWER,                   DEMAND_CURRENT,

    STATUS_TAB,
        CONTACT_WEAR,               MISC,

    COUNT_TAB,

    DIAGNOSIS_TAB,

    PRODUCT_INFO_TAB,
        HW_SERIAL_NUMBER,           MODEL_NUMBER,                   IDENTIFIER,                 FW_VERSION,

    EVENT_TAB,
        SEQ_EVENT,                  FAULT_EVENT,                    FAULT_WAVE_EVENT,
}PageCode;
/*Parameter Descriptor*/
#define GLOBAL_GROUP         .Global
#define CB_GROUP_1            .Cb1
#define CB_GROUP_2            .Cb2
#define VIT_GROUP_1           .Vit1
#define VIT_GROUP_2           .Vit2
#define SCADA0_GROUP         .Scada0
#define SCADA1_GROUP         .Scada1


#define RANGE_TYPE           .range_type
#define DUAL_TYPE            .range_dual_type
#define RANGE_OFF_TYPE       .range_off_type
#define CURSOR_TYPE          .range_cursor_type
#define SELECT_TYPE          .select_type
#define SELECT_NAME_TYPE     .select_name_type
#define NAME_TYPE            .name_type

#define SMALL           .page_content_s
#define MEDIUM          .page_content_m
#define LARGE           .page_content_l

#define LINE_A          .line_contents_A
#define LINE_B          .line_contents_B
#define LINE_C          .line_contents_C

#define LINE_PROPERTY   .LineParameter.property
#define TAG_GROUP       .LineParameter.TagParam.TagGroup
#define TAG_INDEX       .LineParameter.TagParam.TagIndex
#define CHILD           .LineParameter.ChildPageCode

#define TAG_PARAM       .TagParam

const GroupDataContents mmi_group_param_contents = {
                                                                     /*TAG GROUP           TAG ALIAS*/
                                                    GLOBAL_GROUP = { {TAG_GRP_SC_F, ALS_SC_CT_RATIO},
                                                                     {TAG_GRP_SC_F,  ALS_SC_SVOL},
                                                                     {TAG_GRP_SC_UI, ALS_SC_TARGSYS_FREQ},
                                                                     {TAG_GRP_SC_UI, ALS_SC_ROTATION},
                                                                     {TAG_GRP_SC_UI, ALS_SC_FIRSCL},
                                                                     {TAG_GRP_SC_UI, ALS_SC_59P1P0},
                                                                     {TAG_GRP_SC_UI, ALS_SC_27P1P0},
                                                                     {TAG_GRP_SC_UI, ALS_SC_TIME},
                                                                     {TAG_GRP_SC_UI, ALS_SC_TYPE},
                                                                     {TAG_GRP_SC_UI, ALS_SC_LPTIME},
                                                                     {TAG_GRP_SC_UI, ALS_SC_TRIG_WAVE},
                                                                     {TAG_GRP_SC_UI, ALS_SC_STGRP},
                                                                     {TAG_GRP_SC_UI, ALS_SC_STGRP_AT_MODE_ON},
                                                                     {TAG_GRP_SC_UI, ALS_SC_79CLSD},
                                                                     {TAG_GRP_SC_F, ALS_SC_TDURD},
                                                                     {TAG_GRP_SC_F, ALS_SC_BLV},
                                                                     {TAG_GRP_SC_UI, ALS_SC_SBT_HOUR},
                                                                     {TAG_GRP_SC_UI, ALS_SC_SBT_MIN},
                                                                     {TAG_GRP_SC_UI, ALS_SC_SBT_INTERVAL},
                                                    },
                                                    CB_GROUP_1 = {{TAG_GRP_LS0_UI,   ALS_LS0_51P1P},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51N1P},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_50N6P},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51P1C},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P1TD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P1CT},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P1MR},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P1FD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51N1C},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N1TD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N1CT},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N1MR},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P1DD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51P2C},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P2TD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P2CT},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51P2MR},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N1FD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51N2C},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N2TD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N2CT},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N2MR},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_51N1DD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50N6D},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_OPPH},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_OPGR},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_OPLKPH},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_OPLKGR},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_OPLKSF},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_79OI1},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_79OI2},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_79OI3},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_79RSD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_79RSLD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HILKPH},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HILKGR},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50P1P},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_50P1D},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRPH1},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRPH2},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRPH3},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRPH4},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50N1P},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_50N1D},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRGR1},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRGR2},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRGR3},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_HITRGR4},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51P4M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50P4M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51N4M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50N4M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_LLDD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_RMTPD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_RMTGD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_CLPPRS},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_CLPGRS},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_ENSEQ},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_GTP},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51P3M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50P3M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_51N3M},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_50N3M},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_INRPRD},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_INRGRD},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_E67P},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_MTAP},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_TAWP},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_V1P0},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_E67N},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_MTAN},
                                                                {TAG_GRP_LS0_F,    ALS_LS0_TAWN},
                                                                {TAG_GRP_LS0_UI,   ALS_LS0_3V0P0},
                                                    },
                                                    CB_GROUP_2 = {{TAG_GRP_LS1_UI,   ALS_LS1_51P1P},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51N1P},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_50N6P},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51P1C},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P1TD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P1CT},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P1MR},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P1FD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51N1C},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N1TD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N1CT},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N1MR},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P1DD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51P2C},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P2TD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P2CT},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51P2MR},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N1FD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51N2C},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N2TD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N2CT},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N2MR},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_51N1DD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50N6D},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_OPPH},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_OPGR},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_OPLKPH},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_OPLKGR},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_OPLKSF},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_79OI1},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_79OI2},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_79OI3},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_79RSD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_79RSLD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HILKPH},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HILKGR},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50P1P},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_50P1D},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRPH1},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRPH2},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRPH3},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRPH4},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50N1P},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_50N1D},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRGR1},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRGR2},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRGR3},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_HITRGR4},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51P4M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50P4M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51N4M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50N4M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_LLDD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_RMTPD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_RMTGD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_CLPPRS},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_CLPGRS},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_ENSEQ},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_GTP},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51P3M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50P3M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_51N3M},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_50N3M},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_INRPRD},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_INRGRD},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_E67P},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_MTAP},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_TAWP},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_V1P0},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_E67N},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_MTAN},
                                                                {TAG_GRP_LS1_F,    ALS_LS1_TAWN},
                                                                {TAG_GRP_LS1_UI,   ALS_LS1_3V0P0},
                                                    },
                                                    VIT_GROUP_1 = {{TAG_GRP_LS0_UI,  ALS_LS0_OPCN},
                                                                 {TAG_GRP_LS0_F,    ALS_LS0_BCD},
                                                                 {TAG_GRP_LS0_F,    ALS_LS0_XDD},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_XLD},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_NCRD},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_FRD},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_ENARS},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_ENLOVLO},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_ENACL},
                                                                 {TAG_GRP_LS0_UI,   ALS_LS0_ENCLACNT},
                                                    },
                                                    VIT_GROUP_2 = {{TAG_GRP_LS1_UI,  ALS_LS1_OPCN},
                                                                 {TAG_GRP_LS1_F,    ALS_LS1_BCD},
                                                                 {TAG_GRP_LS1_F,    ALS_LS1_XDD},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_XLD},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_NCRD},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_FRD},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_ENARS},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_ENLOVLO},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_ENACL},
                                                                 {TAG_GRP_LS1_UI,   ALS_LS1_ENCLACNT},
                                                    },
                                                    SCADA0_GROUP = {{TAG_GRP_DNP232_UI,   ALS_DNP232_SRCNUM},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_DESTNUM},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_RSPNEEDTIME},
                                                                    {TAG_GRP_DNP232_F,    ALS_DNP232_TSVLDPRD},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_RXFRAGSIZE},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_TXFRAGSIZE},
                                                                    {TAG_GRP_DNP232_F,    ALS_DNP232_LINKSTAT},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_LSTODISCON},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_CONFMODE},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_MAXRETRY},
                                                                    {TAG_GRP_DNP232_F,    ALS_DNP232_DLTIMEOUT},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_USEMODEM},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_BAUDRATE},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_PARITY},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_DATABITS},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_STOPBITS},
                                                                    {TAG_GRP_DNP232_UI,   ALS_DNP232_FLOWCTL},
                                                                    {TAG_GRP_DNP232_UI,   ALS_MODEM_POWER},
                                                    },
                                                    SCADA1_GROUP = {{TAG_GRP_DNPETH_UI,   ALS_DNPETH_SRCNUM},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_DESTNUM},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_RSPNEEDTIME},
                                                                    {TAG_GRP_DNPETH_F,    ALS_DNPETH_TSVLDPRD},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_RXFRAGSIZE},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_TXFRAGSIZE},
                                                                    {TAG_GRP_DNPETH_F,    ALS_DNPETH_LINKSTAT},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_LSTODISCON},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_CONFMODE},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_MAXRETRY},
                                                                    {TAG_GRP_DNPETH_F,    ALS_DNPETH_DLTIMEOUT},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_TCPPORT},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_IPADDR0},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_IPADDR1},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_IPADDR2},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_IPADDR3},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_GWIPADDR0},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_GWIPADDR1},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_GWIPADDR2},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_GWIPADDR3},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_SUBNETMASK0},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_SUBNETMASK1},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_SUBNETMASK2},
                                                                    {TAG_GRP_DNPETH_UI,   ALS_DNPETH_SUBNETMASK3},
                                                    },
};

const ParamDescContents mmi_display_param_contents = {
                    /*TAG GROUP           TAG ALIAS             DisplayDataType,       Min,        Max,       Step,     Level     Unit*/
RANGE_TYPE       =  {{TAG_GRP_LS_UI,      ALS_LS_OPCN,          DISP_DATA_UINT,        1.0,        4.0,       1.0,      3,        N_A},
                     {TAG_GRP_SC_UI,      ALS_SC_59P1P0,        DISP_DATA_UINT,        70.0,       85.0,      5.0,      2,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_27P1P0,        DISP_DATA_UINT,        30.0,       75.0,      5.0,      2,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_TRIG_WAVE,     DISP_DATA_UINT,        1.0,        20.0,      1.0,      3,        "Cycle"},
                     {TAG_GRP_SC_F,       ALS_SC_BLV,           DISP_DATA_FLOAT_1,     18.0,       24.0,      0.1,      2,        "V"},
                     {TAG_GRP_SC_UI,      ALS_SC_SBT_HOUR,      DISP_DATA_UINT,        0.0,        23.0,      1.0,      2,        "Hour"},
                     {TAG_GRP_SC_UI,      ALS_SC_SBT_MIN,       DISP_DATA_UINT,        0.0,        59.0,      1.0,      2,        "Min"},
                     {TAG_GRP_SC_UI,      ALS_SC_SBT_INTERVAL,  DISP_DATA_UINT,        1.0,        4.0,       1.0,      2,        "Day"},
                     {TAG_GRP_LS_UI,      ALS_LS_51P1P,         DISP_DATA_UINT,        20.0,       630.0,     5.0,      3,         "A"},
                     {TAG_GRP_LS_UI,      ALS_LS_51N1P,         DISP_DATA_UINT,        10.0,       315.0,     5.0,      3,         "A"},
                     {TAG_GRP_LS_UI,      ALS_LS_OPLKPH,        DISP_DATA_UINT,        1.0,        4.0,       1.0,      3,         N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_OPLKGR,        DISP_DATA_UINT,        1.0,        4.0,       1.0,      3,         N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_OPLKSF,        DISP_DATA_UINT,        1.0,        4.0,       1.0,      3,         N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_50P1P,         DISP_DATA_UINT,        50.0,       10000.0,   5.0,      3,         "A"},
                     {TAG_GRP_LS_UI,      ALS_LS_50N1P,         DISP_DATA_UINT,        50.0,       10000.0,   5.0,      3,         "A"},
                     {TAG_GRP_LS_F,       ALS_LS_XDD,           DISP_DATA_FLOAT_1,     2.0,        300.0,     0.1,      3,         "Sec"},

},

                    /*TAG GROUP           TAG ALIAS             DisplayDataType,       Min+,       Max+,      Min-      Max-      Step,     Level    Unit*/
DUAL_TYPE        =   {{TAG_GRP_LS_F,      ALS_LS_TAWP,          DISP_DATA_FLOAT_1,     1.0,        170.0,    -170.0,   -1.0,      1.0,       3,       "Deg"},
                      {TAG_GRP_LS_F,      ALS_LS_TAWN,          DISP_DATA_FLOAT_1,     1.0,        170.0,    -170.0,   -1.0,      1.0,       3,       "Deg"},

},

                    /*TAG GROUP           TAG ALIAS             DisplayDataType,       Min,        Max,       Step,     Level     Unit*/
RANGE_OFF_TYPE   =  {{TAG_GRP_LS_UI,      ALS_LS_3V0P0,         DISP_DATA_UINT,        10.0,       80.0,       1.0,      3,        "%"},
                     {TAG_GRP_LS_UI,      ALS_LS_HILKPH,        DISP_DATA_UINT,        1.0,        4.0,       1.0,       3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HILKGR,        DISP_DATA_UINT,        1.0,        4.0,       1.0,       3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_XLD,           DISP_DATA_UINT,        3.0,        300.0,     1.0,     3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_OPPH,          DISP_DATA_UINT,        1.0,        4.0,       1.0,       3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_OPGR,          DISP_DATA_UINT,        1.0,        4.0,       1.0,       3,        N_A},
                     {TAG_GRP_LS_F,       ALS_LS_79OI1,         DISP_DATA_FLOAT_1,     0.5,        60.0,       0.1,      3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_79OI2,         DISP_DATA_UINT,        1.0,        60.0,       1.0,      3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_79OI3,         DISP_DATA_UINT,        1.0,        60.0,       1.0,      3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_51P4M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},

                     {TAG_GRP_LS_UI,      ALS_LS_50P4M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51N4M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_50N4M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51P3M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_50P3M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51N3M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_50N3M,         DISP_DATA_UINT,        1.0,        10.0,       1.0,      3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_V1P0,          DISP_DATA_UINT,        10.0,       80.0,       1.0,      3,        "%"},
                     {TAG_GRP_SC_F,       ALS_SC_81P1P,         DISP_DATA_FLOAT_2,     45.0,       59.0,      0.01,      3,        "Hz"},

                     {TAG_GRP_SC_F,       ALS_SC_81P2P,         DISP_DATA_FLOAT_2,     50.01,      65.0,      0.01,      3,        "Hz"},
                     {TAG_GRP_SC_F,       ALS_SC_81P3P,         DISP_DATA_FLOAT_1,     0.1,        5.0,       0.1,       3,        "Hz"},
                     {TAG_GRP_SC_UI,      ALS_SC_27P2P0,        DISP_DATA_UINT,        20.0,       80.0,      1.0,      3,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_59N1P0,        DISP_DATA_UINT,        2.0,        80.0,      1.0,      3,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_51P5P,         DISP_DATA_UINT,        6.0,        200.0,     1.0,     3,        "A"},
                     {TAG_GRP_SC_F,       ALS_SC_32P1P,         DISP_DATA_FLOAT_1,     0.2,        30.0,      0.1,      3,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_47P1P,         DISP_DATA_UINT,        10.0,       80.0,      1.0,      3,        "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_59P2P0,        DISP_DATA_UINT,        105.0,      190.0,     1.0,     3,        "%"},

},

                    /*TAG GROUP           TAG ALIAS             DisplayDataType,       Min,         Max,       Step,    Level     Unit*/
CURSOR_TYPE      =  {{TAG_GRP_SC_F,       ALS_SC_CT_RATIO,      DISP_DATA_FLOAT_0,     1.0,         6000.0,    1.0,     2,        N_A},
                     {TAG_GRP_SC_F,       ALS_SC_SVOL,          DISP_DATA_FLOAT_1,     6.0,         63.0,      0.1,     2,        "kV"},
                     {TAG_GRP_SC_UI,      ALS_SC_79CLSD,        DISP_DATA_UINT,        0.0,         180.0,     1.0,     2,        "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_TDURD,         DISP_DATA_FLOAT_2,     0.0,         100.0,     0.01,    2,        "Sec"},

                     {TAG_GRP_LS_UI,      ALS_LS_50N6D,         DISP_DATA_UINT,        1.0,         300.0,     1.0,     3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_LLDD,          DISP_DATA_UINT,        1.0,         1000.0,    1.0,     3,        "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_BCD,           DISP_DATA_FLOAT_1,     2.0,         300.0,     0.1,     3,        "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_50N6P,         DISP_DATA_FLOAT_1,     0.1,         20.0,      0.1,     3,        "A"},
                     {TAG_GRP_LS_UI,      ALS_LS_79RSD,         DISP_DATA_UINT,        1.0,         180.0,     1.0,     3,        "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_79RSLD,        DISP_DATA_UINT,        1.0,         180.0,     1.0,     3,        "Sec"},

                     {TAG_GRP_LS_F,       ALS_LS_RMTPD,         DISP_DATA_FLOAT_2,     0.01,        30.0,      0.01,     3,       N_A},
                     {TAG_GRP_LS_F,       ALS_LS_RMTGD,         DISP_DATA_FLOAT_2,     0.01,        30.0,      0.01,     3,      "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_CLPPRS,        DISP_DATA_FLOAT_2,     0.00,        60.0,      0.01,     3,      "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_CLPGRS,        DISP_DATA_FLOAT_2,     0.00,        30.0,      0.01,     3,      "sec"},
                     {TAG_GRP_LS_F,       ALS_LS_INRPRD,        DISP_DATA_FLOAT_1,     0.0,         60.0,      0.1,      3,      "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_INRGRD,        DISP_DATA_FLOAT_1,     0.0,         60.0,      0.1,      3,      "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_MTAP,          DISP_DATA_UINT,        0.0,         359.0,     1.0,      3,      "Deg"},
                     {TAG_GRP_LS_UI,      ALS_LS_MTAN,          DISP_DATA_UINT,        0.0,         359.0,     1.0,      3,      "Deg"},
                     {TAG_GRP_LS_UI,      ALS_LS_NCRD,          DISP_DATA_UINT,        1.0,         600.0,     1.0,      3,      "Sec"},
                     {TAG_GRP_LS_UI,      ALS_LS_FRD,           DISP_DATA_UINT,        60.0,        6000.0,    1.0,      3,      "Min"},

                     {TAG_GRP_SC_F,       ALS_SC_81P1D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_81P2D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_81P3D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_27P2D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_SUBNETMASK2, DISP_DATA_UINT,      0.0,         255.0,     1.0,      3,       N_A},
                     {TAG_GRP_SC_F,       ALS_SC_59P2D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_GCAP,          DISP_DATA_FLOAT_1,     10.0,        100000.0,  1.0,      3,       "kVA"},
                     {TAG_GRP_SC_F,       ALS_SC_59P2D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_F,       ALS_SC_59N1D,         DISP_DATA_FLOAT_1,     0.1,         15.0,      0.1,      3,       "Sec"},
                     {TAG_GRP_SC_UI,      ALS_SC_47P1D,         DISP_DATA_UINT,        1.0,         60.0,      1.0,      3,       "Sec"},

                     {TAG_GRP_SC_UI,      ALS_SC_UNBCR,         DISP_DATA_UINT,         5.0,        100.0,     1.0,      3,       "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_UNBCD,         DISP_DATA_UINT,         5.0,        60.0,      1.0,      3,       "Sec"},
                     {TAG_GRP_SC_UI,      ALS_SC_UNBVR,         DISP_DATA_UINT,         5.0,        100.0,     1.0,      3,       "%"},
                     {TAG_GRP_SC_UI,      ALS_SC_UNBVD,         DISP_DATA_UINT,         5.0,        120.0,     1.0,      3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_50P1D,         DISP_DATA_FLOAT_2,      0.0,        10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_50N1D,         DISP_DATA_FLOAT_2,      0.0,        10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P1TD,        DISP_DATA_FLOAT_2,      0.05,       15.0,      0.01,     3,        N_A},
                     {TAG_GRP_LS_F,       ALS_LS_51P1CT,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P1MR,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P1FD,        DISP_DATA_FLOAT_2,      0.00,       100.0,     0.01,     3,       "Sec"},

                     {TAG_GRP_LS_F,       ALS_LS_51N1TD,        DISP_DATA_FLOAT_2,      0.05,       15.0,      0.01,     3,       N_A},
                     {TAG_GRP_LS_F,       ALS_LS_51N1CT,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51N1MR,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P1DD,        DISP_DATA_FLOAT_2,      0.00,       100.0,     0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P2TD,        DISP_DATA_FLOAT_2,      0.05,       15.0,      0.01,     3,       N_A},
                     {TAG_GRP_LS_F,       ALS_LS_51P2CT,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51P2MR,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51N1FD,        DISP_DATA_FLOAT_2,      0.00,       100.0,     0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51N2TD,        DISP_DATA_FLOAT_2,      0.05,       15.0,      0.01,     3,       N_A},
                     {TAG_GRP_LS_F,       ALS_LS_51N2CT,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},

                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_SUBNETMASK3, DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_LS_F,       ALS_LS_51N2MR,        DISP_DATA_FLOAT_2,      0.00,       10.0,      0.01,     3,       "Sec"},
                     {TAG_GRP_LS_F,       ALS_LS_51N1DD,        DISP_DATA_FLOAT_2,      0.00,       100.0,     0.01,     3,       "Sec"},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_SRCNUM,    DISP_DATA_UINT,         1.00,       65534.0,   1.0,      3,       N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_DESTNUM,   DISP_DATA_UINT,         1.00,       65534.0,   1.0,      3,       N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_RSPNEEDTIME, DISP_DATA_UINT,       0.00,       44640.0,   1.0,      3,       "Min"},
                     {TAG_GRP_DNP232_F,   ALS_DNP232_TSVLDPRD,    DISP_DATA_FLOAT_0,    0.00,       44640.0,   1.0,      3,       "Min"},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_RXFRAGSIZE,  DISP_DATA_UINT,       256.0,      2048.0,    1.0,      3,       N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_TXFRAGSIZE,  DISP_DATA_UINT,       256.0,      2048.0,    1.0,      3,       N_A},
                     {TAG_GRP_DNP232_F,   ALS_DNP232_LINKSTAT,    DISP_DATA_FLOAT_0,    0.0,        60.0,      1.0,      3,       "Sec"},

                     {TAG_GRP_DNP232_UI,  ALS_DNP232_MAXRETRY,    DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNP232_F,   ALS_DNP232_DLTIMEOUT,   DISP_DATA_FLOAT_0,    0.0,        60.0,      1.0,      3,       "Sec"},
                     {TAG_GRP_DNP232_UI,  ALS_MODEM_POWER,        DISP_DATA_UINT,       360.0,      43200.0,   1.0,      3,       "Sec"},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_SRCNUM,      DISP_DATA_UINT,       1.00,       65534.0,   1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_DESTNUM,     DISP_DATA_UINT,       1.00,       65534.0,   1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_RSPNEEDTIME, DISP_DATA_UINT,       0.00,       44640.0,   1.0,      3,       "Min"},
                     {TAG_GRP_DNPETH_F,   ALS_DNPETH_TSVLDPRD,    DISP_DATA_FLOAT_0,    0.00,       44640.0,   1.0,      3,       "Min"},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_RXFRAGSIZE,  DISP_DATA_UINT,       256.0,      2048.0,    1.0,      3,       "Byte"},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_TXFRAGSIZE,  DISP_DATA_UINT,       256.0,      2048.0,    1.0,      3,       "Byte"},
                     {TAG_GRP_DNPETH_F,   ALS_DNPETH_LINKSTAT,    DISP_DATA_FLOAT_0,    0.0,        60.0,      1.0,      3,       "Sec"},

                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_MAXRETRY,    DISP_DATA_UINT,       0.0,        10.0,      1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_F,   ALS_DNPETH_DLTIMEOUT,   DISP_DATA_FLOAT_0,    0.0,        60.0,      1.0,      3,       "Sec"},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_TCPPORT,     DISP_DATA_UINT,       0.0,        65535.0,   0.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_IPADDR0,     DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_IPADDR1,     DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_IPADDR2,     DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_IPADDR3,     DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_GWIPADDR0,   DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_GWIPADDR1,   DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_GWIPADDR2,   DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},

                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_GWIPADDR3,   DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_SUBNETMASK0, DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_SUBNETMASK1, DISP_DATA_UINT,       0.0,        255.0,     1.0,      3,       N_A},
},


                    /*TAG GROUP           TAG ALIAS             DisplayDataType,       Value 1  Value 2     Value 3     Value 4     Value 5     Count        Level      Unit*/
SELECT_TYPE      =  {{TAG_GRP_SC_UI,      ALS_SC_TIME,          DISP_DATA_UINT,        5,       10,         15,         30,         60,         5,           2,         "Min"},
                     {TAG_GRP_SC_UI,      ALS_SC_LPTIME,        DISP_DATA_UINT,        5,       10,         15,         30,         60,         5,           2,         "Min"}},


                    /*TAG GROUP          TAG ALIAS                  DisplayDataType,       Value 1, Value 2,    Value 3,    Str1        Str2        Str3       Cnt       Level      Unit*/
SELECT_NAME_TYPE =  {{TAG_GRP_SC_UI,     ALS_SC_TARGSYS_FREQ,      DISP_DATA_UINT,        50,      60,         N_A,        "50",       "60",       N_A,        2,         2,        "Hz"},
                     {TAG_GRP_SC_UI,     ALS_SC_ROTATION,          DISP_DATA_UINT,        0,       1,          N_A,        "ABC",      "CBA",      N_A,        2,         2,        N_A},
                     {TAG_GRP_SC_UI,     ALS_SC_FIRSCL,            DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         2,        N_A},
                     {TAG_GRP_SC_UI,     ALS_SC_TYPE,              DISP_DATA_UINT,        0,       1,          N_A,        "Rolling",  "Thermal",  N_A,        2,         2,        N_A},
                     {TAG_GRP_SC_UI,     ALS_SC_STGRP,             DISP_DATA_UINT,        0,       1,          N_A,        "Group1",   "Group2",   N_A,        2,         2,        N_A},
                     {TAG_GRP_SC_UI,     ALS_SC_STGRP_AT_MODE_ON,  DISP_DATA_UINT,        0,       1,          N_A,        "Off",      "On",       N_A,        2,         2,        N_A},

                     {TAG_GRP_LS_UI,      ALS_LS_ENSEQ,             DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_GTP,               DISP_DATA_UINT,        0,       1,          N_A,        "No",       "Yes",      N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_E67P,              DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_E67N,              DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_ENARS,             DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_ENLOVLO,           DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},

                     {TAG_GRP_LS_UI,      ALS_LS_ENACL,             DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_ENCLACNT,          DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_SC_UI,      ALS_SC_ENBFD,             DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         3,        N_A},
                     {TAG_GRP_SC_UI,      ALS_SC_ENOC,              DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         2,        N_A},
                     {TAG_GRP_SC_UI,      ALS_SC_ENDELTAI2_I1,      DISP_DATA_UINT,        0,       1,          N_A,        "Disable",  "Enable",   N_A,        2,         2,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_CONFMODE,      DISP_DATA_UINT,        0,       1,           2,         "Never",    "Sometim", "Always",    3,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_USEMODEM,      DISP_DATA_UINT,        0,       1,          N_A,        "No",       "Yes",      N_A,        2,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_BAUDRATE,      DISP_DATA_UINT,        7,       8,           9,         "19200",    "38400",    "57600",    3,         3,        "Bps"},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_PARITY,        DISP_DATA_UINT,        0,       1,           2,         "NONE",     "EVEN",     "ODD",      3,         3,        N_A},

                     {TAG_GRP_DNP232_UI,  ALS_DNP232_DATABITS,      DISP_DATA_UINT,        0,       1,          N_A,        "Bit_7",    "Bit_8",    N_A,        2,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_STOPBITS,      DISP_DATA_UINT,        0,       1,          N_A,        "Bit_1",    "Bit_2",    N_A,        2,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_STOPBITS,      DISP_DATA_UINT,        0,       1,          N_A,        "Bit_1",    "Bit_2",    N_A,        2,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_FLOWCTL,       DISP_DATA_UINT,        0,       1,          N_A,        "NONE",     "HW",       N_A,        2,         3,        N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_CONFMODE,      DISP_DATA_UINT,        0,       1,           2,         "Never",    "Sometim", "Always",    3,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRPH1,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRPH2,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRPH3,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRPH4,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRGR1,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},

                     {TAG_GRP_LS_UI,      ALS_LS_HITRGR2,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRGR3,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_HITRGR4,           DISP_DATA_UINT,        0,       1,          N_A,        "OFF",      "ON",       N_A,        2,         3,        N_A},
                     {TAG_GRP_DNPETH_UI,  ALS_DNPETH_LSTODISCON,    DISP_DATA_UINT,        0,       1,          N_A,        "False",    "True",     N_A,        2,         3,        N_A},
                     {TAG_GRP_DNP232_UI,  ALS_DNP232_LSTODISCON,    DISP_DATA_UINT,        0,       1,          N_A,        "False",    "True",     N_A,        2,         3,        N_A},
},

                     /*TAG GROUP          TAG ALIAS             DisplayDataType             Min                     Max                 Level       Unit*/
NAME_TYPE        =  {{TAG_GRP_LS_UI,      ALS_LS_51P1C,         DISP_DATA_UINT,             TCCCVT_COOPER_101,      TCCCVT_DEF,         3,          N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51N1C,         DISP_DATA_UINT,             TCCCVT_COOPER_101,      TCCCVT_DEF,         3,          N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51P2C,         DISP_DATA_UINT,             TCCCVT_COOPER_101,      TCCCVT_DEF,         3,          N_A},
                     {TAG_GRP_LS_UI,      ALS_LS_51N2C,         DISP_DATA_UINT,             TCCCVT_COOPER_101,      TCCCVT_DEF,         3,          N_A}},
};


const PageContents mmi_display_contents = {
SMALL = {
         {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
               PAGE_PRT_PASSWORD,                   AUTHORITY,                       SAVE_SETTING,           4,
              {/*Line Contents Type     Line Contents        String             Line Property                   */
               { LINE_CONTENTS_TYPE_A,  LINE_A = { " [LEVEL # PASSWORD] ",      {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = { " ",      {LINE_PRT_NONE}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = { " Level # :",               {LINE_PRT_SETTING_U}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = { " [0 - Z : 1]",      {LINE_PRT_INFO}}},
              }
         },
         {    /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
              PAGE_PRT_SAVE_SETTING,              SAVE_SETTING,                      MAIN_MENU,           3,
          {    /*Line Contents Type     Line Contents        String             Line Property                   */
              { LINE_CONTENTS_TYPE_A, LINE_A = { " [SETTING DATA SAVE]",   LINE_PRT_TITLE } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " Press ENTER Save  ",    LINE_PRT_NONE } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " Press MENU  Cancel ",   LINE_PRT_NONE } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { "                    ",   LINE_PRT_NONE } },

          }
         },
         {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
               PAGE_PRT_SETTING,          GLOBAL_SYSTEMCONFIG,            GLOABAL,                3,
              {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
               { LINE_CONTENTS_TYPE_A,  LINE_A = {" [ SYSTEM CONFIG ]",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = {" CTRatio:",                 {LINE_PRT_SETTING_F_0,   TAG_PARAM = {TAG_GRP_SC_F,  ALS_SC_CT_RATIO}}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = {" SystemV:",                 {LINE_PRT_SETTING_F_1,   TAG_PARAM = {TAG_GRP_SC_F,  ALS_SC_SVOL}}}}
              }
         },
         {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
               PAGE_PRT_SETTING,          GLOBAL_SYSTEM_FREQUENCY,        GLOABAL,                2,
              {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
               { LINE_CONTENTS_TYPE_A,  LINE_A = {" [SYSTEM FREQUENCY]",       {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A,  LINE_A = {" Frequency:",               {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_TARGSYS_FREQ}}}}
              }
         },
         {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
               PAGE_PRT_SETTING,          GLOBAL_PHASE_ROTATION,          GLOABAL,                2,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A,  LINE_A = {" [PHASE ROTATION]",        {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A,  LINE_A = {" Phase Rotation:",         {LINE_PRT_SETTING_U,     TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_ROTATION}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_FI_RESET,                GLOABAL,                2,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A,  LINE_A = {" [F.I RESET MODE]",        {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A,  LINE_A = {" FIRSCL:",                 {LINE_PRT_SETTING_U,     TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_FIRSCL}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_VOLTAGE_DETECT,          GLOABAL,                3,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [VOLTAGE DETECTION]",       {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" On  Level:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_59P1P0}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Off Level:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_27P1P0}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_DEMAND_METER,            GLOABAL,                3,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [DEMAND METER]",       {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" TimePeriod:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_TIME}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Type:",                   {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_TYPE}}}},
             }
         },
         {  /*Page Property                         PageCode                            Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_LOAD_PROFILE_TIME,           GLOABAL,                2,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [Load Profile Time]",       {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Time Period:",              {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_LPTIME}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_FAULT_WAVE_PRECYCLE,     GLOABAL,                2,
             {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [Fltwv. Pre-Cycle]",        {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Pre-Cycle:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_TRIG_WAVE}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code        Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_SETTING_GROUP_CHANGE,    GLOABAL,                3,
             {/*Line Contents Type     Line Contents        String                  Line Property                       TAG GROUP         ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [SET GROUP CHANGE]",     {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Set. Mode:",              {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_STGRP}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Set. Mode(Auto):",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_STGRP_AT_MODE_ON}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code         Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_RECLOSE_SUPERVISION,     GLOABAL,                 2,
             {/*Line Contents Type     Line Contents        String                   Line Property                       TAG GROUP         ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [Reclose Superv.]",     {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Wait Time:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_79CLSD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_MIN_TRIP_TIME,           GLOABAL,                  2,
             {/*Line Contents Type     Line Contents        String                   Line Property                       TAG GROUP         ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [MIN. TRIP TIME]",     {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Dur. time:",              {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_TDURD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,             GLOBAL_BATTERY_MANAGE,          GLOABAL,                  5,
             {/*Line Contents Type     Line Contents        String                  Line Property                       TAG GROUP         ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [BATTERY MANAGEMENT]",     {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Low Volt:",               {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F,  ALS_SC_BLV}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" BT_Hour:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_SBT_HOUR}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" BT_Min:",                 {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_SBT_MIN}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" BT_Interv.:",             {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_SBT_INTERVAL}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     CB,                             SETTING_TAB,              4,
             {/*Line Contents Type                                                  Line Type                 Child Page Code*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [ CB ]",     {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" 1.CB Group1",             {LINE_PRT_SELECT,           CB_GROUP1}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" 2.CB Group2",             {LINE_PRT_SELECT,           CB_GROUP2}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" 3.CB Group Copy",         {LINE_PRT_SELECT,           CB_GROUP_COPY}}},
             }
         },

         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_GRP_COPY,                    CB_GROUP_COPY,                  CB,                       3,
             {/*Line Contents Type                                              Line Type */
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [CB GROUP COPY]",        {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" 1.Group1->Group2",       {LINE_PRT_SELECT}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" 2.Group2->Group1",       {LINE_PRT_SELECT}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                PICKUP_CURRENT,                 CB_GROUP1,                4,
             {/*Line Contents Type                                            Line Property                       TAG GROUP         ALIAS*/
              { LINE_CONTENTS_TYPE_A, LINE_A = {" [PICKUP CURRENT]",        {LINE_PRT_TITLE}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Min.Phase :",             {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P1P}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Min.Ground :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51N1P}}}},
              { LINE_CONTENTS_TYPE_A, LINE_A = {" Min.SEF :",               {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F,  ALS_LS_50N6P}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     TCC_CURVE,                      CB_GROUP1,                5,
           {/*Line Contents Type                                              Line Property         Child Page Code*/
            { LINE_CONTENTS_TYPE_A, LINE_A = { " [TCC CURVE]",             {LINE_PRT_TITLE}}},
            { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Fast-Phase",            {LINE_PRT_SELECT,       TCC_FAST_PHASE}}},
            { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Fast-Ground",           {LINE_PRT_SELECT,       TCC_FAST_GROUND}}},
            { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Delay-Phase",           {LINE_PRT_SELECT,       DELAY_PHASE}}},
            { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Delay-Ground",          {LINE_PRT_SELECT,       DELAY_GROUND}}},
           }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                SEF_DELAY,                      CB_GROUP1,                2,
           {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
            { LINE_CONTENTS_TYPE_A, LINE_A = { " [SEF Delay]",             {LINE_PRT_TITLE}}},
            { LINE_CONTENTS_TYPE_A, LINE_A = { " Delay :",                 {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50N6D}}}},
           }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                ACTIVATE_FAST_CURVE,            CB_GROUP1,                3,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [ACT. FAST CURVE]",   {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPPH}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPGR}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                OPERATION_TO_LOCK,              CB_GROUP1,                4,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [OPER. TO LOCK.]",    {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPLKPH}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPLKGR}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " SEF :",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPLKSF}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                RECLOSING_INTERVAL,             CB_GROUP1,                4,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [RECLOSING INTERVAL]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1st:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F,  ALS_LS_79OI1}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2nd:",                 {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_79OI2}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 3rd:",                 {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_79OI3}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                RESET_TIME,                     CB_GROUP1,                3,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [RESET TIME]",        {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 79CY:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_79RSD}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 79LO:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_79RSLD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                HIGH_LOCK_P,                    CB_GROUP1,                2,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [HIGH I LOCK(P)]",    {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Activate :",          {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HILKPH}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                HIGH_LOCK_G,                    CB_GROUP1,                2,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [HIGH I LOCK(G)]",    {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Activate :",          {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HILKGR}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                SEQ_COORDINATION,               CB_GROUP1,                2,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Seq Coordination]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Coordination:",       {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_ENSEQ}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                GROUND_TRIP_PREC,               CB_GROUP1,                2,
             {/*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Ground Trip Prec.]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Precedence:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_GTP}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     INRUSH_RESTRAINT,               CB_GROUP1,                3,
              {/*Line Contents Type                                             Line Property                 Child Page */
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [INRUSH RESTRAINT]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Pickup Multiplier", {LINE_PRT_SELECT,                IR_PICKUP_MULTIPLIER}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Reset Time", {LINE_PRT_SELECT,                IR_RESET_TIME}}},
              }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                DIRE_RELAY_P,                   CB_GROUP1,                5,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [DIRE. RELAY(P)]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Dire.Phase:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_E67P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Max.TorqAng:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_MTAP}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Angle Width:",        {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F,  ALS_LS_TAWP}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Minimum V1:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_V1P0}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                DIRE_RELAY_G,                   CB_GROUP1,                5,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [DIRE. RELAY(G)]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Dire.Ground:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_E67N}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Max.TorqAng:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_MTAN}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Angle Width:",        {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_TAWN}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Minimum V1:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_3V0P0}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_DEFAULT,                       OPEN_CONDUCTOR,                   SETTING_TAB,                5,
             {/**Line Contents Type                                              Line Property         Child Page Code*/
              { LINE_CONTENTS_TYPE_A, LINE_A = { " [OPEN CONDUCTOR]", {LINE_PRT_TITLE} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Open Conductor", {LINE_PRT_SELECT, OC_OPEN_CONDUCTOR} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Delta I2/I1", {LINE_PRT_SELECT, OC_DELTA} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Unbalance Current", {LINE_PRT_SELECT, OC_UNBALANCE_CURRENT} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Unbalance Voltage", {LINE_PRT_SELECT, OC_UNBALANCE_VOLTAGE} } },
             }
         },

         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     OC_OPEN_CONDUCTOR,              OPEN_CONDUCTOR,           2,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [OPEN CONDUCTOR]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Open Con:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_ENOC}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     OC_DELTA,                       OPEN_CONDUCTOR,           2,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [DELTA I2/I1]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Delta I2/I1:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_ENDELTAI2_I1}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     OC_UNBALANCE_CURRENT,           OPEN_CONDUCTOR,           3,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Unbalance Current]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Level:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI,ALS_SC_UNBCR}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Det. Time:",          {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_UNBCD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     OC_UNBALANCE_VOLTAGE,           OPEN_CONDUCTOR,           3,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Unbalance Voltage]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Level:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_UNBVR}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Det. Time:",          {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_UNBVD}}}},
             }
         },

          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                IR_PICKUP_MULTIPLIER,           INRUSH_RESTRAINT,         5,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [PICKUP MULT]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P3M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " HighI-Phase:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50P3M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51N3M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " HighI-Ground:",       {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50N3M}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                IR_RESET_TIME,                  INRUSH_RESTRAINT,         3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [RESET TIME]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F,ALS_LS_INRPRD}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F,ALS_LS_INRGRD}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_UNDER_FREQUENCY,             CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Under Frequency]",  {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P1P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P1D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_OVER_FREQUENCY,              CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Over Frequency]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P2P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P2D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_ROCOF,                       CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [ROCOF(df/dt)]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P3P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_81P3D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_UNDER_VOLTAGE,               CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Under Voltage]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_27P2P0}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F,  ALS_SC_27P2D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_OVER_VOLTAGE,                CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Over Voltage]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI,ALS_SC_59P2P0}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_59P2D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_REVERSE_POWER,               CUSTOMER_PROTECTION,       4,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Reverse Power]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Rat.Power:",          {LINE_PRT_SETTING_F_1, TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_GCAP}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_F_1, TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_32P1P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1, TAG_PARAM = {TAG_GRP_SC_F, ALS_SC_59P2D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_V0_DISPLACEMENT,             CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [V0 Displacement]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_59N1P0}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_SC_F,  ALS_SC_59N1D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_UNBALANCE_V,                 CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Unbalance V(V0/V1)]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Pick. Lev.:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_47P1P}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD:",                 {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_47P1D}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING,                     CP_BLOWN_FUSE_DETECTION,        CUSTOMER_PROTECTION,      3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Blown Fuse Detect]",  {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " BFD:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_ENBFD}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Fuse Rated I:",       {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_51P5P}}}},
              }
          },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     VIT_MODE,                       SETTING_TAB,              4,
             {/*Line Contents Type                                             Line Property                  Child Page */
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [VIT MODE]",            {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.VIT Group1",          {LINE_PRT_SELECT,                 VIT_GROUP1}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.VIT Group2",          {LINE_PRT_SELECT,                 VIT_GROUP2}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.VIT Group Copy",      {LINE_PRT_SELECT,                 VIT_GROUP_COPY}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_GRP_COPY,                    VIT_GROUP_COPY,                 VIT_MODE,                 3,
             {/*Line Contents Type                                             Line Property*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = {" [VIT GROUP COPY]",       {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = {" 1.Group1->Group2",       {LINE_PRT_SELECT}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = {" 2.Group2->Group1",       {LINE_PRT_SELECT}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                VIT_COUNT,                      VIT_GROUP1,                 2,
             {/*Line Contents Type                                             Line Property                    TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [ COUNT ]",          {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Count :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_OPCN}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                VIT_NC_CLOSE_TIME,              VIT_GROUP1,               3,
             {/*Line Contents Type                                             Line Property                    TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A= { " [N.C Close Time]",     {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " BCD :",               {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_BCD}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " N.C Close:",          {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_XDD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                VIT_NO_CLOSE_TIME,              VIT_GROUP1,               2,
             {
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [N.O Close Time]",    {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " N.O Close:",          {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_XLD}}}},
             }
         },
         { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
           PAGE_PRT_SETTING,                VIT_RESET_TIME,                 VIT_GROUP1,               3,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [RESET TIME]",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " AutoRstTime:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_NCRD}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " ForceRstTime:",       {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_FRD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                VIT_ADDITIONAL_FUNC,            VIT_GROUP1,               5,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [ADDITIONAL FUNC.]",  {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " AUTO Reset:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_ENARS}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " LOV Lockout:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_ENLOVLO}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Rst Auto CL:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_ENACL}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " ENCLACNT:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_ENCLACNT}}}},
             }
         },

         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_DEFAULT,                       COLD_LOAD,                        CB_GROUP1,                    5,
            {   /*Line Contents Type                                                 Line Property                 Child Page */
              { LINE_CONTENTS_TYPE_A, LINE_A = { " [COLD LOAD]",                  {LINE_PRT_TITLE} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Pickup Multiplier",          {LINE_PRT_SELECT,              CL_PICKUP_MULTIPLIER} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Loss Of Diversity",          {LINE_PRT_SELECT,              LOSS_OF_LOAD_DIVERSITY} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.RestoreMin.Pickup",          {LINE_PRT_SELECT,              RESTORE_MIN_PICKUP} } },
              { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Reset Time",                 {LINE_PRT_SELECT,              CL_RESET_TIME} } },
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                CL_PICKUP_MULTIPLIER,                    COLD_LOAD,                5,
             {/*Line Contents Type                                             Line Property                        TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [PICKUP MULTIPLIER]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase  :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P4M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " HighI-Phase:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50P4M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51N4M}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " HighI-Ground:",       {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50N4M}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                       LOSS_OF_LOAD_DIVERSITY,           COLD_LOAD,                2,
             {/*Line Contents Type                                                Line Property                       TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [LOSS_OF_LOAD_DIVERSITY]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " TD :",                    {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_LLDD}} } },

             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                   RESTORE_MIN_PICKUP,                    COLD_LOAD,                3,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [RESTORE MIN.PICKUP]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_RMTPD}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_RMTGD}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_SETTING,                     CL_RESET_TIME,                       COLD_LOAD,                3,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [RESET TIME]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Phase :",             {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_CLPPRS}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " Ground :",            {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_CLPGRS}}}},
              }
          },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     STATUS_TAB,                     MAIN_MENU,                3,
             {/*Line Contents Type                                             Line Property                    Child Page */
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [ STATUS ]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Contact Wear", {LINE_PRT_SELECT,                   CONTACT_WEAR}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Misc", {LINE_PRT_SELECT,                   MISC}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     CONTACT_WEAR,                   STATUS_TAB,               4,
             {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [Contact Wear]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " A Phase:",            {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_NVV_F, ALS_NVV_CWFA}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " B Phase:",            {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_NVV_F, ALS_NVV_CWFB}}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " C Phase:",            {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_NVV_F, ALS_NVV_CWFC}}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     COMMUNICATION,                  SETTING_TAB,              3,
             {/*Line Contents Type                                             Line Property                 Child Page */
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [COMMUNICATION]", {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.SCADA (Serial)", {LINE_PRT_SELECT,               COMM_SCADA0}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.SCADA (ETH)",    {LINE_PRT_SELECT,               COMM_SCADA1}}},
             }
         },
         {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_DEFAULT,              COMM_SCADA0,                    COMMUNICATION,            4,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SCADA (Serial)]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.DNP Protocol",  {LINE_PRT_SELECT,                SCADA0_DNP}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Serial",        {LINE_PRT_SELECT,                SCADA0_SERIAL}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " *.Save Settings", {LINE_PRT_SELECT,                SAVE_SETTING}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_DEFAULT,              COMM_SCADA1,                    COMMUNICATION,            4,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SCADA (ETH)]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.DNP Protocol", {LINE_PRT_SELECT,                 SCADA1_DNP}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.TCP/IP", {LINE_PRT_SELECT,                       SCADA1_TCP_IP}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " *.Save Settings", {LINE_PRT_SELECT,                SAVE_SETTING}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     PRODUCT_INFO_TAB,               MAIN_MENU,                5,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [PRODUCT INFO]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.H/W Serial Number", {LINE_PRT_SELECT,                HW_SERIAL_NUMBER}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Model Number",      {LINE_PRT_SELECT,                MODEL_NUMBER}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Identifier",        {LINE_PRT_SELECT,                IDENTIFIER}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.F/W Version",       {LINE_PRT_SELECT,                FW_VERSION}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_HW_INFO,                  HW_SERIAL_NUMBER,               PRODUCT_INFO_TAB,         2,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [H/W Serial Number]",    {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                       {LINE_PRT_DISPLAY_COMMON}}},
              }
          },

          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_MODEL_NUM,                   MODEL_NUMBER,                   PRODUCT_INFO_TAB,         2,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [Model Number]",         {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                       {LINE_PRT_DISPLAY_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_IDENTIFIER,                  IDENTIFIER,                     PRODUCT_INFO_TAB,         2,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [IDENTIFIER]",           {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                       {LINE_PRT_DISPLAY_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
            PAGE_PRT_VERSION,                     FW_VERSION,                     PRODUCT_INFO_TAB,         2,
              {/*Line Contents Type                                             Line Property                 TAG GROUP         ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [F/W VERSION]",          {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                       {LINE_PRT_DISPLAY_COMMON,      TAG_PARAM = {TAG_GRP_SC_UI, ALS_SC_PECAPP_VERSION}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_DEFAULT,                     EVENT_TAB,                      MAIN_MENU,                4,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ Event ]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Sequential", {LINE_PRT_SELECT,                SEQ_EVENT}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Fault", {LINE_PRT_SELECT,                FAULT_EVENT}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Fault Wave", {LINE_PRT_SELECT,                FAULT_WAVE_EVENT}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SEQ_EVENT,                   SEQ_EVENT,                      EVENT_TAB,                4,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SEQUENTIAL EVENT]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_FLT_EVENT,                   FAULT_EVENT,                    EVENT_TAB,                4,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { "      [FAULT]      ", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_FLTWV_EVENT,                 FAULT_WAVE_EVENT,               EVENT_TAB,                2,
              {/*Line Contents Type                                             Line Property                 Child Page */
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [FAULT WAVE]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ", {LINE_PRT_DISPLAY_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_TIME,                        TIME,                           SETTING_TAB,              4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [CURRENT TIME]",             {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                           {LINE_PRT_DISPLAY_COMMON}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SETTING TIME]",             {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                           {LINE_PRT_SETTING_COMMON}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING_PASSWORD,            VIEWER,                         PASSWORD,                 4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [Viewer]",                   {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Password : ****",            {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                           {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ 0 - Z : 1 ]",              {LINE_PRT_INFO}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING_PASSWORD,            OPERATOR,                       PASSWORD,                 4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [Operator]",                {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Password : ****",           {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                          {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ 0 - Z : 1 ]",             {LINE_PRT_INFO}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_SETTING_PASSWORD,            ENGINEER,                       PASSWORD,                 4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [Engineer]",                {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Password : ****",           {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                          {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ 0 - Z : 1 ]",             {LINE_PRT_INFO}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
               PAGE_PRT_SETTING_PASSWORD,           ADMIN,                          PASSWORD,                 4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [Admin]",                   {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Password : ****",           {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                          {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ 0 - Z : 1 ]",             {LINE_PRT_INFO}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
              PAGE_PRT_BAT_TEST,                    BATTERY_TEST,                   MAIN_VIEW,                4,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ BATTERY TEST ]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { "                    ", {LINE_PRT_NONE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " BatteryV :",         {LINE_PRT_DISPLAY_F_1,     TAG_PARAM = {TAG_GRP_AI, ALS_AI_AIBATV}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ............. ",     {LINE_PRT_NONE,            TAG_PARAM = {TAG_GRP_BV, ALS_BV_BATTB}}}},
              }
          },
          {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_DEFAULT,                    COUNT_TAB,                     MAIN_MENU,                4,
               {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [ COUNT ]",                 {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Prot. CNT:",                {LINE_PRT_DISPLAY_U,      TAG_PARAM = {TAG_GRP_NVV_UI, ALS_NVV_PT_CNT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " TotalTripCNT:",             {LINE_PRT_DISPLAY_U,      TAG_PARAM = {TAG_GRP_NVV_UI, ALS_NVV_TOP_CNT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Restart CNT:",              {LINE_PRT_DISPLAY_U,      TAG_PARAM = {TAG_GRP_NVV_UI, ALS_NVV_CL_RST_CNT}}}},
               }
          },
},
MEDIUM = {
          {     /*Page Property                   PageCode                          Parent Page code           Line Contents count*/
                  PAGE_PRT_MEASURE,               MAIN_VIEW,                        MAIN_MENU,                 8,
               {/*Line Contents Type    Line Type                            Line Property                       TAG GROUP        ALIAS*/
                { LINE_CONTENTS_TYPE_C, LINE_C = {"IA:",                    {{LINE_PRT_DISPLAY_F_0,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_IA}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VA}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VR}}}}},
                { LINE_CONTENTS_TYPE_C, LINE_C = {"IB:",                    {{LINE_PRT_DISPLAY_F_0,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_IB}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VB}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VS}}}}},
                { LINE_CONTENTS_TYPE_C, LINE_C = {"IC:",                    {{LINE_PRT_DISPLAY_F_0,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_IC}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VC}},
                                                                             {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_VT}}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = {"IN:",                     {LINE_PRT_DISPLAY_F_0,  TAG_PARAM = {TAG_GRP_AI,     ALS_AI_RMS_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = {"79RS(L)T[Sec]:",          {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_NMV_UI, ALS_NMV_RS_L_T_COUNT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = {"79OIT[Sec]:",             {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_NMV_UI, ALS_NMV_79OIT_COUNT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "ShotCounter:SH",         {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_NMV_UI, ALS_NMV_SH_COUNT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "TotalCounter:",          {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_NVV_UI, ALS_NVV_TOP_CNT}}}},
               },
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                   MAIN_MENU,                    MAIN_VIEW,                  8,
               {/*Line Contents Type    Line Type                           Line Property                       Child Page Code*/
                { LINE_CONTENTS_TYPE_A, LINE_A = {" [Main Menu]",          {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Settings",          {LINE_PRT_SELECT,                   SETTING_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Metering",          {LINE_PRT_SELECT,                   METERING_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Status",            {LINE_PRT_SELECT,                   STATUS_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Count",             {LINE_PRT_SELECT,                   COUNT_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Diagnosis",         {LINE_PRT_SELECT,                   DIAGNOSIS_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.Product info",      {LINE_PRT_SELECT,                   PRODUCT_INFO_TAB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Event",             {LINE_PRT_SELECT,                   EVENT_TAB}}}
               }
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                   SETTING_TAB,                  MAIN_MENU,                  9,
               {/*Line Contents Type                                         Line Type                          Child Page Code*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [ SETTINGS ]",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Global",            {LINE_PRT_SELECT,                   GLOABAL}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.CB",                {LINE_PRT_SELECT,                   CB}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.VIT Mode",          {LINE_PRT_SELECT,                   VIT_MODE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Open Conductor",    {LINE_PRT_SELECT,                   OPEN_CONDUCTOR}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Customer Prot.",    {LINE_PRT_SELECT,                   CUSTOMER_PROTECTION}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.Communication",     {LINE_PRT_SELECT,                   COMMUNICATION}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Time",              {LINE_PRT_SELECT,                   TIME}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.Password",          {LINE_PRT_SELECT,                   PASSWORD}}}
               }
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                   METERING_TAB,                 MAIN_MENU,                  9,
               {/*Line Contents Type                                        Line Type                           Child Page Code*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [ METERING ]",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Voltage & Current", {LINE_PRT_SELECT,                    VOLTAGE_CURRENT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.L-L Voltage",       {LINE_PRT_SELECT,                    LL_VOLTAGE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Power(Act/Rct)",    {LINE_PRT_SELECT,                    POWER_ACT_RCT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Power(App/Fact)",   {LINE_PRT_SELECT,                    POWER_APP_FACT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Symmetric Comp.",   {LINE_PRT_SELECT,                    SYM_COMPONENT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.Energy",            {LINE_PRT_SELECT,                    ENERGY}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Demand Power",      {LINE_PRT_SELECT,                    DEMAND_POWER}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.Demand Current",    {LINE_PRT_SELECT,                    DEMAND_CURRENT}}},
               }
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                   MISC,                         STATUS_TAB,                 7,
              {   /*Line Contents Type                                              Line Type                   TAG GROUP        ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [ MISC ]",  {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " ChargeV:",             {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_AICHV}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Battery:",             {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_AIBATV}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Temp:",                {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_CTEMP}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " +5VREF:",              {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_12VAP}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " -5VREF:",              {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_12VAN}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 0.75VREF:",            {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_REF_DP}}}},
              }
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                PAGE_PRT_SETTING,              SCADA0_SERIAL,                COMM_SCADA0,                8,
              {   /*Line Contents Type                                              Line Type                               TAG GROUP        ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SERIAL]",    {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Use Modem:",             {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_USEMODEM}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Baudrate:",              {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_BAUDRATE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Parity:",                {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_PARITY}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Num Data Bits:",         {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_DATABITS}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Num Stop Bits:",         {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_STOPBITS}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Flow Control:",          {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_FLOWCTL}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Inter. Time:",           {LINE_PRT_SETTING_U, TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_MODEM_POWER}}}},
              }
          },
          {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
               PAGE_PRT_DEFAULT,                     SYM_COMPONENT,                  METERING_TAB,             9,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [SYM COMPONENT]", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " (Voltage)", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " V0:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_V0}},
                                                                             {LINE_PRT_DISPLAY_F_0 ,TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_V0}}}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " V1:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_V1}},
                                                                             {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_V1}}}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " V2:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_V2}},
                                                                             {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_V2}}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " (Current)", {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " I0:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_I0}},
                                                                             {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_I0}}}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " I1:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_I1}},
                                                                             {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_I1}}}}},
                  { LINE_CONTENTS_TYPE_B, LINE_B = { " I2:",                {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_I2}},
                                                                             {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_I2}}}}},
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
                PAGE_PRT_DEFAULT,                  PASSWORD,                               SETTING_TAB,             6,
              {
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [PASSWORD]",               {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Viewer",                 {LINE_PRT_SELECT,          VIEWER}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Operator",               {LINE_PRT_SELECT,          OPERATOR}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Engineer",               {LINE_PRT_SELECT,          ENGINEER}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Admin",                  {LINE_PRT_SELECT,          ADMIN}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Save Password",          {LINE_PRT_SELECT,          SAVE_SETTING}}},
              }
          },
          {       /*Page Property                     PageCode                    Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                   DIAGNOSIS_TAB,              MAIN_MENU,                  15,
              {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [DIAGNOSIS]",             {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [Norm.:0/Blown.:1]",      {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Operate Fuse:",           {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_OPFB}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Control Fuse:",           {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_CPFB}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Modem Fuse:",             {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_MODFB}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " ",                        {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [Norm.:0/Abnorm.:1]",     {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " CWF:",                    {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_CWF}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " CPT:",                    {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_CPT}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " EMOL:",                   {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_EMOL}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " CTT:",                    {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_CTT}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " MODEMCHK:",               {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_MMI,   ALS_MMI_LEDMODEM}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " COCT:",                   {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_COCT}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " IPT:",                    {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_IPT}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " CFB:",                    {LINE_PRT_DISPLAY_U,    TAG_PARAM = {TAG_GRP_BV,    ALS_BV_CFB}}}},
              },
          },
          {       /*Page Property                     PageCode                    Parent Page code            Line Contents count*/
                  PAGE_PRT_SETTING,           SCADA0_DNP,                 COMM_SCADA0,                12,
              {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [DNP Protocol]",      {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Src Addr:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_SRCNUM}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Dst Addr:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_DESTNUM}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Sync:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_RSPNEEDTIME}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Clock Valid:",             {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNP232_F,  ALS_DNP232_TSVLDPRD}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Rx len:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_RXFRAGSIZE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Tx len:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_TXFRAGSIZE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " LinkSt. Per.:",            {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNP232_F,  ALS_DNP232_LINKSTAT}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Link Discon.:",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_LSTODISCON}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. Mode:",              {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_CONFMODE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. Retry Cnt:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNP232_UI, ALS_DNP232_MAXRETRY}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. TimeOut:",           {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNP232_F,  ALS_DNP232_DLTIMEOUT}}}},
              }
          },
          {       /*Page Property                     PageCode                    Parent Page code            Line Contents count*/
                  PAGE_PRT_SETTING,           SCADA1_DNP,                 COMM_SCADA1,                12,
              {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [DNP Protocol]",      {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Src Addr:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_SRCNUM}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Dst Addr:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_DESTNUM}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Sync:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_RSPNEEDTIME}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Clock Valid:",             {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNPETH_F, ALS_DNPETH_TSVLDPRD}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Rx len:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_RXFRAGSIZE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Tx len:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_TXFRAGSIZE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " LinkSt. Per.:",            {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNPETH_F, ALS_DNPETH_LINKSTAT}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Link Discon.:",            {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_LSTODISCON}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. Mode:",              {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_CONFMODE}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. Retry Cnt:",         {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_MAXRETRY}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Conf. TimeOut:",           {LINE_PRT_SETTING_F_1,  TAG_PARAM = {TAG_GRP_DNPETH_F, ALS_DNPETH_DLTIMEOUT}}}},
              }
          },
          {       /*Page Property                     PageCode                    Parent Page code            Line Contents count*/
                  PAGE_PRT_SETTING,           SCADA1_TCP_IP,              COMM_SCADA1,                14,
              {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " [TCP/IP]",      {LINE_PRT_TITLE}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " TCP port:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_TCPPORT}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " IPv4 1:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_IPADDR0}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " IPv4 2:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_IPADDR1}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " IPv4 3:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_IPADDR2}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " IPv4 4:",                  {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_IPADDR3}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " GateWay 1:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_GWIPADDR0}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " GateWay 2:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_GWIPADDR1}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " GateWay 3:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_GWIPADDR2}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " GateWay 4:",               {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_GWIPADDR3}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Subnet Mask 1:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_SUBNETMASK0}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Subnet Mask 2:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_SUBNETMASK1}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Subnet Mask 3:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_SUBNETMASK2}}}},
                  { LINE_CONTENTS_TYPE_A, LINE_A = { " Subnet Mask 4:",           {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_DNPETH_UI, ALS_DNPETH_SUBNETMASK3}}}},
              }
          },
          {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
             PAGE_PRT_SETTING,                     TCC_FAST_PHASE,                      TCC_CURVE,                6,
            {/*Line Contents Type                                              Line Property         Child Page Code*/
             { LINE_CONTENTS_TYPE_A, LINE_A = { " [Fast - Phase]",      {LINE_PRT_TITLE}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " TCC Type:",        {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P1C}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Mult:",          {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1TD}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Add:",             {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1CT}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Min Resp:",              {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1MR}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Def.Time:",              {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1FD}}}},

            }
          },
          {
             PAGE_PRT_SETTING,                       HIGH_TRIP_P,                     CB_GROUP1,                                7,
              {      /*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [HIGH I TRIP(P)]",          {LINE_PRT_TITLE} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Pickup I:",                    {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50P1P}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Delay:",                       {LINE_PRT_SETTING_F_2, TAG_PARAM = {TAG_GRP_LS_F,  ALS_LS_50P1D}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH1:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRPH1}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH2:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRPH2}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH3:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRPH3}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH4:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRPH4}} } },
              }
          },
          {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
             PAGE_PRT_SETTING,                       HIGH_TRIP_G,                     CB_GROUP1,                                7,
              {      /*Line Contents Type                                              Line Property                       TAG GROUP         ALIAS*/
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [HIGH I TRIP(G)]",          {LINE_PRT_TITLE} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Pickup I:",                    {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_50N1P}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Delay:",                       {LINE_PRT_SETTING_F_2, TAG_PARAM = {TAG_GRP_LS_F,  ALS_LS_50N1D}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH1:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRGR1}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH2:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRGR2}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH3:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRGR3}} } },
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " Act SH4:",                     {LINE_PRT_SETTING_U,   TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_HITRGR4}} } },
              }
          },
          {  /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
             PAGE_PRT_SETTING,                     TCC_FAST_PHASE,                      TCC_CURVE,             6,
            {/*Line Contents Type                                              Line Property                        TAG GROUP         ALIAS*/
             { LINE_CONTENTS_TYPE_A, LINE_A = { " [Fast - Phase]",      {LINE_PRT_TITLE}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " TCC Type :",      {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P1C}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Mult :",      {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1TD}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Add :",      {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1CT}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Min Resp :",      {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1MR}}}},
             { LINE_CONTENTS_TYPE_A, LINE_A = { " Def.Time :",      {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1FD}}}},

            }
          },
          {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_SETTING,                  TCC_FAST_GROUND,                     TCC_CURVE,                6,
               {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [FAST-GROUND]",      {LINE_PRT_TITLE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " TCC Type:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51N1C}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Mult:",               {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N1TD}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Add:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N1CT}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Min.Resp:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N1MR}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Def.Time:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P1DD}} } },
               }
          },
          {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_SETTING,                  DELAY_PHASE,                     TCC_CURVE,                6,
               {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [DELAY_PHASE]",      {LINE_PRT_TITLE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " TCC Type:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51P2C}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Mult:",               {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P2TD}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Add:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P2CT}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Min.Resp:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51P2MR}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Def.Time:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N1FD}} } },
               }
          },
          {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_SETTING,                  DELAY_GROUND,                     TCC_CURVE,                6,
               {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [DELAY_GROUND]",      {LINE_PRT_TITLE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " TCC Type:",                {LINE_PRT_SETTING_U,    TAG_PARAM = {TAG_GRP_LS_UI, ALS_LS_51N2C}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Mult:",               {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N2TD}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Time Add:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N2CT}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Min.Resp:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N2MR}} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Def.Time:",                {LINE_PRT_SETTING_F_2,  TAG_PARAM = {TAG_GRP_LS_F, ALS_LS_51N1DD}} } },
               }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
                PAGE_PRT_DEFAULT,                    VIT_GROUP1,                       VIT_MODE,                 7,
              {
               { LINE_CONTENTS_TYPE_A, LINE_A = { " [VIT GROUP1]",        {LINE_PRT_TITLE} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Count",             {LINE_PRT_SELECT, VIT_COUNT} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.N.C Close Time",    {LINE_PRT_SELECT, VIT_NC_CLOSE_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.N.O Close Time",    {LINE_PRT_SELECT, VIT_NO_CLOSE_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Reset Time",        {LINE_PRT_SELECT, VIT_RESET_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Additional Func.",  {LINE_PRT_SELECT, VIT_ADDITIONAL_FUNC} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " *.Save VITMode Set",  {LINE_PRT_SELECT, SAVE_SETTING} } },
              }
          },
          { /*Page Property                         PageCode                        Parent Page code          Line Contents count*/
                PAGE_PRT_DEFAULT,                    VIT_GROUP2,                       VIT_MODE,                 7,
              {
               { LINE_CONTENTS_TYPE_A, LINE_A = { " [VIT GROUP2]",       {LINE_PRT_TITLE} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Count",            {LINE_PRT_SELECT, VIT_COUNT} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.N.C Close Time",   {LINE_PRT_SELECT, VIT_NC_CLOSE_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.N.O Close Time",   {LINE_PRT_SELECT, VIT_NO_CLOSE_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Reset Time",       {LINE_PRT_SELECT, VIT_RESET_TIME} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Additional Func.", {LINE_PRT_SELECT, VIT_ADDITIONAL_FUNC} } },
               { LINE_CONTENTS_TYPE_A, LINE_A = { " *.Save VITMode Set", {LINE_PRT_SELECT, SAVE_SETTING} } },
              }
          },
          {     /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                  PAGE_PRT_DEFAULT,                  CUSTOMER_PROTECTION,             SETTING_TAB,                  10,
               {/*Line Contents Type                                        Line Type                           Child Page Code*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [CUSTOM PROTECTION]", {LINE_PRT_TITLE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Under Frequency", {LINE_PRT_SELECT, CP_UNDER_FREQUENCY} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.Over Frequency", {LINE_PRT_SELECT, CP_OVER_FREQUENCY} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.ROCOF(df/dt)", {LINE_PRT_SELECT, CP_ROCOF} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Under Voltage", {LINE_PRT_SELECT, CP_UNDER_VOLTAGE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Over Voltage", {LINE_PRT_SELECT, CP_OVER_VOLTAGE} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.Reverse Power", {LINE_PRT_SELECT, CP_REVERSE_POWER} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.V0 Displacement", {LINE_PRT_SELECT, CP_V0_DISPLACEMENT} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.Unbalance V(V0/1)", {LINE_PRT_SELECT, CP_UNBALANCE_V} } },
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 9.Blown Fuse Detect", {LINE_PRT_SELECT, CP_BLOWN_FUSE_DETECTION} } },
               }
          },
          {     /*Page Property                      PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_DEFAULT,                  LL_VOLTAGE,                     METERING_TAB,                7,
               {/*Line Contents Type     Line Contents        String             Line Property                       TAG GROUP           ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [L-L VOLTAGE]",      {LINE_PRT_TITLE} } },
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VAB:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VAB}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VAB}}}}},
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VBC:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VBC}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VBC}}} } },
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VCA:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VCA}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VCA}}} } },
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VRS:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VRS}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VRS}}} } },
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VST:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VST}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VST}}} } },
                { LINE_CONTENTS_TYPE_B, LINE_B = { " VTR:",                     {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VTR}},
                                                                                 {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VTR}}} } },
               }
          },

},
LARGE = {
         {      /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                PAGE_PRT_DEFAULT,                   VOLTAGE_CURRENT,              METERING_TAB,               13,
               {/*Line Contents Type                                                Line Type                   TAG GROUP        ALIAS*/
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " [VOLTAGE & CURRENT]",       {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " (Voltage)",                 {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VA:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VA}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VA}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VB:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VB}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VB}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VC:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VC}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VC}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VR:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VR}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VR}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VS:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VS}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VS}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " VT:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_VT}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_VT}}}}},
                   { LINE_CONTENTS_TYPE_A, LINE_A = { " (Current)",                 {LINE_PRT_TITLE}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " IA:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_IA_DISP}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_IA}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " IB:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_IB_DISP}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_IB}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " IC:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_IC_DISP}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_IC}}}}},
                   { LINE_CONTENTS_TYPE_B, LINE_B = { " IN:",                      {{LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_RMS_IN_DISP}},
                                                                                    {LINE_PRT_DISPLAY_F_0, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ANG_IN}}}}},
               }
         },
         {     /*Page Property                       PageCode                       Parent Page code             Line Contents count*/
               PAGE_PRT_DEFAULT,            GLOABAL,                       SETTING_TAB,                 14,
              {/*Line Contents Type                                                 Line Type               Child Page Code*/
               { LINE_CONTENTS_TYPE_A, LINE_A = { " [GLOBAL]",                    {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.System Config",             {LINE_PRT_SELECT,          GLOBAL_SYSTEMCONFIG}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.System Frequency",          {LINE_PRT_SELECT,          GLOBAL_SYSTEM_FREQUENCY}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.Phase Rotation",            {LINE_PRT_SELECT,          GLOBAL_PHASE_ROTATION}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.F.I Reset Mode",            {LINE_PRT_SELECT,          GLOBAL_FI_RESET}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Voltage Detection",         {LINE_PRT_SELECT,          GLOBAL_VOLTAGE_DETECT}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.Demand Meter",              {LINE_PRT_SELECT,          GLOBAL_DEMAND_METER}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Load Profile Time",         {LINE_PRT_SELECT,          GLOBAL_LOAD_PROFILE_TIME}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.Fltwv. Pre-Cycle",          {LINE_PRT_SELECT,          GLOBAL_FAULT_WAVE_PRECYCLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 9.SettingGrpChange",          {LINE_PRT_SELECT,          GLOBAL_SETTING_GROUP_CHANGE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 10.Reclose Superv.",          {LINE_PRT_SELECT,          GLOBAL_RECLOSE_SUPERVISION}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 11.Min.Trip Time",            {LINE_PRT_SELECT,          GLOBAL_MIN_TRIP_TIME}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 12.Battery Manage",           {LINE_PRT_SELECT,          GLOBAL_BATTERY_MANAGE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " *.Save Global Set",           {LINE_PRT_SELECT,          SAVE_SETTING}}}
              }
         },
        {     /*Page Property                       PageCode                        Parent Page code        Line Contents count*/
                PAGE_PRT_DEFAULT,                   CB_GROUP1,                      CB,                     19,
             {/*Line Contents Type                                          Line Type               Child Page Code*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [CB GROUP1]",         {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Pickup Current",    {LINE_PRT_SELECT,        PICKUP_CURRENT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.TCC Curve",         {LINE_PRT_SELECT,        TCC_CURVE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.SEF Delay",         {LINE_PRT_SELECT,        SEF_DELAY}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Act Fast Curve",    {LINE_PRT_SELECT,        ACTIVATE_FAST_CURVE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Oper.To Lockout",   {LINE_PRT_SELECT,        OPERATION_TO_LOCK}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.ReclosingInterval", {LINE_PRT_SELECT,        RECLOSING_INTERVAL}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Reset Time",        {LINE_PRT_SELECT,        RESET_TIME}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.High I Trip(P)",    {LINE_PRT_SELECT,        HIGH_TRIP_P}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 9.High I Trip(G)",    {LINE_PRT_SELECT,        HIGH_TRIP_G}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 10.High I Lock(P)",   {LINE_PRT_SELECT,        HIGH_LOCK_P}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 11.High I Lock(G)",   {LINE_PRT_SELECT,        HIGH_LOCK_G}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 12.Cold Load",        {LINE_PRT_SELECT,        COLD_LOAD}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 13.Seq.Coordination", {LINE_PRT_SELECT,        SEQ_COORDINATION}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 14.Ground Trip Prec", {LINE_PRT_SELECT,        GROUND_TRIP_PREC}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 15.Inrush Restraint", {LINE_PRT_SELECT,        INRUSH_RESTRAINT}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 16.Direct. Relay(P)", {LINE_PRT_SELECT,        DIRE_RELAY_P}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " 17.Direct. Relay(G)", {LINE_PRT_SELECT,        DIRE_RELAY_G}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " *. Save CB Settings", {LINE_PRT_SELECT,        SAVE_SETTING}}},
            }
        },
        {       /*Page Property                     PageCode                        Parent Page code        Line Contents count*/
                  PAGE_PRT_DEFAULT,                 CB_GROUP2,                      CB,                     19,
            {/*Line Contents Type                                           Line Type               Child Page Code*/
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " [CB GROUP2]",          {LINE_PRT_TITLE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 1.Pickup Current",     {LINE_PRT_SELECT,       PICKUP_CURRENT}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 2.TCC Curve",          {LINE_PRT_SELECT,       TCC_CURVE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 3.SEF Delay",          {LINE_PRT_SELECT,       SEF_DELAY}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 4.Act Fast Curve",     {LINE_PRT_SELECT,       ACTIVATE_FAST_CURVE}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 5.Oper.To Lockout",    {LINE_PRT_SELECT,       OPERATION_TO_LOCK}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 6.ReclosingInterval",  {LINE_PRT_SELECT,       RECLOSING_INTERVAL}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 7.Reset Time",         {LINE_PRT_SELECT,       RESET_TIME}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 8.High I Trip(P)",     {LINE_PRT_SELECT,       HIGH_TRIP_P}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 9.High I Trip(G)",     {LINE_PRT_SELECT,       HIGH_TRIP_G}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 10.High I Lock(P)",    {LINE_PRT_SELECT,       HIGH_LOCK_P}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 11.High I Lock(G)",    {LINE_PRT_SELECT,       HIGH_LOCK_G}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 12.Cold Load",         {LINE_PRT_SELECT,       COLD_LOAD}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 13.Seq.Coordination",  {LINE_PRT_SELECT,       SEQ_COORDINATION}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 14.Ground Trip Prec",  {LINE_PRT_SELECT,       GROUND_TRIP_PREC}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 15.Inrush Restraint",  {LINE_PRT_SELECT,       INRUSH_RESTRAINT}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 16.Direct. Relay(P)",  {LINE_PRT_SELECT,       DIRE_RELAY_P}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " 17.Direct. Relay(G)",  {LINE_PRT_SELECT,       DIRE_RELAY_G}}},
                 { LINE_CONTENTS_TYPE_A, LINE_A = { " *. Save CB Settings",  {LINE_PRT_SELECT,       SAVE_SETTING}}},
            }
        },

        {       /*Page Property                     PageCode                        Parent Page code          Line Contents count*/
                PAGE_PRT_DEFAULT,                   DEMAND_POWER,                   METERING_TAB,             25,
            {   /*Line Contents Type                                          Line Property                         TAG GROUP     ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  [DEMAND (POWER)]",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Act Total)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_ACT_TOTAL}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_ACT_PTOTAL}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Rct Total)",  {LINE_PRT_TITLE }}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_RCT_TOTAL}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_RCT_PTOTAL}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Act A Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_ACT_PA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_ACT_PA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Rct A Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_RCT_PA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_RCT_PA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Act B Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_ACT_PB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_ACT_PB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Rct B Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_RCT_PB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_RCT_PB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Act C Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_ACT_PC}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_ACT_PC}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Rct C Phase)",  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Dmd:",                {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_RCT_PC}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  PeakDmd:",            {LINE_PRT_DISPLAY_F_1,      TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_RCT_PC}}}},
            }
        },
        {       /*Page Property                     PageCode                        Parent Page code            Line Contents count*/
                PAGE_PRT_DEFAULT,                   DEMAND_CURRENT,                 METERING_TAB,               19,
            {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [DEMAND (CURRENT)]",      {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (A Phase)",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_IA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_IA}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (B Phase)",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_IB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_IB}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (C Phase)",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_IC}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_IC}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (N Phase)",        {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (3I0)",            {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_3I0}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_3I0}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (3I2)",            {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " Dmd:",                     {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_DMD_3I2}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " PeakDmd:",                 {LINE_PRT_DISPLAY_F_1,  TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_PKDMD_3I2}}}},
            }
        },
        {       /*Page Property                     PageCode                    Parent Page code                Line Contents count*/
                PAGE_PRT_DEFAULT,                   ENERGY,                     METERING_TAB,                   21,
            {   /*Line Contents Type                                            Line Property                         TAG GROUP     ALIAS*/
                { LINE_CONTENTS_TYPE_A, LINE_A = { " [ENERGY]",      {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (Total)",                  {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_ETOTAL_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_ETOTAL_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_ETOTAL_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_ETOTAL_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (A Phase)",                {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EA_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EA_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EA_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EA_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (B Phase)",                {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EB_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EB_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EB_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EB_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { " (C Phase)",                {LINE_PRT_TITLE}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EC_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Act(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_ACT_EC_OUT}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(+):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EC_IN}}}},
                { LINE_CONTENTS_TYPE_A, LINE_A = { "  Rct(-):",                 {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_ACC, ALS_ACC_RCT_EC_OUT}}}},
            }
        },
        {      /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                 PAGE_PRT_DEFAULT,                   POWER_ACT_RCT,              METERING_TAB,               11,
              {/*Line Contents Type                                                Line Type                   TAG GROUP        ALIAS*/
               { LINE_CONTENTS_TYPE_A, LINE_A = { " [Power(Act/Rct)]",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " (Active Power)",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " A Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ACTIVE_A}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " B Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ACTIVE_B}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " C Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ACTIVE_C}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3 Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_ACTIVE_TOTAL}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " (Reactive Power)",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " A Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_REACTIVE_A}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " B Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_REACTIVE_B}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " C Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_REACTIVE_C}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3 Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_REACTIVE_TOTAL}}}},
              }
        },
        {      /*Page Property                       PageCode                      Parent Page code            Line Contents count*/
                 PAGE_PRT_DEFAULT,                   POWER_APP_FACT,              METERING_TAB,               11,
              {/*Line Contents Type                                                Line Type                   TAG GROUP        ALIAS*/
               { LINE_CONTENTS_TYPE_A, LINE_A = { " [Power(App/Factor)]",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " (Active Power)",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " A Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_APPARENT_A}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " B Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_APPARENT_B}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " C Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_APPARENT_C}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3 Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_APPARENT_TOTAL}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " (Reactive Power)",        {LINE_PRT_TITLE}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " A Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_PF_A}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " B Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_PF_B}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " C Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_PF_C}}}},
               { LINE_CONTENTS_TYPE_A, LINE_A = { " 3 Phase:",                   {LINE_PRT_DISPLAY_F_1, TAG_PARAM = {TAG_GRP_AI, ALS_AI_PF_TOTAL}}}},
              }
        },
}
};
#endif /* APPLICATION_MMIPARAM_H_ */
