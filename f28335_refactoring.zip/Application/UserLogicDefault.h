/*
 * UserLogicDefault.h
 *
 *  Created on: 2024. 1. 17.
 *      Author: ShinSung Industrial Electric
 */

#ifndef APPLICATION_USERLOGICDEFAULT_H_
#define APPLICATION_USERLOGICDEFAULT_H_
#if 0
#include "Plaffom_Interface.h"
#include "src/app/tag/tag_db.h"
#include "src/app/mmi/mmi_display.h"

#define CASTING            (const char*[])

/*Level 1*/
#define MENU_PAGE_LINE                      7
#define SETTING_PAGE_LINE                   8
#define METERING_PAGE_LINE                  8
#define STATUS_PAGE_LINE                    2
#define COUNT_PAGE_LINE                     3
#define DIAGNOSIS_PAGE_LINE                 2
#define PRODUCT_PAGE_LINE                   4
#define EVENT_PAGE_LINE                     3
/*Level 2*/
#define GLOBAL_PAGE_LINE                    13
#define CB_PAGE_LINE                        3
#define VIT_MODE_PAGE_LINE                  3
#define OPEN_CONDUCTOR_PAGE_LINE            4
#define CUSTOMER PROTECTION_PAGE_LINE       9
#define COMMUNICATION_PAGE_LINE             2
#define TIME_PAGE_LINE                      4
#define PASSWORD_PAGE_LINE                  4

/*Parameter Description*/
#define PARAMETER_CURSOR_TYPE_MAX           2
#define LINE_CONTENTS_MAX                   2

/*Default Value*/



const UserListPageDesc UserListPage[LIST_PAGE_MAX] = {
/*Level 0*/
{.Level = 0,.ParentPageIndex = LIST_PAGE_MENU,     .PageIndex = LIST_PAGE_MENU,        .pStr = CASTING{
"   [Main Menu]      ",
" 1.Settings         ",
" 2.Metering         ",
" 3.Status           ",
" 4.Event            ",
" 5.Diagnosis        ",
" 6.Product Info     ",
" 7.Event            "},
.LineMax = MENU_PAGE_LINE,              .SubDirectoryCnt = MENU_PAGE_LINE,  .ChildPageIndex = LIST_PAGE_SETTING},
/*Level 1*/
{.Level = 1,.ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_SETTING,
.pStr = CASTING{
"   [SETTINGS]       ",
" 1.Global           ",
" 2.CB               ",
" 3.VIT MODE         ",
" 4.Open Conductor   ",
" 5.Customer Prot.   ",
" 6.Communication    ",
" 7.Time             ",
" 8.Password         "},
.LineMax = SETTING_PAGE_LINE,.SubDirectoryCnt = SETTING_PAGE_LINE,.ChildPageIndex = LIST_PAGE_GLOBAL},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_METERING,
.pStr = CASTING{
"   [METERING]       ",
" 1.Voltage & Current",
" 2.L-L Voltage      ",
" 3.Power(Act/Rct)   ",
" 4.Power(App/Fact)  ",
" 5.Symmetric Comp   ",
" 6.Energy           ",
" 7.Demand Power     ",
" 8.Demand Current   "},
.LineMax = METERING_PAGE_LINE,  .SubDirectoryCnt = METERING_PAGE_LINE,  .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_STATUS,
.pStr = CASTING{
"   [STATUS]         ",
" 1.Contact Wear     ",
" 2.Mics             "},
.LineMax = COUNT_PAGE_LINE,    .SubDirectoryCnt = COUNT_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_COUNT,
.pStr = CASTING{
"   [COUNT]          ",
" Prot. CNT          ",
" Total Trip CNT     ",
" Restart CNT        "},
.LineMax = STATUS_PAGE_LINE,    .SubDirectoryCnt = STATUS_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_STATUS,
.pStr = CASTING{
"   [DIAGNOSIS]      ",
" [Norm.:0/Blown.:1] ",
" Ope             "},
.LineMax = STATUS_PAGE_LINE,    .SubDirectoryCnt = STATUS_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_STATUS,
.pStr = CASTING{
"   [DIAGNOSIS]      ",
" 1.Contact Wear     ",
" 2.Mics             "},
.LineMax = DIAGNOSIS_PAGE_LINE,     .SubDirectoryCnt = DIAGNOSIS_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_STATUS,
.pStr = CASTING{
"   [PRODUCT INFO]   ",
" 1.H/W Serial Number",
" 2.Model Number     ",
" 3.Identifier       ",
" 4.F/W Version      "},
.LineMax = PRODUCT_PAGE_LINE,    .SubDirectoryCnt = PRODUCT_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 1, .ParentPageIndex = LIST_PAGE_MENU, .PageIndex = LIST_PAGE_EVENT,
.pStr = CASTING{
"   [EVENT]   ",
" 1.Sequential",
" 2.Fault     ",
" 3.Fault Wave       "},
.LineMax = EVENT_PAGE_LINE,     .SubDirectoryCnt = EVENT_PAGE_LINE,    .ChildPageIndex = 0},
/*Level 2*/
{.Level = 2, .ParentPageIndex = LIST_PAGE_SETTING, .PageIndex = LIST_PAGE_GLOBAL,
.pStr = CASTING{
"  [GLOBAL]          ",
" 1.System Config    ",
" 2.System Frequency ",
" 3.Phase Rotation   ",
" 4.F.I Reset Mode   ",
" 5.Voltage Detection",
" 6.Demand Meter     ",
" 7.Load Profile Time",
" 8.Fltwv. Pre-cycld ",
" 9.SettingGrpChange ",
" 10.Reclose Superv. ",
" 11.Min.Trip Time   ",
" 12.Battery Manage  ",
" *.Save Global Set  "},
.LineMax = GLOBAL_PAGE_LINE+1,  .SubDirectoryCnt = GLOBAL_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 2, .ParentPageIndex = LIST_PAGE_SETTING, .PageIndex = LIST_PAGE_CB,
.pStr = CASTING{
"   [CB]             ",
" 1.CB Group 1       ",
" 2.CB Group 2       ",
" 3.CB Group Copy    "},
.LineMax = EVENT_PAGE_LINE,     .SubDirectoryCnt = EVENT_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 2, .ParentPageIndex = LIST_PAGE_SETTING, .PageIndex = LIST_PAGE_VIT_MODE,
.pStr = CASTING{
"   [VIT MODE]       ",
" 1.VIT Group 1      ",
" 2.VIT Group 2      ",
" 3.VIT Group Copy   "},
.LineMax = EVENT_PAGE_LINE,     .SubDirectoryCnt = EVENT_PAGE_LINE,    .ChildPageIndex = 0},
{.Level = 2, .ParentPageIndex = LIST_PAGE_SETTING, .PageIndex = LIST_PAGE_OPEN_CONDUCTOR,
.pStr = CASTING{
"  [OPEN CONDUCTOR]  ",
" 1.Open Conductor   ",
" 2.Delta I2/I1      ",
" 3.Unbalance Current",
" 4.Unbalance Voltage"},
.LineMax = EVENT_PAGE_LINE,     .SubDirectoryCnt = EVENT_PAGE_LINE,    .ChildPageIndex = 0}};

const UserEditPageDesc UserEditPage[EDIT_PAGE_MAX] = {{
 .pTitle = "  [System Config]   ",
 .Level = 3,.EditPageIndex = EDIT_PAGE_SYSTEM_CONFIG,.ItemCount = 2,
 .LineDesc[0] = {.LineContentsType = LINE_CONTENTS_TYPE_A,
                 .TypeA = {.pStr = " CT Ratio:%04d      ",.PrintType = PRINT_FLOAT_0,
                           .TagData = {.TagGroup = TAG_GRP_SC_SCFG_F, .TagIndex = ALS_SC_CT_RATIO},
                           .ParamRangeType = RANGE_CURSOR_TYPE,
                           .ParamDesc = {.RangeTypeDesc = {.MaxValue = 6000,
                                                           .MinValue = 6}}}},
 .LineDesc[1] = {.LineContentsType = LINE_CONTENTS_TYPE_A,
                 .TypeA = {.pStr = " SystemV :%.1fkV    ",.PrintType = PRINT_FLOAT_0,
                           .TagData = {.TagGroup = TAG_GRP_SC_UCFG_F, .TagIndex = ALS_SC_SVOL},
                           .ParamRangeType = RANGE_CURSOR_TYPE,
                           .ParamDesc = {.RangeTypeDesc = {.MaxValue = 60.0,
                                                           .MinValue = 6.0}}}}
}};
#endif

#endif /* APPLICATION_USERLOGICDEFAULT_H_ */
