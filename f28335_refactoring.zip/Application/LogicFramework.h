/*
 * LogicFramework.h
 *
 *  Created on: 2023. 12. 8.
 *      Author: ShinSung Industrial Electric
 */

#ifndef APPLICATION_LOGICFRAMEWORK_H_
#define APPLICATION_LOGICFRAMEWORK_H_

#include "types.h"

#define CMF_TRUE            1
#define CMF_FALSE           0


typedef void                CMF_VOID;
typedef bool                CMF_BOOL;
typedef uint8               CMF_UINT8;
typedef uint16              CMF_UINT16;
typedef uint32              CMF_UINT32;
typedef uint64              CMF_UINT64;
typedef int16               CMF_INT16;
typedef int32               CMF_INT32;
typedef int64               CMF_INT64;
typedef float32             CMF_FLOAT32;
typedef float64             CMF_FLOAT64;
typedef size_t              CMF_SIZE_T;

typedef unsigned char       CMF_UCHAR;              // 8-bit unsigned
typedef unsigned char       CMF_BYTE;               // 8-bit unsigned
typedef unsigned int        CMF_UINT;               // 16-bit unsigned
typedef char                CMF_CHAR;               // 8-bit signed
typedef unsigned int        CMF_WORD;               // 16-bit unsigned
typedef unsigned long       CMF_DWORD;              // 32-bit unsigned
typedef unsigned long long  CMF_QWORD;              // 64-bit unsigned
typedef signed short int    CMF_SHORT;              // 16-bit signed
typedef signed long         CMF_LONG;               // 32-bit signed
typedef signed long long    CMF_LONGLONG;           // 64-bit signed

#endif /* APPLICATION_LOGICFRAMEWORK_H_ */
