/*
 * Plafform_Interface.h
 *
 *    Created on: 2023. 11. 8.
 *        Author: ShinSung Industrial Electric
 *  Description : Header collection for logic
 */

#ifndef USERLOGIC_Plafform_INTERFACE_H_
#define USERLOGIC_Plafform_INTERFACE_H_

#include "LogicFramework.h"

/*TagDB Interface*/
#include "src/app/tag/tag_header.h"
#include "src/app/tag/tag_db_macro.h"

/*Function Block Interface*/
#include "FunctionBlock/FunctionBlock_Interface.h"
#endif /* USERLOGIC_Plafform_INTERFACE_H_ */
