/*
 * FuncBlkManager.h
 *
 *  Created on: 2023. 11. 13.
 *      Author: ShinSung Industrial Electric
 */


/* Function block manager's macro function */

#ifndef COMPONENTS_CALCULATION_INTERFACE_FUNCBLKS_FUNCBLKMANAGER_H_
#define COMPONENTS_CALCULATION_INTERFACE_FUNCBLKS_FUNCBLKMANAGER_H_

#include <math.h>
#include <src/app/logic/FunctionBlock/EdgeDetector.h>
#include <src/app/logic/FunctionBlock/LogicRingBufferObject.h>
#include <src/app/logic/FunctionBlock/PdTimer.h>
#include <src/app/logic/FunctionBlock/rtc.h>
#include <src/app/logic/FunctionBlock/tcc.h>

#include "src/app/logging/event.h"

#include "types.h"
/*Builtin Logic*/

#define SFB_DEF_GBTV(inst, type, dft_value)                         static type inst = dft_value

#define SFB_DEF_SQRT(inst)
#define SFB_USE_SQRT(inst, in, p_out)                               *p_out = sqrtf(in)

#define SFB_DEF_SQRT_F(inst)
#define SFB_USE_SQRT_F(inst, in, p_out)                             *p_out = sqrtf(in)

#define SFB_DEF_POW_F(inst)
#define SFB_USE_POW_F(inst, x, y)                                   powf(x, y)

inline float32 AngleRange_Fit(float32 angle)
{
    if(angle > 0)
    {
        while(angle > 360.0)  angle -= 360.0;
    }
    else if(angle < 0)
    {
        while(angle < 0)        angle += 360.0;
    }
    return angle;
}

#define SFB_DEF_FIT_ANG_RANGE(inst)
#define SFB_USE_FIT_ANG_RANGE(inst, angle)                         AngleRange_Fit(angle)


inline float32 AbsoluteAngle_Diff(float32 degree_a, float32 degree_b)
{
   float32 DiffAngle =  AngleRange_Fit(degree_a-degree_b);

   if(DiffAngle > 180.0)            return (360.0 - DiffAngle);

   else                             return DiffAngle;

}

#define SFB_DEF_DIFF_ABS_ANGLE(inst)
#define SFB_USE_DIFF_ABS_ANGLE(inst, deg_a, deg_b)                 AbsoluteAngle_Diff(deg_a, deg_b)


#define SFB_DEF_HV_F(inst, size, dft_val)                          static CircularBuffer* inst; \
                                                                    static bool inst##_is_initd = false; \
                                                                    if (!inst##_is_initd) { \
                                                                    float FloatInitValue = dft_val;\
                                                                    inst = LogicRingBufCreate(FLOAT_TYPE, size, (void*)&FloatInitValue); \
                                                                    inst##_is_initd = true; \
                                                                    }

#define SFB_USE_HV_PUSH_F(inst, val)                                CircularBuffer_Push(inst, &val)

#define SFB_USE_HV_GET_PREV_F(inst, p_out, PreviousNumber)          CircularBufferPrevious_Get(inst, p_out, PreviousNumber)

#define SFB_DEF_RTC(inst)
#define SFB_USE_RTC(inst, p_year, p_mon, p_day, p_hour, p_min, p_sec, p_msec)       LogicRtcUse(p_year, p_mon, p_day, p_hour, p_min, p_sec, p_msec)



#define SFB_DEF_EDGE_DETR(inst, type, dft_last_val) \
                static EdgeDetector *inst; \
                static bool inst##_is_initd = false; \
                if (!inst##_is_initd) { \
                    inst = EdgeDetectorCreate(type, dft_last_val); \
                    inst##_is_initd = true; \
                }

#define SFB_USE_EDGE_DETR(inst, in, p_out)              UseEdgeDetector(inst, in, p_out)


#define SFB_DEF_PD_TIMER(Instance,                                              \
                         PickupTimerType, PickupTimeout,                        \
                         DropoutTimerType, DropoutTimeout)                      \
static PdTimer *Instance;                                                       \
static bool Instance##_is_initd = false;                                        \
if (!Instance##_is_initd) {                                                     \
    Instance = PdTimerCreate(PickupTimerType,  PickupTimeout,  N_A, N_A,        \
                             DropoutTimerType, DropoutTimeout, N_A, N_A);       \
    Instance##_is_initd = true;}


#define SFB_DEF_PD_TIMER_EX(Instance,                                                                       \
                            PickupTimerType,  PickupTagGroup,  PickupTagIndex,                              \
                            DropoutTimerType, DropoutTagGroup, DropoutTagIndex)                             \
static PdTimer* Instance;                                                                                   \
static bool Instance##_is_initd = false;                                                                    \
if (!Instance##_is_initd) {                                                                                 \
    Instance = PdTimerCreate(PickupTimerType,  N_A,  PickupTagGroup,  PickupTagIndex,             \
                             DropoutTimerType, N_A,  DropoutTagGroup, DropoutTagIndex);           \
    Instance##_is_initd = true;}


#define SFB_USE_PD_TIMER(inst, in, reset, p_out)        PdTimerUse(inst, in, reset, p_out)

#define SFB_DEF_TCC_EX(Instance,                                                                            \
                       TagGroup1, TagCurveType,           TagGroup2,      TagTimeDialMultiplier,            \
                       TagGroup3, TagDefiniteTimeDelay,   TagGroup4,      TagElementReset,                  \
                       TagGroup5, TagConstTimeAdder,      TagGroup6,      TagMinimumResponseTime,           \
                       TagGroup7, TagFactorA,             TagGroup8,      TagFactorB,                       \
                       TagGroup9, TagFactorP)                                                               \
static Tcc *Instance;                                                                                       \
static bool Instance##_is_initd = false;                                                                    \
if (!Instance##_is_initd) {                                                                                 \
    Instance = TccCreate(TagGroup1, TagCurveType,           TagGroup2,      TagTimeDialMultiplier,          \
                         TagGroup3, TagDefiniteTimeDelay,   TagGroup4,      TagElementReset,                \
                         TagGroup5, TagConstTimeAdder,      TagGroup6,      TagMinimumResponseTime,         \
                         TagGroup7, TagFactorA,             TagGroup8,      TagFactorB,                     \
                         TagGroup9, TagFactorP);                                                            \
    Instance##_is_initd = true;                                                                             \
}

#define SFB_USE_TCC(Instance, PickupValue, CurrentMax, pPickup, pCurveTimeout, pReset)                      \
        LogicTccUse(Instance, PickupValue, CurrentMax, pPickup, pCurveTimeout, pReset)

#if 0
#define SFB_DEF_EVM(inst)                   \
    static FaultEvent* inst;                \
    static bool inst##_is_initd = false;    \
    if(!inst##_is_initd){                   \
        inst = FaultEventHandle_Get();      \
        inst##_is_initd = true;            \
    }
#endif
#define SFB_USE_EVM_PUSH_FLTEV_EX(fault_type, va, vb, vc, ia, ib, ic, in) \
                   FltEvt_Push(fault_type, va, vb, vc, ia, ib, ic, in)

#define SFB_USE_EVM_PUSH_FLTWVEV(inst, fault_type) \
            //    RT_PE_PushFaultWaveEvent(fault_type, 12)

#define SFB_USE_EVM_PUSH_FLTWVEV_EX(inst, fault_type, prefltwv_length) \
            //    RT_PE_PushFaultWaveEvent(fault_type, prefltwv_length)

#endif /* COMPONENTS_CALCULATION_INTERFACE_FUNCBLKMANAGER_H_ */
