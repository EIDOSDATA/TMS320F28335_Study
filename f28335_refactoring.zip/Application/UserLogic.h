/*
 * UserLogic.h
 *
 *  Created on: 2023. 12. 13.
 *      Author: ShinSung Industrial Electric
 */

#ifndef APPLICATION_USERLOGIC_H_
#define APPLICATION_USERLOGIC_H_

void AT_Logic_EnableLogic(void);
void AT_Logic_VoltageCheck(void);
void AT_Logic_SettingGroup(void);
void AT_Logic_CurrentCheck(void);
void AT_Logic_OperationSetting(void);
void AT_Logic_Pickup(void);
void AT_Logic_Directional(void);
void AT_Logic_ColdLoad(void);
void AT_Logic_Inrush(void);
void AT_Logic_TorqueControl(void);
void AT_Logic_SEF(void);
void AT_Logic_51(void);
void AT_Logic_DGProtection(void);
void AT_Logic_BlownFuseDetection(void);
void AT_Logic_VIT_OperationMode(void);
void AT_Logic_VIT_Count(void);
void AT_Logic_OpenConductor(void);
void AT_Logic_VIT_Reset(void);
void AT_Logic_VIT_Lockout_Condition(void);
void AT_Logic_VIT_Lockout(void);
void AT_Logic_VIT_Sequence(void);
void AT_Logic_Trip(void);
void AT_Logic_DriveToLockout(void);
void AT_Logic_RecloseInterval(void);
void AT_Logic_Close(void);
void AT_Logic_SequenceCoordination(void);
void AT_Logic_ReclosingLogic(void);
void AT_Logic_ExPowerMonitoring(void);
void AT_Logic_FuseMonitoring(void);
void AT_Logic_FaultIndicator(void);
void AT_Logic_BatteryTest(void);
void AT_Logic_Count(void);
void AT_Logic_LED(void);
void AT_Logic_PowerSealin(void);
void AT_Logic_DoorOpen(void);
void AT_Logic_Diagnostic(void);

#endif /* APPLICATION_USERLOGIC_H_ */
