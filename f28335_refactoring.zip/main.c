/*
 * main.c
 *
 *  Created on: 2023. 12. 5.
 *      Author: ShinSung Industrial Electric
 */


#include "def.h"

#include "src/app/Initializer/Initializer.h"
#include "src/app/logic/logic.h"

/*User Logic*/
#include "Application/UserLogic.h"

// These are defined by the linker (see F28335.cmd)
extern uint16 RamfuncsLoadStart;
extern uint16 RamfuncsLoadEnd;
extern uint16 RamfuncsRunStart;

/*
 *  ======== main ========
 */
void Startup(void);

Int main()
{

    PecAppVersion_Set(1, 5, 27);

    UserLogic_Add(36,
                  AT_Logic_EnableLogic,
                  AT_Logic_VoltageCheck,
                  AT_Logic_SettingGroup,
                  AT_Logic_CurrentCheck,
                  AT_Logic_OperationSetting,
                  AT_Logic_Pickup,
                  AT_Logic_Directional,
                  AT_Logic_ColdLoad,
                  AT_Logic_Inrush,
                  AT_Logic_TorqueControl,
                  AT_Logic_SEF,
                  AT_Logic_51,
                  AT_Logic_DGProtection,
                  AT_Logic_BlownFuseDetection,
                  AT_Logic_VIT_OperationMode,
                  AT_Logic_VIT_Count,
                  AT_Logic_OpenConductor,
                  AT_Logic_VIT_Reset,
                  AT_Logic_VIT_Lockout_Condition,
                  AT_Logic_VIT_Lockout,
                  AT_Logic_VIT_Sequence,
                  AT_Logic_Trip,
                  AT_Logic_DriveToLockout,
                  AT_Logic_RecloseInterval,
                  AT_Logic_Close,
                  AT_Logic_SequenceCoordination,
                  AT_Logic_ReclosingLogic,
                  AT_Logic_ExPowerMonitoring,
                  AT_Logic_FuseMonitoring,
                  AT_Logic_FaultIndicator,
                  AT_Logic_BatteryTest,
                  AT_Logic_Count,
                  AT_Logic_LED,
                  AT_Logic_PowerSealin,
                  AT_Logic_DoorOpen,
                  AT_Logic_Diagnostic);

    SpecPhyPlatform_Init();

    BIOS_start();    /* does not return */
    return(0);
}


/*
 * Startup Function Before main enter
 */
void Startup(void)
{
    MemCopy(&RamfuncsLoadStart, &RamfuncsLoadEnd, &RamfuncsRunStart);
    InitPeripheralClocks();
    InitGpio();
    InitFlash();
    XintfInit();

    InitPieCtrl();
}
