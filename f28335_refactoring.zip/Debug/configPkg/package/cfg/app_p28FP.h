/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#include <xdc/std.h>

#include <ti/sysbios/family/c28/Hwi.h>
extern const ti_sysbios_family_c28_Hwi_Handle hwi0;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Cli;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Logging;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Logic;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Sampling;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Mmi;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Communication;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_UART1;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_UART2;

#include <ti/sysbios/knl/Mailbox.h>
extern const ti_sysbios_knl_Mailbox_Handle mailbox0;

#include <ti/sysbios/knl/Mailbox.h>
extern const ti_sysbios_knl_Mailbox_Handle mailbox1;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle Task_Metering;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle SemSampling;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle SemLogic;

extern int xdc_runtime_Startup__EXECFXN__C;

extern int xdc_runtime_Startup__RESETFXN__C;

extern int xdc_rov_runtime_Mon__checksum;

extern int xdc_rov_runtime_Mon__write;

