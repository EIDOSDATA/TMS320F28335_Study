
/*
 * circularbuf.c
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>
#include "src/utils/circularbuf.h"

void CircularBuffer_Push(CircularBuffer* pHandle, void* pInput)
{
    if(pHandle == NULL)
    {
        return;
    }

    if(pHandle->Position >= pHandle->Max)
    {
        pHandle->Position = 0;
    }

    switch(pHandle->Type)
    {
        case UINT_TYPE:
            memcpy(pHandle->pUintBuf + pHandle->Position, pInput, sizeof(uint16));
            break;
        case FLOAT_TYPE:
            memcpy(pHandle->pFloatBuf + pHandle->Position, pInput, sizeof(float32));
            break;
    }
    pHandle->Position++;

}
void CircularBufferPrevious_Get(CircularBuffer* pHandle, void* pOut, uint16 Previous)
{
    int16 Gap = pHandle->Position - Previous;
    uint16 Index = Gap >= 0 ? Gap : pHandle->Max +(Gap);

    switch(pHandle->Type)
    {
        case UINT_TYPE:
            memcpy(pOut, &pHandle->pUintBuf[Index], sizeof(uint16));
            break;
        case FLOAT_TYPE:
            memcpy(pOut, &pHandle->pFloatBuf[Index], sizeof(float32));
            break;
    }

}
void CircularBuffer_Get(CircularBuffer* pHandle, void* pOut, uint16 Index)
{
    switch(pHandle->Type)
    {
        case UINT_TYPE:
            memcpy(pOut, &pHandle->pUintBuf[Index], sizeof(uint16));
            break;
        case FLOAT_TYPE:
            memcpy(pOut, &pHandle->pFloatBuf[Index], sizeof(float32));
            break;
    }
}

bool CircularBufCreate(CircularBuffer* phandle, CircularBufType Type, void* pbuf, uint16 size)
{
    if((phandle == NULL)||(pbuf == NULL))
    {
        return false;
    }

    memset(phandle, 0, sizeof(CircularBuffer));

    switch(Type)
    {
        case UINT_TYPE:
            phandle->pUintBuf  = pbuf;
            memset(pbuf, 0, size);
            break;
        case FLOAT_TYPE:
            phandle->pFloatBuf = pbuf;
            memset(pbuf, 0, sizeof(float32)*size);
            break;
    }

    phandle->Type       = Type;
    phandle->Max        = size;

    return true;
}
