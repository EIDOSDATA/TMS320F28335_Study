/*
 * circularbuf.h
 *
 *  Created on: 2024. 5. 28.
 *      Author: hp878
 */

#ifndef CIRCULARBUF_H_
#define CIRCULARBUF_H_

#include "def.h"

typedef enum
{
    UINT_TYPE,
    FLOAT_TYPE

} CircularBufType;

typedef struct
{
    CircularBufType    Type;

    uint16              Position;

    uint16              Max;

    float32*            pFloatBuf;
    uint16*             pUintBuf;

} CircularBuffer;


bool CircularBufCreate(CircularBuffer* phandle, CircularBufType Type, void* pbuf, uint16 size);
void CircularBuffer_Push(CircularBuffer* pHandle, void* pInput);
void CircularBuffer_Get(CircularBuffer* pHandle, void* pOut, uint16 Index);
void CircularBufferPrevious_Get(CircularBuffer* pHandle, void* pOut, uint16 Previous);
#endif /* CIRCULARBUF_H_ */
