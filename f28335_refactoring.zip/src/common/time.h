/*
 * Time.h
 *
 *  Created on: 2023. 11. 6.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_UTILITY_TIME_H_
#define COMPONENTS_UTILITY_TIME_H_

#include "src/port/rtc/DS1302.h"

/*TimeStamp Format For Logic RTC*/
typedef struct
{
    uint16 Year;
    uint16 Month;
    uint16 Day;
    uint16 Hour;
    uint16 Min;
    uint16 Sec;
    uint16 msec;

} Logic_TimeStamp;

/*TimeStamp Format For HMIS*/
typedef struct
{
    uint16 YearMonth;           /* ex. 0x7e69 -> 0x7e60 => 2022 ,  0x9 => month */
    uint16 HourDay;             /* Upper Value : Hour Lower Value : Day */
    uint16 SecMin;              /* Upper Value : Sec  Lower Value : Min*/
    uint16 MsFlag;              /*ex. 0x2391 -> 0x2390 => 569 ms, 0x1 => daylight flag?*/

} HMIS_TimeStamp;

typedef struct
{
    uint16 Year;
    uint16 Month;
    uint16 Day;
    uint16 Hour;
    uint16 Min;
    uint16 Sec;
    uint16 msec;

} Mmi_TimeStamp;


void TimeObject_Init(void);
void RTC_SetTime(const SystemTime_t *pDateTime);
void RTC_GetTime(SystemTime_t *p_time_tag);
SystemTime_t *TimeData_Get(void);

SystemTime_t *TimeObjectGet(void);

void ConvertHMISToMmiTimeStamp(HMIS_TimeStamp *pHMISTimeStamp,Mmi_TimeStamp *pMMITimeStamp);

/*For MMI*/
void Mmi_TimeStamping(Mmi_TimeStamp *pTimeStamp);
void Mmi_TimeSet(Mmi_TimeStamp *pTimeStamp);
/*For Logic*/
void Logic_TimeStamping(Logic_TimeStamp *pTimeStamp);
/*For HMIS*/
void HMIS_TimeStamping(HMIS_TimeStamp *pTimeStamp);
void SystemTimeSet(SystemTime_t *pSystemTime);
#endif /* COMPONENTS_UTILITY_TIME_H_ */
