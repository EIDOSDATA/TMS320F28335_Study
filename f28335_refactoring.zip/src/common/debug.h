/*
 * debug.h
 *
 *  Created on: 2023. 9. 5.
 *      Author: ShinSung Industrial Electric
 */

#ifndef PORTS_INCLUDE_DEBUG_H_
#define PORTS_INCLUDE_DEBUG_H_

#include <os.h>

/*
 *  ======== Debug ========
 */
#define DEBUG_ON 1
#if DEBUG_ON
#define DEBUG_Msg(format ) System_printf(format);\
    System_flush()
#define DEBUG_Printf(format, ...) System_printf(format, __VA_ARGS__);\
    System_flush()
#define DEBUG_Info()   System_printf("[%s %d]\n", __FUNCTION__, __LINE__);\
    System_flush()
#else
#define DEBUG_Msg(format)
#define DEBUG_Printf(format, ...)
#define DEBUG_Info()
#endif




#endif /* PORTS_INCLUDE_DEBUG_H_ */
