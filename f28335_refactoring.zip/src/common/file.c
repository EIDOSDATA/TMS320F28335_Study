/*
 * file.c
 *
 *  Created on: 2023. 11. 14.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>

#include "def.h"
#include "src/common/file.h"
#include "src/app/logging/event.h"
#include "src/app/tag/tag_db.h"

#pragma DATA_SECTION (FileHandle,          "ZONE6DATA")
#pragma DATA_SECTION (FileCache,           "ZONE6DATA")
#pragma DATA_SECTION (SystemInfoFile,      "ZONE6DATA")
#pragma DATA_SECTION (ChannelConfigsFile,  "ZONE6DATA")
#pragma DATA_SECTION (PtctCorrInfoFile,    "ZONE6DATA")

#pragma DATA_SECTION (ScadaAiConfigFile,    "ZONE6DATA")
#pragma DATA_SECTION (ScadaAoConfigFile,    "ZONE6DATA")
#pragma DATA_SECTION (ScadaBiConfigFile,    "ZONE6DATA")
#pragma DATA_SECTION (ScadaBoConfigFile,    "ZONE6DATA")


#define FILE_UPDATE_START_SECTOR            288

#define FRAM_MSG_ADDR                        0x007F00

enum
{
    FILE_HEADER_OFFSET_ADDR = FRAM_INDEX60 * FRAM_BLOCK_SIZE,   /*0x3C00*/
};

#define FILE_CACHE_BUF_MAX          FLASH_SECTOR_SIZE*2
#define FILE_HEADER_SIZE            6               /*6 Bytes*/

#define FILE_HEADER_USED            0
#define FILE_HEADER_FREE            2
#define FILE_HEADER_CRC             4

static TAG_DB*              pTagDb;

static FileDescriptor       FileHandle[FILE_INDEX_MAX];
static uint16               FileCache[FILE_CACHE_BUF_MAX];

static SystemInformation    SystemInfoFile;

static ChannelConfigs       ChannelConfigsFile;
static PtctCorrInfo         PtctCorrInfoFile;
static GpaiCorrInfo         GpaiCorrInfoFile;

static SdnpAiMap4Scada      ScadaAiConfigFile;
static SdnpAoMap4Scada      ScadaAoConfigFile;
static SdnpBiMap4Scada      ScadaBiConfigFile;
static SdnpBoMap4Scada      ScadaBoConfigFile;

static MmiPassword          PasswordFile;
static UpdateInfo           UpdateInfoFile;

static void FileHeader_Read(FileDescriptor *pFile);
static bool FileHeader_Write(FileDescriptor *pFile);

SystemInformation* SystemInfoFile_Get(void)
{
    return &SystemInfoFile;
}

void UpdateCalibrationFile(bool* pChModifyFlag, float32* pChA_Gain, float32* pChB_Gain)
{
    ADC_CHA ChA;
    ADC_CHB ChB;
    CALIBRATION_CH CalibrationCh;

    for(ChA = VA_CH, CalibrationCh = CALIBRATION_VA; ChA <= VT_CH; ChA++, CalibrationCh++)
    {
        if(pChModifyFlag[CalibrationCh] == false)
            continue;

        PtctCorrInfoFile.CalibrationParameter[CalibrationCh].ChannelGain = pChA_Gain[ChA];
    }

    for(ChB = IA_CH, CalibrationCh = CALIBRATION_IA; ChB <= IN_CH; ChB++, CalibrationCh++)
    {
        if(pChModifyFlag[CalibrationCh] == false)
            continue;

        /*normal ch*/
        PtctCorrInfoFile.CalibrationParameter[CalibrationCh].ChannelGain   = pChB_Gain[ChB];
        /*amp ch*/
        PtctCorrInfoFile.CalibrationParameter[CalibrationCh+4].ChannelGain = pChB_Gain[ChB+4];

    }
}
void* GetSystemInfoFileAddr(void)
{
    return (void*)&SystemInfoFile;
}
void* GetChannelConfigFileAddr(void)
{
    return (void*)&ChannelConfigsFile;
}
void* GetPtctCorrInfoFileAddr(void)
{
    return (void*)&PtctCorrInfoFile;
}
void* GetGpaiCorrInfoFileAddr(void)
{
    return (void*)&GpaiCorrInfoFile;
}
void* GetUpdateInfoFileAddr(void)
{
    return (void*)&UpdateInfoFile;
}
void Init_MMI_PASSWORD(void)
{
    FileDescriptor*     pPasswordFileDescriptor;
    MmiPassword         Password;

    pPasswordFileDescriptor=File_Open(FILE_MMI_PASSWORD,MODE_READ);

    if(pPasswordFileDescriptor==NULL) return 0;

    File_Read(pPasswordFileDescriptor,&Password, 17);
    File_Close(pPasswordFileDescriptor);

    if(!Password.Init_Flag)
    {
        Password.Init_Flag =1;

        memset(&Password.password, 0x30, sizeof(Password.password));
        Password.password[PW_LEVEL_4][0]='S';
        Password.password[PW_LEVEL_4][1]='S';
        Password.password[PW_LEVEL_4][2]='I';
        Password.password[PW_LEVEL_4][3]='C';

        pPasswordFileDescriptor=File_Open(FILE_MMI_PASSWORD,MODE_WRITE);
        File_Write(pPasswordFileDescriptor,&Password, 17);
        File_Close(pPasswordFileDescriptor);
    }

    return 0;
}

void SystemFile_Load(FileIndex FileIndex, void* pDefaultFile)
{
    uint16* pBuf;
    uint16 ComputedCRC, Size;
    FileDescriptor* pFile = File_Open(FileIndex, MODE_READ);

    if(pFile == NULL)
            return;

    pBuf = pFile->pFileCache;
    Size = pFile->Size;

    if(File_Read(pFile, pBuf, Size) == true)
    {
        File_Close(pFile);

        ComputedCRC = Compute_DNP_CRC(pBuf, Size);

        if(ComputedCRC != pFile->CRC)
        {
            if(pDefaultFile == NULL)
            {
                memset(pBuf, 0, Size);
                return;
            }
            /*Invalid*/
            DEBUG_Printf("save default file index %d\n", pFile->FileIndex);
            pFile = File_Open(FileIndex, MODE_WRITE);
            File_Write(pFile, (uint16*)pDefaultFile, Size);
            File_Close(pFile);
        }
    }

    if(FileIndex == FILE_CHANNEL_CONFIG)
    {
        float32 FileData[2] = {ChannelConfigsFile.CT_Ratio,
                               ChannelConfigsFile.PT_Ratio};
        float32 TagData[2]  = {pTagDb->SC.SC_F[ALS_SC_CT_RATIO],
                               pTagDb->SC.SC_F[ALS_SC_PT_RATIO]};

        if(memcmp(&FileData[0], &TagData[0], sizeof(FileData) != 0))
        {
            ChannelConfigsFile.CT_Ratio = TagData[0];
            ChannelConfigsFile.PT_Ratio = TagData[1];

            ComputedCRC = Compute_DNP_CRC(pBuf, Size);

            pFile = File_Open(FileIndex, MODE_WRITE);
            File_Write(pFile, (uint16*)pDefaultFile, Size);
            File_Close(pFile);
        }
    }
}
void FileModule_Init(void)
{
    uint16 i, Index, FlashSectorNum;

    uint16 EventFileSize[5] = {FILE_SEQ_EVENT_SIZE, FILE_FLT_EVENT_SIZE, FILE_FLTWAVE_EVENT_SIZE,
                               FILE_DMD_EVENT_SIZE, FILE_ENERGY_LOG_SIZE};

    uint16 SystemFileSize[FILE_INDEX_MAX-FILE_SYSTEM_INFO] = {sizeof(SystemInformation),
                                                              sizeof(ChannelConfigs),
                                                              sizeof(PtctCorrInfo),
                                                              sizeof(GpaiCorrInfo),
                                                              sizeof(SdnpAiMap4Scada),
                                                              sizeof(SdnpAoMap4Scada),
                                                              sizeof(SdnpBiMap4Scada),
                                                              sizeof(SdnpBoMap4Scada),
                                                              sizeof(MmiPassword)};

    void* pSystemFileAddr[FILE_INDEX_MAX-FILE_SYSTEM_INFO] = {&SystemInfoFile,
                                                             &ChannelConfigsFile,
                                                             &PtctCorrInfoFile,
                                                             &GpaiCorrInfoFile,
                                                             &ScadaAiConfigFile,
                                                             &ScadaAoConfigFile,
                                                             &ScadaBiConfigFile,
                                                             &ScadaBoConfigFile,
                                                             &PasswordFile};


    memset(FileCache, 0,  sizeof(uint16)*FLASH_SECTOR_SIZE);
    memset(FileHandle, 0, sizeof(FileDescriptor)*FILE_INDEX_MAX);

    /* Event File (Flash) */
    for(i=FILE_SEQ_EVENT0; i<=FILE_ENERGY_LOG9; i++)
    {
        FlashSectorNum = (16*(i/10)) + i%10;
        FileHandle[i].FileIndex   = (FileIndex)i;
        FileHandle[i].FileStorage = STORAGE_FLASH;
        FileHandle[i].Size           = EventFileSize[i/10];
        FileHandle[i].BaseAddr       = (uint32)FlashSectorNum*(uint32)FLASH_SECTOR_SIZE;
        FileHandle[i].HeaderBaseAddr = FILE_HEADER_OFFSET_ADDR + (FlashSectorNum*FILE_HEADER_SIZE);
        FileHandle[i].Sector         = FlashSectorNum;
        FileHandle[i].pFileCache     = &FileCache[0];

        FileHeader_Read(&FileHandle[i]);
    }

    /* Firmware update File (Flash) */

    FlashSectorNum = FILE_UPDATE_START_SECTOR;
    for(i=FILE_SECTOR_H_1; i<=FILE_SECTOR_B_16; i++, FlashSectorNum++)
    {
        FileHandle[i].FileIndex      = (FileIndex)i;
        FileHandle[i].FileStorage    = STORAGE_FLASH;
        FileHandle[i].Size           = FLASH_SECTOR_SIZE;
        FileHandle[i].BaseAddr       = (uint32)FlashSectorNum*(uint32)FLASH_SECTOR_SIZE;
        FileHandle[i].HeaderBaseAddr = FILE_HEADER_OFFSET_ADDR + (FlashSectorNum*FILE_HEADER_SIZE);
        FileHandle[i].Sector         = FlashSectorNum;
        FileHandle[i].pFileCache     = &FileCache[0];

        FileHeader_Read(&FileHandle[i]);
    }

    Index = 0;
    /* System File (Fram) */
    for(i=FILE_SYSTEM_INFO; i<=FILE_MMI_PASSWORD; i++, Index++)
    {
        FileHandle[i].FileIndex   = (FileIndex)i;
        FileHandle[i].FileStorage = STORAGE_FRAM;

        FileHandle[i].FramIndex  = Index;
        FileHandle[i].BaseAddr   = (uint32)(Index)*(uint32)FRAM_BLOCK_SIZE;
        FileHandle[i].HeaderBaseAddr = FileHandle[i].BaseAddr;
        FileHandle[i].Size       = SystemFileSize[Index];
        FileHandle[i].pFileCache = pSystemFileAddr[Index];

        FileHeader_Read(&FileHandle[i]);

        memset(FileHandle[i].pFileCache, 0,  FileHandle[i].Size);
    }

    Init_MMI_PASSWORD();


    /*Get TAG DB address*/
    pTagDb = TagDB_Get();


}

/*
 * Functgion   : File_Open
 * Description :
 * Parameter   :
 */



FileDescriptor* File_Open(FileIndex Index, FileMode Mode)
{
    FileDescriptor *pFile = NULL;

    pFile = &FileHandle[Index];

    if(Mode == MODE_NULL)
        return pFile;

    if(pFile->Status != FILE_CLOSE)
        return NULL;

    pFile->Mode = Mode;

    switch(Mode)
    {
        case MODE_WRITE:

                pFile->Status = FILE_OPEN;
                pFile->WritePos = 0;

                if(pFile->FileStorage == STORAGE_FLASH)
                {
                    Zone7BusTake(FLASH);
                    EraseFlashSector(pFile->Sector);
                    Zone7BusRelease();

                    TASK_SLEEP(18);

                    Zone7BusTake(FLASH);
                    if(CheckFlashSectorErase(pFile->Sector) == false)
                    {
                        DEBUG_Printf("fail to erase flash sector %d\n", pFile->Sector);
                    }

                    Zone7BusRelease();
                    pFile->Free = pFile->Size;
                    pFile->Used = 0;
                    pFile->CRC  = 0;
                    FileHeader_Write(pFile);
                }

            break;
        case MODE_APPEND:
            pFile->Status   = FILE_OPEN;
            pFile->WritePos = pFile->Used;
            break;
        case MODE_READ:
            if(pFile->ReadPos >= pFile->Used)
                pFile->ReadPos = 0;
            pFile->Status = FILE_OPEN;
            break;
        default:
            return NULL;
    }

    return pFile;
}
/*
 * Functgion   : File_Close
 * Description :
 * Parameter   :
 */
bool File_Close(FileDescriptor *pFile)
{
    if(pFile == NULL)                       return false;

    if(pFile->Status != FILE_OPEN)          return false;

    pFile->Mode = MODE_NULL;
    pFile->Status = FILE_CLOSE;

    return true;
}
/*
 * Function    : File_Write
 * Description :
 * Parameter   :
 */
bool File_Write(FileDescriptor *pFile, uint16 *pBuf, uint16 Size)
{
    uint16 i;
    uint16 Data;
    if((pFile == NULL)||(pFile->Status != FILE_OPEN))               return false;

    switch(pFile->Mode)
    {
        case MODE_WRITE:
        {
            if(pFile->Size < Size)                                  return false;

            pFile->Status = FILE_WRITING;
            uint32 addr = pFile->BaseAddr;

            if(pFile->FileStorage == STORAGE_FLASH)
            {
                uint16 FlashData;
                Zone7BusTake(FLASH);
                for(i=0; i<Size; i++)
                {
                    Data = *(pBuf+i);
                    FLASH_Write(addr + i,  Data);
                }

                Zone7BusRelease();
                pFile->Free = pFile->Size-Size;
                pFile->Used = Size;
                pFile->CRC = Compute_DNP_CRC(pBuf , Size);
                FileHeader_Write(pFile);
            }
            else
            {
                /*HMIS (File Write)*/
                if(pFile->FileIndex >= FILE_SYSTEM_INFO)
                {
                    memcpy(pFile->pFileCache, pBuf, Size);

                    switch(pFile->FileIndex)
                    {
                        case FILE_SYSTEM_INFO:
                            break;
                        case FILE_CHANNEL_CONFIG:
                            pTagDb->SC.SC_F[ALS_SC_PT_RATIO] = ChannelConfigsFile.PT_Ratio;
                            pTagDb->SC.SC_F[ALS_SC_CT_RATIO] = ChannelConfigsFile.CT_Ratio;

                            FramTagEvt_Push(TAG_GRP_SC_F, ALS_SC_CT_RATIO);
                            FramTagEvt_Push(TAG_GRP_SC_F, ALS_SC_PT_RATIO);
                            break;
                    }
                }

                pFile->Used = pFile->Size;
                pFile->Free = 0;
                pFile->CRC  = Compute_DNP_CRC(pBuf, Size);

                /*Write file header */
                FileHeader_Write(pFile);
                /*Write file data*/
                FramFile_Write(pFile->BaseAddr + FILE_HEADER_SIZE, pBuf, Size);
            }

            pFile->WritePos += Size;
            pFile->Status = FILE_OPEN;

            return true;
        }
    case MODE_APPEND:
        {
            if(pFile->Free < Size)
            {
                return false;
            }
            uint16 PrevCrc;
            uint32 addr = pFile->BaseAddr + pFile->WritePos;
            uint16 FlashData;
            pFile->Status = FILE_WRITING;

            Zone7BusTake(FLASH);
            for(i=0; i<Size; i++)
            {
                Data = *(pBuf+i);

                FLASH_Write(addr + i,  Data);

                pFile->Free -= 1;
                pFile->Used += 1;
                PrevCrc = pFile->CRC;
                pFile->CRC = CRC_Update(&Data , 1, PrevCrc);

             //   FileHeader_Write(pFile);

            }
            Zone7BusRelease();
            FileHeader_Write(pFile);
            pFile->Status = FILE_OPEN;

            return true;
        }
    default:
        return false;
    }
}

/*
 * Function    : File_Read
 * Description :
 * Parameter   :
 */
bool File_Read(FileDescriptor *pFile, uint16 *pBuf, uint16 Size)
{
    uint16 i;
    uint32 FlashAddr = pFile->BaseAddr + pFile->ReadPos;
    uint16 Available = pFile->Used - pFile->ReadPos;

    if((pFile == NULL)||(pFile->Mode != MODE_READ))
        return false;
#if 0       // Block erase test
    if(Available < Size)
        Size = Available;
#endif
    pFile->Status = FILE_READING;

    if(pFile->FileStorage == STORAGE_FLASH)
    {
        Zone7BusTake(FLASH);

        for(i=0; i<Size; i++)
        {
            *(pBuf + i) =  FLASH_Read(FlashAddr + i);
        }

        Zone7BusRelease();

        pFile->ReadPos += Size;

    }
    else
    {
        FramFile_Read(pFile->BaseAddr + FILE_HEADER_SIZE, pBuf, Size);
    }

    if(pFile->ReadPos >= pFile->Used)
        pFile->ReadPos = 0;

    pFile->Status = FILE_OPEN;

    return true;
}

bool File_Erase(FileDescriptor *pFile)
{
    bool Result = false;
    if(pFile == NULL)
        return false;

    pFile->Free = pFile->Size;
    pFile->Used = 0;
    pFile->CRC  = 0;

    FileHeader_Write(pFile);

    if(pFile->FileStorage == STORAGE_FLASH)
    {
        Zone7BusTake(FLASH);
        EraseFlashSector(pFile->Sector);
        Zone7BusRelease();
        TASK_SLEEP(25);

        Zone7BusTake(FLASH);
        if(CheckFlashSectorErase(pFile->Sector) == false)
        {
            DEBUG_Printf("fail to erase flash sector %d\n", pFile->Sector);
        }
        Zone7BusRelease();
    }
    else
    {
        memset(pFile->pFileCache, 0x0, pFile->Size);
        FramFile_Write(pFile->BaseAddr + FILE_HEADER_SIZE, pFile->pFileCache, pFile->Size);
        Result = true;
    }

    return Result;
}

bool UpdataFile_Erase(void)
{
    FileDescriptor* pUpdateFile;
    FileIndex Index;
    uint16 i;
    bool FlashEraseFlag = false;

    /*update file header*/
    for(Index = FILE_SECTOR_H_1; Index<= FILE_SECTOR_B_16; Index++)
    {
        pUpdateFile = File_Open(Index, MODE_NULL);

        Zone7BusTake(FLASH);

        EraseFlashSector(pUpdateFile->Sector);

        Zone7BusRelease();

        TASK_SLEEP(18);

        do
        {
            FlashEraseFlag = CheckFlashSectorErase(pUpdateFile->Sector);

            if(FlashEraseFlag == false)
            {
                DEBUG_Msg("flash device sector erasing... \n");
                TASK_SLEEP(1);
            }
            else
            {
                break;
            }

        } while(FlashEraseFlag == false);

        pUpdateFile->Free = pUpdateFile->Size;
        pUpdateFile->Used = 0;
        pUpdateFile->CRC  = 0;

        FileHeader_Write(pUpdateFile);
    }

    /*Write the message to be read by the bootloader to the FRAM*/
    char Msg[16] = "DOWNLONDING";

    Zone7BusTake(FRAM);

    for(i=0; i< 16; i++)
    {
        FRAM_ByteWrite(FRAM_MSG_ADDR+i, Msg[i]);
    }

    Zone7BusRelease();

   return true;
}

void UpdateFileError(void)
{
    uint16 i;
    /*Write the message to be read by the bootloader to the FRAM*/
    char Msg[16] = "ERROR";

    Zone7BusTake(FRAM);

    for(i=0; i< 16; i++)
    {
        FRAM_ByteWrite(0x7FF0, Msg[i]);
    }

    Zone7BusRelease();
}

void UpdateFileHeader(void)
{
    FileDescriptor* pUpdateFile;
    FileIndex i;

    /*update file header*/
    for(i = FILE_SECTOR_H_1; i<= FILE_SECTOR_B_16; i++)
    {
        pUpdateFile = File_Open(i, MODE_READ);

        Zone7BusTake(FLASH);

        if(File_Read(pUpdateFile, pUpdateFile->pFileCache, pUpdateFile->Size) == false)
            DEBUG_Printf("fail to file read file index : %d\n", i);

        Zone7BusRelease();

        File_Close(pUpdateFile);

        pUpdateFile->Free = 0;
        pUpdateFile->Used = pUpdateFile->Size;
        pUpdateFile->CRC  = Compute_DNP_CRC(pUpdateFile->pFileCache, pUpdateFile->Size);

        FileHeader_Write(pUpdateFile);
    }

    /*Write the message to be read by the bootloader to the FRAM*/
    char Msg[16] = "COMPLETE";

    Zone7BusTake(FRAM);

    for(i=0; i< 16; i++)
    {
        FRAM_ByteWrite(FRAM_MSG_ADDR+i, Msg[i]);
    }

    Zone7BusRelease();

}
/*
 * Function   : FileHeader_Write
 * Description :
 * Parameter   :
 */
static bool FileHeader_Write(FileDescriptor *pFile)
{
    uint16 Addr = pFile->HeaderBaseAddr;

    Zone7BusTake(FRAM);

    FRAM_WordWrite(Addr + FILE_HEADER_USED, pFile->Used);
    FRAM_WordWrite(Addr + FILE_HEADER_FREE, pFile->Free);
    FRAM_WordWrite(Addr + FILE_HEADER_CRC , pFile->CRC);

    Zone7BusRelease();

    return true;

}
static void FileHeader_Read(FileDescriptor *pFile)
{
    uint16 FramAddr = pFile->HeaderBaseAddr;

    Zone7BusTake(FRAM);

    pFile->Used = FRAM_WordRead(FramAddr + FILE_HEADER_USED);
    pFile->Free = FRAM_WordRead(FramAddr + FILE_HEADER_FREE);
    pFile->CRC  = FRAM_WordRead(FramAddr + FILE_HEADER_CRC);

    Zone7BusRelease();
}
void FramFile_Write(uint16 FramAddr, uint16* pBuf, uint16 Size)
{
    uint16 i;

    Zone7BusTake(FRAM);

    for(i=0; i<Size; i++)
    {
        FRAM_WordWrite(FramAddr, *pBuf++);
        FramAddr += 2;
    }

    Zone7BusRelease();
}

void FramFile_Read(uint16 FramAddr, uint16* pBuf, uint16 Size)
{
    uint16 i;

    Zone7BusTake(FRAM);

    for(i=0; i<Size; i++)
    {
        *pBuf++ = FRAM_WordRead(FramAddr);
        FramAddr += 2;
    }

    Zone7BusRelease();

}

void FileDataPacking(char* pBuf, uint16* pFileBuf, uint16 WordSize)
{
    uint16 i;
    uint16 PackingData;

    for(i=0; i<WordSize; i++)
    {
        PackingData  = *pBuf++;
        PackingData |= ((*pBuf++)<<8);

        *pFileBuf++ = PackingData;
    }
}
void FileDataUnpacking(char* pBuf, uint16* pFileBuf, uint16 WordSize)
{
    uint16 i;
    uint16 FileData;

    for(i=0; i<WordSize; i++)
    {
        FileData = *pFileBuf++;
        *pBuf++ = FileData&0xFF;
        *pBuf++ = FileData>>8;
    }
}
