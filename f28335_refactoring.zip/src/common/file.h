/*
 * file.h
 *
 *  Created on: 2023. 11. 14.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_UTILITY_FILEMANAGER_H_
#define COMPONENTS_UTILITY_FILEMANAGER_H_

#include "def.h"
#include "src/utils/crc.h"
#include "src/port/decoder.h"
#include "src/port/memory/flash.h"
#include "src/port/memory/fram.h"

#define FILE_HEADER_SIZE                6

#define FILE_SEQ_EVENT_MAX                    10
#define FILE_SEQ_EVENT_SIZE                 2048

#define FILE_FLT_EVENT_MAX                  10
#define FILE_FLT_EVENT_SIZE                2046

#define FILE_FLTWAVE_EVENT_MAX               10
#define FILE_FLTWAVE_EVENT_SIZE            2000

#define FILE_DMD_EVENT_MAX               10
#define FILE_DMD_EVENT_SIZE              2030

#define FILE_ENERGY_LOG_MAX                 10
#define FILE_ENERGY_LOG_SIZE                2000

#define SCADA_CONFIG_MAX                    20


typedef enum
{
    /*Event file*/
    FILE_SEQ_EVENT0,        FILE_SEQ_EVENT1,        FILE_SEQ_EVENT2,        FILE_SEQ_EVENT3,        FILE_SEQ_EVENT4,
    FILE_SEQ_EVENT5,        FILE_SEQ_EVENT6,        FILE_SEQ_EVENT7,        FILE_SEQ_EVENT8,        FILE_SEQ_EVENT9,

    FILE_FLT_EVENT0,        FILE_FLT_EVENT1,        FILE_FLT_EVENT2,        FILE_FLT_EVENT3,        FILE_FLT_EVENT4,
    FILE_FLT_EVENT5,        FILE_FLT_EVENT6,        FILE_FLT_EVENT7,        FILE_FLT_EVENT8,        FILE_FLT_EVENT9,

    FILE_FLTWAVE_EVENT0,    FILE_FLTWAVE_EVENT1,    FILE_FLTWAVE_EVENT2,    FILE_FLTWAVE_EVENT3,    FILE_FLTWAVE_EVENT4,
    FILE_FLTWAVE_EVENT5,    FILE_FLTWAVE_EVENT6,    FILE_FLTWAVE_EVENT7,    FILE_FLTWAVE_EVENT8,    FILE_FLTWAVE_EVENT9,

    FILE_LOAD_PROFILE0,     FILE_LOAD_PROFILE1,     FILE_LOAD_PROFILE2,     FILE_LOAD_PROFILE3,     FILE_LOAD_PROFILE4,
    FILE_LOAD_PROFILE5,     FILE_LOAD_PROFILE6,     FILE_LOAD_PROFILE7,     FILE_LOAD_PROFILE8,     FILE_LOAD_PROFILE9,

    FILE_ENERGY_LOG0,       FILE_ENERGY_LOG1,       FILE_ENERGY_LOG2,       FILE_ENERGY_LOG3,       FILE_ENERGY_LOG4,
    FILE_ENERGY_LOG5,       FILE_ENERGY_LOG6,       FILE_ENERGY_LOG7,       FILE_ENERGY_LOG8,       FILE_ENERGY_LOG9,

    /*for update*/
    FILE_SECTOR_H_1,        FILE_SECTOR_H_2,        FILE_SECTOR_H_3,        FILE_SECTOR_H_4,
    FILE_SECTOR_H_5,        FILE_SECTOR_H_6,        FILE_SECTOR_H_7,        FILE_SECTOR_H_8,
    FILE_SECTOR_H_9,        FILE_SECTOR_H_10,       FILE_SECTOR_H_11,       FILE_SECTOR_H_12,
    FILE_SECTOR_H_13,       FILE_SECTOR_H_14,       FILE_SECTOR_H_15,       FILE_SECTOR_H_16,

    FILE_SECTOR_G_1,        FILE_SECTOR_G_2,        FILE_SECTOR_G_3,        FILE_SECTOR_G_4,
    FILE_SECTOR_G_5,        FILE_SECTOR_G_6,        FILE_SECTOR_G_7,        FILE_SECTOR_G_8,
    FILE_SECTOR_G_9,        FILE_SECTOR_G_10,       FILE_SECTOR_G_11,       FILE_SECTOR_G_12,
    FILE_SECTOR_G_13,       FILE_SECTOR_G_14,       FILE_SECTOR_G_15,       FILE_SECTOR_G_16,

    FILE_SECTOR_F_1,        FILE_SECTOR_F_2,        FILE_SECTOR_F_3,        FILE_SECTOR_F_4,
    FILE_SECTOR_F_5,        FILE_SECTOR_F_6,        FILE_SECTOR_F_7,        FILE_SECTOR_F_8,
    FILE_SECTOR_F_9,        FILE_SECTOR_F_10,       FILE_SECTOR_F_11,       FILE_SECTOR_F_12,
    FILE_SECTOR_F_13,       FILE_SECTOR_F_14,       FILE_SECTOR_F_15,       FILE_SECTOR_F_16,

    FILE_SECTOR_E_1,        FILE_SECTOR_E_2,        FILE_SECTOR_E_3,        FILE_SECTOR_E_4,
    FILE_SECTOR_E_5,        FILE_SECTOR_E_6,        FILE_SECTOR_E_7,        FILE_SECTOR_E_8,
    FILE_SECTOR_E_9,        FILE_SECTOR_E_10,       FILE_SECTOR_E_11,       FILE_SECTOR_E_12,
    FILE_SECTOR_E_13,       FILE_SECTOR_E_14,       FILE_SECTOR_E_15,       FILE_SECTOR_E_16,

    FILE_SECTOR_D_1,        FILE_SECTOR_D_2,        FILE_SECTOR_D_3,        FILE_SECTOR_D_4,
    FILE_SECTOR_D_5,        FILE_SECTOR_D_6,        FILE_SECTOR_D_7,        FILE_SECTOR_D_8,
    FILE_SECTOR_D_9,        FILE_SECTOR_D_10,       FILE_SECTOR_D_11,       FILE_SECTOR_D_12,
    FILE_SECTOR_D_13,       FILE_SECTOR_D_14,       FILE_SECTOR_D_15,       FILE_SECTOR_D_16,

    FILE_SECTOR_C_1,        FILE_SECTOR_C_2,        FILE_SECTOR_C_3,        FILE_SECTOR_C_4,
    FILE_SECTOR_C_5,        FILE_SECTOR_C_6,        FILE_SECTOR_C_7,        FILE_SECTOR_C_8,
    FILE_SECTOR_C_9,        FILE_SECTOR_C_10,       FILE_SECTOR_C_11,       FILE_SECTOR_C_12,
    FILE_SECTOR_C_13,       FILE_SECTOR_C_14,       FILE_SECTOR_C_15,       FILE_SECTOR_C_16,

    FILE_SECTOR_B_1,        FILE_SECTOR_B_2,        FILE_SECTOR_B_3,        FILE_SECTOR_B_4,
    FILE_SECTOR_B_5,        FILE_SECTOR_B_6,        FILE_SECTOR_B_7,        FILE_SECTOR_B_8,
    FILE_SECTOR_B_9,        FILE_SECTOR_B_10,       FILE_SECTOR_B_11,       FILE_SECTOR_B_12,
    FILE_SECTOR_B_13,       FILE_SECTOR_B_14,       FILE_SECTOR_B_15,       FILE_SECTOR_B_16,

    /*System file*/
    FILE_SYSTEM_INFO,       FILE_CHANNEL_CONFIG,    FILE_PTCT_CORR,         FILE_GPAI_CORR,
    /*SCADA Configuration*/
    FILE_SCADA_CONFIG_AI,   FILE_SCADA_CONFIG_AO,   FILE_SCADA_CONFIG_BI,   FILE_SCADA_CONFIG_BO,
    /*MMI_PASSWORD*/
    FILE_MMI_PASSWORD,
    /*Update info*/
    FILE_UPDATE_INFO,

    FILE_INDEX_MAX,

    INVALID_FILE,

} FileIndex;

typedef enum
{
    STORAGE_FLASH,
    STORAGE_FRAM,
} FileStorage;
typedef enum
{
    FILE_CLOSE,
    FILE_OPEN,
    FILE_WRITING,
    FILE_READING

} FileStatus;
typedef enum
{
    MODE_NULL,
    MODE_READ,
    MODE_WRITE,
    MODE_APPEND

} FileMode;

typedef struct
{
    FileIndex           FileIndex;
    FileStorage         FileStorage;

    FileMode            Mode;

    FileStatus          Status;

    /*Only event file*/
    uint16              Sector;
    /*Only System file*/
    uint16              FramIndex;

    uint16              HeaderBaseAddr;

    uint32              BaseAddr;

    /*File Header*/
    uint16              Size;
    uint16              Free;
    uint16              Used;
    uint16              CRC;

    uint16              WritePos;
    uint16              ReadPos;

    void               *pFileCache;

} FileDescriptor;


#define SYSTEM_INFO_MAX            16
/*File Struct*/
/*System Information*/
typedef struct
{
    char SerialNumber[SYSTEM_INFO_MAX];
    char ModelNumber[SYSTEM_INFO_MAX];
    char Identifier[SYSTEM_INFO_MAX];

} SystemInformation;

/* HMIS - Calibration Channelconfigs.bin*/
typedef struct
{

    float32 CT_Ratio;              /*CT Ratio*/
    float32 PT_Ratio;              /*PT Ratio*/

    float32 VaVrReference_RMS;
    float32 VaVrReference_Angle;

    float32 VbVsReference_RMS;
    float32 VbVsReference_Angle;

    float32 VcVtReference_RMS;
    float32 VcVtReference_Angle;

    float32 IaReference_RMS;
    float32 IaReference_Angle;

    float32 IbReference_RMS;
    float32 IbReference_Angle;

    float32 IcReference_RMS;
    float32 IcReference_Angle;

    float32 InReference_RMS;
    float32 InReference_Angle;

    float32 IaAmpReference_RMS;
    float32 IaAmpReference_Angle;

    float32 IbAmpReference_RMS;
    float32 IbAmpReference_Angle;

    float32 IcAmpReference_RMS;
    float32 IcAmpReference_Angle;

    float32 InAmpReference_RMS;
    float32 InAmpReference_Angle;

} ChannelConfigs;

typedef struct
{
    float32 Reserved[2];
    float32 ChannelGain;
    float32 AngleOffset;

} AdcCalibration;
/* HMIS - Calibration ptctcorrinfo.bin*/
typedef struct
{
    AdcCalibration  CalibrationParameter[CALIBRATION_CH_MAX];

} PtctCorrInfo;

/*GPAI Gain, Offset*/
typedef struct
{
    GpaiParam       GpaiChParameter[GPAI_CH_MAX];

} GpaiCorrInfo;

typedef struct
{
    ADCChannelConfig_t ChannelA[ADC_CHA_MAX];
    ADCChannelConfig_t ChannelB[ADC_CHB_MAX];

} CalibrationParameter;


typedef enum
{
    REFERENCE_PAHSE_A,
    REFERENCE_PAHSE_B,
    REFERENCE_PAHSE_C,

} RefencePhase;
typedef struct
{
    uint16          TargetSystemFrequency;
    uint16          LogicSettingGroup;
    uint16          Reserved;
    uint16          PhaseRotation;
    RefencePhase    ReferencePhase;
    uint16          FlowDirection;
    uint16          DiDebounceTime;
    uint16          RunUserLogic;
    float32         PhasorPrevious_N_Cycle;
    float32         FrequencyPrevious_N_Cycle;
    float32         SymmetricPrevious_N_Cycle;
    uint16          DemandTime;
    uint16          DemandType;
    uint16          Reserved1[45];

} SystemConfig;

/*
 * SCADA Configuration file
 */
typedef struct
{
    uint16      IndexNumber;
    uint16      Deadband;
    uint16      Class;
    uint16      SOE;
    uint16      Scale;

} ScadaAiConfig;

typedef struct
{
    uint16      IndexNumber;
    uint16      Invert;
    uint16      Class;
    uint16      SOE;

} ScadaBiConfig;

typedef struct
{
    uint16      IndexNumber;
    uint16      Command;

} ScadaBoConfig;

typedef struct
{
    uint16          TotalIndex;
    ScadaAiConfig   ScadaAiConfig[SCADA_CONFIG_MAX];

} SdnpAiMap4Scada;

typedef struct
{

} SdnpAoMap4Scada;
typedef struct
{
    uint16          TotalIndex;
    ScadaBiConfig   ScadaBiConfig[SCADA_CONFIG_MAX];

} SdnpBiMap4Scada;

typedef struct
{
    uint16          TotalIndex;
    ScadaBoConfig   ScadaBoConfig[SCADA_CONFIG_MAX];

} SdnpBoMap4Scada;
typedef enum
{
    PW_LEVEL_1,
    PW_LEVEL_2,
    PW_LEVEL_3,
    PW_LEVEL_4,

    PW_LEVEL_MAX,

} PassWordType;
typedef struct _MmiPassword {
    char                    password[PW_LEVEL_MAX][4];
    uint16                  Init_Flag;
} MmiPassword;

typedef struct
{

    uint32           FirmwareFileSize;
    uint16           CRC;

} UpdateInfo;










/*Initialization*/

void FileModule_Init(void);
void SystemFile_Load(FileIndex FileIndex, void* pDefaultFile);


void CalibrationFlagAddr_Set(uint16 Addr);

PtctCorrInfo* CalibrationInterface(ADCChannelConfig_t* pAdcChAParam, ADCChannelConfig_t* pAdcChBParam);


void* GetSystemInfoFileAddr(void);
void* GetChannelConfigFileAddr(void);
void* GetPtctCorrInfoFileAddr(void);
void* GetGpaiCorrInfoFileAddr(void);
void* GetUpdateInfoFileAddr(void);

PtctCorrInfo* CalibrationFileAddr_Get(void);

FileDescriptor* File_Open(FileIndex Index, FileMode Mode);
bool File_Close(FileDescriptor *pFile);
bool File_Read(FileDescriptor *pFile, uint16 *pBuf, uint16 Size);
bool File_Write(FileDescriptor *pFile, uint16 *pBuf, uint16 Size);
bool File_Erase(FileDescriptor *pFile);

bool UpdataFile_Erase(void);
void UpdateFileHeader(void);



void FramFile_Write(uint16 FramAddr, uint16* pBuf, uint16 Size);
void FramFile_Read(uint16 FramAddr, uint16* pBuf, uint16 Size);

/*Dnp Interface*/
bool DnpFile_Read(FileDescriptor *pFile, void *pBuf, uint16 ReadWords);
bool DnpFile_Write(FileDescriptor *pFile, uint16 *pBuf, uint16 WriteWords);

void FileDataUnpacking(char* pBuf, uint16* pFileBuf, uint16 WordSize);
void FileDataPacking(char* pBuf, uint16* pFileBuf, uint16 WordSize);

void ChannelConfigFileInfo_Get(uint16** pFileAddr, uint16** pFileSize);


#endif /* COMPONENTS_UTILITY_FILEMANAGER_H_ */
