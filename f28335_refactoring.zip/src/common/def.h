/*
 * def.h
 *
 *  Created on: 2023. 9. 22.
 *      Author: ShinSung Industrial Electric
 */

#ifndef BSP_PORTS_INCLUDE_DEF_H_
#define BSP_PORTS_INCLUDE_DEF_H_

#include "DSP2833x_GlobalPrototypes.h"
#include "DSP28x_Project.h"

#include "debug.h"
#include "os.h"
#include "types.h"

typedef enum
{
    VA_CH,          VB_CH,          VC_CH,
    VR_CH,          VS_CH,          VT_CH,
    MUX2_CH,        MUX1_CH,        ADC_CHA_MAX,

} ADC_CHA;

typedef enum
{
    IA_CH,          IB_CH,          IC_CH,
    IN_CH,          IAM_CH,         IBM_CH,
    ICM_CH,         INM_CH,         ADC_CHB_MAX,

} ADC_CHB;
typedef enum
{
    CALIBRATION_VA,     CALIBRATION_VB,     CALIBRATION_VC,
    CALIBRATION_VR,     CALIBRATION_VS,     CALIBRATION_VT,
    CALIBRATION_IA,     CALIBRATION_IB,     CALIBRATION_IC,     CALIBRATION_IN,
    CALIBRATION_IAM,    CALIBRATION_IBM,    CALIBRATION_ICM,    CALIBRATION_INM,

    CALIBRATION_CH_MAX,

} CALIBRATION_CH;

enum
{
    /*MUX1 S1A              MUX2 S1B                MUX1 S2A                   MUX2 S2B */
    GPAI0_RESERVED,         GPAI1_12VAN,            GPAI2_AIMODFB,             GPAI3_12VAP,
    /*MUX1 S3A              MUX2 S3B                MUX1 S4A                   MUX2 S4B */
    GPAI4_AICPFB,           GPAI5_REF_DP,           GPAI6_AIOPFB,              GPAI7_CTEMP,
    /*MUX1 S5A              MUX2 S5B                MUX1 S6A                   MUX2 S6B */
    GPAI8_BATV,             GPAI9_RESERVED,         GPAI10_AICHV,              GPAI11_RESERVED,
    /*MUX1 S7A              MUX2 S7B                MUX1 S8A                   MUX  S8B*/
    GPAI12_AIOPV,           GPAI13_RESERVED,        GPAI14_RESERVED,           GPAI15_RESERVED,
    GPAI_CH_MAX = 16
};

/*UART CH*/
#define DEBUG_PORT            0           /*  SCI C*/
#define SCADA_PORT            1           /*  SCI B*/

/*TMS320F28335 DAC GAIN = 3/4096*/
#define DAC_GAIN                                0.000732421875F
/*Neutral   Current Channel Damping ratio 1/8*/
#define NEUTRAL_DAMPING_RATIO                   0.125F
/*Amplified Current Channel Damping ratio 1/16*/
#define AMP_DAMPING_RATIO                       0.0625F
/*Neutral Amplified Current Channel Damping ratio 1/128*/
#define NEUTRAL_AMP_DAMPING_RATIO               0.0078125F


#define VOLTAGE_CH_DEFAULT_GAIN     6.4F
#define CURRENT_CH_DEFAULT_GAIN     15.5F

#define VA_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN
#define VB_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN
#define VC_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN

#define VR_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN
#define VS_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN
#define VT_DEFAULT_GAIN     VOLTAGE_CH_DEFAULT_GAIN

#define MUX2_DEFAULT_GAIN   DAC_GAIN
#define MUX1_DEFAULT_GAIN   DAC_GAIN

#define IA_DEFAULT_GAIN     CURRENT_CH_DEFAULT_GAIN
#define IB_DEFAULT_GAIN     CURRENT_CH_DEFAULT_GAIN
#define IC_DEFAULT_GAIN     CURRENT_CH_DEFAULT_GAIN

#define IN_DEFAULT_GAIN     (CURRENT_CH_DEFAULT_GAIN * NEUTRAL_DAMPING_RATIO)

#define IAM_DEFAULT_GAIN    (IA_DEFAULT_GAIN * AMP_DAMPING_RATIO)
#define IBM_DEFAULT_GAIN    (IA_DEFAULT_GAIN * AMP_DAMPING_RATIO)
#define ICM_DEFAULT_GAIN    (IA_DEFAULT_GAIN * AMP_DAMPING_RATIO)
#define INM_DEFAULT_GAIN    (IN_DEFAULT_GAIN * NEUTRAL_AMP_DAMPING_RATIO)


typedef struct
{
    float32 GainUnit;
    /*ADC Default factor*/
    float32 TotalGain;

} ADCChannelConfig_t;

typedef struct
{
    float32         GpaiCh_Gain;
    float32         GpaiCh_Offset;

} GpaiParam;

#endif /* BSP_PORTS_INCLUDE_DEF_H_ */
