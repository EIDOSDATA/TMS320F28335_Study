/*
 * button.h
 *
 *  Created on: 2024. 1. 11.
 *      Author: ShinSung Industrial Electric
 */

#ifndef BUTTON_H_
#define BUTTON_H_

#include "types.h"

uint16 ButtonBlock_Read(uint16 block);

#endif /* BUTTON_H_ */
