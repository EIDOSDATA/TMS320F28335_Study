/*
 * targiodefs.h
 *
 *  Created on: 2023. 10. 24.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIODEFS_H_
#define COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIODEFS_H_


#include "tmwscl/utils/tmwcnfg.h"
#include "tmwscl/utils/tmwpltmr.h"
#include "tmwscl/utils/tmwtarg.h"

#include "src/port/tmwDNP/targiocnfg.h"

#include "src/port/uart.h"
#include "src/utils/ringbuf.h"

#define IP_ADDRESS_NUM      4

typedef enum
{
    TMWTARGIO_TYPE_NONE,
    TMWTARGIO_TYPE_232,
    TMWTARGIO_TYPE_TCP,
    TMWTARGIO_TYPE_UDP

} TMWTARGIO_TYPE_ENUM;

typedef enum
{
    SOCKET_0,
    SOCKET_1,
    SOCKET_2,
    SOCKET_3,

    SOCKET_MAX,
} SOCKET_NUM;

typedef enum
{
    SOCKET_CLOSE      = 0x00,    SOCKET_INIT      = 0x13,    SOCKET_LISTEN     = 0x14,
    SOCKET_SYNSENT    = 0x15,    SOCKET_SYNRECV   = 0x16,    SOCKET_ESTABLISED = 0x17,
    SOCKET_FIN_WAIT   = 0x18,    SOCKET_CLOSING   = 0x1A,    SOCKET_TIME_WAIT  = 0x1B,
    SOCKET_CLOSE_WAIT = 0x1C,    SOCKET_LAST_ACK  = 0x1D,    SOCKET_UDP        = 0x22,
    SOCKET_IPRAW      = 0x32,    SOCKET_MACRAW    = 0x42,    SOCKET_PPOE       = 0x5F

} SOCKET_STATUS_ENUM;

/* UART Configuration structure */
typedef struct
{
  SCI_CH           PortType;
  /* User specified channel name */
  TMWTYPES_CHAR    chnlName[IOCNFG_MAX_NAME_LEN];

  /* "/dev/ttyS0", "/dev/ttyS1", etc. */
  TMWTYPES_CHAR    portName[IOCNFG_MAX_NAME_LEN];

  /* flow control: none, hardware */
  RS232_PORT_MODE   portMode;

  /* baud rate */
  uint32            baudRate;

  /* parity */
  RS232_PARITY      parity;

  /* 7 or 8 */
  RS232_DATA_BITS   numDataBits;

  /* 1 or 2 */
  RS232_STOP_BITS   numStopBits;

  /* MODBUS RTU or not */
  TMWTYPES_BOOL     bModbusRTU;

} RS232_CONFIG;


/* UART Channel Configuration structure */
typedef struct
{
  TMWTARGIO_TYPE_ENUM   type;

  RS232_CONFIG          targ232;

  Ringbuf_t             *pRingbufHandle;

  void                  *pTargIOChannel;

} TARGUART_CONFIG;


/* Define serial port channel */
typedef struct
{
    TMWTARGIO_TYPE_ENUM     TargChType;

    SCI_CH                  PortType;

    TMWTYPES_CHAR         chnlName[IOCNFG_MAX_NAME_LEN];
    TMWTYPES_CHAR         portName[IOCNFG_MAX_NAME_LEN];

    bool              is_open;

    /* Callback function for this channel */
    TMWTARG_CHANNEL_CALLBACK_FUNC     pChannelCallback;      /* From TMWTARG_CONFIG  */
    void                             *pChannelCallbackParam; /* From TMWTARG_CONFIG  */

    TMWTARG_CHANNEL_READY_CBK_FUNC    pChannelReadyCallback; /* From TMWTARG_CONFIG  */
    void                             *pChannelReadyCbkParam; /* From TMWTARG_CONFIG  */

    TMWTARG_CHANNEL_RECEIVE_CBK_FUNC  pReceiveCallbackFunc;  /* From openChannel    */
    TMWTARG_CHECK_ADDRESS_FUNC        pCheckAddrCallbackFunc;/* From openChannel    */
    void                             *pCallbackParam;        /* From openChannel, used by both above */

    /* parity */
    RS232_PARITY      parity;

    /* flow control: none, hardware */
    RS232_PORT_MODE   portMode;

    /* 7 or 8 */
    RS232_DATA_BITS   numDataBits;

    /* 1 or 2 */
    RS232_STOP_BITS   numStopBits;

    /* MODBUS RTU or not */
    TMWTYPES_BOOL      bModbusRTU;

  /*
   * Specifies the amount of time (in character times) to use to
   * determine that a frame has been completed.  For modbus RTU this
   * value is 3.5 (i.e. 4 will be used)
   */
    TMWTYPES_USHORT numCharTimesBetweenFrames;

  /*
   * Specifies the amount of time to use to
   * determine that an inter character timeout has occured.
   * For modbus RTU this value is 1.5 character times (i.e. 2 would be used)
   */
    TMWTYPES_USHORT       interCharTimeout;

    uint16                baudRate;


    Ringbuf_t             *pRxRingbufHd;
    Ringbuf_t             *pTxRingbufHd;

    bool                  (*pf_Init)(uint16 ch, UART_InitTypeDef *pHandle);
    uint16                (*pf_Read)(Ringbuf_t *phandle, void *pbuf, uint16 bufsize);


} SERIAL_IO_CHANNEL;

typedef struct
{

  TMWTYPES_UINT           SoureceIp[IP_ADDRESS_NUM];
  TMWTYPES_UINT           GateWay[4];
  TMWTYPES_UINT           SubnetMask[4];
  TMWTYPES_UINT           PortNumber;

  SOCKET_NUM              Socket;

} TCP_CONFIG;

typedef struct
{
  TMWTARGIO_TYPE_ENUM   type;

  TCP_CONFIG            targTCP;


  void                  *pTargIOChannel;


} TARGETH_CONFIG;

/* Define TCP port channel */
typedef struct
{
    TMWTARGIO_TYPE_ENUM     TargChType;

    SOCKET_NUM              Socket;
    TMWTYPES_CHAR           chnlName[IOCNFG_MAX_NAME_LEN];
    TMWTYPES_CHAR           portName[IOCNFG_MAX_NAME_LEN];

    TMWTARGTCP_MODE         Mode;
    SOCKET_STATUS_ENUM      Status;

    TMWTYPES_BYTE           SoreceIp[IP_ADDRESS_NUM];
    TMWTYPES_BYTE           DestinationIp[IP_ADDRESS_NUM];

    TMWTYPES_UINT           PortNumber;

    /* Callback function for this channel */
    TMWTARG_CHANNEL_CALLBACK_FUNC     pChannelCallback;      /* From TMWTARG_CONFIG  */
    void                             *pChannelCallbackParam; /* From TMWTARG_CONFIG  */

    TMWTARG_CHANNEL_READY_CBK_FUNC    pChannelReadyCallback; /* From TMWTARG_CONFIG  */
    void                             *pChannelReadyCbkParam; /* From TMWTARG_CONFIG  */

    TMWTARG_CHANNEL_RECEIVE_CBK_FUNC  pReceiveCallbackFunc;  /* From openChannel    */
    TMWTARG_CHECK_ADDRESS_FUNC        pCheckAddrCallbackFunc;/* From openChannel    */
    void                             *pCallbackParam;        /* From openChannel, used by both above */

} TCP_IO_CHANNEL;


#endif /* COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIODEFS_H_ */
