/*
 * targDatabase.c
 *
 *  Created on: 2023. 10. 27.
 *      Author: ShinSung Industrial Electric
 */
#include <stdio.h>
#include <string.h>

#include "file.h"
#include "src/port/tmwDNP/targDatabase.h"
#include "src/port/tmwDNP/CommConfig.h"

#include "src/app/logging/event.h"

#include "src/app/shell/cli.h"
#include "src/utils/crc.h"

#include "src/port/tmwDNP/sdnpfile.h"

#include "src/port/tmwDNP/sdnpmap.h"

#include "src/app/calculation/calculation.h"

/*samling.c*/
extern void* GetChUpdateFlagAddr(void);
/*DNP BO Mapping For HMIS Connection*/
#define DNP_BO_TAG_SIM_DI_INDEX                                 63

#define SCADA_CONFIG_FILE_STX                                   0xF2
#define SCADA_CONFIG_FILE_ETX                                   0xF3

#define SCADA_AI_INDEX_SIZE                                     7
#define SCADA_AO_INDEX_SIZE                                     0
#define SCADA_BI_INDEX_SIZE                                     5
#define SCADA_BO_INDEX_SIZE                                     3
#define UPDATEFILE_BUF_MAX                                      4096

static TAG_DB* pTagDb;
static uint16* pTagScSettingGroup;

static ScadaMap             SdnpScadaMap = {.IsScadaMapInit = 0};

#pragma DATA_SECTION (SdnpMapFile,      "ZONE6DATA")
#pragma DATA_SECTION (SDNP_FileCtx,     "ZONE6DATA")
#pragma DATA_SECTION (ScadaMapFile,     "ZONE6DATA")
#pragma DATA_SECTION (UpdateFileBuf,    "ZONE6DATA")



static SdnpDatabase SdnpMapFile = {.IsSdnpDbInit = 0};

static SDNP_FileContext     SDNP_FileCtx;

static uint16   UpdateFileBuf[UPDATEFILE_BUF_MAX];

static void DnpAI_Mapping(DnpAiPointDescription *pDnpAiPoint);
static void DnpAO_Mapping(DnpAoPointDescription *pDnpAoPoint);
static void DnpBI_Mapping(DnpBiPointDescription *pDnpBiPoint);
static void DnpBO_Mapping(DnpBoPointDescription *pDnpBoPoint);

bool SdnpTagDbAddress_Get(void* pParam)
{
    if(pParam == NULL)
    {
        return false;
    }

    pTagDb = pParam;

    pTagScSettingGroup = &pTagDb->SC.SC_UI[ALS_SC_STGRP];

    return true;

}
/*
 * Description :
 * Parameter   :
 */
void ScadaMap_Init()
{
    uint16 i, PointIndex;

    SdnpAiMap4Scada* pScadaAiMapFile;
    SdnpBiMap4Scada* pScadaBiMapFile;
    SdnpBoMap4Scada* pScadaBoMapFile;

    /*SCADA AI Index configure*/
    FileDescriptor* pFile = File_Open(FILE_SCADA_CONFIG_AI, MODE_NULL);
    pScadaAiMapFile = (SdnpAiMap4Scada*)pFile->pFileCache;

    if(pScadaAiMapFile->TotalIndex > 0)
    {
        DnpAiPointDescription *pDnpAiPoint = &SdnpMapFile.DnpAiPointList[0];
        SdnpScadaMap.ScadaAiQuantity = pScadaAiMapFile->TotalIndex;

        for(i=0; i<SdnpScadaMap.ScadaAiQuantity; i++)
        {
            PointIndex = pScadaAiMapFile->ScadaAiConfig[i].IndexNumber;

            SdnpScadaMap.ScadaAiPointList[i].DataType   = pDnpAiPoint[PointIndex].DataType;
            SdnpScadaMap.ScadaAiPointList[i].pDataPoint = pDnpAiPoint[PointIndex].pDataPoint;
            SdnpScadaMap.ScadaAiPointList[i].DeadBand   = pScadaAiMapFile->ScadaAiConfig[i].Deadband;
            SdnpScadaMap.ScadaAiPointList[i].DataClass  = pScadaAiMapFile->ScadaAiConfig[i].Class;
            SdnpScadaMap.ScadaAiPointList[i].SOE        = pScadaAiMapFile->ScadaAiConfig[i].SOE;
            SdnpScadaMap.ScadaAiPointList[i].Scale      = pScadaAiMapFile->ScadaAiConfig[i].Scale;
        }
    }

    /*SCADA BI Index configure*/
    pFile = File_Open(FILE_SCADA_CONFIG_BI, MODE_NULL);
    pScadaBiMapFile = (SdnpBiMap4Scada*)pFile->pFileCache;

    if(pScadaBiMapFile->TotalIndex > 0)
    {
        DnpBiPointDescription *pDnpBiPoint = &SdnpMapFile.DnpBiPointList[0];
        SdnpScadaMap.ScadaBiQuantity = pScadaBiMapFile->TotalIndex;

        for(i=0; i<SdnpScadaMap.ScadaBiQuantity; i++)
        {
            PointIndex = pScadaBiMapFile->ScadaBiConfig[i].IndexNumber;

            SdnpScadaMap.ScadaBiPointList[i].pDataPoint = pDnpBiPoint[PointIndex].pDataPoint;
            SdnpScadaMap.ScadaBiPointList[i].Invert     = pScadaBiMapFile->ScadaBiConfig[i].Invert;
            SdnpScadaMap.ScadaBiPointList[i].DataClass  = pScadaBiMapFile->ScadaBiConfig[i].Class;
            SdnpScadaMap.ScadaBiPointList[i].SOE        = pScadaBiMapFile->ScadaBiConfig[i].SOE;
        }
    }
    /*SCADA BO Index configure*/
    pFile = File_Open(FILE_SCADA_CONFIG_BO, MODE_NULL);
    pScadaBoMapFile = (SdnpBoMap4Scada*)pFile->pFileCache;

    if(pScadaBoMapFile->TotalIndex > 0)
    {
        DnpBoPointDescription *pDnpBoPoint = &SdnpMapFile.DnpBoPointList[0];
        SdnpScadaMap.ScadaBoQuantity = pScadaBoMapFile->TotalIndex;

        for(i=0; i<SdnpScadaMap.ScadaBoQuantity; i++)
        {
            PointIndex = pScadaBoMapFile->ScadaBoConfig[i].IndexNumber;

            SdnpScadaMap.ScadaBoPointList[i].pDataPoint = pDnpBoPoint[PointIndex].pDataPoint;
            SdnpScadaMap.ScadaBoPointList[i].Command    = pScadaBoMapFile->ScadaBoConfig[i].Command;
        }
    }

}
void* TargDB_init(void *pHandle)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
            /*SdnpDatabase Already Init*/
            if(SdnpMapFile.IsSdnpDbInit == true)
            {
                pSdnpDbHandle->pDatabase = (void*)&SdnpMapFile;
            }
            else
            {
                memset(&SdnpMapFile, 0, sizeof(SdnpDatabase));

                SdnpMapFile.DnpAiIndexQuantity = AI_POINT_MAX;
                DnpAI_Mapping(&SdnpMapFile.DnpAiPointList[0]);
                SdnpMapFile.DnpAoIndexQuantity = AO_POINT_MAX;
                DnpAO_Mapping(&SdnpMapFile.DnpAoPointList[0]);
                SdnpMapFile.DnpBiIndexQuantity = BI_POINT_MAX;
                DnpBI_Mapping(&SdnpMapFile.DnpBiPointList[0]);
                SdnpMapFile.DnpBoIndexQuantity = BO_POINT_MAX;
                DnpBO_Mapping(&SdnpMapFile.DnpBoPointList[0]);

                SdnpMapFile.IsSdnpDbInit = true;

                pSdnpDbHandle->pDatabase = (void*)&SdnpMapFile;
            }
            break;
        case SCADA_DB:
            if(SdnpScadaMap.IsScadaMapInit == false)
            {
                memset(&SdnpScadaMap, 0, sizeof(ScadaMap));

                ScadaMap_Init();
                SdnpScadaMap.IsScadaMapInit = true;
            }

            pSdnpDbHandle->pScadaMap = (void*)&SdnpScadaMap;
            break;
    }

    return (void*)pSdnpDbHandle;
}

static void DnpAI_Mapping(DnpAiPointDescription *pDnpAiPoint)
{
    uint16 i;
    TagData Instance;

    const DnpAnalogMap* pDnpAiList = &DnpAiMap[0];

    for(i=0; i< AI_POINT_MAX; i++)
    {
        pDnpAiPoint[i].DataType = (TMWTYPES_ANALOG_TYPE)pDnpAiList[i].AnalogType;
        pDnpAiPoint[i].TagGroup = pDnpAiList[i].TagGroup;

        Instance.TagGroup       = pDnpAiList[i].TagGroup;
        Instance.TagIndex       = pDnpAiList[i].TagIndex;
        /*set tag data address*/
        pDnpAiPoint[i].pDataPoint = TagDataAddr_Get(&Instance);

    }
}
static void DnpAO_Mapping(DnpAoPointDescription *pDnpAoPoint)
{
    uint16 i;
    TagData Instance;

    const DnpAnalogMap* pDnpAoList = &DnpAoList[0];

    for(i=0; i< AO_POINT_MAX; i++)
    {
        pDnpAoPoint[i].DataType = (TMWTYPES_ANALOG_TYPE)pDnpAoList[i].AnalogType;
        pDnpAoPoint[i].TagGroup = pDnpAoList[i].TagGroup;
        pDnpAoPoint[i].TagIndex = pDnpAoList[i].TagIndex;

        Instance.TagGroup       = pDnpAoList[i].TagGroup;
        Instance.TagIndex       = pDnpAoList[i].TagIndex;
        /*set tag data address*/
        pDnpAoPoint[i].pDataPoint = TagDataAddr_Get(&Instance);


    }
}
static void DnpBI_Mapping(DnpBiPointDescription *pDnpBiPoint)
{
    uint16 i;
    TagData Instance;

    const DnpBinaryMap* pDnpBiList = &DnpBiList[0];

    for(i=0; i< BI_POINT_MAX; i++)
    {

        pDnpBiPoint[i].TagGroup = pDnpBiList[i].TagGroup;

        Instance.TagGroup       = pDnpBiList[i].TagGroup;
        Instance.TagIndex       = pDnpBiList[i].TagIndex;
        /*set tag data address*/
        pDnpBiPoint[i].pDataPoint = TagDataAddr_Get(&Instance);
    }
}
static void DnpBO_Mapping(DnpBoPointDescription *pDnpBoPoint)
{
    uint16 i;
    TagData Instance;

    const DnpBinaryMap* pDnpBoList = &DnpBoList[0];

    for(i=0; i< BO_POINT_MAX; i++)
    {
        pDnpBoPoint[i].TagGroup = pDnpBoList[i].TagGroup;
        pDnpBoPoint[i].TagIndex = pDnpBoList[i].TagIndex;

        Instance.TagGroup       = pDnpBoList[i].TagGroup;
        Instance.TagIndex       = pDnpBoList[i].TagIndex;
        /*set tag data address*/
        pDnpBoPoint[i].pDataPoint = TagDataAddr_Get(&Instance);
    }
}


/*
 * Description :
 * Parameter   :
 */
uint16 AI_Quantity_Get(void *pHandle)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    uint16 Quantity = 0;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            Quantity =  pSdnpDb->DnpAiIndexQuantity;
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            Quantity = pScadaMap->ScadaAiQuantity;
        }
            break;
    }

    return Quantity;
}
/*
 * Description :
 * Parameter   :
 */
void* AI_Point_Get(void *pHandle, uint16 PointNum)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    void* pPoint = NULL;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            pPoint = (void*)&pSdnpDb->DnpAiPointList[PointNum];
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            pPoint = (void*)&pScadaMap->ScadaAiPointList[PointNum];
        }
            break;
    }

    return pPoint;
}
/*Only SCADA*/
uint16 AI_PointClass_Get(void* pPoint)
{
    DnpAiPointDescription* pPointList = (DnpAiPointDescription*)pPoint;

    return pPointList->DataClass;

}
/*
 * Description :
 * Parameter   :
 */
uint16 AO_Quantity_Get(void *pHandle)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    uint16 Quantity = 0;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            Quantity = pSdnpDb->DnpAoIndexQuantity;
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            Quantity = pScadaMap->ScadaAoQuantity;
        }
            break;
    }

    return Quantity;
}
/*
 * Description :
 * Parameter   :
 */
void* AO_Point_Get(void *pHandle, uint16 PointNum)
{
    SdnpDbHandle *pSdnpDbHandle = (SdnpDbHandle *)pHandle;

    void* pPoint = NULL;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            pPoint = (void*)&pSdnpDb->DnpAoPointList[PointNum];
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            pPoint = (void*)&pScadaMap->ScadaAoPointList[PointNum];
        }
            break;
    }

    return pPoint;
}

/*
 * Description :
 * Parameter   :
 */
uint16 BI_Quantity_Get(void *pHandle)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    uint16 Quantity = 0;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            Quantity = pSdnpDb->DnpBiIndexQuantity;
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            Quantity = pScadaMap->ScadaBiQuantity;
        }
            break;
    }
    return Quantity;
}
/*
 * Description :
 * Parameter   :
 */
void* BI_Point_Get(void *pHandle, uint16 PointNum)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    void *pPoint = NULL;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            pPoint = (void*)&pSdnpDb->DnpBiPointList[PointNum];
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            pPoint = (void*)&pScadaMap->ScadaBiPointList[PointNum];
        }
            break;
    }
    return pPoint;
}
uint16 BI_PointClass_Get(void* pPoint)
{
    DnpBiPointDescription* pPointList = (DnpBiPointDescription*)pPoint;

    return pPointList->DataClass;

}
/*
 * Description :
 * Parameter   :
 */
uint16 BO_Quantity_Get(void *pHandle)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    uint16 Quantity = 0;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            Quantity = pSdnpDb->DnpBoIndexQuantity;
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            Quantity = pScadaMap->ScadaBoQuantity;
        }
            break;
    }
    return Quantity;
}
/*
 * Description :
 * Parameter   :
 */
void* BO_Point_Get(void *pHandle, uint16 PointNum)
{
    SdnpDbHandle *pSdnpDbHandle = pHandle;

    void *pPoint = NULL;

    switch(pSdnpDbHandle->DatabaseType)
    {
        case LOCAL_DB:
        {
            SdnpDatabase *pSdnpDb = pSdnpDbHandle->pDatabase;
            pPoint = (void*)&pSdnpDb->DnpBoPointList[PointNum];
        }
            break;
        case SCADA_DB:
        {
            ScadaMap* pScadaMap = pSdnpDbHandle->pScadaMap;
            pPoint = (void*)&pScadaMap->ScadaBoPointList[PointNum];
        }
            break;
    }
    return pPoint;
}
bool LsSettingMode_Check(void)
{
    return *pTagScSettingGroup;
}
void Status_On(DnpBoPointDescription* pPointDescription)
{
    uint16* pTagData = (uint16*)pPointDescription->pDataPoint;

    *pTagData = true;

    SeqEvt_Push(pPointDescription->TagGroup, pPointDescription->TagIndex, true);
}
void Status_Off(DnpBoPointDescription* pPointDescription)
{
    uint16* pTagData = (uint16*)pPointDescription->pDataPoint;

    *pTagData = false;

    SeqEvt_Push(pPointDescription->TagGroup, pPointDescription->TagIndex, false);
}
void Select_Off(void* pParam)
{
    bool* pSelectFlag = (bool*)pParam;

    *pSelectFlag = false;
}


/*
 * TAG SC (ALS_SC_STGRP)
 */
void LsData_Copy(uint16 LsGroup)
{
    uint16 i;
    TAG_LS* pTagLS = &pTagDb->LS;

    TAG_LS_UI_F* pSource;
    TAG_LS_UI_F* pDestination = &pTagLS->LS_INTERNAL;

    switch(LsGroup)
    {
        /*Copy TAG LS0 -> TAG LS */
        case 0:
            pSource = &pTagLS->LS_GROUP1;
            break;
        /*Copy TAG LS1 -> TAG LS */
        case 1:
            pSource = &pTagLS->LS_GROUP2;
            break;
    }

    /*Check UI*/
    for(i=0; i<TAG_LS_UI_INDEX_MAX; i++)
    {
        if(pDestination->LS_UI[i] != pSource->LS_UI[i])
        {
            pDestination->LS_UI[i] = pSource->LS_UI[i];
            SeqEvt_Push(TAG_GRP_LS_UI, i, pSource->LS_UI[i]);
        }
    }

    /*Check F*/
    for(i=0; i<TAG_LS_F_INDEX_MAX; i++)
    {
        if(pDestination->LS_F[i] != pSource->LS_F[i])
        {
            pDestination->LS_F[i] = pSource->LS_F[i];
            SeqEvt_Push(TAG_GRP_LS_F, i, pSource->LS_F[i]);
        }
    }
}

uint16* TagLsUiAddr_Get(void)
{
    return &pTagDb->LS.LS_INTERNAL.LS_UI[0];
}

float32* TagLsFloatAddr_Get(void)
{
    return &pTagDb->LS.LS_INTERNAL.LS_F[0];
}


FileIndex FileName_Parsing(const char *pString)
{
    bool   FindFlag = false;
    uint16 i;
    uint16 Len = strlen(pString);
    const char* pFileName;

    uint16 ComputedCRC = CRC16_ARC((uint8*)pString, Len);

    for(i=0; i<SDNP_FILE_MAX; i++)
    {
        if(FileInfo[i].FileNameCRC == ComputedCRC)
        {
            FindFlag = true;
            break;
        }
    }

    if(FindFlag == false)
        return INVALID_FILE;


    pFileName = FileInfo[i].pFileName;

    if(strncmp(pString, pFileName, Len) == 0)
    {
        return FileInfo[i].FileIndex;
    }
}


/*
 * SCADA Configuration file data parser
 */

bool SdnpAiMapFile_Parser(FileDescriptor* pFile, uint16* pBuf)
{
    /*Check STX, ETX*/
    uint16 i, Temp, BufIndex = 0;
    uint16 Stx = pBuf[BufIndex++], Etx;
    uint16 TotalIndex = pBuf[BufIndex];

    SdnpAiMap4Scada* pSdnpAiMap4Scada = (SdnpAiMap4Scada*)pFile->pFileCache;

    if(TotalIndex)
    {
        Etx = pBuf[BufIndex +TotalIndex*SCADA_AI_INDEX_SIZE];

        if((Stx != SCADA_CONFIG_FILE_STX)&&(Etx != SCADA_CONFIG_FILE_ETX))
            return false;
    }

    memset(pSdnpAiMap4Scada, 0, sizeof(SdnpAiMap4Scada));

    BufIndex++;

    pSdnpAiMap4Scada->TotalIndex = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index number*/
        Temp = pBuf[BufIndex++];
        Temp |= pBuf[BufIndex++]<<8;;
        pSdnpAiMap4Scada->ScadaAiConfig[i].IndexNumber = Temp;

        /*Deadband*/
        Temp = pBuf[BufIndex++];
        Temp |= pBuf[BufIndex++]<<8;
        pSdnpAiMap4Scada->ScadaAiConfig[i].Deadband = Temp;

        pSdnpAiMap4Scada->ScadaAiConfig[i].Class = pBuf[BufIndex++];
        pSdnpAiMap4Scada->ScadaAiConfig[i].SOE   = pBuf[BufIndex++];
        pSdnpAiMap4Scada->ScadaAiConfig[i].Scale = pBuf[BufIndex++];
    }

    return true;
}
uint16 SdnpAiMapFile_Send(FileDescriptor* pFile, uint16* pSendBuf)
{
    uint16 i,Temp, BufIndex = 0, TotalIndex;
    SdnpAiMap4Scada* pSdnpAiMap4Scada = (SdnpAiMap4Scada*)pFile->pFileCache;

    TotalIndex = pSdnpAiMap4Scada->TotalIndex;

    if(TotalIndex == 0)
        return false;

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_STX;
    pSendBuf[BufIndex++] = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index*/
        Temp = pSdnpAiMap4Scada->ScadaAiConfig[i].IndexNumber;
        pSendBuf[BufIndex++] = Temp&0xFF;
        pSendBuf[BufIndex++] = Temp>>8;

        /*Deadband*/
        Temp = pSdnpAiMap4Scada->ScadaAiConfig[i].Deadband;
        pSendBuf[BufIndex++] = Temp&0xFF;
        pSendBuf[BufIndex++] = Temp>>8;

        /*Class*/
        Temp = pSdnpAiMap4Scada->ScadaAiConfig[i].Class;
        pSendBuf[BufIndex++] = Temp;

        /*SOE*/
        Temp = pSdnpAiMap4Scada->ScadaAiConfig[i].SOE;
        pSendBuf[BufIndex++] = Temp;

        /*Scale*/
        Temp = pSdnpAiMap4Scada->ScadaAiConfig[i].Scale;
        pSendBuf[BufIndex++] = Temp;
    }

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_ETX;

    /*Return buf length*/
    return BufIndex;
}
bool SdnpBiMapFile_Parser(FileDescriptor* pFile, uint16* pBuf)
{
    /*Check STX, ETX*/
    uint16 i, Temp, BufIndex = 0;
    uint16 Stx = pBuf[BufIndex++], Etx;
    uint16 TotalIndex = pBuf[BufIndex];

    SdnpBiMap4Scada* pSdnpBiMap4Scada = (SdnpBiMap4Scada*)pFile->pFileCache;

    if(TotalIndex)
    {
        Etx = pBuf[BufIndex +TotalIndex*SCADA_BI_INDEX_SIZE];

        if((Stx != SCADA_CONFIG_FILE_STX)&&(Etx != SCADA_CONFIG_FILE_ETX))
            return false;
    }

    memset(pSdnpBiMap4Scada, 0, sizeof(SdnpBiMap4Scada));

    BufIndex++;

    pSdnpBiMap4Scada->TotalIndex = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index number*/
        Temp = pBuf[BufIndex++];
        Temp |= pBuf[BufIndex++]<<8;;

        pSdnpBiMap4Scada->ScadaBiConfig[i].IndexNumber = Temp;

        /*Invert*/
        pSdnpBiMap4Scada->ScadaBiConfig[i].Invert   = pBuf[BufIndex++];
        /*Class*/
        pSdnpBiMap4Scada->ScadaBiConfig[i].Class    = pBuf[BufIndex++];
        /*SOE*/
        pSdnpBiMap4Scada->ScadaBiConfig[i].SOE      = pBuf[BufIndex++];
    }

    return true;
}
uint16 SdnpBiMapFile_Send(FileDescriptor* pFile, uint16* pSendBuf)
{
    uint16 i,Temp, BufIndex = 0, TotalIndex;
    SdnpBiMap4Scada* pSdnpBiMap4Scada = (SdnpBiMap4Scada*)pFile->pFileCache;

    TotalIndex = pSdnpBiMap4Scada->TotalIndex;

    if(TotalIndex == 0)
        return false;

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_STX;
    pSendBuf[BufIndex++] = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index*/
        Temp = pSdnpBiMap4Scada->ScadaBiConfig[i].IndexNumber;
        pSendBuf[BufIndex++] = Temp&0xFF;
        pSendBuf[BufIndex++] = Temp>>8;
        /*Invert*/
        pSendBuf[BufIndex++] = pSdnpBiMap4Scada->ScadaBiConfig[i].Invert;
        /*Class*/
        pSendBuf[BufIndex++] = pSdnpBiMap4Scada->ScadaBiConfig[i].Class;
        /*SOE*/
        pSendBuf[BufIndex++] = pSdnpBiMap4Scada->ScadaBiConfig[i].SOE;
    }

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_ETX;

    /*Return buf length*/
    return BufIndex;
}
bool SdnpBoMapFile_Parser(FileDescriptor* pFile, uint16* pBuf)
{
    /*Check STX, ETX*/
    uint16 i, Temp, BufIndex = 0;
    uint16 Stx = pBuf[BufIndex++], Etx;
    uint16 TotalIndex = pBuf[BufIndex];

    SdnpBoMap4Scada* pSdnpBoMap4Scada = (SdnpBoMap4Scada*)pFile->pFileCache;

    if(TotalIndex)
    {
        Etx = pBuf[BufIndex +TotalIndex*SCADA_BO_INDEX_SIZE];

        if((Stx != SCADA_CONFIG_FILE_STX)&&(Etx != SCADA_CONFIG_FILE_ETX))
            return false;
    }

    memset(pSdnpBoMap4Scada, 0, sizeof(SdnpBoMap4Scada));

    BufIndex++;

    pSdnpBoMap4Scada->TotalIndex = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index number*/
        Temp = pBuf[BufIndex++];
        Temp |= pBuf[BufIndex++]<<8;;

        pSdnpBoMap4Scada->ScadaBoConfig[i].IndexNumber = Temp;
        /*Command*/
        pSdnpBoMap4Scada->ScadaBoConfig[i].Command      = pBuf[BufIndex++];
    }

    return true;
}
uint16 SdnpBoMapFile_Send(FileDescriptor* pFile, uint16* pSendBuf)
{
    uint16 i,Temp, BufIndex = 0, TotalIndex;
    SdnpBoMap4Scada* pSdnpBoMap4Scada = (SdnpBoMap4Scada*)pFile->pFileCache;

    TotalIndex = pSdnpBoMap4Scada->TotalIndex;

    if(TotalIndex == 0)
        return false;

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_STX;
    pSendBuf[BufIndex++] = TotalIndex;

    for(i=0; i<TotalIndex; i++)
    {
        /*Index*/
        Temp = pSdnpBoMap4Scada->ScadaBoConfig[i].IndexNumber;
        pSendBuf[BufIndex++] = Temp&0xFF;
        pSendBuf[BufIndex++] = Temp>>8;
        /*Command*/
        pSendBuf[BufIndex++] = pSdnpBoMap4Scada->ScadaBoConfig[i].Command;
    }

    pSendBuf[BufIndex++] = SCADA_CONFIG_FILE_ETX;

    /*Return buf length*/
    return BufIndex;
}


#define OFFSET  0x270000UL
bool CheckFirmwareFileValid(FirmwareParser* pFwParser, uint16* pBuf, uint16 len)
{
    uint16 i;
    bool Rtn = true;
    UpdateFileHandle* pUpdateFileHd = &pFwParser->UpdateFileHd;

    for(i = 0; i< len; i++)
    {
        if(pFwParser->PacketIndex < 128)
        {
            pFwParser->PacketBuf[pFwParser->PacketIndex++] = pBuf[i];
        }

        pFwParser->LineEndFlag = ((pBuf[i] == 0x0A) || (pFwParser->PacketIndex>= 128)) ? true : false;

        if(pFwParser->LineEndFlag == true)
        {
            uint16 j, Temp, index;
            pFwParser->LineEndFlag      = false;
            pFwParser->PacketIndex      = 0;

            if(parseIntelHexRecord((const char*)pFwParser->PacketBuf, &pFwParser->Record) == false)
            {
                Rtn = false;
                CLI_Printf("fail to parse intelhex\r\n CLI#");
                break;
            }
            if(pFwParser->Record.type == 0x04)
            {
                /*Update address*/
                pUpdateFileHd->ExtendedAddress = pFwParser->Record.b32Address<<16;
                pUpdateFileHd->ExtendedAddress -= OFFSET;

                continue;
            }
            else if(pFwParser->Record.type == 0x01)
            {
                break;
            }
            else if(compareChecksum(&pFwParser->Record) == false)
            {
                Rtn = false;
                CLI_Printf("fail to parse checksum\r\n CLI#");
                break;
            }
            /*Complete line parsing write to external flash*/

            if(pFwParser->Record.type == 0x00)
            {
                pUpdateFileHd->Address       = pUpdateFileHd->ExtendedAddress + pFwParser->Record.address;
                pUpdateFileHd->WriteLength   = pFwParser->Record.len/2;
                /*data*/
                for(j=0, index = 0; index< pUpdateFileHd->WriteLength; index++)
                {
                    Temp  = pFwParser->Record.data[j++]<<8;
                    Temp |= pFwParser->Record.data[j++];
                    pUpdateFileHd->WriteBuf[index] = Temp;
                }

                Zone7BusTake(FLASH);

                /*write data to ext flash*/
                for(j=0; j<pUpdateFileHd->WriteLength; j++)
                {
                    if(FLASH_Write(pUpdateFileHd->Address+j, pUpdateFileHd->WriteBuf[j]) == false)
                    {
                        CLI_Printf("ail to write firmware data to ext flash address : 0x%lx\r\n CLI#", pUpdateFileHd->Address+j);
                    }

                    if(pUpdateFileHd->WriteBuf[j] == FLASH_Read(pUpdateFileHd->Address+j))
                    {
                      //  CLI_Printf("0x%lx, 0x%x, ", pUpdateFileHd->Address+j+OFFSET, pUpdateFileHd->WriteBuf[j]);
                    }
                    else
                    {
                        CLI_Printf("ext flash do not match firmware data to ext flash address : 0x%lx\r\n CLI#", pUpdateFileHd->Address+j);
                    }
                }

                Zone7BusRelease();
               // CLI_Printf("\r\n");

            }
        }
    }

    return Rtn;

}

SDNP_FileContext* SDNPFileHandle_Get(void)
{
    uint16 i, len;

    memset(&SDNP_FileCtx, 0, sizeof(SDNP_FileCtx));

    EventHandle* pEventHandle = EventHandle_Get(EVENT_SEQUENTIAL);

    SDNP_FileCtx.pFileName_Parser = FileName_Parsing;
    SDNP_FileCtx.pFile_Open       = File_Open;
    SDNP_FileCtx.pFile_Close      = File_Close;

    SDNP_FileCtx.pDnpFile_Read    = File_Read;
    SDNP_FileCtx.pDnpFile_Write   = File_Write;

    SDNP_FileCtx.pfScadaFile_Parser[DNP_AI] = SdnpAiMapFile_Parser;
    SDNP_FileCtx.pfScadaFile_Send[DNP_AI]   = SdnpAiMapFile_Send;

    SDNP_FileCtx.pfScadaFile_Parser[DNP_AO] = NULL;
    SDNP_FileCtx.pfScadaFile_Send[DNP_AO]   = NULL;

    SDNP_FileCtx.pfScadaFile_Parser[DNP_BI] = SdnpBiMapFile_Parser;
    SDNP_FileCtx.pfScadaFile_Send[DNP_BI]   = SdnpBiMapFile_Send;

    SDNP_FileCtx.pfScadaFile_Parser[DNP_BO] = SdnpBoMapFile_Parser;
    SDNP_FileCtx.pfScadaFile_Send[DNP_BO]   = SdnpBoMapFile_Send;

    SDNP_FileCtx.pEventHandle = pEventHandle;

    SDNP_FileCtx.CurrentUpdateIndex = FILE_SECTOR_H_1;//FILE_UPDATE0;

    SDNP_FileCtx.pChGainUpdateFlag  = GetChUpdateFlagAddr();

    if(Ringbuf_Create(&SDNP_FileCtx.UpdateFileRingBuf, &UpdateFileBuf[0], UPDATEFILE_BUF_MAX) == false)
        DEBUG_Msg("fail to create update ringbuf\n");

    for(i=0; i<SDNP_FILE_MAX; i++)
    {
        len =  strlen(FileInfo[i].pFileName);
        FileInfo[i].FileNameCRC = CRC16_ARC((uint8*)FileInfo[i].pFileName, len);
    }

    SDNP_FileCtx.pUpdateInfoFile = GetUpdateInfoFileAddr();

    SDNP_FileCtx.pfSampling_Stop = Sampling_Stop;

    return &SDNP_FileCtx;
}


