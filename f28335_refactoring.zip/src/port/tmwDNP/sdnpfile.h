/*
 * sdnpfile.h
 *
 *  Created on: 2024. 5. 7.
 *      Author: ShinSung Industrial Electric
 */

#ifndef TMWDNP_SDNPFILE_H_
#define TMWDNP_SDNPFILE_H_

#include "file.h"

#define SDNP_FILE_MAX    79

typedef struct
{
    const char*         pFileName;
    const FileIndex     FileIndex;
    uint16              FileNameCRC;

} SdnpFileInfo;

SdnpFileInfo FileInfo[SDNP_FILE_MAX] = {
{.FileIndex = FILE_SYSTEM_INFO,         .pFileName = "systeminfo.bin"},
{.FileIndex = FILE_CHANNEL_CONFIG,      .pFileName = "channelconfigs.bin"},
{.FileIndex = FILE_PTCT_CORR,           .pFileName = "ptctcorrinfo.bin"},
{.FileIndex = FILE_GPAI_CORR,           .pFileName = "gpaicorrinfo.bin"},
{.FileIndex = FILE_SCADA_CONFIG_AI,     .pFileName = "sdnpaimap4scada.bin"},
{.FileIndex = FILE_SCADA_CONFIG_AO,     .pFileName = "sdnpaomap4scada.bin"},
{.FileIndex = FILE_SCADA_CONFIG_BI,     .pFileName = "sdnpbimap4scada.bin"},
{.FileIndex = FILE_SCADA_CONFIG_BO,     .pFileName = "sdnpbomap4scada.bin"},
{.FileIndex = FILE_MMI_PASSWORD,        .pFileName = "mmipassword.bin.bin"},
{.FileIndex = FILE_SECTOR_H_1,/*FILE_UPDATE0,*/             .pFileName = "update.bin"},
{.FileIndex = FILE_SEQ_EVENT0,          .pFileName = "seqevents0.bin"},
{.FileIndex = FILE_SEQ_EVENT1,          .pFileName = "seqevents1.bin"},
{.FileIndex = FILE_SEQ_EVENT2,          .pFileName = "seqevents2.bin"},
{.FileIndex = FILE_SEQ_EVENT3,          .pFileName = "seqevents3.bin"},
{.FileIndex = FILE_SEQ_EVENT4,          .pFileName = "seqevents4.bin"},
{.FileIndex = FILE_SEQ_EVENT5,          .pFileName = "seqevents5.bin"},
{.FileIndex = FILE_SEQ_EVENT6,          .pFileName = "seqevents6.bin"},
{.FileIndex = FILE_SEQ_EVENT7,          .pFileName = "seqevents7.bin"},
{.FileIndex = FILE_SEQ_EVENT8,          .pFileName = "seqevents8.bin"},
{.FileIndex = FILE_SEQ_EVENT9,          .pFileName = "seqevents9.bin"},
{.FileIndex = FILE_SEQ_EVENT0,          .pFileName = "seqevents_latest0.bin"},
{.FileIndex = FILE_SEQ_EVENT1,          .pFileName = "seqevents_latest1.bin"},
{.FileIndex = FILE_SEQ_EVENT2,          .pFileName = "seqevents_latest2.bin"},
{.FileIndex = FILE_SEQ_EVENT3,          .pFileName = "seqevents_latest3.bin"},
{.FileIndex = FILE_SEQ_EVENT4,          .pFileName = "seqevents_latest4.bin"},
{.FileIndex = FILE_SEQ_EVENT5,          .pFileName = "seqevents_latest5.bin"},
{.FileIndex = FILE_SEQ_EVENT6,          .pFileName = "seqevents_latest6.bin"},
{.FileIndex = FILE_SEQ_EVENT7,          .pFileName = "seqevents_latest7.bin"},
{.FileIndex = FILE_SEQ_EVENT8,          .pFileName = "seqevents_latest8.bin"},
{.FileIndex = FILE_SEQ_EVENT9,          .pFileName = "seqevents_latest9.bin"},
{.FileIndex = FILE_FLT_EVENT0,          .pFileName = "fltevents0.bin"},
{.FileIndex = FILE_FLT_EVENT1,          .pFileName = "fltevents1.bin"},
{.FileIndex = FILE_FLT_EVENT2,          .pFileName = "fltevents2.bin"},
{.FileIndex = FILE_FLT_EVENT3,          .pFileName = "fltevents3.bin"},
{.FileIndex = FILE_FLT_EVENT4,          .pFileName = "fltevents4.bin"},
{.FileIndex = FILE_FLT_EVENT5,          .pFileName = "fltevents5.bin"},
{.FileIndex = FILE_FLT_EVENT6,          .pFileName = "fltevents6.bin"},
{.FileIndex = FILE_FLT_EVENT7,          .pFileName = "fltevents7.bin"},
{.FileIndex = FILE_FLT_EVENT8,          .pFileName = "fltevents8.bin"},
{.FileIndex = FILE_FLT_EVENT9,          .pFileName = "fltevents9.bin"},
{.FileIndex = FILE_FLT_EVENT0,          .pFileName = "fltevents_latest0.bin"},
{.FileIndex = FILE_FLT_EVENT1,          .pFileName = "fltevents_latest1.bin"},
{.FileIndex = FILE_FLT_EVENT2,          .pFileName = "fltevents_latest2.bin"},
{.FileIndex = FILE_FLT_EVENT3,          .pFileName = "fltevents_latest3.bin"},
{.FileIndex = FILE_FLT_EVENT4,          .pFileName = "fltevents_latest4.bin"},
{.FileIndex = FILE_FLT_EVENT5,          .pFileName = "fltevents_latest5.bin"},
{.FileIndex = FILE_FLT_EVENT6,          .pFileName = "fltevents_latest6.bin"},
{.FileIndex = FILE_FLT_EVENT7,          .pFileName = "fltevents_latest7.bin"},
{.FileIndex = FILE_FLT_EVENT8,          .pFileName = "fltevents_latest8.bin"},
{.FileIndex = FILE_FLT_EVENT9,          .pFileName = "fltevents_latest9.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT0,      .pFileName = "fltwaveevents0.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT1,      .pFileName = "fltwaveevents1.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT2,      .pFileName = "fltwaveevents2.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT3,      .pFileName = "fltwaveevents3.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT4,      .pFileName = "fltwaveevents4.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT5,      .pFileName = "fltwaveevents5.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT6,      .pFileName = "fltwaveevents6.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT7,      .pFileName = "fltwaveevents7.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT8,      .pFileName = "fltwaveevents8.bin"},
{.FileIndex = FILE_FLTWAVE_EVENT9,      .pFileName = "fltwaveevents9.bin"},
{.FileIndex = FILE_LOAD_PROFILE0,       .pFileName = "loadprofile0.bin"},
{.FileIndex = FILE_LOAD_PROFILE1,       .pFileName = "loadprofile1.bin"},
{.FileIndex = FILE_LOAD_PROFILE2,       .pFileName = "loadprofile2.bin"},
{.FileIndex = FILE_LOAD_PROFILE3,       .pFileName = "loadprofile3.bin"},
{.FileIndex = FILE_LOAD_PROFILE4,       .pFileName = "loadprofile4.bin"},
{.FileIndex = FILE_LOAD_PROFILE5,       .pFileName = "loadprofile5.bin"},
{.FileIndex = FILE_LOAD_PROFILE6,       .pFileName = "loadprofile6.bin"},
{.FileIndex = FILE_LOAD_PROFILE7,       .pFileName = "loadprofile7.bin"},
{.FileIndex = FILE_LOAD_PROFILE8,       .pFileName = "loadprofile8.bin"},
{.FileIndex = FILE_LOAD_PROFILE9,       .pFileName = "loadprofile9.bin"},
{.FileIndex = FILE_ENERGY_LOG0,         .pFileName = "energylog0.bin"},
{.FileIndex = FILE_ENERGY_LOG1,         .pFileName = "energylog1.bin"},
{.FileIndex = FILE_ENERGY_LOG2,         .pFileName = "energylog2.bin"},
{.FileIndex = FILE_ENERGY_LOG3,         .pFileName = "energylog3.bin"},
{.FileIndex = FILE_ENERGY_LOG4,         .pFileName = "energylog4.bin"},
{.FileIndex = FILE_ENERGY_LOG5,         .pFileName = "energylog5.bin"},
{.FileIndex = FILE_ENERGY_LOG6,         .pFileName = "energylog6.bin"},
{.FileIndex = FILE_ENERGY_LOG7,         .pFileName = "energylog7.bin"},
{.FileIndex = FILE_ENERGY_LOG8,         .pFileName = "energylog8.bin"},
{.FileIndex = FILE_ENERGY_LOG9,         .pFileName = "energylog9.bin"},
};

#endif /* TMWDNP_SDNPFILE_H_ */
