/*
 * parser.c
 *
 *  Created on: 2024. 5. 2.
 *      Author: ShinSung Industrial Electric
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "parser.h"

bool parseIntelHexRecord(const char *str, intel_hex_record_t *record)
{
    if ((str == NULL) || (record == NULL))
    {
        DEBUG_Msg("[parser] NULL Point\n");
        return false;
    }

    /// get len
    if (sscanf ((str + 1), "%2hx", &(record->len)) != 1)
    {
        DEBUG_Msg("[parser] invalid len field\n");
        return false;
    }

    /// get addr
    if (sscanf ((str + 3), "%4hx", &(record->address)) != 1)
    {
        DEBUG_Msg("[parser] invalid addr field\n");
        return false;
    }

    /// get type
    if (sscanf ((str + 7), "%2hx", &(record->type)) != 1)
    {
        DEBUG_Msg("[parser] invalid type field\n");
        return false;
    }

    /// get data
    Uint16 i;
    for (i = 0; i < record->len; i++)
    {
        Uint16 data[2];
        if (record->type == 0x04)
        {
            if (sscanf ((str + 9 + (i * 2)), "%2hx", &data[i]) != 1)
            {
                DEBUG_Msg("[parser] invalid b32address field\n");
                return false;
            }

            record->b32Address = ((data[0] & 0x00FF) << 8 | (data[1] & 0x00FF));
        }
        else if ((record->type == 0x00) || (record->type == 0x01))
        {
            if (sscanf ((str + 9 + (i * 2)), "%2hx", &(record->data[i])) != 1)
            {
                DEBUG_Msg("[parser] invalid data field\n");
                return false;
            }
        }
    }

    /// get checksum
    if (sscanf ((str + 9 + (record->len * 2)), "%2hx", &(record->checksum)) != 1)
    {
        DEBUG_Msg("[parser] invalid checksum field\n");
        return false;
    }

    return true;
}

bool compareChecksum(intel_hex_record_t *record)
{
    Uint16 i, myChecksum = 0;

    myChecksum += record->len & 0x00FF;
    myChecksum += ((record->address >> 8) & 0x00FF);
    myChecksum += record->address & 0x00FF;
    myChecksum += record->type & 0x00FF;

    for (i = 0; i < record->len; i++)
    {
        myChecksum += record->data[i] & 0x00FF;
    }

    return ((~(myChecksum & 0x00FF) + 1) & 0x00FF) == record->checksum;
}
