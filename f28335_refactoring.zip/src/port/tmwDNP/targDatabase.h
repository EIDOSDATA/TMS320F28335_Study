/*
 * targDatabase.h
 *
 *  Created on: 2023. 10. 28.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGDATABASE_H_
#define COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGDATABASE_H_


#include "file.h"
#include "src/port/tmwDNP/parser.h"
#include "src/app/tag/tag_db.h"
#include "src/app/logging/event.h"

/*TMW Stack*/
#include "tmwscl/utils/tmwtypes.h"

#define DUMMY                   0

/*DNP File Transfer*/
#define FILE_NAME_MAX           32
#define FILE_PASSWORD_MAX       32

#define AI_POINT_MAX            215
#define AO_POINT_MAX            415
#define BI_POINT_MAX            352
#define BO_POINT_MAX            79

/*Enumeration*/
typedef enum
{
    UART_CH,              //  UART Channel(SCI_C)
    ETHERNET_CH,          //  Ethernet Channel
    CH_MAX          = 2

} SdnpChnlTypeEum;

typedef enum
{
    LOCAL_DB,
    SCADA_DB,

    SDNP_DB_TYPE_MAX,
} SDNP_DATABASE_TYPE;

typedef enum
{
    LOCAL_UART_CH,
    LOCAL_ETHERNET_CH,

    SCADA_UART_CH,
    SCADA_ETHERNET_CH,

    SDNP_CH_MAX,

} SDNP_COMM_CH;
typedef enum
{
    UART_LOCAL,         UART_SCADA1,

    ETHERNET_LOCAL,     ETHERNET_SCADA1,

    SESN_MAX = 5

} SdnpSesnTypeEum;

typedef enum
{
    DNP_AI,   DNP_AO,
    DNP_BI,   DNP_BO,

    DNP_GROUP_MAX,

} DNP_GROUP;

typedef struct
{
    TMWTYPES_ANALOG_TYPE         DataType;

    TAG_GROUP                    TagGroup;

    void*                        pDataPoint;
    float32                      PreviousValue;
    uint16                       DeadBand;
    uint16                       DataClass;
    bool                         SOE;
    uint16                       Scale;

} DnpAiPointDescription;

typedef struct
{
    TMWTYPES_ANALOG_TYPE         DataType;

    TAG_GROUP                    TagGroup;
    /*Use only when TAG LS0,2(Group1, Group2) changes*/
    uint16                       TagIndex;

    void                        *pDataPoint;

} DnpAoPointDescription;

typedef struct
{
    void*                        pDataPoint;
    TAG_GROUP                    TagGroup;
    bool                         PreviousValue;
    bool                         Invert;
    uint16                       DataClass;
    bool                         SOE;

} DnpBiPointDescription;


typedef struct
{
    void*                       pDataPoint;
    TAG_GROUP                   TagGroup;
    uint16                      TagIndex;

    bool                        Command;
    bool                        SelectFlag;
} DnpBoPointDescription;


typedef struct
{
    bool                    IsScadaMapInit;

    uint16                  ScadaAiQuantity;
    uint16                  ScadaAoQuantity;
    uint16                  ScadaBiQuantity;
    uint16                  ScadaBoQuantity;

    DnpAiPointDescription   ScadaAiPointList[SCADA_CONFIG_MAX];
    DnpAoPointDescription   ScadaAoPointList[SCADA_CONFIG_MAX];
    DnpBiPointDescription   ScadaBiPointList[SCADA_CONFIG_MAX];
    DnpBoPointDescription   ScadaBoPointList[SCADA_CONFIG_MAX];

} ScadaMap;

typedef struct
{
    bool                    IsSdnpDbInit;

    uint16                  DnpAiIndexQuantity;
    uint16                  DnpAoIndexQuantity;
    uint16                  DnpBiIndexQuantity;
    uint16                  DnpBoIndexQuantity;

    DnpAiPointDescription   DnpAiPointList[AI_POINT_MAX];
    DnpAoPointDescription   DnpAoPointList[AO_POINT_MAX];
    DnpBiPointDescription   DnpBiPointList[BI_POINT_MAX];
    DnpBoPointDescription   DnpBoPointList[BO_POINT_MAX];

} SdnpDatabase;

typedef struct
{
    uint16      AnalogType;

    TAG_GROUP   TagGroup;
    uint16      TagIndex;

} DnpAnalogMap;
typedef struct
{
    TAG_GROUP   TagGroup;
    uint16      TagIndex;

} DnpBinaryMap;

typedef struct
{
    SDNP_DATABASE_TYPE      DatabaseType;

  //  SdnpSesnTypeEum         Type;

    SdnpDatabase*           pDatabase;

    /*For SCADA Session*/
    ScadaMap*               pScadaMap;

} SdnpDbHandle;


typedef enum
{
    FW_PARSER_READY,
    FW_PARSING,
    FW_CHECKSUM,
    FW_INVALID,

} FW_PARSER_STATUS;

typedef struct
{
    uint32              ExtendedAddress;

    uint32              Address;


    uint16              WriteLength;
    uint16              WriteBuf[32];

} UpdateFileHandle;

typedef struct
{
    bool                LineEndFlag;

    uint16              PacketBuf[128];
    uint16              PacketIndex;

    intel_hex_record_t  Record;

    UpdateFileHandle    UpdateFileHd;

} FirmwareParser;


typedef struct
{
    FileDescriptor        *pFile;

    /*File Interface*/
    FileIndex (*pFileName_Parser)(const char *pString);

    FileDescriptor* (*pFile_Open)(FileIndex Index, FileMode Mode);

    bool (*pFile_Close)(FileDescriptor *pFile);

    bool (*pDnpFile_Read)(FileDescriptor *pFile, void *pBuf, uint16 ReadWords);
    bool (*pDnpFile_Write)(FileDescriptor *pFile, uint16 *pBuf, uint16 WriteWords);

    /*SCADA Configuaation parser*/
    bool   (*pfScadaFile_Parser[DNP_GROUP_MAX])(FileDescriptor* pFile, uint16* pBuf);
    uint16 (*pfScadaFile_Send[DNP_GROUP_MAX])(FileDescriptor* pFile, uint16* pSendBuf);

    EventHandle*        pEventHandle;

    uint32              FileAuthenticationKey;
    char                FileUserName[FILE_NAME_MAX];
    char                FilePassword[FILE_PASSWORD_MAX];


    bool*               pChGainUpdateFlag;

    /*Firmware update*/
    bool                UpdateFlag;
    bool                DownLoadFlag;

    FileIndex           CurrentUpdateIndex;

    uint32              TotalReceiveWordSize;

    uint16              SendWord;
    uint32              TotalSendWordSize;

    Ringbuf_t           UpdateFileRingBuf;
    uint16              FlashReadBuf[2048];         // external flash sector size 2048 word
    void*               pUpdateInfoFile;

    FirmwareParser      UpdateFileParser;

    uint16*             pTaskPeriod;

    void                (*pfSampling_Stop)(void);

} SDNP_FileContext;




void*   TargDB_init(void *pHandle);
/*AI*/
uint16  AI_Quantity_Get(void *pHandle);
void*   AI_Point_Get(void *pHandle, uint16 PointNum);
uint16  AI_PointClass_Get(void* pPoint);
/*AO*/
uint16  AO_Quantity_Get(void *pHandle);
void*   AO_Point_Get(void *pHandle, uint16 PointNum);
/*BI*/
uint16  BI_Quantity_Get(void *pHandle);
void*   BI_Point_Get(void *pHandle, uint16 PointNum);
uint16  BI_PointClass_Get(void* pPoint);

/*BO*/
uint16  BO_Quantity_Get(void *pHandle);
void*   BO_Point_Get(void *pHandle, uint16 PointNum);


void Status_On(DnpBoPointDescription* pPointDescription);
void Status_Off(DnpBoPointDescription* pPointDescription);
void Select_Off(void* pParam);
/**/
bool LsSettingMode_Check(void);


uint16* TagLsUiAddr_Get(void);
float32* TagLsFloatAddr_Get(void);


void LsData_Copy(uint16 LsGroup);
bool SdnpTagDbAddress_Get(void* pParam);
SDNP_FileContext* SDNPFileHandle_Get(void);


bool CheckFirmwareFileValid(FirmwareParser* pFwParser, uint16* pBuf, uint16 len);


bool EraseUpdateFile(void);
#endif /* COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGDATABASE_H_ */
