/*
 * targ232.c
 *
 *  Created on: 2023. 10. 24.
 *      Author: ShinSung Industrial Electric
 */


#include "def.h"

#include "tmwscl/utils/tmwtypes.h"
#include "tmwscl/utils/tmwtarg.h"

#include "src/port/tmwDNP/targiodefs.h"
#include "src/utils/ringbuf.h"

#define DEBUG_PORT      1       //  SCI C

#define TXBUF_SIZE  4096
#define RXBUF_SIZE  4096
#pragma DATA_SECTION(UartObejct,   "ZONE6DATA")
#pragma DATA_SECTION(TxRingBufHd,   "ZONE6DATA")
#pragma DATA_SECTION(TxBuffer,      "ZONE6DATA")
#pragma DATA_SECTION(RxRingBufHd,   "ZONE6DATA")
#pragma DATA_SECTION(RxBuffer,      "ZONE6DATA")

#define UART_PORT_MAX   2           //  SCI-B, SCI-C
static SERIAL_IO_CHANNEL SerialChannel[2];

static Ringbuf_t         TxRingBufHd[2];
static uint16            TxBuffer[2][TXBUF_SIZE];
static Ringbuf_t         RxRingBufHd[2];
static uint16            RxBuffer[2][RXBUF_SIZE];

typedef struct
{
    uint16              PortRemaining;

    SERIAL_IO_CHANNEL   UART_PORT[UART_PORT_MAX];

} SerialModule;

static SerialModule UartObejct = {.PortRemaining = UART_PORT_MAX};

/* function: Targ232_initChannel */
void * TMWDEFS_GLOBAL Targ232_initChannel(
  const void *pUserConfig,
  TMWTARG_CONFIG *pTmwConfig)
{
    if((pUserConfig == NULL)||(pTmwConfig == NULL))
        return NULL;

    SERIAL_IO_CHANNEL* pUartHandle = NULL;

    if(UartObejct.PortRemaining)
    {
        uint16 Index = UART_PORT_MAX- UartObejct.PortRemaining;
        RS232_CONFIG* pIOConfig = (RS232_CONFIG*)pUserConfig;
        pUartHandle = &UartObejct.UART_PORT[Index];

        memset(pUartHandle, 0, sizeof(SERIAL_IO_CHANNEL));

        pUartHandle->pChannelCallback           = pTmwConfig->pChannelCallback;
        pUartHandle->pChannelReadyCallback      = pTmwConfig->pChannelReadyCallback;
        pUartHandle->pChannelReadyCbkParam      = pTmwConfig->pChannelReadyCbkParam;
        pUartHandle->numCharTimesBetweenFrames  = pTmwConfig->numCharTimesBetweenFrames;
        pUartHandle->interCharTimeout           = pTmwConfig->interCharTimeout;

        strcpy(pUartHandle->chnlName, pIOConfig->chnlName);
        strcpy(pUartHandle->portName, pIOConfig->portName);

        pUartHandle->PortType                    = pIOConfig->PortType;
        pUartHandle->portMode                    = pIOConfig->portMode;
        pUartHandle->baudRate                    = pIOConfig->baudRate;
        pUartHandle->parity                      = pIOConfig->parity;
        pUartHandle->numDataBits                 = pIOConfig->numDataBits;
        pUartHandle->numStopBits                 = pIOConfig->numStopBits;
        pUartHandle->bModbusRTU                  = pIOConfig->bModbusRTU;

        if(Ringbuf_Create(&RxRingBufHd[Index], &RxBuffer[Index], RXBUF_SIZE))
            pUartHandle->pRxRingbufHd = &RxRingBufHd[Index];

        else
            DEBUG_Msg("[DNP] fail to create UART Rx ringbuf\n");

        if(Ringbuf_Create(&TxRingBufHd[Index], &TxBuffer[Index], TXBUF_SIZE))
            pUartHandle->pTxRingbufHd = &TxRingBufHd[Index];

        else
            DEBUG_Msg("[DNP] fail to create UART Tx ringbuf\n");

        UartObejct.PortRemaining--;
    }

    return pUartHandle;

}


/* function: Targ232_getChannelName */
const char * TMWDEFS_GLOBAL Targ232_getChannelName(
  SERIAL_IO_CHANNEL *pSerialChannel)
{
  return(pSerialChannel->chnlName);
}

/* function: Targ232_openChannel */
TMWTYPES_BOOL TMWDEFS_GLOBAL Targ232_openChannel(
  SERIAL_IO_CHANNEL* pSerialChannel)
{
    UART_InitTypeDef UART_Instance;

    memset(&UART_Instance, 0, sizeof(UART_InitTypeDef));

    UART_Instance.Baudrate      = pSerialChannel->baudRate;
    UART_Instance.DataBits      = pSerialChannel->numDataBits;
    UART_Instance.Parity        = pSerialChannel->parity;
    UART_Instance.StopBit       = pSerialChannel->numStopBits;
    UART_Instance.FlowControl   = pSerialChannel->portMode;

    UART_Init(pSerialChannel->PortType ,&UART_Instance);

    DEBUG_Msg("[DNP] serial port open\n");

    return(TMWDEFS_TRUE);
}

/* function: TargTCP_receive, this also receives UDP data */
TMWTYPES_USHORT TMWDEFS_GLOBAL Targ232_receive(
  SERIAL_IO_CHANNEL* pSerialChannel,
  TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT maxBytes,
  TMWTYPES_MILLISECONDS maxTimeout,
  TMWTYPES_BOOL *pInterCharTimeoutOccurred)
{
    return Ringbuf_Read(pSerialChannel->pRxRingbufHd, pBuff, maxBytes);
}

/* function: TargTCP_transmit */
TMWTYPES_BOOL TMWDEFS_GLOBAL Targ232_transmit(
  SERIAL_IO_CHANNEL*    pSerialChannel,
  const TMWTYPES_UCHAR* pBuff,
  TMWTYPES_USHORT       numBytes)
{
    TMWTYPES_USHORT WriteBytes = Ringbuf_Write(pSerialChannel->pTxRingbufHd, pBuff, numBytes);

    if(WriteBytes == numBytes)
        return TMWDEFS_TRUE;

    return TMWDEFS_FALSE;
}



