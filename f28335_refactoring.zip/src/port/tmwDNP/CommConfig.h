/*
 * Comm.h
 *
 *  Created on: 2023. 10. 24.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_IMPLEMENTAION_COMM_H_
#define COMPONENTS_COMM_IMPLEMENTAION_COMM_H_

#include "def.h"

/*DNP Stack Header*/
#include "tmwscl/dnp/dnpchnl.h"
#include "tmwscl/dnp/dnptprt.h"
#include "tmwscl/dnp/dnplink.h"
#include "tmwscl/dnp/sdnpsesn.h"

#include "tmwscl/utils/tmwappl.h"
#include "tmwscl/utils/tmwchnl.h"
#include "tmwscl/utils/tmwphys.h"
#include "tmwscl/utils/tmwtarg.h"
#include "tmwscl/utils/tmwsesn.h"
#include "tmwscl/utils/tmwpltmr.h"


/*Target Specific Header*/
#include "src/port/tmwDNP/targiodefs.h"
#include "src/port/tmwDNP/targDatabase.h"

#define ChannelName_Len         12

/*Structure*/
typedef struct
{
    uint16          UartPort;

    uint16          *pBuff;
    uint16          Send_Bytes;

} Message_t;
typedef struct
{
    Mailbox_Handle  MSG_Handle;

    Message_t       Message;

} MSG_Block;

typedef struct
{
  /*Channel type*/
  TMWTARGIO_TYPE_ENUM   type;

  /*TMW stack handle*/
  TMWCHNL*              pTmwCh;
  void*                 pTmwSesn;

  /* My communication channel handle
   * UART     channel
   * Ethernet channel
   */
  void                  *pMyCommCh;


  /*Only use UART channel*/
  MSG_Block             *pMessage;

} TARGIO_Channel;


typedef struct
{
    uint16  Source;
    uint16  Destination;

    float32 LinkStatusPeriod;
} SdnpSessConfigs;

typedef struct
{
    TMWCHNL *pChannel;
    void    *pSession;

} SDNPContext_t;



bool Ethernet_Init(void);


#endif /* COMPONENTS_COMM_IMPLEMENTAION_COMM_H_ */
