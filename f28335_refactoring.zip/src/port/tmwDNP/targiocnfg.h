/*
 * targiocnfg.h
 *
 *  Created on: 2023. 10. 24.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIOCNFG_H_
#define COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIOCNFG_H_

#define IOCNFG_MAX_NAME_LEN            16

/* Currently only support one serial port */
#define IOCNFG_NUM_SERIAL_PORTS        1

#define IOCNFG_SERIAL_INBUF_SIZE       512
#define IOCNFG_SERIAL_OUTBUF_SIZE      512
#define IOCNFG_UDP_BUFFER_SIZE         8000
#define IOCNFG_MAX_UDP_FRAME           2500

/* set this to TMWDEFS_FALSE to remove TCP support */
#define IOTARG_SUPPORT_TCP TMWDEFS_TRUE

/* set this to TMWDEFS_FALSE to remove serial support */
#define IOTARG_SUPPORT_232 TMWDEFS_TRUE

#endif /* COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGIOCNFG_H_ */
