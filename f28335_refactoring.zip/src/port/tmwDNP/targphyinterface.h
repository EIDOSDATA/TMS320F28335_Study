/*
 * targphyinterface.h
 *
 *  Created on: 2023. 11. 2.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGPHYINTERFACE_H_
#define COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGPHYINTERFACE_H_

/*Target Specific Header*/
#include "src/port/tmwDNP/targiodefs.h"


/*Serial Channel*/
void * TMWDEFS_GLOBAL Targ232_initChannel(
  const void *pUserConfig,
  TMWTARG_CONFIG *pTmwConfig);
const char * TMWDEFS_GLOBAL Targ232_getChannelName(
  SERIAL_IO_CHANNEL *pSerialChannel);
TMWTYPES_BOOL TMWDEFS_GLOBAL Targ232_openChannel(
  SERIAL_IO_CHANNEL *pSerialChannel);

TMWTYPES_USHORT TMWDEFS_GLOBAL Targ232_receive(
  SERIAL_IO_CHANNEL* pTcpChannel,
  TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT maxBytes,
  TMWTYPES_MILLISECONDS maxTimeout,
  TMWTYPES_BOOL *pInterCharTimeoutOccurred);

TMWTYPES_BOOL TMWDEFS_GLOBAL Targ232_transmit(
  SERIAL_IO_CHANNEL*    pSerialChannel,
  const TMWTYPES_UCHAR* pBuff,
  TMWTYPES_USHORT       numBytes);



/*Ethernet Channel*/
void* TMWDEFS_GLOBAL TargTCP_initChannel(
 const void *pUserConfig,
 TMWTARG_CONFIG *pTmwConfig);

TMWTYPES_BOOL TMWDEFS_GLOBAL TargTCP_openChannel(TCP_IO_CHANNEL *pTcpChannel);

TMWTYPES_USHORT TMWDEFS_GLOBAL TargTCP_receive(
  TCP_IO_CHANNEL *pTcpChannel,
  TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT maxBytes,
  TMWTYPES_MILLISECONDS maxTimeout,
  TMWTYPES_BOOL *pInterCharTimeoutOccurred);

TMWTYPES_BOOL TMWDEFS_GLOBAL TargTCP_transmit(
  TCP_IO_CHANNEL *pTcpChannel,
  TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT numBytes);

void TMWDEFS_GLOBAL TargTCP_accept(TCP_IO_CHANNEL *pTcpChannel);
#endif /* COMPONENTS_COMM_DNP_TMWSCL_TMWTARG_TARGPHYINTERFACE_H_ */
