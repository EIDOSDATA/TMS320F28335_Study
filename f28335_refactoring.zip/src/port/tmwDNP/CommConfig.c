/*
 * CommConfig.c
 *
 *  Created on: 2023. 11. 1.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>
#include "3rdParty/w5100/w5100.h"
#include "src/port/tmwDNP/CommConfig.h"


#define MAC_ADDRESS_SIZE               6

#define DEVIDE_2KB_PER_SOCKET          0x55
#define DEVIDE_4KB_PER_SOCKET          0x0A

/*
 * TI MAC address used temporarily
 * MAC Address : TexasIns_00:00:80 (a8:63:f2:00:00:80)
 */
uint8 MacAddress[6] = {0xA8, 0x63, 0xF2, 0x00, 0x00, 0x80};

bool Ethernet_Init(void)
{
    uint8 Check[6];
    memset(&Check[0], 0, sizeof(uint8) * MAC_ADDRESS_SIZE);
    /* W5100S Device Reset */
    iinchip_init();
    /* RX/TX buffer 4KB per Sockets  socket 0,1 4 KB, socket 2,3 O KB*/
    sysinit(DEVIDE_4KB_PER_SOCKET, DEVIDE_4KB_PER_SOCKET);
    /* Disable Interrupt */
    setIMR(0);

    /* Mac address write*/
    setSHAR(MacAddress);
    /* Mac address read*/
    getSHAR(Check);

    if(memcmp(MacAddress, &Check[0], MAC_ADDRESS_SIZE) == 0)
    {
        DEBUG_Msg("W5100S Success\n");
        DEBUG_Printf("Mac Address : %x, %x, %x, %x, %x, %x\n", Check[0], Check[1], Check[2], Check[3], Check[4], Check[5]);
        return TRUE;
    }
    DEBUG_Msg("W5100S Fail\n");
    return FALSE;

}
