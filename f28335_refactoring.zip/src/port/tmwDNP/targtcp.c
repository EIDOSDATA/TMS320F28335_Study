/*
 * targtcp.c
 *
 *  Created on: 2023. 10. 24.
 *      Author: ShinSung Industrial Electric
 */

#include "types.h"

#include "tmwscl/utils/tmwtypes.h"
#include "tmwscl/utils/tmwtarg.h"

/*Target Specific Header*/
#include "src/port/tmwDNP/targiodefs.h"
#include "3rdParty/w5100/wsocket.h"


#define Protocol_TCP         1
#define Protocol_UDP         2

#pragma DATA_SECTION(EthObject, "ZONE6DATA")

typedef struct
{
    uint16          SocketRemaing;

    TCP_IO_CHANNEL  ETH_Device[SOCKET_MAX];

} DeviceModule;

static DeviceModule EthObject = {.SocketRemaing = SOCKET_MAX};

TCP_IO_CHANNEL ETH_Device[SOCKET_MAX];

/* function: TargTCP_initChannel */
void* TMWDEFS_GLOBAL TargTCP_initChannel(TCP_CONFIG *pMyTcpConfig, TMWTARG_CONFIG *pTmwConfig)
{
    if((pMyTcpConfig == NULL) || (pTmwConfig == NULL))
        return NULL;

    TCP_IO_CHANNEL* pEthernetHandle = NULL;

    if(EthObject.SocketRemaing)
    {
        pEthernetHandle = &EthObject.ETH_Device[SOCKET_MAX - EthObject.SocketRemaing];

        memset(pEthernetHandle, 0, sizeof(TCP_IO_CHANNEL));

        uint16 PriorIp[4];
        /*applying ethernet configuation data*/
        memcpy(pEthernetHandle->SoreceIp, &pMyTcpConfig->SoureceIp[0], 4);

        pEthernetHandle->TargChType = TMWTARGIO_TYPE_TCP;
        pEthernetHandle->Socket     = pMyTcpConfig->Socket;
        pEthernetHandle->PortNumber = pMyTcpConfig->PortNumber;

        /*TMW Dnp stack config*/
        pEthernetHandle->pChannelCallback = pTmwConfig->pChannelCallback;
        pEthernetHandle->pChannelCallbackParam  = pTmwConfig->pCallbackParam;
        pEthernetHandle->pChannelReadyCallback  = pTmwConfig->pChannelReadyCallback;
        pEthernetHandle->pChannelReadyCbkParam  = pTmwConfig->pChannelReadyCbkParam;

        /*Read W5100 IP Address*/
        getSIPR(&PriorIp[0]);

        if(memcmp(&PriorIp[0], &pEthernetHandle->SoreceIp[0], 4) != 0)
            setSIPR((uint8*)&pEthernetHandle->SoreceIp[0]);

        EthObject.SocketRemaing--;
    }

    return pEthernetHandle;

}

TMWTYPES_BOOL TMWDEFS_GLOBAL TargTCP_openChannel(TCP_IO_CHANNEL *pTcpChannel)
{
    SOCKET_NUM Socket = pTcpChannel->Socket;

    switch(pTcpChannel->Status)
    {
        case SOCKET_CLOSE:
            socket(Socket, Protocol_TCP, pTcpChannel->PortNumber);

            listen(Socket);

            if(getSn_SR(Socket) == SOCKET_ESTABLISED)
            {
                pTcpChannel->Status = SOCKET_ESTABLISED;
                return TMWDEFS_TRUE;
            }

            return TMWDEFS_FALSE;

        case SOCKET_INIT:
            listen(Socket);

            if(getSn_SR(Socket) == SOCKET_ESTABLISED)        return TMWDEFS_TRUE;

            return TMWDEFS_FALSE;
        case SOCKET_CLOSING:
        case SOCKET_CLOSE_WAIT:
            wclose(Socket);
            return TMWDEFS_FALSE;
        case SOCKET_ESTABLISED:
            return TMWDEFS_TRUE;
    }

    return TMWDEFS_FALSE;
}

/* function: TargTCP_receive, this also receives UDP data */
TMWTYPES_USHORT TMWDEFS_GLOBAL TargTCP_receive(
  TCP_IO_CHANNEL *pTcpChannel,
  TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT maxBytes,
  TMWTYPES_MILLISECONDS maxTimeout,
  TMWTYPES_BOOL *pInterCharTimeoutOccurred)
{
    SOCKET_NUM Socket = pTcpChannel->Socket;

    return recv(Socket, (uint8*)pBuff, maxBytes);
}


/* function: TargTCP_transmit */
TMWTYPES_BOOL TMWDEFS_GLOBAL TargTCP_transmit(
  TCP_IO_CHANNEL* pTcpChannel,
  const TMWTYPES_UCHAR *pBuff,
  TMWTYPES_USHORT numBytes)
{
    SOCKET_NUM Socket = pTcpChannel->Socket;

    return send(Socket, (uint8*)pBuff, numBytes);
}


/* function: TargTCP_Accept */
void TMWDEFS_GLOBAL TargTCP_accept(TCP_IO_CHANNEL* pTcpChannel)
{
    SOCKET_NUM Socket = pTcpChannel->Socket;

    SOCKET_STATUS_ENUM SocketStatus = (SOCKET_STATUS_ENUM)getSn_SR(Socket);

    if(SocketStatus != pTcpChannel->Status)
    {
        /*When the socket state changes..*/
        switch(SocketStatus)
        {
            case SOCKET_ESTABLISED:
                pTcpChannel->Status = SocketStatus;
                pTcpChannel->pChannelCallback(pTcpChannel->pChannelCallbackParam, TMWDEFS_TRUE, TMWDEFS_TARG_OC_SUCCESS);
                break;
            case SOCKET_CLOSE:
            case SOCKET_CLOSING:
            case SOCKET_CLOSE_WAIT:
                pTcpChannel->Status = SocketStatus;
                pTcpChannel->pChannelCallback(pTcpChannel->pChannelCallbackParam, TMWDEFS_FALSE, TMWDEFS_TARG_OC_FAILURE);
                break;
            default :
                pTcpChannel->Status = SocketStatus;
                break;

        }
    }

}
