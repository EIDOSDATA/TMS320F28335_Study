/*
 * button.c
 *
 *  Created on: 2024. 1. 11.
 *      Author: ShinSung Industrial Electric
 */

#include "def.h"

#include "src/port/decoder.h"


#define BUTTON_OFFSET_ADDR          0x200400
#define BUTTON_BLOCK_READ(block)    *((volatile uint16 *)(BUTTON_OFFSET_ADDR + block))&0xFF


uint16 ButtonBlock_Read(uint16 block)
{
    uint16 ButtonData;

    Zone7BusTake(MMI_READ);

    ButtonData = BUTTON_BLOCK_READ(block);

    Zone7BusRelease();

    return ButtonData;
}
