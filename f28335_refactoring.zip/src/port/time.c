/*
 * Time.c
 *
 *  Created on: 2023. 11. 6.
 *  Author: ShinSung Industrial Electric
 *
 */


#include <string.h>
#include <stdlib.h>

#include "def.h"
#include "time.h"

#define  YEAR_REF 1900

#define TIME_USE_MAX
static SystemTime_t TimeObject;


SystemTime_t* TimeObjectGet(void)
{
    return &TimeObject;
}
void TimeObject_Init(void)
{
    memset(&TimeObject, 0, sizeof(SystemTime_t));

    RTC_Init(&TimeObject);

    RTC_GetTime(&TimeObject);

    TimeObject.SystemTicks = CLOCK_GET_TICKS();
}

SystemTime_t* TimeData_Get(void)
{
    uint8 Month         = TimeObject.tm_mon;
    uint8 Date          = TimeObject.tm_mday;
    uint8 Hours         = TimeObject.tm_hour;
    uint8 Min           = TimeObject.tm_min;
    uint8 Sec           = TimeObject.tm_sec;
    uint16 Ms           = TimeObject.tm_ms;
    uint32 Prev_Ticks   = TimeObject.SystemTicks;
    uint32 Now_Ticks    = CLOCK_GET_TICKS();
    uint32 Different    = 0;

    if(Prev_Ticks == Now_Ticks)     return &TimeObject;

    else
    {
        if(Prev_Ticks > Now_Ticks)      Different = Prev_Ticks-Now_Ticks;

        else                            Different = Now_Ticks-Prev_Ticks;

        Sec += Different/1000;
        Ms  += Different%1000;

        if(Ms >= 1000)
        {
            Sec += Ms/1000;
            Ms  -= 1000;

            if(Sec >= 60)
                {
                    Min += Sec/60;
                    Sec -= 60;

                    if(Min >= 60)
                        {
                            Hours += Min/60;
                            Min   -= 60;

                            if(Hours >= 24)
                                {
                                    Date += Hours/24;
                                    Hours-= 24;

                                    if(Date >= 30)
                                    {
                                        /*Todo*/
                                    }
                                    else
                                    {
                                        goto DATE;
                                    }
                                }

                            else
                                {
                                    goto HOURS;
                                }
                        }

                    else
                        {
                            goto MIN;
                        }

                }
            else
            {
                goto SEC;
            }
        }
        else
        {
        goto MILLISEC;
        }
    }
    DATE:       TimeObject.tm_mday      = Date;
    HOURS:      TimeObject.tm_hour      = Hours;
    MIN:        TimeObject.tm_min       = Min;
    SEC:        TimeObject.tm_sec       = Sec;
    MILLISEC:   TimeObject.tm_ms        = Ms;
                TimeObject.SystemTicks  = Now_Ticks;

    return &TimeObject;
}

void SystemTimeSet(SystemTime_t *pSystemTime)
{
    TimeObject.tm_sec = pSystemTime->tm_sec;
    TimeObject.tm_min = pSystemTime->tm_min;
    TimeObject.tm_hour = pSystemTime->tm_hour;
    TimeObject.tm_mday = pSystemTime->tm_mday;
    TimeObject.tm_mon = pSystemTime->tm_mon;
    TimeObject.tm_year = pSystemTime->tm_year-YEAR_REF;
    TimeObject.tm_ms = pSystemTime->tm_ms;

    RTC_SetTime(&TimeObject);

}

void Mmi_TimeStamping(Mmi_TimeStamp *pTimeStamp)
{
    SystemTime_t *pTime = TimeData_Get();

    pTimeStamp->Year    = pTime->tm_year;
    pTimeStamp->Month   = pTime->tm_mon;
    pTimeStamp->Day     = pTime->tm_mday;
    pTimeStamp->Hour    = pTime->tm_hour;
    pTimeStamp->Min     = pTime->tm_min;
    pTimeStamp->Sec     = pTime->tm_sec;
    pTimeStamp->msec    = pTime->tm_ms;
}

void Mmi_TimeSet(Mmi_TimeStamp *pTimeStamp)
{
    SystemTime_t *pTime = TimeData_Get();

    pTime->tm_year = pTimeStamp->Year+YEAR_REF;
    pTime->tm_mon  = pTimeStamp->Month;
    pTime->tm_mday = pTimeStamp->Day;
    pTime->tm_hour = pTimeStamp->Hour;
    pTime->tm_min  = pTimeStamp->Min;
    pTime->tm_sec  = pTimeStamp->Sec;
    pTime->tm_ms   = pTimeStamp->msec;

    SystemTimeSet(pTime);
}

void Logic_TimeStamping(Logic_TimeStamp *pTimeStamp)
{
    SystemTime_t *pTime = TimeData_Get();

    pTimeStamp->Year    = pTime->tm_year;
    pTimeStamp->Month   = pTime->tm_mon;
    pTimeStamp->Day     = pTime->tm_mday;
    pTimeStamp->Hour    = pTime->tm_hour;
    pTimeStamp->Min     = pTime->tm_min;
    pTimeStamp->Sec     = pTime->tm_sec;
    pTimeStamp->msec    = pTime->tm_ms;
}

void HMIS_TimeStamping(HMIS_TimeStamp *pTimeStamp)
{
    SystemTime_t *pTime = TimeData_Get();

    uint16 Year = pTime->tm_year + YEAR_REF;

    pTimeStamp->YearMonth  = Year<<4;
    pTimeStamp->YearMonth |= pTime->tm_mon;

    pTimeStamp->HourDay  = pTime->tm_mday;
    pTimeStamp->HourDay |= pTime->tm_hour<<8;

    pTimeStamp->SecMin  = pTime->tm_min;
    pTimeStamp->SecMin |= pTime->tm_sec<<8;

    pTimeStamp->MsFlag = pTime->tm_ms<<4;

}

void ConvertHMISToMmiTimeStamp(HMIS_TimeStamp *pHMISTimeStamp,Mmi_TimeStamp *pMMITimeStamp)
{
    pMMITimeStamp->Year  = pHMISTimeStamp->YearMonth >>4;
    pMMITimeStamp->Month = pHMISTimeStamp->YearMonth & 0x000F;
    pMMITimeStamp->Day   = pHMISTimeStamp->HourDay & 0x00FF;
    pMMITimeStamp->Hour  = pHMISTimeStamp->HourDay >>8;
    pMMITimeStamp->Min   = pHMISTimeStamp->SecMin  & 0x00FF;
    pMMITimeStamp->Sec   = pHMISTimeStamp->SecMin  >>8;
    pMMITimeStamp->msec  = pHMISTimeStamp->MsFlag  >>4;
}

