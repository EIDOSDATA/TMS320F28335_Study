/*
 * clcd.h
 *
 *  Created on: 2024. 1. 9.
 *      Author: hp878
 */

#ifndef CLCD_H_
#define CLCD_H_

#define CLCD_DISPLAY_CLEAR          0x01
#define CLCD_RETURN_HOME            0x02

#define CLCD_LINE_TEXT_MAX               20

typedef enum
{
    CLCD_LINE1,
    CLCD_LINE2,
    CLCD_LINE3,
    CLCD_LINE4,

    CLCD_LINE_MAX,

} CLCD_LINE;
typedef enum
{
   /* I/D : Increase Decrease, SH : Shift
    * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
    *  0   0   0   0   0   1  I/D SH
    */
    /*I/D = 0 SH = 0*/              /*I/D = 0 SH = 1*/
    CLCD_ENTRY_MODE_CMD1 = 0x04,    CLCD_ENTRY_MODE_CMD2 = 0x05,

    /*I/D = 1 SH = 0*/              /*I/D = 1 SH = 1*/
    CLCD_ENTRY_MODE_CMD3 = 0x06,    CLCD_ENTRY_MODE_CMD4 = 0x07

} CLCD_ENTRY_MODE;

typedef enum
{
   /* D : Display, C : Cursor, B : Blink
    * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
    *  0   0   0   0   1   D   C   B
    */
    /*D = 1, C = 0, B = 0*/         /*D = 1, C = 0, B = 1*/
    CLCD_DISPLAY_NORMAL = 0x0C,     CLCD_DISPLAY_BLINK = 0x0D,

    /*D = 1, C = 1, B = 0*/         /*D = 1, C = 1, B = 1*/
    CLCD_DISPLAY_CURSOR = 0x0E,     CLCD_DISPLAY_CURSOR_BLINK = 0x0F,

} CLCD_DISPLAY_MODE;

typedef enum
{
   /* D : Display, C : Cursor, B : Blink
    * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
    *  0   0   0   1  S/C R/L  -   -
    */
    /*S/C = 0, R/L = 0*/                                            /*S/C = 0, R/L = 1*/
    CLCD_CURSOR_DISPLAY_SHIFT_CMD1 = 0x10,                          CLCD_CURSOR_DISPLAY_SHIFT_CMD2 = 0x14,
    /*S/C = 1, R/L = 0*/                                            /*S/C = 1, R/L = 1*/
    CLCD_CURSOR_DISPLAY_SHIFT_CMD3 = 0x18,                          CLCD_CURSOR_DISPLAY_SHIFT_CMD4 = 0x1C,

} CLCD_CURSOR_DISPLAY_SHIFT_CMD;

typedef enum
{
   /* DL : Data Line, N : Number of lines, F : Font
    * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
    *  0   0   1  DL   N   F   -   -
    */
    /*DL = 0, N = 0, F = 0*/        /*DL = 0, N = 0, F = 1*/        /*DL = 0, N = 1, F = 0*/
    CLCD_FUNCTION_SET_CMD1 = 0x20,  CLCD_FUNCTION_SET_CMD2 = 0x24,  CLCD_FUNCTION_SET_CMD3 = 0x28,
    /*DL = 0, N = 1, F = 1*/        /*DL = 1, N = 0, F = 0*/        /*DL = 1, N = 0, F = 1*/
    CLCD_FUNCTION_SET_CMD4 = 0x2C,  CLCD_FUNCTION_SET_CMD5 = 0x30,  CLCD_FUNCTION_SET_CMD6 = 0x34,
    /*DL = 1, N = 1, F = 0*/        /*DL = 1, N = 1, F = 1*/
    CLCD_FUNCTION_SET_CMD7 = 0x38,  CLCD_FUNCTION_SET_CMD8 = 0x3C,

} CLCD_FUNCTION_SET_CMD;

/*CLCD Instruction*/
enum
{
    DISPLAY_CLEAR = 0x01,           RETURN_HOME   = 0x02,           ENTRY_MODE    = 0x06,

    /*Display = 1(On), Cursor = 0(Off), Blink = 0(Off)*/
    DISPLAY_ON = 0x0C,  CURSOR_ON = 0x0A,   BLINK_ON = 0x09,
    /*Display = 1(On), Cursor = 1(On), Blink = 0(Off)*/
    DISPLAY_ON2 = 0x0C,
    /*Display = 1(On), Cursor = 1(On), Blink = 1(On)*/
    DISPLAY_ON3 = 0x0F,


    /*ENTRY MODE SET
    * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
    *  0   0   1   0   0   1  I/D SH
    */
    INCREASE = 0x26, DECREASE = 0x24,


    /*FUNCTION SET
     * DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
     *  0   0   1  DL  N   F   -   -
     */
    INTERFACE_8BIT = 0x30,  INTERFACE_4BIT = 0x20,
    /*DISPLAY LINE*/
    ONE_LINE_DISPLAY = 0x20, TOW_LINE_DISPLAY = 0x28,
    /*Font*/
};

typedef struct
{
    /*LCD Handler*/
    void (*pfLCD_Control)(uint16 data);
    void (*pfLCD_String)(char *pStr);
    void (*pfLCD_Goto)(uint16 x, uint16 y);
    void (*pfLCD_Clear)();

} CLCD_Module;


CLCD_Module* CLCDHandle_Get(void* pMmiBlock4);
void CLCD_Init(void);

#endif /* CLCD_H_ */
