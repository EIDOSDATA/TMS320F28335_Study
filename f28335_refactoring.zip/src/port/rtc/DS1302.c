/*
 * DS1302.c
 *
 *  Author: ShinSung Industrial Electric
 *  Description : DS1302 Pin Interface
 *
 *  MCU Pin       DS1302 Pin
 *  GPIO 56       Data Pin(I/O)
 *  GPIO 57       CLK
 *  GPIO 58       /RST(Chip Enable)
 *
 */

#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File#include "DSP28x_Project.h"
#include "src/port/rtc/DS1302.h"

volatile struct GPIO_CTRL_REGS *pGPIOCtrlReg = &GpioCtrlRegs;
volatile struct GPIO_DATA_REGS *pGPIODataReg = &GpioDataRegs;

static void RTC_ReadyDataTransfer(void)
{
    pGPIODataReg->GPBCLEAR.bit.GPIO57 = 1;      /*CLK = 0*/
    DELAY_US(1.494);
    pGPIODataReg->GPBSET.bit.GPIO58 = 1;        /*RST = 1*/
}

static void RTC_ClearRST(void)
{
    pGPIODataReg->GPBCLEAR.bit.GPIO58 = 1;      /*RST = 0*/
}

static void RTC_WriteByte(uint16 Data)
{
    uint16 i;

    EALLOW;
    pGPIOCtrlReg->GPBDIR.bit.GPIO56 = 1;        /*I/O Output Data*/
    DELAY_US(1.494);                            // 1494 ns
    EDIS;

    for(i = 0; i < 8; i++)
    {
        DELAY_US(1.494);
        pGPIODataReg->GPBCLEAR.bit.GPIO56 = 1;   // IO = 0;
        DELAY_US(0.6);

        if(Data & 0x01)
        {
            pGPIODataReg->GPBSET.bit.GPIO56 = 1; // IO = 1
        }

        DELAY_US(0.6);
        pGPIODataReg->GPBSET.bit.GPIO57 = 1;     // CLK = 1;
        DELAY_US(1.494);
        pGPIODataReg->GPBCLEAR.bit.GPIO57 = 1;   // CLK = 0

        Data >>= 1;
     }
}

static uint16 RTC_ReadByte(void)
{
    uint16 i, temp, data, t1;

    EALLOW;
    pGPIOCtrlReg->GPBDIR.bit.GPIO56 = 0;         //input Data
    DELAY_US(1.494);
    EDIS;

    data = 0x0000;

    for(i=0; i<8; i++)
    {
        pGPIODataReg->GPBCLEAR.bit.GPIO57 = 1;   //CLK = 0
        DELAY_US(1.494);
        pGPIODataReg->GPBSET.bit.GPIO57 = 1;     //CLK = 1

        t1 = (uint16)pGPIODataReg->GPBDAT.bit.GPIO56; // read IO
        temp = (t1 << 7);
        data >>= 1;
        data |= temp;
    }

    return data;
}

void RTC_Init(SystemTime_t* pTime)
{
    uint16  nHalt;

    DELAY_US(10);
    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x8e);    // Clock Control Register              //Write Protect
    RTC_WriteByte(0x00);    // Disable
    RTC_ClearRST();


    DELAY_US(10);
    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x81);        // Sec Register
    nHalt = RTC_ReadByte();
    RTC_ClearRST();

    DELAY_US(10);

    if(nHalt & 0x80)
    {
        RTC_ReadyDataTransfer();
        RTC_WriteByte(0x80);
        RTC_WriteByte(0x00);
        RTC_ClearRST();
        DELAY_US(10);


        SystemTime_t Default_datetime;

        Default_datetime.tm_sec     = 1;
        Default_datetime.tm_min     = 1;
        Default_datetime.tm_hour    = 1;
        Default_datetime.tm_mday    = 1;
        Default_datetime.tm_mon     = 1;
        Default_datetime.tm_year    = 1;

        RTC_SetTime(&Default_datetime);
    }
    else
    {
        DELAY_US(10);
        RTC_GetTime(pTime);

    }

    RTC_ClearRST();
}



void RTC_GetTime(SystemTime_t *p_time_tag)
{
    uint16  Data[6];

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x81);        // Sec Register
    Data[0] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x83);        // min Register
    Data[1] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x85);        // hr  Register
    Data[2] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x87);        // date register
    Data[3] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x89);        //month Register
    Data[4] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x8d);        // year Register
    Data[5] = RTC_ReadByte();
    RTC_ClearRST();
    DELAY_US(10);

    p_time_tag->tm_sec = (Data[0]&0x70);
    p_time_tag->tm_sec >>= 4;
    p_time_tag->tm_sec *= 10;
    p_time_tag->tm_sec += (Data[0]&0x0f);

    p_time_tag->tm_min = (Data[1]&0x70);
    p_time_tag->tm_min >>= 4;
    p_time_tag->tm_min *= 10;
    p_time_tag->tm_min += (Data[1]&0x0f);

    p_time_tag->tm_hour = (Data[2]&0x30);
    p_time_tag->tm_hour >>= 4;
    p_time_tag->tm_hour *= 10;
    p_time_tag->tm_hour += (Data[2]&0x0f);

    p_time_tag->tm_mday = (Data[3]&0x30);
    p_time_tag->tm_mday >>= 4;
    p_time_tag->tm_mday *= 10;
    p_time_tag->tm_mday += (Data[3]&0x0f);

    p_time_tag->tm_mon  = (Data[4]&0x10);
    p_time_tag->tm_mon  >>= 4;
    p_time_tag->tm_mon  *= 10;
    p_time_tag->tm_mon  += (Data[4]&0x0f);

    p_time_tag->tm_year = (Data[5]&0xf0);
    p_time_tag->tm_year >>= 4;
    p_time_tag->tm_year *= 10;
    p_time_tag->tm_year += (Data[5]&0x0f);

}

void RTC_SetTime(const SystemTime_t *pDateTime)
{
    uint16  un1, un2, un3;

//  Set second
    un1 = pDateTime->tm_sec;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x80);        // Sec Register
    RTC_WriteByte(un1);         // Sec, Clock Start
    RTC_ClearRST();
    DELAY_US(5);

//  Set minute
    un1 = pDateTime->tm_min;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x82);        // min Register
    RTC_WriteByte(un1);         // Min
    RTC_ClearRST();
    DELAY_US(5);

//  Set hour
    un1 = pDateTime->tm_hour;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;
    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x84);        // hr  Register
    RTC_WriteByte(un1);         // Hour, 24hour
    RTC_ClearRST();
    DELAY_US(5);

//  Set date
    un1 = pDateTime->tm_mday;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;
    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x86);        // date register
    RTC_WriteByte(un1);     // Day
    RTC_ClearRST();
    DELAY_US(5);

//  Set month
    un1 = pDateTime->tm_mon;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x88);        //month Register
    RTC_WriteByte(un1);     // Mon
    RTC_ClearRST();
    DELAY_US(10);

//  Set year
    un1 = pDateTime->tm_year;
    un2 = un1/10;
    un3 = un1 - un2*10;
    un1 = (un2 << 4) | un3;

    RTC_ReadyDataTransfer();
    RTC_WriteByte(0x8c);        // year Register
    RTC_WriteByte(un1);         // Year
    RTC_ClearRST();
}
