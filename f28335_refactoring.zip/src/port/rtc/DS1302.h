/*
 * DS1302.h
 *
 *  Created on: 2023. 11. 19.
 *      Author: ShinSung Industrial Electric
 */

#ifndef BSP_DS1302_H_
#define BSP_DS1302_H_

#include "types.h"

typedef struct
{
    uint16 tm_sec;      /* seconds after the minute   - [0,59]  */
    uint16 tm_min;      /* minutes after the hour     - [0,59]  */
    uint16 tm_hour;     /* hours after the midnight   - [0,23]  */
    uint16 tm_mday;     /* day of the month           - [1,31]  */
    uint16 tm_mon;      /* months since January       - [0,11]  */
    uint16 tm_year;     /* years since 1900                     */

    uint16 tm_ms;
    uint32 SystemTicks;

} SystemTime_t;

void RTC_Init(SystemTime_t* pTime);
void RTC_GetTime(SystemTime_t *p_time_tag);
void RTC_SetTime(const SystemTime_t *pDateTime);

#endif /* BSP_DS1302_H_ */
