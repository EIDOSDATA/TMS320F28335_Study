/*
 * Flash.c
 *
 *  Created on : 2023. 11. 15.
 *      Author : ShinSung Industrial Electric
 *
 *  Description: External FLASH Device (SST39VF1601C)
 *  Total Block 35
 *  Uniform 2K Word Sectors
 *
 *  Word-Program Time Max 10us
 *
 */

#include "def.h"
#include "src/port/decoder.h"
#include "src/port/memory/flash.h"


#define SECTOR_ERASE_SHIFT(Sector)      (Sector<<11)
#define BLOCK_ERASE_SHIFT(Block)        (Block<<15)


#define FLASH_ADDR(Address)             ((volatile uint16 *)(0x200000 + Address))

#define FLASH_ADDR_MASKING              0xFFFFF

#define FLASH_SECTOR_MAX        512
#define FLASH_DELAY             100//15
#define MAX_TIMEOUT             0x0FFFFFFF

uint16 FLASH_Read(uint32 addr)
{
   uint16 Rtn = 0;

   addr &= FLASH_ADDR_MASKING;

   Rtn = *FLASH_ADDR(addr);

   return Rtn;
}

bool FLASH_Write(uint32 Addr, uint16 Data)
{
    uint16 timeout = 0;

    uint16 ToggleBit1 = 0;

    uint16 ToggleBit2 = 0;

    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;
    *FLASH_ADDR(0x555) = 0x00A0;

    *FLASH_ADDR(Addr) = Data;

    ToggleBit1 = *FLASH_ADDR(Addr);
    ToggleBit1 &= 0x0040;

    while(timeout <MAX_TIMEOUT)
    {
        ToggleBit2 = *FLASH_ADDR(Addr);
        ToggleBit2 &= 0x0040;

        if(ToggleBit1 == ToggleBit2)
         {
            return true;
         }

        ToggleBit1 = ToggleBit2;
        timeout++;
    }

    return false;
}
#if 0
bool FLASH_SectorErase(uint32 Sector)
{
    uint32 SAx = SECTOR_ERASE_SHIFT(Sector);
    uint16 timeout = 0;
    uint16 ToggleBit1 = 0;
    uint16 ToggleBit2 = 0;

    Zone7BusTake(FLASH);

    /*Erase Command*/
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;
    *FLASH_ADDR(0x555) = 0x0080;
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;

    *FLASH_ADDR(SAx) = 0x0050;

    /*Sector Erase Time 18ms(Typical)*/

    Zone7BusRelease();

    TASK_SLEEP(18);

    Zone7BusTake(FLASH);

    while(timeout < MAX_TIMEOUT)
    {
        ToggleBit1 = *FLASH_ADDR(SAx);
        ToggleBit2 = *FLASH_ADDR(SAx);

        if(ToggleBit1 == ToggleBit2)
        {
            Zone7BusRelease();
            return true;
        }
        timeout++;
    }

    Zone7BusRelease();
    return false;
}
#else
void EraseFlashSector(uint32 Sector)
{
    uint32 SAx = SECTOR_ERASE_SHIFT(Sector);

    /*Erase Command*/
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;
    *FLASH_ADDR(0x555) = 0x0080;
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;

    *FLASH_ADDR(SAx) = 0x0050;

    DELAY_US(FLASH_DELAY);
}
#endif
bool CheckFlashSectorErase(uint32 Sector)
{
    uint32 SAx = SECTOR_ERASE_SHIFT(Sector);

    uint16 PrevData = *FLASH_ADDR(SAx);
    uint16 CurrData;

    PrevData &= 0x0040;                 //  read DQ6

    CurrData = *FLASH_ADDR(SAx);

    CurrData &= 0x0040;

    if(PrevData == CurrData)
    {
        return true;
    }
    else
    {
        return false;
    }
}

#if 0
bool FLASH_BlockErase(uint32 Block)
{
    uint32 BAx = BLOCK_ERASE_SHIFT(Block);
    uint16 timeout = 0;
    uint16 ToggleBit1 = 0;
    uint16 ToggleBit2 = 0;

    Zone7BusTake(FLASH);

    /*Erase Command*/
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;
    *FLASH_ADDR(0x555) = 0x0080;
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;

    *FLASH_ADDR(BAx) = 0x0030;

    /*Block Erase Time 18ms(Typical)*/
    Zone7BusRelease();

    TASK_SLEEP(18);

    Zone7BusTake(FLASH);

    while(timeout <MAX_TIMEOUT)
    {
       ToggleBit1 = *FLASH_ADDR(BAx);
       ToggleBit2 = *FLASH_ADDR(BAx);

       if(ToggleBit1 == ToggleBit2)
       {
           Zone7BusRelease();
           return true;
       }

         timeout++;
    }
   Zone7BusRelease();
   return false;
}
#else

void EraseFlashBlock(uint32 Block)
{
    uint32 BAx = BLOCK_ERASE_SHIFT(Block);

    /*Erase Command*/
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;
    *FLASH_ADDR(0x555) = 0x0080;
    *FLASH_ADDR(0x555) = 0x00AA;
    *FLASH_ADDR(0x2AA) = 0x0055;

    *FLASH_ADDR(BAx) = 0x0030;

    DELAY_US(1);

}

bool CheckFlashBlockErase(uint32 Block)
{
    uint32 BAx = BLOCK_ERASE_SHIFT(Block);

    uint32 timeout = 0;

    uint16 PrevData = *FLASH_ADDR(BAx);
    uint16 CurrData;

    PrevData &= 0x0040;                 //  read DQ6

    while(timeout <MAX_TIMEOUT)
    {

        CurrData = *FLASH_ADDR(BAx);
        CurrData &= 0x0040;

        if(PrevData == CurrData)
        {
            return true;
        }

        PrevData = CurrData;
        timeout++;
    }

    return false;
}
#endif
