/*
 * clcd.c
 *
 *  Created on: 2024. 1. 8.
 *      Author: ShinSung Industrial Electric
 *
 *      WriteBlock4
 *      Bit         Net Name
 *      0           LOOP_NC_LED
 *      1           LOOP_NO_LED
 *      2           ABC_RST_LED
 *      3           RST_ABC_LED
 *      4           TRIP_LED
 *      5           LCD_AO(CLCD RS)
 *      6           LCD_BL(CLCD Back Light)
 *      7           LCD_E(CLCD Enable)
 */
#include <string.h>

#include "def.h"
#include "src/port/decoder.h"
#include "src/port/clcd.h"

#define CLCD_DELAY              5


#define CLCD_LINE1_START_ADDR       0x00
#define CLCD_LINE2_START_ADDR       0x40
#define CLCD_LINE3_START_ADDR       0x14
#define CLCD_LINE4_START_ADDR       0x54

#define CLCD_LINE_ADDR_SET
#define CLCD_CONTROL_LINE_ADDR  0x200404
#define CLCD_DATA_LINE_ADDR     0x200405

#define CLCD_CMD_WRITE(data)    *((volatile uint16 *)(CLCD_CONTROL_LINE_ADDR)) = data
#define CLCD_DATA_WRITE(data)   *((volatile uint16 *)(CLCD_DATA_LINE_ADDR)) = data

#define RS_SET(data)              data |= 0x20
#define RS_CLEAR(data)            data &= 0xDF

#define ENABLE_SET(data)          data |= 0x80
#define ENABLE_CLEAR(data)        data &= 0x7F



#define FUNCTION_SET            0x38
#define DISPLAY_ON_OFF          0x0e
#define DISPLAY_CLEAR           0x01
#define ENTRY_MODE_SET          0x06

static CLCD_Module Device;

static uint16* pWriteBlock4;
static uint16 MmiInitValue = 0x1F;
static Delay_loop16(uint16 delay)
{
    while(delay--);
}

static void CLCD_ControlWrite(uint16 data)
{
    uint16 MmiBlock4 = *pWriteBlock4;

    Zone7BusTake(MMI_WRITE);

    ENABLE_CLEAR(MmiBlock4);
    RS_CLEAR(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);
    Delay_loop16(CLCD_DELAY);

    ENABLE_SET(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);
    Delay_loop16(CLCD_DELAY);

    CLCD_DATA_WRITE(data);
    Delay_loop16(CLCD_DELAY);

    ENABLE_CLEAR(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);
    Delay_loop16(CLCD_DELAY);

    RS_SET(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);

    DELAY_US(30);

    Zone7BusRelease();
}
void CLCD_DataWrite(char data)
{
    uint16 MmiBlock4 = *pWriteBlock4;

    Zone7BusTake(MMI_WRITE);

    RS_SET(MmiBlock4);
    ENABLE_CLEAR(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);
    Delay_loop16(CLCD_DELAY);

    CLCD_DATA_WRITE(data);
    Delay_loop16(CLCD_DELAY);

    ENABLE_SET(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);
    Delay_loop16(CLCD_DELAY);

    ENABLE_CLEAR(MmiBlock4);
    RS_CLEAR(MmiBlock4);
    CLCD_CMD_WRITE(MmiBlock4);

    DELAY_US(30);

    Zone7BusRelease();
}
void CLCD_DisplayClear(void)
{
    CLCD_ControlWrite(CLCD_DISPLAY_CLEAR);
}

void CLCD_Goto(uint16 y, uint16 x)
{
    uint16 Line_Addr[CLCD_LINE_MAX] = {CLCD_LINE1_START_ADDR,
                                       CLCD_LINE2_START_ADDR,
                                       CLCD_LINE3_START_ADDR,
                                       CLCD_LINE4_START_ADDR};


    CLCD_ControlWrite((Line_Addr[y] + x)|0x80);
}
void CLCD_LineMove(CLCD_LINE line)
{
    uint16 Line_Addr[CLCD_LINE_MAX] = {CLCD_LINE1_START_ADDR,
                                       CLCD_LINE2_START_ADDR,
                                       CLCD_LINE3_START_ADDR,
                                       CLCD_LINE4_START_ADDR};

    CLCD_ControlWrite(Line_Addr[line]);
}




void CLCD_StrWrite(char *pStr)
{
    while(*pStr != NULL)
    {
        CLCD_DataWrite(*pStr++);
    }
}
void CLCD_LineWrite(CLCD_LINE line, char*pStr)
{
    switch(line)
    {
    case CLCD_LINE1:
        CLCD_ControlWrite(CLCD_LINE1_START_ADDR);
        break;
    case CLCD_LINE2:
        CLCD_ControlWrite(CLCD_LINE2_START_ADDR);
        break;
    case CLCD_LINE3:
        CLCD_ControlWrite(CLCD_LINE3_START_ADDR);
        break;
    case CLCD_LINE4:
        CLCD_ControlWrite(CLCD_LINE4_START_ADDR);
        break;
    default:
        return;
    }

    while(*pStr != NULL)
    {
        CLCD_DataWrite(*pStr++);
    }
}
CLCD_Module* CLCDHandle_Get(void* pMmiBlock4)
{
    pWriteBlock4 = pMmiBlock4;

    return &Device;
}

void CLCD_Init(void)
{
    /*Wait for more than 30ms after VDD stabilized*/
    pWriteBlock4 = &MmiInitValue;
    DELAY_US(30000);

    /*Function Set*/
    CLCD_ControlWrite(0x30);
    DELAY_US(6000);

    CLCD_ControlWrite(0x30);
    DELAY_US(200);

    CLCD_ControlWrite(0x30);
    DELAY_US(50);

    CLCD_ControlWrite(FUNCTION_SET);
    DELAY_US(50);

    /*Display ON/OFF Control*/
    CLCD_ControlWrite(CLCD_DISPLAY_NORMAL);
    DELAY_US(50);

    /*Entry Mode Set*/
    CLCD_ControlWrite(ENTRY_MODE);
    DELAY_US(100);

    /*Display Clear*/
    CLCD_ControlWrite(DISPLAY_CLEAR);
    DELAY_US(3000);
    Device.pfLCD_Control = CLCD_ControlWrite;
    Device.pfLCD_Clear   = CLCD_DisplayClear;
    Device.pfLCD_Goto    = CLCD_Goto;
    Device.pfLCD_String  = CLCD_StrWrite;

}
