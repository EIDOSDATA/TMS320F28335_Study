/*
 * Decoder.h
 *
 *  Created on: 2023. 10. 31.
 *      Author: ShinSung Industrial Electric
 */

#ifndef BSP_ETHERNET_DECODER_H_
#define BSP_ETHERNET_DECODER_H_

typedef enum
{
    FLASH,
    FRAM,
    MMI_READ,
    MMI_WRITE,
    W5100S

} Zone7DeviceEnum;

void Zone7BusTake(Zone7DeviceEnum Device);
void Zone7BusRelease(void);

void Zone7BusTaskWithoutSem(Zone7DeviceEnum Device);
void Zone7BusReleaseWithoutSem(void);

#endif /* BSP_ETHERNET_DECODER_H_ */
