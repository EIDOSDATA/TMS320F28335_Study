/*
 * EdgeDetetor.c
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#include <string.h>
#include "src/app/logic/FunctionBlock/EdgeDetector.h"
#pragma DATA_SECTION (EdgeDetectorObject, "ZONE6DATA")

static EdgeDetectorModule EdgeDetectorObject = {.EdgeDetectorRemaing = USERLOGIC_EDGE_DETECTOR_OBJECT_MAX};

EdgeDetectorModule* EdgeDetector_Load(void)
{
    return &EdgeDetectorObject;
}

EdgeDetector* EdgeDetectorCreate(EdgeDetectorType Type, bool DFT_LastValue)
{
    EdgeDetector* pHandle = NULL;
    uint16  Remaing = EdgeDetectorObject.EdgeDetectorRemaing;

    if(Remaing)
    {
        pHandle = &EdgeDetectorObject.Object[USERLOGIC_EDGE_DETECTOR_OBJECT_MAX - Remaing];

        memset(pHandle, 0, sizeof(EdgeDetector));

        pHandle->Type = Type;
        pHandle->LastValue = DFT_LastValue;

        EdgeDetectorObject.EdgeDetectorRemaing--;

    }
    else
        DEBUG_Msg("not enough EdgeDector Object\n");

    return pHandle;
}

void UseEdgeDetector(EdgeDetector* pHandle, bool in, bool *p_out)
{
    switch(pHandle->Type)
    {
    case EDT_RISING:
        if((pHandle->LastValue == false) && (in == true))           *p_out = true;

        else                                                        *p_out = false;

        break;
    case EDT_FALLING:
        if((pHandle->LastValue == true)&& (in == false))            *p_out = true;

        else                                                        *p_out = false;

        break;
    default:
        *p_out = false;
        break;
    }
    /*Save Input Data*/
    pHandle->LastValue = in;
}
