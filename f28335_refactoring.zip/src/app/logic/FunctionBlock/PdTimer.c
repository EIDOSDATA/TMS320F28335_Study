/*
 * PdTimer.c
 *
 *  Created on: 2023. 12. 14.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>

#include "src/app/logic/FunctionBlock/PdTimer.h"

#pragma DATA_SECTION (PdTimerObject, "ZONE6DATA")

static PdTimerModule  PdTimerObject = {.PdTimerRemaing = USERLOGIC_PDTIMER_OBJECT_MAX};

/*
 * PD Timer Tick Coefficient
 * Description : Initialize at Logic Component Start
 * 1 Cycle Time             1/4 Cycle Time(Ideal)               1/4 Cycle Time(Reality)
 * 50Hz : 20ms              5ms                                 5ms + a(Calculation Threading Time)
 * 60Hz : 16.666666ms       4.166666ms                          4.166666ms + a(Calculation Threading Time)
 */

PdTimer* PdTimerCreate(PdTimerType PickUpTimerType,  float32 PickUpTimerTimeout,  uint16  PickupTagGroup,  uint16  PickupTagIndex,
                       PdTimerType DropOutTimerType, float32 DropOutTimerTimeout, uint16  DropOutTagGroup, uint16  DropOutTagIndex)
{
    PdTimer* pPdTimerHandle = NULL;

    if(PdTimerObject.PdTimerRemaing)
    {
        pPdTimerHandle = &PdTimerObject.Object[USERLOGIC_PDTIMER_OBJECT_MAX - PdTimerObject.PdTimerRemaing];

        memset(pPdTimerHandle, 0, sizeof(PdTimer));

        pPdTimerHandle->PickUpTimerType         = PickUpTimerType;

        switch(PickUpTimerType)
        {
            case PDTT_CYCLE:
                pPdTimerHandle->PickUpTimerTimeout      = PickUpTimerTimeout;
                break;
            case PDTT_SEC:
                pPdTimerHandle->PickUpTimerTimeout      = PickUpTimerTimeout * 1000;
                break;
        }

        if(PickupTagGroup != NULL)
        {
            pPdTimerHandle->PickupTag.TagGroup      = (TAG_GROUP)PickupTagGroup;
            pPdTimerHandle->PickupTag.TagIndex      = PickupTagIndex;

            pPdTimerHandle->PickUpTimerTimeout = *(float32*)TagDataAddr_Get(&pPdTimerHandle->PickupTag) * 1000;
        }


        if(pPdTimerHandle->PickUpTimerTimeout > 0)
            pPdTimerHandle->PickUpTimerActive = true;

        pPdTimerHandle->DropOutTimerType        = DropOutTimerType;

        switch(DropOutTimerType)
        {
            case PDTT_CYCLE:
                pPdTimerHandle->DropOutTimerTimeout      = DropOutTimerTimeout;
                break;
            case PDTT_SEC:
                pPdTimerHandle->DropOutTimerTimeout      = DropOutTimerTimeout * 1000;
                break;
        }

        pPdTimerHandle->DropOutTag.TagGroup     = (TAG_GROUP)DropOutTagGroup;
        pPdTimerHandle->DropOutTag.TagIndex     = DropOutTagIndex;

        if(DropOutTagGroup != NULL)
        {
            pPdTimerHandle->DropOutTag.TagGroup      = (TAG_GROUP)DropOutTagGroup;
            pPdTimerHandle->DropOutTag.TagIndex      = DropOutTagIndex;

            pPdTimerHandle->DropOutTimerTimeout      = *(float32*)TagDataAddr_Get(&pPdTimerHandle->DropOutTag) * 1000;
        }

        if(pPdTimerHandle->DropOutTimerTimeout > 0)
            pPdTimerHandle->DropOutTimerActive = true;

        PdTimerObject.PdTimerRemaing--;
    }

    else
        DEBUG_Msg("not enough PdTimer Object\n");


    return pPdTimerHandle;
}

static float32 TimerDuration_Get(float32 TimerTimeout, uint32* pLastSystemTick)
{
    float32 TimerDuration  = 0;
    int32   TimeDifferent = 0;
    uint32  NowSystemTicks = CLOCK_GET_TICKS();

    TimeDifferent = NowSystemTicks - *pLastSystemTick;

    *pLastSystemTick = NowSystemTicks;

    if(TimeDifferent > 0)
        TimerDuration = (float32)abs(TimeDifferent);

    else if(TimeDifferent < 0)
        TimerDuration = (float32)abs(TimeDifferent);

    return TimerDuration;
}

void PdTimerUse(PdTimer *pHandle, bool in, bool reset, bool *p_out)
{
    if(reset == true)
    {
        if((pHandle->PickUpTimerType == PDTT_SEC)||(pHandle->PickUpTimerType == PDTT_TAG))
            pHandle->PickUpTimerLastSystemTicks  = CLOCK_GET_TICKS();

        if((pHandle->DropOutTimerType == PDTT_SEC)||(pHandle->DropOutTimerType == PDTT_TAG))
            pHandle->DropOutTimerLastSystemTicks = CLOCK_GET_TICKS();

        pHandle->PickUpTimerDuration     = 0;
        pHandle->DropOutTimerDuration    = 0;
        pHandle->TimerResult             = 0;

        pHandle->PickUpTimerActive  = 0;
        pHandle->DropOutTimerActive = 0;
    }
    else
    {
        /*Input High*/
        if(in == true)
        {
            pHandle->DropOutTimerActive = false;

            /*PickUp Timer Active*/
            if(pHandle->PickUpTimerActive)
            {
                switch(pHandle->PickUpTimerType)
                {
                    case PDTT_CYCLE:
                        pHandle->PickUpTimerDuration += 0.25;
                        break;
                    case PDTT_SEC:
                        pHandle->PickUpTimerDuration += TimerDuration_Get(pHandle->PickUpTimerTimeout, &pHandle->PickUpTimerLastSystemTicks);
                        break;
                    case PDTT_TAG:
                    {
                        uint16   UintTemp = *(uint16*)TagDataAddr_Get(&pHandle->PickupTag);
                        float32 FloatTemp = *(float32*)TagDataAddr_Get(&pHandle->PickupTag);

                        switch(pHandle->PickupTag.TagGroup)
                        {
                            case TAG_GRP_SC_UI:
                            case TAG_GRP_LS_UI:
                            case TAG_GRP_NMV_UI:
                            case TAG_GRP_NVV_UI:
                                pHandle->PickUpTimerTimeout   = UintTemp * 1000;
                                break;
                            case TAG_GRP_SC_F:
                            case TAG_GRP_LS_F:
                            case TAG_GRP_NMV_F:
                            case TAG_GRP_NVV_F:
                                pHandle->PickUpTimerTimeout   = FloatTemp * 1000;
                                break;
                        }
                            pHandle->PickUpTimerDuration += TimerDuration_Get(pHandle->PickUpTimerTimeout, &pHandle->PickUpTimerLastSystemTicks);
                        }
                            break;
                    }
            }
            /*PickUp Timer Deactivate*/
            else
            {
                pHandle->PickUpTimerActive = true;
                pHandle->PickUpTimerDuration = 0;
                pHandle->PickUpTimerLastSystemTicks = CLOCK_GET_TICKS();
            }
            /*
             * PickupTimer Result
             * When the timer expires or the initial setting value is zero
             */
            if((pHandle->PickUpTimerDuration >= pHandle->PickUpTimerTimeout)||(pHandle->PickUpTimerTimeout == 0))
            {
                    pHandle->TimerResult         = true;
            }
        }
        /*Input Low*/
        else
        {
            pHandle->PickUpTimerActive = false;

            if(pHandle->DropOutTimerActive)
            {
                switch(pHandle->DropOutTimerType)
                {
                    case PDTT_CYCLE:
                        pHandle->DropOutTimerDuration += 0.25;
                        break;
                    case PDTT_SEC:
                        pHandle->DropOutTimerDuration += TimerDuration_Get(pHandle->DropOutTimerTimeout, &pHandle->DropOutTimerLastSystemTicks);
                        break;
                    case PDTT_TAG:
                    {
                        uint16   UintTemp = *(uint16*)TagDataAddr_Get(&pHandle->DropOutTag);
                        float32 FloatTemp = *(float32*)TagDataAddr_Get(&pHandle->DropOutTag);

                        switch(pHandle->PickupTag.TagGroup)
                        {
                            case TAG_GRP_SC_UI:
                            case TAG_GRP_LS_UI:
                            case TAG_GRP_NMV_UI:
                            case TAG_GRP_NVV_UI:
                                pHandle->DropOutTimerTimeout   = UintTemp * 1000;
                                break;
                            case TAG_GRP_SC_F:
                            case TAG_GRP_LS_F:
                            case TAG_GRP_NMV_F:
                            case TAG_GRP_NVV_F:
                                pHandle->DropOutTimerTimeout   = FloatTemp * 1000;
                                break;
                        }
                            pHandle->DropOutTimerDuration += TimerDuration_Get(pHandle->DropOutTimerTimeout, &pHandle->DropOutTimerLastSystemTicks);
                    }
                        break;
                }
            }
            else
            {
                pHandle->DropOutTimerActive = true;
                pHandle->DropOutTimerDuration = 0;
                pHandle->DropOutTimerLastSystemTicks = CLOCK_GET_TICKS();
            }
            /*
             * DropOuptTimer Result
             * When the timer expires or the initial setting value is zero
             */
            if((pHandle->DropOutTimerDuration >= pHandle->DropOutTimerTimeout)||(pHandle->DropOutTimerTimeout == 0))
            {
                /*Expire Timer*/
                pHandle->TimerResult         = false;
            }
        }
    }
    if(p_out)
        *p_out = pHandle->TimerResult;
}


PdTimerModule* PdTimer_Load(void)
{
    return &PdTimerObject;
}
