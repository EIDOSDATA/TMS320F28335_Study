/*
 * tcc.c
 *
 *  Created on: 2023. 12. 14.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>
#include <math.h>
#include "src/app/logic/FunctionBlock/tcc.h"

#include "src/app/tag/tag_db_macro.h"


static float32 TccQuaterCycleTime = 0;

/*Tcc Object(Before BuiltinLogic) For User Logic*/
static TccModule TccObject = {.TccObjectRemaing = USERLOGIC_TCC_OBJECT_MAX};

Tcc* TccCreate(TAG_GROUP TagGroup1,       uint16  TagCurveType,           TAG_GROUP TagGroup2,      uint16  TagTimeDialMultiplier,
               TAG_GROUP TagGroup3,       uint16  TagDefiniteTimeDelay,   TAG_GROUP TagGroup4,      uint16  TagElementReset,
               TAG_GROUP TagGroup5,       uint16  TagConstTimeAdder,      TAG_GROUP TagGroup6,      uint16  TagMinimumResponseTime,
               TAG_GROUP TagGroup7,       uint16  TagFactorA,             TAG_GROUP TagGroup8,      uint16  TagFactorB,
               TAG_GROUP TagGroup9,       uint16  TagFactorP)
{
    Tcc*   pHandle = NULL;
    uint16 Remaing = TccObject.TccObjectRemaing;

    if(Remaing)
    {
        pHandle = &TccObject.Object[USERLOGIC_TCC_OBJECT_MAX - Remaing];

        memset(pHandle, 0, sizeof(Tcc));

        pHandle->TagCurveType.TagGroup  = TagGroup1;
        pHandle->TagCurveType.TagIndex  = TagCurveType;

        pHandle->TagTimeDialMultiplier.TagGroup  = TagGroup2;
        pHandle->TagTimeDialMultiplier.TagIndex  = TagTimeDialMultiplier;

        pHandle->TagDefiniteTimeDelay.TagGroup   = TagGroup3;
        pHandle->TagDefiniteTimeDelay.TagIndex   = TagDefiniteTimeDelay;

        pHandle->TagElementReset.TagGroup        = TagGroup4;
        pHandle->TagElementReset.TagIndex        = TagElementReset;

        pHandle->TagConstantTimeAdder.TagGroup   = TagGroup5;
        pHandle->TagConstantTimeAdder.TagIndex   = TagConstTimeAdder;
        pHandle->TagMinimumResponseTime.TagGroup = TagGroup6;
        pHandle->TagMinimumResponseTime.TagIndex = TagMinimumResponseTime;

        pHandle->TagFactorA.TagGroup             = TagGroup7;
        pHandle->TagFactorA.TagIndex             = TagFactorA;

        pHandle->TagFactorB.TagGroup             = TagGroup8;
        pHandle->TagFactorB.TagIndex             = TagFactorB;

        pHandle->TagFactorP.TagGroup             = TagGroup9;
        pHandle->TagFactorP.TagIndex             = TagFactorP;

        TccObject.TccObjectRemaing--;
    }
    else
    {
        DEBUG_Msg("not enough tcc Object\n");
    }
    return pHandle;
}

float32 calcTpWithCooper(Tcc* pHandle, float32 multiple, bool is_reset)
{
    float32 tp;
    float32 MinimumResponseTimeCache, factor_a, factor_b, factor_c, factor_p;

    if(is_reset == false)
    {
        switch(pHandle->CurveType)
        {
            case TCCCVT_COOPER_101:
                pHandle->MinimumResponseTimeCache     = 0.0;

                pHandle->FactorACache   = 0.144;
                pHandle->FactorBCache   = 0.016;
                pHandle->FactorCCache   = -0.179;

                pHandle->FactorPCache   = 4.609;
                break;
            case TCCCVT_COOPER_117:
                pHandle->MinimumResponseTimeCache     = 0.017;

                pHandle->FactorACache = 5.243;
                pHandle->FactorBCache= 0.008;
                pHandle->FactorCCache = -0.031;

                pHandle->FactorPCache = 1.842;
                break;
            case TCCCVT_COOPER_133:
                pHandle->MinimumResponseTimeCache     = 0.039;

                pHandle->FactorACache = 10.251;
                pHandle->FactorBCache = 0.032;
                pHandle->FactorCCache = 0.282;

                pHandle->FactorPCache = 1.915;

                break;
            case TCCCVT_COOPER_116:
                pHandle->MinimumResponseTimeCache     = 0.011;

                pHandle->FactorACache = 5.295;
                pHandle->FactorBCache = 0.007;
                pHandle->FactorCCache = 0.174;

                pHandle->FactorPCache = 2.224;
                break;
            case TCCCVT_COOPER_132:
                pHandle->MinimumResponseTimeCache     = 0.016;

                pHandle->FactorACache = 9.081;
                pHandle->FactorBCache = 0.005;
                pHandle->FactorCCache = 0.511;

                pHandle->FactorPCache = 2.093;
                break;
            case TCCCVT_COOPER_163:
                pHandle->MinimumResponseTimeCache     = 0.012;

                pHandle->FactorACache = 5.561;
                pHandle->FactorBCache = 0.01;
                pHandle->FactorCCache = 0.923;

                pHandle->FactorPCache = 2.142;
                break;
            case TCCCVT_COOPER_165:
                if (multiple >= 1.0 && multiple < 2.0)
                {
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 64.7;
                    pHandle->FactorBCache = -1.05;
                    pHandle->FactorCCache = 0.29;

                    pHandle->FactorPCache = 2.328;
                }
                else if (multiple >= 2.0 && multiple < 3.0)
                {
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 86.57;
                    pHandle->FactorBCache = -1.05;
                    pHandle->FactorCCache = 0.29;

                    pHandle->FactorPCache = 2.727;
                }
                else if (multiple >= 3.0 && multiple < 4.0)
                {
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 37.475;
                    pHandle->FactorBCache = -0.9;
                    pHandle->FactorCCache = 0.27;

                    pHandle->FactorPCache = 2.01;
                }
                else if (multiple >= 4.0)
                {
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 23.602;
                    pHandle->FactorBCache = 0.007;
                    pHandle->FactorCCache = 0.174;

                    pHandle->FactorPCache = 2.024;
                }
                    break;
                case TCCCVT_COOPER_162:
                    pHandle->MinimumResponseTimeCache     = 0.018;

                    pHandle->FactorACache = 14.774;
                    pHandle->FactorBCache = 0.009;
                    pHandle->FactorCCache = 0.574;

                    pHandle->FactorPCache = 2.124;
                    break;
                case TCCCVT_COOPER_107:
                    pHandle->MinimumResponseTimeCache     = 0.011;

                    pHandle->FactorACache = 3.602;
                    pHandle->FactorBCache = 0.007;
                    pHandle->FactorCCache = -1.496;

                    pHandle->FactorPCache = 3.411;
                    break;
                case TCCCVT_COOPER_118:
                    pHandle->MinimumResponseTimeCache     = 0.016;

                    pHandle->FactorACache = 3.802;
                    pHandle->FactorBCache = 0.01;
                    pHandle->FactorCCache = 0.513;

                    pHandle->FactorPCache = 1.885;
                    break;
                case TCCCVT_COOPER_104:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 2.098;
                    pHandle->FactorBCache = 0.01;
                    pHandle->FactorCCache = -3.658;

                    pHandle->FactorPCache = 3.299;
                    break;
                case TCCCVT_COOPER_115:
                    pHandle->MinimumResponseTimeCache     = 0.014;

                    pHandle->FactorACache = 5.544;
                    pHandle->FactorBCache = 0.006;
                    pHandle->FactorCCache = 0.13;

                    pHandle->FactorPCache = 3.032;
                    break;
                case TCCCVT_COOPER_105:
                    pHandle->MinimumResponseTimeCache     = 0.011;

                    pHandle->FactorACache = 0.62;
                    pHandle->FactorBCache = 0.0;
                    pHandle->FactorCCache = 0.084;

                    pHandle->FactorPCache = 1.378;
                    break;
                case TCCCVT_COOPER_161:
                    pHandle->MinimumResponseTimeCache     = 0.029;

                    pHandle->FactorACache = 4.341;
                    pHandle->FactorBCache = 0.024;
                    pHandle->FactorCCache = 0.926;

                    pHandle->FactorPCache = 1.874;
                    break;
                case TCCCVT_COOPER_137:
                    pHandle->MinimumResponseTimeCache     = 0.602;

                    pHandle->FactorACache = 20.882;
                    pHandle->FactorBCache = 0.383;
                    pHandle->FactorCCache = -0.033;

                    pHandle->FactorPCache = 1.734;
                    break;
                case TCCCVT_COOPER_138:
                    pHandle->MinimumResponseTimeCache     = 0.119;

                    pHandle->FactorACache = 21.717;
                    pHandle->FactorBCache = 0.083;
                    pHandle->FactorCCache = -0.023;

                    pHandle->FactorPCache = 1.834;
                    break;
                case TCCCVT_COOPER_120:
                    pHandle->MinimumResponseTimeCache     = 0.093;

                    pHandle->FactorACache = 6.04;
                    pHandle->FactorBCache = 0.086;
                    pHandle->FactorCCache = 0.362;

                    pHandle->FactorPCache = 1.867;
                    break;
                case TCCCVT_COOPER_134:
                    pHandle->MinimumResponseTimeCache     = 0.041;

                    pHandle->FactorACache = 11.906;
                    pHandle->FactorBCache = 0.355;
                    pHandle->FactorCCache = 0.172;

                    pHandle->FactorPCache = 2.61;
                    break;
                case TCCCVT_COOPER_102:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 0.271;
                    pHandle->FactorBCache = 0.016;
                    pHandle->FactorCCache = 0.144;

                    pHandle->FactorPCache = 4.441;
                    break;
                case TCCCVT_COOPER_135:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 12.355;
                    pHandle->FactorBCache = 0.501;
                    pHandle->FactorCCache = 0.145;

                    pHandle->FactorPCache = 1.96;
                    break;
                case TCCCVT_COOPER_140:
                    pHandle->MinimumResponseTimeCache     = 0.972;

                    pHandle->FactorACache = 15.341;
                    pHandle->FactorBCache = 0.853;
                    pHandle->FactorCCache = 0.432;

                    pHandle->FactorPCache = 1.74;
                    break;
                case TCCCVT_COOPER_106:
                    pHandle->MinimumResponseTimeCache     = 0.011;

                    pHandle->FactorACache = 1.298;
                    pHandle->FactorBCache = 0.007;
                    pHandle->FactorCCache = 0.0;

                    pHandle->FactorPCache = 2.835;
                    break;
                case TCCCVT_COOPER_152:
                    pHandle->MinimumResponseTimeCache     = 29.51;

                    pHandle->FactorACache = 0.098;
                    pHandle->FactorBCache = 14.609;
                    pHandle->FactorCCache = 0.998;

                    pHandle->FactorPCache = 0.002;
                    break;
                case TCCCVT_COOPER_113:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 3.132;
                    pHandle->FactorBCache = 0.162;
                    pHandle->FactorCCache = -0.032;

                    pHandle->FactorPCache = 2.606;
                    break;
                case TCCCVT_COOPER_111:
                    pHandle->MinimumResponseTimeCache     = 0.016;

                    pHandle->FactorACache = 1.484;
                    pHandle->FactorBCache = 0.003;
                    pHandle->FactorCCache = 0.436;

                    pHandle->FactorPCache = 1.484;
                    break;
                case TCCCVT_COOPER_131:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 7.767;
                    pHandle->FactorBCache = 5.299;
                    pHandle->FactorCCache = -0.26;

                    pHandle->FactorPCache = 2.002;
                    break;
                case TCCCVT_COOPER_141:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 9.059;
                    pHandle->FactorBCache = 10.466;
                    pHandle->FactorCCache = 0.241;

                    pHandle->FactorPCache = 1.792;
                    break;
                case TCCCVT_COOPER_142:
                    pHandle->MinimumResponseTimeCache     = 0.029;

                    pHandle->FactorACache = 32.548;
                    pHandle->FactorBCache = 0.005;
                    pHandle->FactorCCache = 0.264;

                    pHandle->FactorPCache = 2.153;
                    break;
                case TCCCVT_COOPER_119:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 2.616;
                    pHandle->FactorBCache = 0.396;
                    pHandle->FactorCCache = 0.678;

                    pHandle->FactorPCache = 1.615;
                    break;
                case TCCCVT_COOPER_112:
                    pHandle->MinimumResponseTimeCache     = 0.022;

                    pHandle->FactorACache = 1.598;
                    pHandle->FactorBCache = 0.021;
                    pHandle->FactorCCache = 0.343;

                    pHandle->FactorPCache = 1.773;
                    break;
                case TCCCVT_COOPER_103:
                    pHandle->MinimumResponseTimeCache     = 0.014;

                    pHandle->FactorACache = 0.142;
                    pHandle->FactorBCache = 0.009;
                    pHandle->FactorCCache = 0.61;

                    pHandle->FactorPCache = 1.536;
                    break;
                case TCCCVT_COOPER_151:
                    pHandle->MinimumResponseTimeCache     = 0.453;

                    pHandle->FactorACache = 22.995;
                    pHandle->FactorBCache = 0.423;
                    pHandle->FactorCCache = 0.535;

                    pHandle->FactorPCache = 2.271;
                    break;
                default:
                    pHandle->MinimumResponseTimeCache     = 0.0;

                    pHandle->FactorACache = 0.0;
                    pHandle->FactorBCache = 0.0;
                    pHandle->FactorCCache = 0.0;

                    pHandle->FactorPCache = 0.0;
                    break;
                }

        MinimumResponseTimeCache        = pHandle->MinimumResponseTimeCache;

        factor_a = pHandle->FactorACache;
        factor_b = pHandle->FactorBCache;
        factor_c = pHandle->FactorCCache;
        factor_p = pHandle->FactorPCache;

        float32 TimeDialMultiplier      = *(float32*)TagDataAddr_Get(&pHandle->TagTimeDialMultiplier);
        float32 ConstantTimeAdd         = *(float32*)TagDataAddr_Get(&pHandle->TagConstantTimeAdder);
        float32 MinimumResponseTime     = *(float32*)TagDataAddr_Get(&pHandle->TagMinimumResponseTime);


        tp = TimeDialMultiplier * ((factor_a/(pow(multiple, factor_p) - factor_c)) + factor_b) + ConstantTimeAdd;

        if(MinimumResponseTimeCache > 0.0)
        {
            if(tp < MinimumResponseTimeCache)            tp = MinimumResponseTimeCache;
        }
        else
        {
            if(tp < MinimumResponseTime)            tp = MinimumResponseTime;
        }

    }
    /*When reset*/
    else                                            tp = 0.0;

    return tp;
}

float32 calcTpWithIEC(Tcc* pHandle, float32 multiple, bool is_reset)
{
    float32 tp, factor_a, factor_p;

    if(is_reset == false)
    {
        switch(pHandle->CurveType)
        {
            case TCCCVT_IEC_C1:
                pHandle->FactorACache = 0.14;
                pHandle->FactorPCache = 0.02;
                break;
            case TCCCVT_IEC_C2:
                pHandle->FactorACache = 13.5;
                pHandle->FactorPCache = 1.0;
                break;
            case TCCCVT_IEC_C3:
                pHandle->FactorACache = 80.0;
                pHandle->FactorPCache = 2.0;
                break;
            case TCCCVT_IEC_C4:
                pHandle->FactorACache = 120.0;
                pHandle->FactorPCache = 1.0;
                break;
            case TCCCVT_IEC_C5:
                pHandle->FactorACache = 0.05;
                pHandle->FactorPCache = 0.04;
                break;
            default:
                break;
        }

        factor_a = pHandle->FactorACache;
        factor_p = pHandle->FactorPCache;


        float32 TimeDialMultiplier      = *(float32*)TagDataAddr_Get(&pHandle->TagTimeDialMultiplier);
        float32 ConstantTimeAdd         = *(float32*)TagDataAddr_Get(&pHandle->TagConstantTimeAdder);
        float32 MinimumResponseTime     = *(float32*)TagDataAddr_Get(&pHandle->TagMinimumResponseTime);

        tp = TimeDialMultiplier * ((factor_a/pow(multiple, factor_p) - 1.0)) + ConstantTimeAdd;

        if(tp < MinimumResponseTime)         tp = MinimumResponseTime;

    }
    /*When reset*/
    else                                    tp = 0.0;

    return tp;
}

float32 calcTpWithUS(Tcc* pHandle, float32 multiple, bool is_reset)
{
    float32 tp, factor_a, factor_b, factor_p;

    if(is_reset == false)
    {
        switch(pHandle->CurveType)
        {
            case TCCCVT_US_U1:
                pHandle->FactorACache = 0.0104;
                pHandle->FactorBCache = 0.0226;
                pHandle->FactorPCache = 0.02;
                break;
            case TCCCVT_US_U2:
                pHandle->FactorACache = 5.95;
                pHandle->FactorBCache = 0.18;
                pHandle->FactorPCache = 2.0;
                break;
            case TCCCVT_US_U3:
                pHandle->FactorACache = 3.88;
                pHandle->FactorBCache = 0.0963;
                pHandle->FactorPCache = 2.0;
                break;
            case TCCCVT_US_U4:
                pHandle->FactorACache = 5.67;
                pHandle->FactorBCache = 0.0352;
                pHandle->FactorPCache = 2.0;
                break;
            case TCCCVT_US_U5:
                pHandle->FactorACache = 0.00342;
                pHandle->FactorBCache = 0.00262;
                pHandle->FactorPCache = 0.02;
                break;
            default:
                break;
        }

        factor_a = pHandle->FactorACache;
        factor_b = pHandle->FactorBCache;
        factor_p = pHandle->FactorPCache;

        float32 TimeDialMultiplier      = *(float32*)TagDataAddr_Get(&pHandle->TagTimeDialMultiplier);
        float32 ConstantTimeAdd         = *(float32*)TagDataAddr_Get(&pHandle->TagConstantTimeAdder);
        float32 MinimumResponseTime     = *(float32*)TagDataAddr_Get(&pHandle->TagMinimumResponseTime);

        tp = TimeDialMultiplier * (factor_b + (factor_a/(pow(multiple, factor_p) - 1.0))) + ConstantTimeAdd;

        if(tp < MinimumResponseTime)        tp = MinimumResponseTime;
    }
    /*When reset*/
    else                            tp = 0.0;

    return tp;
}

float32 calcTpWithUser(Tcc* pHandle, float32 multiple, bool is_reset)
{
    float32 tp;

    if(is_reset)
    {

        float32 TimeDialMultiplier      = *(float32*)TagDataAddr_Get(&pHandle->TagTimeDialMultiplier);

        float32 factor_a = *(float32*)TagDataAddr_Get(&pHandle->TagFactorA);
        float32 factor_b = *(float32*)TagDataAddr_Get(&pHandle->TagFactorB);
        float32 factor_p = *(float32*)TagDataAddr_Get(&pHandle->TagFactorP);

        if(factor_p == 0.0)                 factor_p = 1.0;


        float32 ConstantTimeAdd         = *(float32*)TagDataAddr_Get(&pHandle->TagConstantTimeAdder);
        float32 MinimumResponseTime     = *(float32*)TagDataAddr_Get(&pHandle->TagMinimumResponseTime);

        tp = TimeDialMultiplier * (factor_b + (factor_a / (pow(multiple, factor_p) -1.0))) + ConstantTimeAdd;

        if(tp < MinimumResponseTime)            tp = MinimumResponseTime;

    }

    else                                tp = 0.0;

    return tp;
}

float32 calcTpWithDef(Tcc* pHandle, float32 multiple, bool is_reset)
{
    float32 tp;

    if(is_reset == false)           tp = *(float32*)TagDataAddr_Get(&pHandle->TagDefiniteTimeDelay);

    else                            tp = 0.0;

    return tp;
}

float32 calculateTccProgress(Tcc *pHandle, float32 multiple, bool is_reset)
{
    float32 tp = 0.0, progress = 0.0;

    if(pHandle->p_tp_func)              tp = pHandle->p_tp_func(pHandle, multiple, is_reset);

    if(tp > 0.0)                        progress = TccQuaterCycleTime/tp;

    return progress;
}

void LogicTccUse(Tcc*  pHandle,  float32 pickup_sp,     float32 i_max,
                 bool *p_pickup, bool *p_curve_timeout, bool *p_reset)
{

    TccCurveType TagDataCurveType = (TccCurveType)(*(uint16*)TagDataAddr_Get(&pHandle->TagCurveType));
    bool is_pickup    = false;

    bool ElementReset = *(bool*)TagDataAddr_Get(&pHandle->TagElementReset);

    /*When Tcc Curve Type Changed*/
    if(TagDataCurveType != pHandle->CurveType)
    {
        pHandle->CurveType = TagDataCurveType;

        uint16 Group_ID = TagDataCurveType & 0xFF00;

        switch(Group_ID)
        {
        case TCCCVT_GRP_COOPER:
            pHandle->p_tp_func = calcTpWithCooper;
            break;
        case TCCCVT_GRP_IEC:
            pHandle->p_tp_func = calcTpWithIEC;
            break;
        case TCCCVT_GRP_US:
            pHandle->p_tp_func = calcTpWithUS;
            break;
        case TCCCVT_GRP_USER:
            pHandle->p_tp_func = calcTpWithUser;
            break;
        case TCCCVT_GRP_DEF:
            pHandle->p_tp_func = calcTpWithDef;
            break;
        default:
            return; // error: not supported type
        }
    }

    if(i_max >= pickup_sp)          is_pickup = true;

    if(is_pickup)
    {
        pHandle->started = true;

        if(ElementReset == false)       pHandle->reset_cnt = 0;

        float32 multiple = i_max/pickup_sp;

        pHandle->acc_val += calculateTccProgress(pHandle, multiple, !is_pickup);
    }
    else
    {
        if(ElementReset == false)
        {
            if(TagDataCurveType == TCCCVT_DEF)         pHandle->acc_val = 0;

            else
            {
                if(pHandle->acc_val > 0)
                {
                    pHandle->reset_cnt += 1;

                    if(pHandle->reset_cnt >= 4)
                    {
                        pHandle->acc_val    = 0;
                        pHandle->reset_cnt  = 0;
                    }
                }
            }
        }
        else
        {
            float32 multiple = i_max/pickup_sp;

            pHandle->acc_val -= calculateTccProgress(pHandle, multiple, !is_pickup);

            if(pHandle->acc_val <= 0.0)         pHandle->acc_val = 0;
        }
    }

    if(pHandle->acc_val <= 0.0)
    {
        if(p_curve_timeout)                     *p_curve_timeout = false;

        if(p_reset)
        {
            if(pHandle->started)                *p_reset = true;

            else                                *p_reset = false;
        }
    }
    else if(pHandle->acc_val >= 1.0)
    {
        if(p_curve_timeout)                     *p_curve_timeout = true;

        if(p_reset)                             *p_reset         = false;
    }
    else
    {
        if(p_curve_timeout)                     *p_curve_timeout = false;

        if(p_reset)                             *p_reset         = false;
    }

    if(p_pickup)                                *p_pickup        = is_pickup;

}

TccModule* TccObject_Load(void)
{
    return &TccObject;
}

void TccTickTime_Set(void)
{
    uint16 Hz = GET_TAG_SC_UI(ALS_SC_TARGSYS_FREQ);

    switch(Hz)
    {
    case 50:
        TccQuaterCycleTime = 0.005;
        break;
    case 60:
        TccQuaterCycleTime = 0.004166;
        break;
    }
}

