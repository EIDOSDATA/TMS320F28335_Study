/*
 * LogicRingBufferObject.c
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>
#include "src/app/logic/FunctionBlock/LogicRingBufferObject.h"

#pragma DATA_SECTION(LogicCircularBufObjectBufObject, "ZONE6DATA")
#pragma DATA_SECTION(FloatBuffer, "ZONE6DATA")

#define FLOAT_DATA_SIZE         2           /*2 Word*/

float32 FloatBuffer[USERLOGIC_CIRCULARBUF_OBJECT_MAX][USERLOGIC_RINGBUF_SIZE_MAX];

static LogicCircularModule   LogicCircularBufObject = {
.CircularBufRemaining  = USERLOGIC_CIRCULARBUF_OBJECT_MAX};

CircularBuffer* LogicRingBufCreate(CircularBufType type, uint16 size, void* pInitValue)
{
    uint16 ObjectRemain = LogicCircularBufObject.CircularBufRemaining;
    CircularBuffer* pRtn = NULL;
    uint16 i;

    if(ObjectRemain)
    {
        uint16 Index = USERLOGIC_CIRCULARBUF_OBJECT_MAX-ObjectRemain;
        pRtn = &LogicCircularBufObject.CircularBufObject[Index];

        memset(pRtn, 0, sizeof(CircularBuffer));

        pRtn->Type = type;

        if(type == FLOAT_TYPE)
        {
            pRtn->pFloatBuf = &FloatBuffer[Index][0];
            /*Charge Buffer*/
            float32 Temp = *(float32*)pInitValue;
            for(i=0; i<size; i++)
            {
                memcpy(pRtn->pFloatBuf+pRtn->Position, &Temp, FLOAT_DATA_SIZE);
                pRtn->Position++;
            }
                pRtn->Max    = size;
        }
        LogicCircularBufObject.CircularBufRemaining--;

    }
    return pRtn;
}

LogicCircularModule* LogicRingBufObject_Load(void)
{
    return &LogicCircularBufObject;
}

