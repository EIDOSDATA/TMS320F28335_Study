/*
 * rtc.h
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_FUNCTIONBLOCK_RTC_H_
#define LOGIC_FUNCTIONBLOCK_RTC_H_

#include "types.h"

void LogicRtcUse(uint16* p_year, uint16* p_mon, uint16* p_day, uint16* p_hour,
                 uint16* p_min,  uint16* p_sec, uint16* p_msec);

#endif /* LOGIC_FUNCTIONBLOCK_RTC_H_ */
