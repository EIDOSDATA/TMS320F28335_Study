/*
 * LogicRingBufferObject.h
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_FUNCTIONBLOCK_LOGICRINGBUFFEROBJECT_H_
#define LOGIC_FUNCTIONBLOCK_LOGICRINGBUFFEROBJECT_H_

#include "def.h"
#include "src/utils/circularbuf.h"

#define USERLOGIC_CIRCULARBUF_OBJECT_MAX                  10
#define USERLOGIC_RINGBUF_SIZE_MAX                        1500

typedef struct
{
    uint16              CircularBufRemaining;

    CircularBuffer      CircularBufObject[USERLOGIC_CIRCULARBUF_OBJECT_MAX];

} LogicCircularModule;

CircularBuffer* LogicRingBufCreate(CircularBufType type, uint16 size, void* pInitValue);

#endif /* LOGIC_FUNCTIONBLOCK_LOGICRINGBUFFEROBJECT_H_ */
