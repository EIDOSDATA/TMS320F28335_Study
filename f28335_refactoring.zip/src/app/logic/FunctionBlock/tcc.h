/*
 * tcc.h
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_FUNCTIONBLOCK_TCC_H_
#define LOGIC_FUNCTIONBLOCK_TCC_H_

#include "def.h"

#include "src/app/tag/tag_header.h"

#define USERLOGIC_TCC_OBJECT_MAX                                10
/*Forward Declaration*/
typedef struct  _Tcc _Tcc;

typedef float32 (*CalcTpFuncPtr)(_Tcc *p_tcc, float32 multiple, bool is_reset);

#define TCCCVT_GRP_COOPER   0x1000
#define TCCCVT_GRP_IEC      0x1100
#define TCCCVT_GRP_US       0x1200
#define TCCCVT_GRP_USER     0x1300
#define TCCCVT_GRP_DEF      0x1400

typedef enum
{
    TCCCVT_COOPER_101       = TCCCVT_GRP_COOPER + 1,
    TCCCVT_COOPER_102,      TCCCVT_COOPER_103,      TCCCVT_COOPER_104,      TCCCVT_COOPER_105,      TCCCVT_COOPER_106,      TCCCVT_COOPER_107,

    TCCCVT_COOPER_111       = TCCCVT_GRP_COOPER + 11,
    TCCCVT_COOPER_112,      TCCCVT_COOPER_113,

    TCCCVT_COOPER_115       = TCCCVT_GRP_COOPER + 15,
    TCCCVT_COOPER_116,      TCCCVT_COOPER_117,      TCCCVT_COOPER_118,      TCCCVT_COOPER_119,      TCCCVT_COOPER_120,

    TCCCVT_COOPER_131       = TCCCVT_GRP_COOPER + 31,
    TCCCVT_COOPER_132,      TCCCVT_COOPER_133,      TCCCVT_COOPER_134,      TCCCVT_COOPER_135,

    TCCCVT_COOPER_137       = TCCCVT_GRP_COOPER + 37,
    TCCCVT_COOPER_138,

    TCCCVT_COOPER_140       = TCCCVT_GRP_COOPER + 40,
    TCCCVT_COOPER_141,      TCCCVT_COOPER_142,

    TCCCVT_COOPER_151       = TCCCVT_GRP_COOPER + 51,
    TCCCVT_COOPER_152,

    TCCCVT_COOPER_161       = TCCCVT_GRP_COOPER + 61,
    TCCCVT_COOPER_162,      TCCCVT_COOPER_163,

    TCCCVT_COOPER_165       = TCCCVT_GRP_COOPER + 65,

    TCCCVT_IEC_C1           = TCCCVT_GRP_IEC + 1,
    TCCCVT_IEC_C2,          TCCCVT_IEC_C3,          TCCCVT_IEC_C4,          TCCCVT_IEC_C5,

    TCCCVT_US_U1            = TCCCVT_GRP_US + 1,
    TCCCVT_US_U2,           TCCCVT_US_U3,           TCCCVT_US_U4,           TCCCVT_US_U5,

    TCCCVT_USER             = TCCCVT_GRP_USER,

    TCCCVT_DEF              = TCCCVT_GRP_DEF,

    TCCCVT_MAX

} TccCurveType;

typedef struct _Tcc
{
    TagData TagCurveType;
    TagData TagTimeDialMultiplier;
    TagData TagDefiniteTimeDelay;
    TagData TagElementReset;
    TagData TagConstantTimeAdder;
    TagData TagMinimumResponseTime;

    TagData TagFactorA;
    TagData TagFactorB;
    TagData TagFactorP;

    CalcTpFuncPtr   p_tp_func;
    /*Cache Data*/
    uint16      CurveType;
    float32     MinimumResponseTimeCache;
    float32     FactorACache;
    float32     FactorBCache;
    float32     FactorCCache;
    float32     FactorPCache;

    // variables for running
    uint16      reset_cnt;
    float32     acc_val;
    bool        started; // to avoid the reset output as true when it started
} Tcc;

typedef struct
{
    uint16      TccObjectRemaing;
    Tcc         Object[USERLOGIC_TCC_OBJECT_MAX];

} TccModule;

TccModule* TccObject_Load(void);
void TccTickTime_Set(void);

Tcc* TccCreate(uint16 TagGroup1,       uint16  TagCurveType,           uint16 TagGroup2,      uint16  TagTimeDialMultiplier,
               uint16 TagGroup3,       uint16  TagDefiniteTimeDelay,   uint16 TagGroup4,      uint16  TagElementReset,
               uint16 TagGroup5,       uint16  TagConstTimeAdder,      uint16 TagGroup6,      uint16  TagMinimumResponseTime,
               uint16 TagGroup7,       uint16  TagFactorA,             uint16 TagGroup8,      uint16  TagFactorB,
               uint16 TagGroup9,       uint16  TagFactorP);

void LogicTccUse(Tcc*  pHandle,  float32 pickup_sp,       float32 i_max,
                 bool* p_pickup, bool*   p_curve_timeout, bool*   p_reset);
#endif /* LOGIC_FUNCTIONBLOCK_TCC_H_ */
