/*
 * EdgeDetector.h
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_BUILTINLOIGIC_EDGEDETECTOR_H_
#define LOGIC_BUILTINLOIGIC_EDGEDETECTOR_H_

#include "def.h"

#define USERLOGIC_EDGE_DETECTOR_OBJECT_MAX                      150

/*Edge Detector*/
typedef enum
{
    EDT_RISING,
    EDT_FALLING

} EdgeDetectorType;

typedef struct
{
    EdgeDetectorType        Type;
    bool                    LastValue;

} EdgeDetector;

typedef struct
{
    uint16                  EdgeDetectorRemaing;
    EdgeDetector            Object[USERLOGIC_EDGE_DETECTOR_OBJECT_MAX];

} EdgeDetectorModule;

EdgeDetectorModule* EdgeDetector_Load(void);

EdgeDetector* EdgeDetectorCreate(EdgeDetectorType Type, bool DFT_LastValue);
void UseEdgeDetector(EdgeDetector* pHandle, bool in, bool *p_out);

#endif /* LOGIC_BUILTINLOIGIC_EDGEDETECTOR_H_ */
