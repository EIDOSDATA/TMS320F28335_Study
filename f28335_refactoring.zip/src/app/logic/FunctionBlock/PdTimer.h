/*
 * PdTimer.h
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_FUNCTIONBLOCK_PDTIMER_H_
#define LOGIC_FUNCTIONBLOCK_PDTIMER_H_

#include "def.h"
#include "src/app/tag/tag_db.h"

#define USERLOGIC_PDTIMER_OBJECT_MAX       200

typedef enum
{
    PDTT_NULL,
    PDTT_CYCLE,
    PDTT_SEC,

    PDTT_TAG,

} PdTimerType;

typedef struct
{
    /*Pickup Timer*/
    PdTimerType     PickUpTimerType;
    bool            PickUpTimerActive;
    TagData         PickupTag;


    float32         PickUpTimerTimeout;
    float32         PickUpTimerDuration;
    uint32          PickUpTimerLastSystemTicks;

    /*Dropout Timer*/
    PdTimerType     DropOutTimerType;
    bool            DropOutTimerActive;
    TagData         DropOutTag;

    float32         DropOutTimerTimeout;
    float32         DropOutTimerDuration;
    uint32          DropOutTimerLastSystemTicks;

    bool            TimerResult;
} PdTimer;

typedef struct
{
    uint16          PdTimerRemaing;
    PdTimer         Object[USERLOGIC_PDTIMER_OBJECT_MAX];

} PdTimerModule;

PdTimerModule* PdTimer_Load(void);
PdTimer* PdTimerCreate(PdTimerType PickUpTimerType,  float32 PickUpTimerTimeout,
                       uint16  PickupTagGroup,       uint16  PickupTagIndex,
                       PdTimerType DropOutTimerType, float32 DropOutTimerTimeout,
                       uint16  DropOutTagGroup,      uint16  DropOutTagIndex);
void PdTimerUse(PdTimer *pHandle, bool in, bool reset, bool *p_out);

#endif /* LOGIC_FUNCTIONBLOCK_PDTIMER_H_ */
