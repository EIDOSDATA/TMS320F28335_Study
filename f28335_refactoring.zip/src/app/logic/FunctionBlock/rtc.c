/*
 * rtc.c
 *
 *  Created on: 2023. 12. 15.
 *      Author: ShinSung Industrial Electric
 */

#include <src/app/logic/FunctionBlock/rtc.h>
#include "time.h"

void LogicRtcUse(uint16* p_year, uint16* p_mon, uint16* p_day, uint16* p_hour,
                 uint16* p_min,  uint16* p_sec, uint16* p_msec)
{
    Logic_TimeStamp TimeStamp;

    Logic_TimeStamping(&TimeStamp);

    *p_year  = TimeStamp.Year;
    *p_mon   = TimeStamp.Month;
    *p_day   = TimeStamp.Day;
    *p_hour  = TimeStamp.Hour;
    *p_min   = TimeStamp.Min;
    *p_sec   = TimeStamp.Sec;
    *p_msec  = TimeStamp.msec;
}
