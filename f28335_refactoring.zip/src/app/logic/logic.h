/*
 * logic_.h
 *
 *  Created on: 2023. 12. 12.
 *      Author: ShinSung Industrial Electric
 */

#ifndef LOGIC_LOGIC_H_
#define LOGIC_LOGIC_H_

#include "types.h"

/*BuiltinLogic*/
#include "src/app/logic/FunctionBlock/EdgeDetector.h"
#include "src/app/logic/FunctionBlock/LogicRingBufferObject.h"
#include "src/app/logic/FunctionBlock/PdTimer.h"
#include "src/app/logic/FunctionBlock/tcc.h"


#include "src/utils/ringbuf.h"

#include "src/app/tag/tag_db.h"
#include "src/app/tag/tag_db_macro.h"

#define BUILTIN_LOGIC_COUNT_MAX                 48
#define USERLOGIC_COUNT_MAX                     48

typedef struct
{
    uint16              *pSytem_Frequency;

    uint16              UserLogicCount;
    void                (*pfBuiltInLogic[BUILTIN_LOGIC_COUNT_MAX])(void);
    void                (*pfUserLogic[USERLOGIC_COUNT_MAX])(void);

    /*EdgeDetector*/
    EdgeDetectorModule*   pEdgeDetectorObject;

    /*PdTimer*/
    PdTimerModule*        pPdTimerObject;
    float32*              pPdTimerTickTime;

    /*TCC*/
    TccModule*            pTccObject;

} LogicContext;

extern void     Logic_Task(UArg arg0, UArg arg1);
bool            UserLogic_Add(uint16 count, ...);

#endif /* LOGIC_LOGIC_H_ */
