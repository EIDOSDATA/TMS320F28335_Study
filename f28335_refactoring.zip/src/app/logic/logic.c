/*
 * Logic.c
 *
 *  Created on: 2023. 10. 6.
 *      Author: ShinSung Industrial Electric
 */


#include "def.h"

#include "src/app/logic/logic.h"

/*FunctionBlock TEST*/
#include "FunctionBlock/FunctionBlock_Interface.h"

/*
 * OS instance
 */
extern Semaphore_Handle SemLogic;

#pragma DATA_SECTION (LogicCtx, "ZONE6DATA")

static LogicContext LogicCtx;

void Logic_Task(UArg arg0, UArg arg1)
{

    uint16 i;

    SystemTime_t * pTime = TimeObjectGet();

    DEBUG_Printf("%d. %d. %d. %d : %d : %d : %d \n",pTime->tm_year + 1900, pTime->tm_mon, pTime->tm_mday, pTime->tm_hour,
                                                    pTime->tm_min, pTime->tm_sec, pTime->tm_ms);
    /*Load BuiltinLogic Module*/
    LogicCtx.pEdgeDetectorObject    = EdgeDetector_Load();
    LogicCtx.pPdTimerObject         = PdTimer_Load();
    LogicCtx.pTccObject             = TccObject_Load();

    /*Set TccQuaterCycleTime*/
    TccTickTime_Set();

    while(1)
    {
        SEMAPHORE_PEND(SemLogic, WAIT_FOREVER);

        /*Start UserLogic*/

        for(i=0; i<LogicCtx.UserLogicCount; i++)
        {
            LogicCtx.pfUserLogic[i]();
        }

    }
}


bool UserLogic_Add(uint16 count, ...)
{
    uint16 i;
    va_list args;

    if(count > USERLOGIC_COUNT_MAX)
    {
        DEBUG_Msg("UserLogic count overflow\n");
        return false;
    }

    va_start(args, count);

    for(i=0; i<count; i++)
    {
        LogicCtx.pfUserLogic[i] = va_arg(args, void*);
    }

    va_end(args);

    LogicCtx.UserLogicCount = i;

    return true;
}

LogicContext* LogicContextReturn(void)
{
    return &LogicCtx;
}

