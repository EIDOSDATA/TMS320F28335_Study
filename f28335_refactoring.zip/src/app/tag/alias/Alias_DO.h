/*
 * Alias_DO.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_DO_H_
#define USERLOGIC_ALIAS_DO_H_

enum
{
    ALS_DO_CLOSE,
    ALS_DO_TRIP,
    ALS_DO_DOBT,
    ALS_DO_PWSEALIN,
    ALS_DO_MODEM,
    ALS_DO_ALARM,
    ALS_DO_DOSL,

    TAG_DO_INDEX_MAX,
};


#define TID_DO                                  3
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
enum
{
    TID_DO_GROUP0  =  BUILD_L2CODE(TID_DO, 0),     TID_DO_GROUP1  =  BUILD_L2CODE(TID_DO, 1)
};

/*Group Index 0*/
enum
{
    TID_DO_RAW0         = TID_DO_GROUP0,
    TID_DO_RAW1,        TID_DO_RAW2,            TID_DO_RAW3,            TID_DO_RAW4,
    TID_DO_RAW5,        TID_DO_RAW6,            TID_DO_RAW7,            TID_DO_RAW8,
    TID_DO_RAW9,        TID_DO_RAW10,           TID_DO_RAW11,           TID_DO_RAW12,
    TID_DO_RAW13,       TID_DO_RAW14,           TID_DO_RAW15
};

/*Group Index 1*/
enum
{
    TID_DO_LOGICAL0     = TID_DO_GROUP1,
    TID_DO_LOGICAL1,    TID_DO_LOGICAL2,        TID_DO_LOGICAL3,        TID_DO_LOGICAL4,
    TID_DO_LOGICAL5,    TID_DO_LOGICAL6,        TID_DO_LOGICAL7,        TID_DO_LOGICAL8,
    TID_DO_LOGICAL9,    TID_DO_LOGICAL10,       TID_DO_LOGICAL11,       TID_DO_LOGICAL12,
    TID_DO_LOGICAL13,   TID_DO_LOGICAL14,       TID_DO_LOGICAL15
};

/*For HMIS*/
typedef enum
{
    TID_DO_CLOSE = TID_DO_LOGICAL0,
    TID_DO_TRIP,
    TID_DO_DOBT,
    TID_DO_PWSEALIN,
    TID_DO_MODEM,
    TID_DO_ALARM,
    TID_DO_DOSL,

} TAGID_DO;

#endif /* USERLOGIC_ALIAS_DO_H_ */
