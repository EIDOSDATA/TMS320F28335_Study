/*
 * Alias_NMV.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_NMV_H_
#define USERLOGIC_ALIAS_NMV_H_
/*TAG NMV UI*/
enum
{
    ALS_NMV_SH0,
    ALS_NMV_SH1,
    ALS_NMV_SH2,
    ALS_NMV_SH3,
    ALS_NMV_79RST_COUNT,
    ALS_NMV_79RSLT_COUNT,
    ALS_NMV_SH_COUNT,
    ALS_NMV_RS_L_T_COUNT,
    ALS_NMV_79OI1_COUNT,
    ALS_NMV_79OI2_COUNT,
    ALS_NMV_79OI3_COUNT,
    ALS_NMV_79OIT_COUNT,
    ALS_NMV_BLD,
    ALS_NMV_NORD,
    ALS_NMV_ARD,
    ALS_NMV_UI_SPARE1,

    ALS_NMV_UI_SPARE2,
    ALS_NMV_UI_SPARE3,
    ALS_NMV_UI_SPARE4,
    ALS_NMV_UI_SPARE5,

    TAG_NMV_UI_INDEX_MAX,
};
/*TAG NMV F*/
enum
{
    ALS_NMV_50P3P,
    ALS_NMV_50P4P,
    ALS_NMV_50N3P,
    ALS_NMV_50N4P,
    ALS_NMV_51P3P,
    ALS_NMV_51N3P,
    ALS_NMV_51P4P,
    ALS_NMV_51N4P,
    ALS_NMV_59P1P,
    ALS_NMV_59N1P,
    ALS_NMV_59P2P,
    ALS_NMV_27P1P,
    ALS_NMV_27P2P,
    ALS_NMV_APR,
    ALS_NMV_V1P,
    ALS_NMV_3V0P,

    ALS_NMV_BG3I0,
    ALS_NMV_BGI2_I1,

    ALS_DG_BAT_TEMP,
    ALS_DG_DROP_VOLT,
    ALS_DG_DEAD_VOLT,

    ALS_NMV_VA_MAX,
    ALS_NMV_VB_MAX,
    ALS_NMV_VC_MAX,
    ALS_NMV_IA_MAX,
    ALS_NMV_IB_MAX,
    ALS_NMV_IC_MAX,
    ALS_NMV_IN_MAX,
    ALS_NMV_YCD,
    ALS_NMV_OLD,
    ALS_NMV_LOVD,
    ALS_NMV_UVD,

    ALS_NMV_BCD_ADD,
    ALS_NMV_F_SPARE1,
    ALS_NMV_F_SPARE2,
    ALS_NMV_F_SPARE3,
    ALS_NMV_F_SPARE4,
    ALS_NMV_F_SPARE5,

    TAG_NMV_F_INDEX_MAX,
};
/*TAG ID*/
#define TID_NMV                                 5
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_NMV_GROUP0  =  BUILD_L2CODE(TID_NMV, 0),     TID_NMV_GROUP1  =  BUILD_L2CODE(TID_NMV, 1),
    TID_NMV_GROUP2  =  BUILD_L2CODE(TID_NMV, 2),     TID_NMV_GROUP3  =  BUILD_L2CODE(TID_NMV, 3),
    TID_NMV_GROUP4  =  BUILD_L2CODE(TID_NMV, 4),     TID_NMV_GROUP5  =  BUILD_L2CODE(TID_NMV, 5),
};


/*Group Index 0 UI(Unsigned Integer Type)*/
enum
{
    TID_NMV_UI0_0       = TID_NMV_GROUP0,
    TID_NMV_UI0_1,      TID_NMV_UI0_2,          TID_NMV_UI0_3,          TID_NMV_UI0_4,
    TID_NMV_UI0_5,      TID_NMV_UI0_6,          TID_NMV_UI0_7,          TID_NMV_UI0_8,
    TID_NMV_UI0_9,      TID_NMV_UI0_10,         TID_NMV_UI0_11,         TID_NMV_UI0_12,
    TID_NMV_UI0_13,     TID_NMV_UI0_14,         TID_NMV_UI0_15
};

/*Group Index 1 UI(Unsigned Integer Type)*/
enum
{
    TID_NMV_UI1_0       = TID_NMV_GROUP1,
    TID_NMV_UI1_1,      TID_NMV_UI1_2,          TID_NMV_UI1_3,          TID_NMV_UI1_4,
    TID_NMV_UI1_5,      TID_NMV_UI1_6,          TID_NMV_UI1_7,          TID_NMV_UI1_8,
    TID_NMV_UI1_9,      TID_NMV_UI1_10,         TID_NMV_UI1_11,         TID_NMV_UI1_12,
    TID_NMV_UI1_13,     TID_NMV_UI1_14,         TID_NMV_UI1_15
};

/*Group Index 2 F(Floating Type)*/
enum
{
    TID_NMV_F0_0        = TID_NMV_GROUP2,
    TID_NMV_F0_1,       TID_NMV_F0_2,           TID_NMV_F0_3,           TID_NMV_F0_4,
    TID_NMV_F0_5,       TID_NMV_F0_6,           TID_NMV_F0_7,           TID_NMV_F0_8,
    TID_NMV_F0_9,       TID_NMV_F0_10,          TID_NMV_F0_11,          TID_NMV_F0_12,
    TID_NMV_F0_13,      TID_NMV_F0_14,          TID_NMV_F0_15
};

/*Group Index 3 F(Floating Type)*/
enum
{
    TID_NMV_F1_0        = TID_NMV_GROUP3,
    TID_NMV_F1_1,       TID_NMV_F1_2,           TID_NMV_F1_3,           TID_NMV_F1_4,
    TID_NMV_F1_5,       TID_NMV_F1_6,           TID_NMV_F1_7,           TID_NMV_F1_8,
    TID_NMV_F1_9,       TID_NMV_F1_10,          TID_NMV_F1_11,          TID_NMV_F1_12,
    TID_NMV_F1_13,      TID_NMV_F1_14,          TID_NMV_F1_15

};

/*Group Index 4 F(Floating Type)*/
enum
{
    TID_NMV_F2_0        = TID_NMV_GROUP4,
    TID_NMV_F2_1,       TID_NMV_F2_2,           TID_NMV_F2_3,           TID_NMV_F2_4,
    TID_NMV_F2_5,       TID_NMV_F2_6,           TID_NMV_F2_7,           TID_NMV_F2_8,
    TID_NMV_F2_9,       TID_NMV_F2_10,          TID_NMV_F2_11,          TID_NMV_F2_12,
    TID_NMV_F2_13,      TID_NMV_F2_14,          TID_NMV_F2_15
};

typedef enum
{
    TID_NMV_SH0         = TID_NMV_UI0_0,
    TID_NMV_SH1,
    TID_NMV_SH2,
    TID_NMV_SH3,
    TID_NMV_79RST_COUNT,
    TID_NMV_79RSLT_COUNT,
    TID_NMV_SH_COUNT,
    TID_NMV_RS_L_T_COUNT,
    TID_NMV_79OI1_COUNT,
    TID_NMV_79OI2_COUNT,
    TID_NMV_79OI3_COUNT,
    TID_NMV_79OIT_COUNT,
    TID_NMV_BLD,
    TID_NMV_NORD,
    TID_NMV_ARD,
    TID_NMV_UI_SPARE1,

    TID_NMV_UI_SPARE2       = TID_NMV_UI1_0,
    TID_NMV_UI_SPARE3,
    TID_NMV_UI_SPARE4,
    TID_NMV_UI_SPARE5,

} TAGID_NMV_UI;

typedef enum
{
    TID_NMV_50P3P           = TID_NMV_F0_0,
    TID_NMV_50P4P,
    TID_NMV_50N3P,
    TID_NMV_50N4P,
    TID_NMV_51P3P,
    TID_NMV_51N3P,
    TID_NMV_51P4P,
    TID_NMV_51N4P,
    TID_NMV_59P1P,
    TID_NMV_59N1P,
    TID_NMV_59P2P,
    TID_NMV_27P1P,
    TID_NMV_27P2P,
    TID_NMV_APR,
    TID_NMV_V1P,
    TID_NMV_3V0P,

    TID_NMV_BG3I0           = TID_NMV_F1_0,
    TID_NMV_BGI2_I1,
    TID_DG_BAT_TEMP,
    TID_DG_DROP_VOLT,
    TID_DG_DEAD_VOLT,

    TID_NMV_VA_MAX          = TID_NMV_F1_5,
    TID_NMV_VB_MAX,
    TID_NMV_VC_MAX,
    TID_NMV_IA_MAX,
    TID_NMV_IB_MAX,
    TID_NMV_IC_MAX,
    TID_NMV_IN_MAX,
    TID_NMV_YCD,
    TID_NMV_OLD,
    TID_NMV_LOVD,
    TID_NMV_UVD,

    TID_NMV_BCD_ADD         = TID_NMV_F2_0,
    TID_NMV_F_SPARE1,
    TID_NMV_F_SPARE2,
    TID_NMV_F_SPARE3,
    TID_NMV_F_SPARE4,
    TID_NMV_F_SPARE5,

} TAGID_NMV_F;

#endif /* USERLOGIC_ALIAS_NMV_H_ */
