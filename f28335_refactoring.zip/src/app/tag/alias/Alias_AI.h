/*
 * Alias_AI.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_AI_H_
#define USERLOGIC_ALIAS_AI_H_

enum
{
    ALS_AI_RMS_VA_MAX,
    ALS_AI_RMS_VB_MAX,
    ALS_AI_RMS_VC_MAX,
    ALS_AI_RMS_IA_MAX,
    ALS_AI_RMS_IB_MAX,
    ALS_AI_RMS_IC_MAX,
    ALS_AI_RMS_IN_MAX,
    ALS_AI_RMS_VA,
    ALS_AI_RMS_VB,
    ALS_AI_RMS_VC,
    ALS_AI_RMS_VR,
    ALS_AI_RMS_VS,
    ALS_AI_RMS_VT,
    ALS_AI_RMS_IA,
    ALS_AI_RMS_IB,
    ALS_AI_RMS_IC,
    ALS_AI_RMS_IN,

    ALS_AI_ANG_VA,
    ALS_AI_ANG_VB,
    ALS_AI_ANG_VC,
    ALS_AI_ANG_VR,
    ALS_AI_ANG_VS,
    ALS_AI_ANG_VT,
    ALS_AI_ANG_IA,
    ALS_AI_ANG_IB,
    ALS_AI_ANG_IC,
    ALS_AI_ANG_IN,

    ALS_AI_FREQ_VA,
    ALS_AI_FREQ_VB,
    ALS_AI_FREQ_VC,
    ALS_AI_FREQ_VR,
    ALS_AI_FREQ_VS,
    ALS_AI_FREQ_VT,

    ALS_AI_FREQ_P_VA,
    ALS_AI_FREQ_P_VB,
    ALS_AI_FREQ_P_VC,
    ALS_AI_FREQ_P_VR,
    ALS_AI_FREQ_P_VS,
    ALS_AI_FREQ_P_VT,

    ALS_AI_RMS_VAB,
    ALS_AI_RMS_VBC,
    ALS_AI_RMS_VCA,
    ALS_AI_RMS_VRS,
    ALS_AI_RMS_VST,
    ALS_AI_RMS_VTR,
    ALS_AI_ANG_VAB,
    ALS_AI_ANG_VBC,
    ALS_AI_ANG_VCA,
    ALS_AI_ANG_VRS,
    ALS_AI_ANG_VST,
    ALS_AI_ANG_VTR,
    ALS_AI_RMS_V0,
    ALS_AI_RMS_V1,
    ALS_AI_RMS_V2,
    ALS_AI_RMS_VR0,
    ALS_AI_RMS_VR1,
    ALS_AI_RMS_VR2,
    ALS_AI_ANG_V0,
    ALS_AI_ANG_V1,
    ALS_AI_ANG_V2,
    ALS_AI_ANG_VR0,
    ALS_AI_ANG_VR1,
    ALS_AI_ANG_VR2,
    ALS_AI_RMS_I0,
    ALS_AI_RMS_I1,
    ALS_AI_RMS_I2,
    ALS_AI_ANG_I0,
    ALS_AI_ANG_I1,
    ALS_AI_ANG_I2,
    ALS_AI_APPARENT_A,
    ALS_AI_APPARENT_B,
    ALS_AI_APPARENT_C,
    ALS_AI_APPARENT_TOTAL,
    ALS_AI_ACTIVE_A,
    ALS_AI_ACTIVE_B,
    ALS_AI_ACTIVE_C,
    ALS_AI_ACTIVE_TOTAL,
    ALS_AI_REACTIVE_A,
    ALS_AI_REACTIVE_B,
    ALS_AI_REACTIVE_C,
    ALS_AI_REACTIVE_TOTAL,
    ALS_AI_PF_A,
    ALS_AI_PF_B,
    ALS_AI_PF_C,
    ALS_AI_PF_TOTAL,

    ALS_AI_12VAN,
    ALS_AI_AIMODFB,
    ALS_AI_12VAP,
    ALS_AI_AICPFB,
    ALS_AI_REF_DP,
    ALS_AI_AIOPFB,
    ALS_AI_CTEMP,
    ALS_AI_AIBATV,
    ALS_AI_AICHV,
    ALS_AI_AIOPV,
    ALS_AI_RMS_IA_DISP,
    ALS_AI_RMS_IB_DISP,
    ALS_AI_RMS_IC_DISP,
    ALS_AI_RMS_IN_DISP,

    TAG_AI_INDEX_MAX,
};

/*TAG ID*/
#define TID_AI                                  1
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
enum
{
    TID_AI_GROUP0  =  BUILD_L2CODE(TID_AI, 0),     TID_AI_GROUP1  =  BUILD_L2CODE(TID_AI, 1),      TID_AI_GROUP2  =  BUILD_L2CODE(TID_AI, 2),
    TID_AI_GROUP3  =  BUILD_L2CODE(TID_AI, 3),     TID_AI_GROUP4  =  BUILD_L2CODE(TID_AI, 4),      TID_AI_GROUP5  =  BUILD_L2CODE(TID_AI, 5),
    TID_AI_GROUP6  =  BUILD_L2CODE(TID_AI, 6),     TID_AI_GROUP7  =  BUILD_L2CODE(TID_AI, 7),      TID_AI_GROUP8  =  BUILD_L2CODE(TID_AI, 8),
    TID_AI_GROUP9  =  BUILD_L2CODE(TID_AI, 9),     TID_AI_GROUP10 =  BUILD_L2CODE(TID_AI, 10),     TID_AI_GROUP11 =  BUILD_L2CODE(TID_AI, 11),
    TID_AI_GROUP12 =  BUILD_L2CODE(TID_AI, 12),    TID_AI_GROUP13 =  BUILD_L2CODE(TID_AI, 13),     TID_AI_GROUP14 =  BUILD_L2CODE(TID_AI, 14),
    TID_AI_GROUP15 =  BUILD_L2CODE(TID_AI, 15),    TID_AI_GROUP16 =  BUILD_L2CODE(TID_AI, 16),     TID_AI_GROUP17 =  BUILD_L2CODE(TID_AI, 17)

};

/*TAG ID*/
/*Group Index 0*/
enum
{
    TID_AI_RMS_VA_MAX           = TID_AI_GROUP0,
    TID_AI_RMS_VB_MAX,          TID_AI_RMS_VC_MAX,      TID_AI_RMS_IA_MAX,      TID_AI_RMS_IB_MAX,
    TID_AI_RMS_IC_MAX,          TID_AI_RMS_IN_MAX,      TID_AI_RMS_VA_MIN,      TID_AI_RMS_VB_MIN,
    TID_AI_RMS_VC_MIN,          TID_AI_RMS_IA_MIN,      TID_AI_RMS_IB_MIN,      TID_AI_RMS_IC_MIN,
    TID_AI_RMS_IN_MIN

};

/*Group Index 1*/
enum
{
    TID_AI_RMS_VA               = TID_AI_GROUP1,
    TID_AI_RMS_VB,              TID_AI_RMS_VC,          TID_AI_RMS_VR,          TID_AI_RMS_VS,
    TID_AI_RMS_VT,              TID_AI_RMS_IA,          TID_AI_RMS_IB,          TID_AI_RMS_IC,
    TID_AI_RMS_IN,              TID_AI_ADIF_ABS_VAR,    TID_AI_ADIF_ABS_VBS,    TID_AI_ADIF_ABS_VCT,
    TID_AI_PHSR0_RSVD0,         TID_AI_PHSR0_RSVD1,     TID_AI_PHSR0_RSVD2

};

/*Group Index 2*/
enum
{
    TID_AI_ANG_VA               = TID_AI_GROUP2,
    TID_AI_ANG_VB,              TID_AI_ANG_VC,          TID_AI_ANG_VR,          TID_AI_ANG_VS,
    TID_AI_ANG_VT,              TID_AI_ANG_IA,          TID_AI_ANG_IB,          TID_AI_ANG_IC,
    TID_AI_ANG_IN,              TID_AI_PHSR1_RSVD0,     TID_AI_PHSR1_RSVD1,     TID_AI_PHSR1_RSVD2,
    TID_AI_PHSR1_RSVD3,         TID_AI_PHSR1_RSVD4,     TID_AI_PHSR1_RSVD5
};

/*Group Index 3*/
enum
{
    TID_AI_FREQ_VA              = TID_AI_GROUP3,
    TID_AI_FREQ_VB,             TID_AI_FREQ_VC,         TID_AI_FREQ_VR,         TID_AI_FREQ_VS,
    TID_AI_FREQ_VT,             TID_AI_FREQ_P_VA,       TID_AI_FREQ_P_VB,       TID_AI_FREQ_P_VC,
    TID_AI_FREQ_P_VR,           TID_AI_FREQ_P_VS,       TID_AI_FREQ_P_VT,       TID_AI_FREQ_RSVD0,
    TID_AI_FREQ_RSVD1,          TID_AI_FREQ_RSVD2,      TID_AI_FREQ_RSVD3
};

/*Group Index 4*/
enum
{
    TID_AI_RMS_VAB              = TID_AI_GROUP4,
    TID_AI_RMS_VBC,             TID_AI_RMS_VCA,         TID_AI_RMS_VRS,         TID_AI_RMS_VST,
    TID_AI_RMS_VTR,             TID_AI_ANG_VAB,         TID_AI_ANG_VBC,         TID_AI_ANG_VCA,
    TID_AI_ANG_VRS,             TID_AI_ANG_VST,         TID_AI_ANG_VTR,         TID_AI_LINEV_RSVD0,
    TID_AI_LINEV_RSVD1,         TID_AI_LINEV_RSVD2,     TID_AI_LINEV_RSVD3
};

/*Group Index 5*/
enum
{
    TID_AI_RMS_V0               = TID_AI_GROUP5,
    TID_AI_RMS_V2,              TID_AI_RMS_VR0,         TID_AI_RMS_VR1,         TID_AI_RMS_VR2,
    TID_AI_ANG_V0,              TID_AI_ANG_V1,          TID_AI_ANG_V2,          TID_AI_ANG_VR0,
    TID_AI_ANG_VR1,             TID_AI_ANG_VR2,         TID_AI_RMS_V0_PREV,     TID_AI_RMS_V1_PREV,
    TID_AI_RMS_V2_PREV,         TID_AI_SYMC0_RSVD0
};

/*Group Index 6*/
enum
{
    TID_AI_RMS_I0               = TID_AI_GROUP6,
    TID_AI_RMS_I1,              TID_AI_RMS_I2,          TID_AI_ANG_I0,          TID_AI_ANG_I1,
    TID_AI_ANG_I2,              TID_AI_ADIF_V0_I0,      TID_AI_ADIF_V1_I1,      TID_AI_ADIF_V2_I2,
    TID_AI_ADIF_I0_V0,          TID_AI_ADIF_I1_V1,      TID_AI_ADIF_I2_V2,      TID_AI_RMS_I0_PREV,
    TID_AI_RMS_I1_PREV,         TID_AI_RMS_I2_PREV,     TID_AI_SYMC1_RSVD0

};

/*Group Index 7*/
enum
{
    TID_AI_APPARENT_A           = TID_AI_GROUP7,
    TID_AI_APPARENT_B,          TID_AI_APPARENT_C,      TID_AI_APPARENT_TOTAL,  TID_AI_ACTIVE_A,
    TID_AI_ACTIVE_B,            TID_AI_ACTIVE_C,        TID_AI_ACTIVE_TOTAL,    TID_AI_REACTIVE_A,
    TID_AI_REACTIVE_B,          TID_AI_REACTIVE_C,      TID_AI_REACTIVE_TOTAL,  TID_AI_PWR0_RSVD0,
    TID_AI_PWR0_RSVD1,          TID_AI_PWR0_RSVD2,      TID_AI_PWR0_RSVD3
};

/*Group Index 8*/
enum
{
    TID_AI_PF_A                 = TID_AI_GROUP8,
    TID_AI_PF_B,                TID_AI_PF_C,            TID_AI_PF_TOTAL,        TID_AI_PKMAX_APP,
    TID_AI_PKMIN_APP,           TID_AI_PKMAX_ACT,       TID_AI_PKMIN_ACT,       TID_AI_PKMAX_RCT,
    TID_AI_PKMIN_RCT,           TID_AI_PWR_QDRT_A,      TID_AI_PWR_QDRT_B,      TID_AI_PWR_QDRT_C,
    TID_AI_PWR_QDRT_TOTAL,      TID_AI_PWR1_RSVD0,      TID_AI_PWR1_RSVD1
};

/*Group Index 9 ~ 13 is not use*/
/*Group Index 9*/
enum
{
    TID_AI_APP_EA               = TID_AI_GROUP9,
    TID_AI_APP_EB,              TID_AI_APP_EC,          TID_AI_APP_ETOTAL,      TID_AI_ACT_EA_IN,
    TID_AI_ACT_EA_OUT,          TID_AI_ACT_EB_IN,       TID_AI_ACT_EB_OUT,      TID_AI_ACT_EC_IN,
    TID_AI_ACT_EC_OUT,          TID_AI_ACT_ETOTAL_IN,   TID_AI_ACT_ETOTAL_OUT,  TID_AI_ENG0_RSVD0,
    TID_AI_ENG0_RSVD1,          TID_AI_ENG0_RSVD2,      TID_AI_ENG0_RSVD3
};

/*Group Index 10*/
enum
{
    TID_AI_RCT_EA_IN            = TID_AI_GROUP10,
    TID_AI_RCT_EA_OUT,          TID_AI_RCT_EB_IN,       TID_AI_RCT_EB_OUT,      TID_AI_RCT_EC_IN,
    TID_AI_RCT_EC_OUT,          TID_AI_RCT_ETOTAL_IN,   TID_AI_RCT_ETOTAL_OUT,  TID_AI_ENG1_RSVD0,
    TID_AI_ENG1_RSVD1,          TID_AI_ENG1_RSVD2,      TID_AI_ENG1_RSVD3,      TID_AI_ENG1_RSVD4,
    TID_AI_ENG1_RSVD5,          TID_AI_ENG1_RSVD6,      TID_AI_ENG1_RSVD7
};
/*Group Index 11*/
enum
{
    TID_AI_DMD0_RSVD0           = TID_AI_GROUP11,
    TID_AI_DMD0_RSVD1,          TID_AI_DMD0_RSVD2,      TID_AI_DMD0_RSVD3,      TID_AI_DMD0_RSVD4,
    TID_AI_DMD0_RSVD5,          TID_AI_DMD_ACT_PA,      TID_AI_DMD_ACT_PB,      TID_AI_DMD_ACT_PC,
    TID_AI_DMD_ACT_PN,          TID_AI_DMD_RCT_PA,      TID_AI_DMD_RCT_PB,      TID_AI_DMD_RCT_PC,
    TID_AI_DMD_RCT_PN,          TID_AI_DMD0_RSVD6,      TID_AI_DMD0_RSVD7
};
/*Group Index 12*/
enum
{
    TID_AI_DMD1_RSVD0           = TID_AI_GROUP12,
    TID_AI_DMD1_RSVD1,          TID_AI_DMD1_RSVD2,      TID_AI_DMD1_RSVD3,      TID_AI_DMD1_RSVD4,
    TID_AI_DMD1_RSVD5,          TID_AI_PKDMD_ACT_PA,    TID_AI_PKDMD_ACT_PB,    TID_AI_PKDMD_ACT_PC,
    TID_AI_PKDMD_ACT_PTOTAL,    TID_AI_PKDMD_RCT_PA,    TID_AI_PKDMD_RCT_PB,    TID_AI_PKDMD_RCT_PC,
    TID_AI_PKDMD_RCT_PTOTAL,    TID_AI_DMD1_RSVD6,      TID_AI_DMD1_RSVD7
};
/*Group Index 13*/
enum
{
    TID_AI_RMS_P_VA             = TID_AI_GROUP13,
    TID_AI_RMS_P_VB,            TID_AI_RMS_P_VC,        TID_AI_RMS_P_VR,        TID_AI_RMS_P_VS,
    TID_AI_RMS_P_VT,            TID_AI_RMS_P_IA,        TID_AI_RMS_P_IB,        TID_AI_RMS_P_IC,
    TID_AI_RMS_P_IN,            TID_AI_PREV_RSVD0,      TID_AI_PREV_RSVD1,      TID_AI_PREV_RSVD2,
    TID_AI_PREV_RSVD3,          TID_AI_PREV_RSVD4,      TID_AI_PREV_RSVD5
};


/*Group Index 14*/
enum
{
    TID_AI_GPAI0                = TID_AI_GROUP14,
    TID_AI_GPAI1,               TID_AI_GPAI2,           TID_AI_GPAI3,           TID_AI_GPAI4,
    TID_AI_GPAI5,               TID_AI_GPAI6,           TID_AI_GPAI7,           TID_AI_GPAI8,
    TID_AI_GPAI9,               TID_AI_GPAI10,          TID_AI_GPAI11,          TID_AI_GPAI12,
    TID_AI_GPAI13,              TID_AI_GPAI14,          TID_AI_GPAI15
};

/*Group Index 15 is empty*/

enum
{
    TID_AI_RMS_VA_DISP          = TID_AI_GROUP15,
    TID_AI_RMS_VB_DISP,         TID_AI_RMS_VC_DISP,     TID_AI_RMS_VR_DISP,     TID_AI_RMS_VS_DISP,
    TID_AI_RMS_VT_DISP,         TID_AI_RMS_IA_DISP,     TID_AI_RMS_IB_DISP,     TID_AI_RMS_IC_DISP,
    TID_AI_RMS_IN_DISP

};
/*Group Index 16*/
enum
{
    TID_AI_ANG_VA_DISP          = TID_AI_GROUP16,
    TID_AI_ANG_VB_DISP,         TID_AI_ANG_VC_DISP,     TID_AI_ANG_VR_DISP,     TID_AI_ANG_VS_DISP,
    TID_AI_ANG_VT_DISP,         TID_AI_ANG_IA_DISP,     TID_AI_ANG_IB_DISP,     TID_AI_ANG_IC_DISP,
    TID_AI_ANG_IN_DISP,
};
#if 0
/*Group Index 0*/
#define ALS_AI_RMS_VA_MAX                      0        //  TID_AI_RMS_VA_MAX
#define ALS_AI_RMS_VB_MAX                      1        //  TID_AI_RMS_VB_MAX
#define ALS_AI_RMS_VC_MAX                      2        //  TID_AI_RMS_VC_MAX
#define ALS_AI_RMS_IA_MAX                      3        //  ID_AI_RMS_IA_MAX
#define ALS_AI_RMS_IB_MAX                      4        //  TID_AI_RMS_IB_MAX
#define ALS_AI_RMS_IC_MAX                      5        //  TID_AI_RMS_IC_MAX
#define ALS_AI_RMS_IN_MAX                      6        //  TID_AI_RMS_IN_MAX

/*Group Index 1*/
#define ALS_AI_RMS_VA                          16       //  TID_AI_RMS_VA
#define ALS_AI_RMS_VB                          17       //  TID_AI_RMS_VB
#define ALS_AI_RMS_VC                          18       //  TID_AI_RMS_VC
#define ALS_AI_RMS_VR                          19       //  TID_AI_RMS_VR
#define ALS_AI_RMS_VS                          20       //  TID_AI_RMS_VS
#define ALS_AI_RMS_VT                          21       //  TID_AI_RMS_VT
#define ALS_AI_RMS_IA                          22       //  TID_AI_RMS_IA
#define ALS_AI_RMS_IB                          23       //  TID_AI_RMS_IB
#define ALS_AI_RMS_IC                          24       //  TID_AI_RMS_IC
#define ALS_AI_RMS_IN                          25       //  TID_AI_RMS_IN

/*Group Index 2*/

#define ALS_AI_ANG_VA                          32       //  TID_AI_ANG_VA
#define ALS_AI_ANG_VB                          33       //  TID_AI_ANG_VB
#define ALS_AI_ANG_VC                          34       //  TID_AI_ANG_VC
#define ALS_AI_ANG_VR                          35       //  TID_AI_ANG_VR
#define ALS_AI_ANG_VS                          36       //  TID_AI_ANG_VS
#define ALS_AI_ANG_VT                          37       //  TID_AI_ANG_VT
#define ALS_AI_ANG_IA                          38       //  TID_AI_ANG_IA
#define ALS_AI_ANG_IB                          39       //  TID_AI_ANG_IB
#define ALS_AI_ANG_IC                          40       //  TID_AI_ANG_IC
#define ALS_AI_ANG_IN                          41       //  TID_AI_ANG_IN

/*Group Index 3*/

#define ALS_AI_FREQ_VA                         48       //  TID_AI_FREQ_VA
#define ALS_AI_FREQ_VB                         49       //  TID_AI_FREQ_VB
#define ALS_AI_FREQ_VC                         50       //  TID_AI_FREQ_VC
#define ALS_AI_FREQ_VR                         51       //  TID_AI_FREQ_VR
#define ALS_AI_FREQ_VS                         52       //  TID_AI_FREQ_VS
#define ALS_AI_FREQ_VT                         53       //  TID_AI_FREQ_VT
#define ALS_AI_FREQ_P_VA                       54       //  TID_AI_FREQ_P_VA
#define ALS_AI_FREQ_P_VB                       55       //  TID_AI_FREQ_P_VB
#define ALS_AI_FREQ_P_VC                       56       //  TID_AI_FREQ_P_VC
#define ALS_AI_FREQ_P_VR                       57       //  TID_AI_FREQ_P_VR
#define ALS_AI_FREQ_P_VS                       58       //  TID_AI_FREQ_P_VS
#define ALS_AI_FREQ_P_VT                       59       //  TID_AI_FREQ_P_VT

/*Group Index 4*/
#define ALS_AI_RMS_VAB                         64       //  TID_AI_RMS_VAB
#define ALS_AI_RMS_VBC                         65       //  TID_AI_RMS_VBC
#define ALS_AI_RMS_VCA                         66       //  TID_AI_RMS_VCA
#define ALS_AI_RMS_VRS                         67       //  TID_AI_RMS_VRS
#define ALS_AI_RMS_VST                         68       //  TID_AI_RMS_VST
#define ALS_AI_RMS_VTR                         69       //  TID_AI_RMS_VTR
#define ALS_AI_ANG_VAB                         70       //  TID_AI_ANG_VAB
#define ALS_AI_ANG_VBC                         71       //  TID_AI_ANG_VBC
#define ALS_AI_ANG_VCA                         72       //  TID_AI_ANG_VCA
#define ALS_AI_ANG_VRS                         73       //  TID_AI_ANG_VRS
#define ALS_AI_ANG_VST                         74       //  TID_AI_ANG_VST
#define ALS_AI_ANG_VTR                         75       //  TID_AI_ANG_VTR

/*Group Index 5*/
#define ALS_AI_RMS_V0                          80       //  TID_AI_RMS_V0
#define ALS_AI_RMS_V1                          81       //  TID_AI_RMS_V1
#define ALS_AI_RMS_V2                          82       //  TID_AI_RMS_V2
#define ALS_AI_RMS_VR0                         83       //  TID_AI_RMS_VR0
#define ALS_AI_RMS_VR1                         84       //  TID_AI_RMS_VR1
#define ALS_AI_RMS_VR2                         85       //  TID_AI_RMS_VR2
#define ALS_AI_ANG_V0                          86       //  TID_AI_ANG_V0
#define ALS_AI_ANG_V1                          87       //  TID_AI_ANG_V1
#define ALS_AI_ANG_V2                          88       //  TID_AI_ANG_V2
#define ALS_AI_ANG_VR0                         89       //  TID_AI_ANG_VR0
#define ALS_AI_ANG_VR1                         90       //  TID_AI_ANG_VR1
#define ALS_AI_ANG_VR2                         91       //  TID_AI_ANG_VR2

/*Group Index 6*/
#define ALS_AI_RMS_I0                          96       //  TID_AI_RMS_I0
#define ALS_AI_RMS_I1                          97       //  TID_AI_RMS_I1
#define ALS_AI_RMS_I2                          98       //  TID_AI_RMS_I2
#define ALS_AI_ANG_I0                          99       //  TID_AI_ANG_I0
#define ALS_AI_ANG_I1                          100       //  TID_AI_ANG_I1
#define ALS_AI_ANG_I2                          101       //  TID_AI_ANG_I2


/*Group Index 7*/
#define ALS_AI_APPARENT_A                      112       //  TID_AI_APPARENT_A
#define ALS_AI_APPARENT_B                      113       //  TID_AI_APPARENT_B
#define ALS_AI_APPARENT_C                      114       //  TID_AI_APPARENT_C
#define ALS_AI_APPARENT_TOTAL                  115       //  TID_AI_APPARENT_TOTAL
#define ALS_AI_ACTIVE_A                        116       //  TID_AI_ACTIVE_A
#define ALS_AI_ACTIVE_B                        117       //  TID_AI_ACTIVE_B
#define ALS_AI_ACTIVE_C                        118       //  TID_AI_ACTIVE_C
#define ALS_AI_ACTIVE_TOTAL                    119       //  TID_AI_ACTIVE_TOTAL
#define ALS_AI_REACTIVE_A                      120       //  TID_AI_REACTIVE_A
#define ALS_AI_REACTIVE_B                      121       //  TID_AI_REACTIVE_B
#define ALS_AI_REACTIVE_C                      122       //  TID_AI_REACTIVE_C
#define ALS_AI_REACTIVE_TOTAL                  123       //  TID_AI_REACTIVE_TOTAL

/*Group Index 8*/
#define ALS_AI_PF_A                            128       //  TID_AI_PF_A
#define ALS_AI_PF_B                            129       //  TID_AI_PF_B
#define ALS_AI_PF_C                            130       //  TID_AI_PF_C
#define ALS_AI_PF_TOTAL                        131       //  TID_AI_PF_TOTAL

/*Group Index 9*/
/*Group Index 10*/
/*Group Index 11*/
/*Group Index 12*/
/*Group Index 13*/
/*Group Index 14*/
#define ALS_AI_12VAN                           144       //TID_AI_GPAI1
#define ALS_AI_AIMODFB                         145       //TID_AI_GPAI2
#define ALS_AI_12VAP                           146       //TID_AI_GPAI3
#define ALS_AI_AICPFB                          147       //TID_AI_GPAI4
#define ALS_AI_REF_DP                          148       //TID_AI_GPAI5
#define ALS_AI_AIOPFB                          149       //TID_AI_GPAI6
#define ALS_AI_CTEMP                           150       //TID_AI_GPAI7
#define ALS_AI_AIBATV                          151       //TID_AI_GPAI8
#define ALS_AI_AICHV                           152       //TID_AI_GPAI10
#define ALS_AI_AIOPV                           153       //TID_AI_GPAI12


/*Group Index 16*/
#define ALS_AI_RMS_IA_DISP                     160       //TID_AI_RMS_IA_DISP
#define ALS_AI_RMS_IB_DISP                     161       //TID_AI_RMS_IB_DISP
#define ALS_AI_RMS_IC_DISP                     162       //TID_AI_RMS_IC_DISP
#define ALS_AI_RMS_IN_DISP                     163       //TID_AI_RMS_IN_DISP
#endif
#endif /* USERLOGIC_ALIAS_AI_H_ */
