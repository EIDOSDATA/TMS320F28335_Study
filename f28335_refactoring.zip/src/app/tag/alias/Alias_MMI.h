/*
 * Alias_MMI.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_ALIAS_MMI_H_
#define USERLOGIC_ALIAS_ALIAS_MMI_H_

enum
{
    ALS_MMI_BLK_LED0,
    ALS_MMI_BLK_LED1,
    ALS_MMI_BLK_LED2,
    ALS_MMI_BLK_LED3,

    ALS_MMI_BLK_PB0,
    ALS_MMI_BLK_PB1,

    ALS_MMI_LEDAC,
    ALS_MMI_LEDCPU,
    ALS_MMI_LED79RS,
    ALS_MMI_LED79CY,
    ALS_MMI_LED79LO,
    ALS_MMI_LEDFLTA,
    ALS_MMI_LEDFLTB,
    ALS_MMI_LEDFLTC,
    ALS_MMI_LEDFLTN,
    ALS_MMI_LEDFLTSEF,
    ALS_MMI_LEDBATTB,
    ALS_MMI_LEDHLOCK,
    ALS_MMI_LEDLOAD,
    ALS_MMI_LEDBUMP,
    ALS_MMI_LEDABC,
    ALS_MMI_LEDOC,

    ALS_MMI_LEDHIGH,
    ALS_MMI_LED81,
    ALS_MMI_LEDDIAGNOSFAIL,
    ALS_MMI_LEDSCH,
    ALS_MMI_LEDLOV,
    ALS_MMI_LEDSOURCE,
    ALS_MMI_LEDCBA,
    ALS_MMI_LEDPROT,
    ALS_MMI_LEDRC,
    ALS_MMI_LEDGND,
    ALS_MMI_LEDSEF,
    ALS_MMI_LEDRT,
    ALS_MMI_LEDCLP,
    ALS_MMI_LEDCLOSE,
    ALS_MMI_LEDHT,
    ALS_MMI_LEDRNC,

    ALS_MMI_LEDLNC,
    ALS_MMI_LEDLNO,
    ALS_MMI_LEDA2R,
    ALS_MMI_LEDR2A,
    ALS_MMI_LEDTRIP,
    ALS_MMI_LEDFLTA_Y,
    ALS_MMI_LEDFLTB_Y,
    ALS_MMI_LEDFLTC_Y,
    ALS_MMI_LEDFLTN_Y,
    ALS_MMI_LEDSG1,
    ALS_MMI_LEDSG2,
    ALS_MMI_LEDV79RS,
    ALS_MMI_LEDV79CY,

    ALS_MMI_LEDCWF,
    ALS_MMI_LEDCFB,
    ALS_MMI_LEDCOCT,
    ALS_MMI_LEDCPT,
    ALS_MMI_LEDCTT,
    ALS_MMI_LEDIPT,
    ALS_MMI_LEDEMOL,
    ALS_MMI_LEDMODEM,
    ALS_MMI_LEDOPFB,
    ALS_MMI_LEDCPFB,
    ALS_MMI_LEDMODFB,
    ALS_MMI_LEDPOLY,

    ALS_MMI_PBLRS,
    ALS_MMI_PBTARR,
    ALS_MMI_PBBATTEST,
    ALS_MMI_PBPT,
    ALS_MMI_PBRC,
    ALS_MMI_PBGND,
    ALS_MMI_PBSEF,
    ALS_MMI_PBRT,
    ALS_MMI_PBCLP,
    ALS_MMI_PBCL,
    ALS_MMI_PBHT,
    ALS_MMI_PBRNC,
    ALS_MMI_PBLNC,
    ALS_MMI_PBLNO,
    ALS_MMI_PBA2R,
    ALS_MMI_PBR2A,

    ALS_MMI_PBTR,

    TAG_MMI_INDEX_MAX,
};

/*TAG ID*/
#define TID_MMI                                 12
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_MMI_GROUP0  =  BUILD_L2CODE(TID_MMI, 0),     TID_MMI_GROUP1  =  BUILD_L2CODE(TID_MMI, 1),      TID_MMI_GROUP2  =  BUILD_L2CODE(TID_MMI, 2),
    TID_MMI_GROUP3  =  BUILD_L2CODE(TID_MMI, 3),     TID_MMI_GROUP4  =  BUILD_L2CODE(TID_MMI, 4),      TID_MMI_GROUP5  =  BUILD_L2CODE(TID_MMI, 5),
    TID_MMI_GROUP6  =  BUILD_L2CODE(TID_MMI, 6),     TID_MMI_GROUP7  =  BUILD_L2CODE(TID_MMI, 7),      TID_MMI_GROUP8  =  BUILD_L2CODE(TID_MMI, 8)

};

/*Group Index 0*/
enum
{
    TID_MMI_BLK_LED0        = TID_MMI_GROUP0,
    TID_MMI_BLK_LED1,       TID_MMI_BLK_LED2,       TID_MMI_BLK_LED3,       TID_MMI_BLK_PB0,
    TID_MMI_BLK_PB1
};

/*Group Index 1*/
enum
{
    TID_MMI_LED0_0          = TID_MMI_GROUP1,
    TID_MMI_LED0_1,         TID_MMI_LED0_2,         TID_MMI_LED0_3,         TID_MMI_LED0_4,
    TID_MMI_LED0_5,         TID_MMI_LED0_6,         TID_MMI_LED0_7,         TID_MMI_LED0_8,
    TID_MMI_LED0_9,         TID_MMI_LED0_10,        TID_MMI_LED0_11,        TID_MMI_LED0_12,
    TID_MMI_LED0_13,        TID_MMI_LED0_14,        TID_MMI_LED0_15
};

/*Group Index 2*/
enum
{
    TID_MMI_LED1_0          = TID_MMI_GROUP2,
    TID_MMI_LED1_1,         TID_MMI_LED1_2,         TID_MMI_LED1_3,         TID_MMI_LED1_4,
    TID_MMI_LED1_5,         TID_MMI_LED1_6,         TID_MMI_LED1_7,         TID_MMI_LED1_8,
    TID_MMI_LED1_9,         TID_MMI_LED1_10,        TID_MMI_LED1_11,        TID_MMI_LED1_12,
    TID_MMI_LED1_13,        TID_MMI_LED1_14,        TID_MMI_LED1_15
};

/*Group Index 3*/
enum
{
    TID_MMI_LED2_0          = TID_MMI_GROUP3,
    TID_MMI_LED2_1,         TID_MMI_LED2_2,         TID_MMI_LED2_3,         TID_MMI_LED2_4,
    TID_MMI_LED2_5,         TID_MMI_LED2_6,         TID_MMI_LED2_7,         TID_MMI_LED2_8,
    TID_MMI_LED2_9,         TID_MMI_LED2_10,        TID_MMI_LED2_11,        TID_MMI_LED2_12,
    TID_MMI_LED2_13,        TID_MMI_LED2_14,        TID_MMI_LED2_15

};

/*Group Index 4*/
enum
{
    TID_MMI_LED3_0          = TID_MMI_GROUP4,
    TID_MMI_LED3_1,         TID_MMI_LED3_2,         TID_MMI_LED3_3,         TID_MMI_LED3_4,
    TID_MMI_LED3_5,         TID_MMI_LED3_6,         TID_MMI_LED3_7,         TID_MMI_LED3_8,
    TID_MMI_LED3_9,         TID_MMI_LED3_10,        TID_MMI_LED3_11,        TID_MMI_LED3_12,
    TID_MMI_LED3_13,        TID_MMI_LED3_14,        TID_MMI_LED3_15
};

/*Group Index 5*/
enum
{
    TID_MMI_PBS0_0          = TID_MMI_GROUP5,
    TID_MMI_PBS0_1,         TID_MMI_PBS0_2,         TID_MMI_PBS0_3,         TID_MMI_PBS0_4,
    TID_MMI_PBS0_5,         TID_MMI_PBS0_6,         TID_MMI_PBS0_7,         TID_MMI_PBS0_8,
    TID_MMI_PBS0_9,         TID_MMI_PBS0_10,        TID_MMI_PBS0_11,        TID_MMI_PBS0_12,
    TID_MMI_PBS0_13,        TID_MMI_PBS0_14,        TID_MMI_PBS0_15

};

/*Group Index 6*/
enum
{
    TID_MMI_PBL0_0          = TID_MMI_GROUP6,
    TID_MMI_PBL0_1,         TID_MMI_PBL0_2,         TID_MMI_PBL0_3,         TID_MMI_PBL0_4,
    TID_MMI_PBL0_5,         TID_MMI_PBL0_6,         TID_MMI_PBL0_7,         TID_MMI_PBL0_8,
    TID_MMI_PBL0_9,         TID_MMI_PBL0_10,        TID_MMI_PBL0_11,        TID_MMI_PBL0_12,
    TID_MMI_PBL0_13,        TID_MMI_PBL0_14,        TID_MMI_PBL0_15
};

/*Group Index 7*/
enum
{
    TID_MMI_PBS1_0          = TID_MMI_GROUP7,
    TID_MMI_PBS1_1,         TID_MMI_PBS1_2,         TID_MMI_PBS1_3,         TID_MMI_PBS1_4,
    TID_MMI_PBS1_5,         TID_MMI_PBS1_6,         TID_MMI_PBS1_7,         TID_MMI_PBS1_8,
    TID_MMI_PBS1_9,         TID_MMI_PBS1_10,        TID_MMI_PBS1_11,        TID_MMI_PBS1_12,
    TID_MMI_PBS1_13,        TID_MMI_PBS1_14,        TID_MMI_PBS1_15
};
/*Group Index 8*/
enum
{
    TID_MMI_PBL1_0          = TID_MMI_GROUP8,
    TID_MMI_PBL1_1,         TID_MMI_PBL1_2,         TID_MMI_PBL1_3,         TID_MMI_PBL1_4,
    TID_MMI_PBL1_5,         TID_MMI_PBL1_6,         TID_MMI_PBL1_7,         TID_MMI_PBL1_8,
    TID_MMI_PBL1_9,         TID_MMI_PBL1_10,        TID_MMI_PBL1_11,        TID_MMI_PBL1_12,
    TID_MMI_PBL1_13,        TID_MMI_PBL1_14,        TID_MMI_PBL1_15
};

#if 0
/*Group Index 0*/
#define ALS_MMI_BLK_LED0                        0//TID_MMI_BLK_LED0
#define ALS_MMI_BLK_LED1                        1//TID_MMI_BLK_LED1
#define ALS_MMI_BLK_LED2                        2//TID_MMI_BLK_LED2
#define ALS_MMI_BLK_LED3                        3//TID_MMI_BLK_LED3

#define ALS_MMI_BLK_PB0                         4//TID_MMI_BLK_PB0
#define ALS_MMI_BLK_PB1                         5//TID_MMI_BLK_PB1

/*Group Index 1*/
#define ALS_MMI_LEDAC                           6//TID_MMI_LED0_0
#define ALS_MMI_LEDCPU                          7//TID_MMI_LED0_1
#define ALS_MMI_LED79RS                         8//TID_MMI_LED0_2
#define ALS_MMI_LED79CY                         9//TID_MMI_LED0_3
#define ALS_MMI_LED79LO                         10//TID_MMI_LED0_4
#define ALS_MMI_LEDFLTA                         11//TID_MMI_LED0_5
#define ALS_MMI_LEDFLTB                         12//TID_MMI_LED0_6
#define ALS_MMI_LEDFLTC                         13//TID_MMI_LED0_7
#define ALS_MMI_LEDFLTN                         14//TID_MMI_LED0_8
#define ALS_MMI_LEDFLTSEF                       15//TID_MMI_LED0_9
#define ALS_MMI_LEDBATTB                        16//TID_MMI_LED0_10
#define ALS_MMI_LEDHLOCK                        17//TID_MMI_LED0_11
#define ALS_MMI_LEDLOAD                         18//TID_MMI_LED0_12
#define ALS_MMI_LEDBUMP                         19//TID_MMI_LED0_13
#define ALS_MMI_LEDABC                          20//TID_MMI_LED0_14
#define ALS_MMI_LEDOC                           21//TID_MMI_LED0_15

/*Group Index 2*/
#define ALS_MMI_LEDHIGH                         22//TID_MMI_LED1_0
#define ALS_MMI_LED81                           23//TID_MMI_LED1_1
#define ALS_MMI_LEDDIAGNOSFAIL                  24//TID_MMI_LED1_2
#define ALS_MMI_LEDSCH                          25//TID_MMI_LED1_3
#define ALS_MMI_LEDLOV                          26//TID_MMI_LED1_4
#define ALS_MMI_LEDSOURCE                       27//TID_MMI_LED1_5
#define ALS_MMI_LEDCBA                          28//TID_MMI_LED1_6
#define ALS_MMI_LEDPROT                         29//TID_MMI_LED1_7
#define ALS_MMI_LEDRC                           30//TID_MMI_LED1_8
#define ALS_MMI_LEDGND                          31//TID_MMI_LED1_9
#define ALS_MMI_LEDSEF                          32//TID_MMI_LED1_10
#define ALS_MMI_LEDRT                           33//TID_MMI_LED1_11
#define ALS_MMI_LEDCLP                          34//TID_MMI_LED1_12
#define ALS_MMI_LEDCLOSE                        35//TID_MMI_LED1_13
#define ALS_MMI_LEDHT                           36//TID_MMI_LED1_14
#define ALS_MMI_LEDRNC                          37//TID_MMI_LED1_15

/*Group Index 3*/
#define ALS_MMI_LEDLNC                          38//TID_MMI_LED2_0
#define ALS_MMI_LEDLNO                          39//TID_MMI_LED2_1
#define ALS_MMI_LEDA2R                          40//TID_MMI_LED2_2
#define ALS_MMI_LEDR2A                          41//TID_MMI_LED2_3
#define ALS_MMI_LEDTRIP                         42//TID_MMI_LED2_4
#define ALS_MMI_LEDFLTA_Y                       43//TID_MMI_LED2_8
#define ALS_MMI_LEDFLTB_Y                       44//TID_MMI_LED2_9
#define ALS_MMI_LEDFLTC_Y                       45//TID_MMI_LED2_10
#define ALS_MMI_LEDFLTN_Y                       46//TID_MMI_LED2_11
#define ALS_MMI_LEDSG1                          47//TID_MMI_LED2_12
#define ALS_MMI_LEDSG2                          48//TID_MMI_LED2_13
#define ALS_MMI_LEDV79RS                        49//TID_MMI_LED2_14
#define ALS_MMI_LEDV79CY                        50//TID_MMI_LED2_15

/*Group Index 4*/
#define ALS_MMI_LEDCWF                          51//TID_MMI_LED3_1
#define ALS_MMI_LEDCFB                          52//TID_MMI_LED3_2
#define ALS_MMI_LEDCOCT                         53//TID_MMI_LED3_3
#define ALS_MMI_LEDCPT                          54//TID_MMI_LED3_4
#define ALS_MMI_LEDCTT                          55//TID_MMI_LED3_5
#define ALS_MMI_LEDIPT                          56//TID_MMI_LED3_6
#define ALS_MMI_LEDEMOL                         57//TID_MMI_LED3_7
#define ALS_MMI_LEDMODEM                        58//TID_MMI_LED3_8
#define ALS_MMI_LEDOPFB                         59//TID_MMI_LED3_9
#define ALS_MMI_LEDCPFB                         60//TID_MMI_LED3_10
#define ALS_MMI_LEDMODFB                        61//TID_MMI_LED3_11
#define ALS_MMI_LEDPOLY                         62//TID_MMI_LED3_12

/*Group Index 5*/
#define ALS_MMI_PBLRS                           63//TID_MMI_PBS0_0
#define ALS_MMI_PBTARR                          64//TID_MMI_PBS0_1
#define ALS_MMI_PBBATTEST                       65//TID_MMI_PBS0_2
#define ALS_MMI_PBPT                            66//TID_MMI_PBS0_3
#define ALS_MMI_PBRC                            67//TID_MMI_PBS0_4
#define ALS_MMI_PBGND                           68//TID_MMI_PBS0_5
#define ALS_MMI_PBSEF                           69//TID_MMI_PBS0_6
#define ALS_MMI_PBRT                            70//TID_MMI_PBS0_7
#define ALS_MMI_PBCLP                           71//TID_MMI_PBS0_8
#define ALS_MMI_PBCL                            72//TID_MMI_PBS0_9
#define ALS_MMI_PBHT                            73//TID_MMI_PBS0_10
#define ALS_MMI_PBRNC                           74//TID_MMI_PBS0_11
#define ALS_MMI_PBLNC                           75//TID_MMI_PBS0_12
#define ALS_MMI_PBLNO                           76//TID_MMI_PBS0_13
#define ALS_MMI_PBA2R                           77//TID_MMI_PBS0_14
#define ALS_MMI_PBR2A                           78//TID_MMI_PBS0_15

#define ALS_MMI_PBTR                            79//TID_MMI_PBS1_0

/*Group Index 8*/

#endif
#endif /* USERLOGIC_ALIAS_ALIAS_MMI_H_ */
