/*
 * Alias_SC.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_ALIAS_SC_H_
#define USERLOGIC_ALIAS_ALIAS_SC_H_

enum
{
        ALS_SC_SCHED_FREQ,
        ALS_SC_SAMP_FREQ,
        ALS_SC_IO_PROC_FREQ,
        ALS_SC_LG_PROC_FREQ,

        ALS_SC_PECAPP_VERSION,

        ALS_SC_TARGSYS_FREQ,
        ALS_SC_STGRP,

        ALS_SC_ROTATION,
        ALS_SC_REF_PHASE,
        ALS_SC_FLOWDIR,
        ALS_SC_DICHAT,
        ALS_SC_CFG_UPDATED,
        ALS_SC_PWR_ON,
        ALS_SC_SYMC_PREV_ENABLE,
        ALS_SC_TIME,
        ALS_SC_TYPE,
        ALS_SC_LPTIME,


        ALS_SC_FIRSCL,
        ALS_SC_59P1P0,
        ALS_SC_27P1P0,
        ALS_SC_STGRP_AT_MODE_ON,
        ALS_SC_79CLSD,
        ALS_SC_SBT_HOUR,
        ALS_SC_SBT_MIN,
        ALS_SC_SBT_INTERVAL,
        ALS_SC_ENOC,
        ALS_SC_ENDELTAI2_I1,
        ALS_SC_UNBCR,
        ALS_SC_UNBCD,
        ALS_SC_UNBVR,
        ALS_SC_UNBVD,
        ALS_SC_27P2P0,
        ALS_SC_59P2P0,

        ALS_SC_59N1P0,
        ALS_SC_47P1P,
        ALS_SC_47P1D,
        ALS_SC_ENBFD,
        ALS_SC_51P5P,
        ALS_SC_USERC,
        ALS_SC_USERRS,
        ALS_SC_BATTEST_SCHED,
        ALS_SC_ENPROT,
        ALS_SC_ENGND,
        ALS_SC_ENSEF,
        ALS_SC_ENCLP,
        ALS_SC_TRIG_WAVE,
        ALS_MODEM_POWER,

        TAG_SC_UI_INDEX_MAX,
};

enum
{
        ALS_SC_CT_RATIO,
        ALS_SC_PT_RATIO,
        ALS_SC_FREQ_PREV_N_CYC,
        ALS_SC_SVOL,
        ALS_SC_TDURD,
        ALS_SC_BLV,
        ALS_SC_81P1P,
        ALS_SC_81P1D,
        ALS_SC_81P2P,
        ALS_SC_81P2D,
        ALS_SC_81P3P,
        ALS_SC_81P3D,
        ALS_SC_27P2D,
        ALS_SC_59P2D,
        ALS_SC_GCAP,
        ALS_SC_32P1P,
        ALS_SC_32P1D,
        ALS_SC_59N1D,
        ALS_SC_USERTD,

        ALS_SC_USERCT,
        ALS_SC_USERMR,
        ALS_SC_TCC_FAC_A,
        ALS_SC_TCC_FAC_B,
        ALS_SC_TCC_FAC_P,

        TAG_SC_F_INDEX_MAX,
};


/*TAG ID*/
#define TID_SC                                  9
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_GRP_SC_SYSINFO  =  BUILD_L2CODE(TID_SC, 0),     TID_GRP_SC_SCFG_UI  =  BUILD_L2CODE(TID_SC, 1),      TID_GRP_SC_SCFG_F   =  BUILD_L2CODE(TID_SC, 2),
    TID_GRP_SC_UCFG_UI0 =  BUILD_L2CODE(TID_SC, 3),     TID_GRP_SC_UCFG_UI1 =  BUILD_L2CODE(TID_SC, 4),      TID_GRP_SC_UCFG_UI2 =  BUILD_L2CODE(TID_SC, 5),
    TID_GRP_SC_UCFG_UI3 =  BUILD_L2CODE(TID_SC, 6),     TID_GRP_SC_UCFG_F0  =  BUILD_L2CODE(TID_SC, 7),      TID_GRP_SC_UCFG_F1  =  BUILD_L2CODE(TID_SC, 8),
    TID_GRP_SC_UCFG_F2  =  BUILD_L2CODE(TID_SC, 9),     TID_GRP_SC_UCFG_F3  =  BUILD_L2CODE(TID_SC, 10),     TID_GRP_SC_S232_UI0 =  BUILD_L2CODE(TID_SC, 11),
    TID_GRP_SC_S232_UI1 =  BUILD_L2CODE(TID_SC, 12),    TID_GRP_SC_S232_F   =  BUILD_L2CODE(TID_SC, 13),     TID_GRP_SC_SETH_UI0 =  BUILD_L2CODE(TID_SC, 14),
    TID_GRP_SC_SETH_UI1 =  BUILD_L2CODE(TID_SC, 15),    TID_GRP_SC_SETH_F   =  BUILD_L2CODE(TID_SC, 16)
};

/*Group Index 0*/
enum
{
    ORIGIN_TID_SC_SCHED_FREQ           = TID_GRP_SC_SYSINFO,
    ORIGIN_TID_SC_SAMP_FREQ,           ORIGIN_TID_SC_IO_PROC_FREQ,            ORIGIN_TID_SC_LG_PROC_FREQ,            ORIGIN_TID_SC_PEC_VERSION,
    ORIGIN_TID_SC_PECAPP_VERSION
};

/*Group Index 1*/
enum
{
    ORIGIN_TID_SC_TARGSYS_FREQ         = TID_GRP_SC_SCFG_UI,
    ORIGIN_TID_SC_STGRP,               ORIGIN_TID_SC_RESERVED0,               ORIGIN_TID_SC_ROTATION,                ORIGIN_TID_SC_REF_PHASE,
    ORIGIN_TID_SC_FLOWDIR,             ORIGIN_TID_SC_DICHAT,                  ORIGIN_TID_SC_CFG_UPDATED,             ORIGIN_TID_SC_PWR_ON,
    ORIGIN_TID_SC_SYMC_PREV_ENABLE,    ORIGIN_TID_SC_DMD_TIME,                ORIGIN_TID_SC_DMD_TYPE,                ORIGIN_TID_SC_PROP_REC_PRD
};

/*Group Index 2*/
enum
{
    ORIGIN_TID_SC_CT_RATIO             = TID_GRP_SC_SCFG_F,
    ORIGIN_TID_SC_PT_RATIO,            ORIGIN_TID_SC_PHSR_PREV_N_CYC,         ORIGIN_TID_SC_FREQ_PREV_N_CYC,         ORIGIN_TID_SC_SYMC_PREV_N_CYC
};

/*Group Index 3*/
enum
{
    TID_SC_UCFG_UI0_0           = TID_GRP_SC_UCFG_UI0,
    TID_SC_UCFG_UI0_1,          TID_SC_UCFG_UI0_2,              TID_SC_UCFG_UI0_3,              TID_SC_UCFG_UI0_4,
    TID_SC_UCFG_UI0_5,          TID_SC_UCFG_UI0_6,              TID_SC_UCFG_UI0_7,              TID_SC_UCFG_UI0_8,
    TID_SC_UCFG_UI0_9,          TID_SC_UCFG_UI0_10,             TID_SC_UCFG_UI0_11,             TID_SC_UCFG_UI0_12,
    TID_SC_UCFG_UI0_13,         TID_SC_UCFG_UI0_14,             TID_SC_UCFG_UI0_15
};

/*Group Index 4*/
enum
{
    TID_SC_UCFG_UI1_0           = TID_GRP_SC_UCFG_UI1,
    TID_SC_UCFG_UI1_1,          TID_SC_UCFG_UI1_2,              TID_SC_UCFG_UI1_3,              TID_SC_UCFG_UI1_4,
    TID_SC_UCFG_UI1_5,          TID_SC_UCFG_UI1_6,              TID_SC_UCFG_UI1_7,              TID_SC_UCFG_UI1_8,
    TID_SC_UCFG_UI1_9,          TID_SC_UCFG_UI1_10,             TID_SC_UCFG_UI1_11,             TID_SC_UCFG_UI1_12,
    TID_SC_UCFG_UI1_13,         TID_SC_UCFG_UI1_14,             TID_SC_UCFG_UI1_15
};

/*Group Index 5*/
enum
{
    TID_SC_UCFG_UI2_0           = TID_GRP_SC_UCFG_UI2,
    TID_SC_UCFG_UI2_1,          TID_SC_UCFG_UI2_2,              TID_SC_UCFG_UI2_3,              TID_SC_UCFG_UI2_4,
    TID_SC_UCFG_UI2_5,          TID_SC_UCFG_UI2_6,              TID_SC_UCFG_UI2_7,              TID_SC_UCFG_UI2_8,
    TID_SC_UCFG_UI2_9,          TID_SC_UCFG_UI2_10,             TID_SC_UCFG_UI2_11,             TID_SC_UCFG_UI2_12,
    TID_SC_UCFG_UI2_13,         TID_SC_UCFG_UI2_14,             TID_SC_UCFG_UI2_15
};

/*Group Index 6*/
enum
{
    TID_SC_UCFG_UI3_0           = TID_GRP_SC_UCFG_UI3,
    TID_SC_UCFG_UI3_1,          TID_SC_UCFG_UI3_2,              TID_SC_UCFG_UI3_3,              TID_SC_UCFG_UI3_4,
    TID_SC_UCFG_UI3_5,          TID_SC_UCFG_UI3_6,              TID_SC_UCFG_UI3_7,              TID_SC_UCFG_UI3_8,
    TID_SC_UCFG_UI3_9,          TID_SC_UCFG_UI3_10,             TID_SC_UCFG_UI3_11,             TID_SC_UCFG_UI3_12,
    TID_SC_UCFG_UI3_13,         TID_SC_UCFG_UI3_14,             TID_SC_UCFG_UI3_15
};

/*Group Index 7*/
enum
{
    TID_SC_UCFG_F0_0            = TID_GRP_SC_UCFG_F0,
    TID_SC_UCFG_F0_1,           TID_SC_UCFG_F0_2,               TID_SC_UCFG_F0_3,               TID_SC_UCFG_F0_4,
    TID_SC_UCFG_F0_5,           TID_SC_UCFG_F0_6,               TID_SC_UCFG_F0_7,               TID_SC_UCFG_F0_8,
    TID_SC_UCFG_F0_9,           TID_SC_UCFG_F0_10,              TID_SC_UCFG_F0_11,              TID_SC_UCFG_F0_12,
    TID_SC_UCFG_F0_13,          TID_SC_UCFG_F0_14,              TID_SC_UCFG_F0_15
};

/*Group Index 8*/
enum
{
    TID_SC_UCFG_F1_0            = TID_GRP_SC_UCFG_F1,
    TID_SC_UCFG_F1_1,           TID_SC_UCFG_F1_2,               TID_SC_UCFG_F1_3,               TID_SC_UCFG_F1_4,
    TID_SC_UCFG_F1_5,           TID_SC_UCFG_F1_6,               TID_SC_UCFG_F1_7,               TID_SC_UCFG_F1_8,
    TID_SC_UCFG_F1_9,           TID_SC_UCFG_F1_10,              TID_SC_UCFG_F1_11,              TID_SC_UCFG_F1_12,
    TID_SC_UCFG_F1_13,          TID_SC_UCFG_F1_14,              TID_SC_UCFG_F1_15
};

/*Group Index 9*/
enum
{
    TID_SC_UCFG_F2_0            = TID_GRP_SC_UCFG_F2,
    TID_SC_UCFG_F2_1,           TID_SC_UCFG_F2_2,               TID_SC_UCFG_F2_3,               TID_SC_UCFG_F2_4,
    TID_SC_UCFG_F2_5,           TID_SC_UCFG_F2_6,               TID_SC_UCFG_F2_7,               TID_SC_UCFG_F2_8,
    TID_SC_UCFG_F2_9,           TID_SC_UCFG_F2_10,              TID_SC_UCFG_F2_11,              TID_SC_UCFG_F2_12,
    TID_SC_UCFG_F2_13,          TID_SC_UCFG_F2_14,              TID_SC_UCFG_F2_15
};

/*Group Index 10*/
enum
{
    TID_SC_UCFG_F3_0            = TID_GRP_SC_UCFG_F3,
    TID_SC_UCFG_F3_1,           TID_SC_UCFG_F3_2,               TID_SC_UCFG_F3_3,               TID_SC_UCFG_F3_4,
    TID_SC_UCFG_F3_5,           TID_SC_UCFG_F3_6,               TID_SC_UCFG_F3_7,               TID_SC_UCFG_F3_8,
    TID_SC_UCFG_F3_9,           TID_SC_UCFG_F3_10,              TID_SC_UCFG_F3_11,              TID_SC_UCFG_F3_12,
    TID_SC_UCFG_F3_13,          TID_SC_UCFG_F3_14,              TID_SC_UCFG_F3_15
};


typedef enum
{
    TID_SC_SC_SCHD_FREQ         = ORIGIN_TID_SC_SCHED_FREQ,
    TID_SC_SC_SAMP_FREQ,
    TID_SC_IO_PROC_FREQ,
    TID_SC_LG_PROC_FREQ,
    TID_SC_PECAPP_VERSION       = ORIGIN_TID_SC_PECAPP_VERSION,

    TID_SC_TARGSYS_FREQ         = ORIGIN_TID_SC_TARGSYS_FREQ,
    TID_SC_STGRP,

    TID_SC_ROTATION             = ORIGIN_TID_SC_ROTATION,
    TID_SC_REF_PHASE,
    TID_SC_FLOWDIR,
    TID_SC_DICHAT,
    TID_SC_CFG_UPDATED,
    TID_SC_PWR_ON,
    TID_SC_SYMC_PREV_ENABLE,
    TID_SC_TIME,
    TID_SC_TYPE,
    TID_SC_LPTIME,

    TID_SC_FIRSCL               = TID_SC_UCFG_UI0_1,
    TID_SC_59P1P0,
    TID_SC_27P1P0,
    TID_SC_STGRP_AT_MODE_ON,
    TID_SC_79CLSD,
    TID_SC_SBT_HOUR,
    TID_SC_SBT_MIN,
    TID_SC_SBT_INTERVAL,
    TID_SC_ENOC,
    TID_SC_ENDELTAI2_I1,
    TID_SC_UNBCR,
    TID_SC_UNBCD,
    TID_SC_UNBVR,
    TID_SC_UNBVD,
    TID_SC_27P2P0,

    TID_SC_59P2P0               = TID_SC_UCFG_UI1_0,
    TID_SC_59N1P0,
    TID_SC_47P1P,
    TID_SC_47P1D,
    TID_SC_ENBFD,
    TID_SC_51P5P,
    TID_SC_USERC,
    TID_SC_USERRS,
    TID_SC_BATTEST_SCHED,
    TID_SC_ENPROT,
    TID_SC_ENGND,
    TID_SC_ENSEF,
    TID_SC_ENCLP,
    TID_SC_TRIG_WAVE,
    TID_MODEM_POWER,

} TAGID_SC_UI;

typedef enum
{
    TID_SC_CT_RATIO             = ORIGIN_TID_SC_CT_RATIO,
    TID_SC_PT_RATIO,

    TID_SC_FREQ_PREV_N_CYC      = ORIGIN_TID_SC_FREQ_PREV_N_CYC,

    TID_SC_SVOL                 = TID_SC_UCFG_F0_0,
    TID_SC_TDURD,
    TID_SC_BLV,
    TID_SC_81P1P,
    TID_SC_81P1D,
    TID_SC_81P2P,
    TID_SC_81P2D,
    TID_SC_81P3P,
    TID_SC_81P3D,
    TID_SC_27P2D,
    TID_SC_59P2D,
    TID_SC_GCAP,
    TID_SC_32P1P,
    TID_SC_32P1D,
    TID_SC_59N1D,
    TID_SC_USERTD,
    TID_SC_USERCT,
    TID_SC_USERMR,
    TID_SC_TCC_FAC_A,
    TID_SC_TCC_FAC_B,
    TID_SC_TCC_FAC_P,

} TAGID_SC_F;


#endif /* USERLOGIC_ALIAS_ALIAS_SC_H_ */
