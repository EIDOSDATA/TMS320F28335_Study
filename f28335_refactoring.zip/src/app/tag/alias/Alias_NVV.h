/*
 * Alias_NVV.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_NVV_H_
#define USERLOGIC_ALIAS_NVV_H_

enum
{
    ALS_NVV_OP2,
    ALS_NVV_OP3,
    ALS_NVV_OP4,

    ALS_NVV_PT_CNT,
    ALS_NVV_TOP_CNT,
    ALS_NVV_CL_RST_CNT,
    ALS_NVV_BATT_INTV_CNT,

    ALS_NVV_FLT_N_CNT,
    ALS_NVV_ENRC,

    ALS_NVV_ENHT,
    ALS_NVV_FLT_A_CNT,
    ALS_NVV_FLT_B_CNT,
    ALS_NVV_FLT_C_CNT,

    ALS_NVV_ENRT,
    ALS_NVV_UI_SPARE1,
    ALS_NVV_UI_SPARE2,
    ALS_NVV_UI_SPARE3,
    ALS_NVV_UI_SPARE4,
    ALS_NVV_UI_SPARE5,
    ALS_NVV_UI_SPARE6,
    ALS_NVV_UI_SPARE7,
    ALS_NVV_UI_SPARE8,
    ALS_NVV_UI_SPARE9,
    ALS_NVV_UI_SPARE10,

    TAG_NVV_UI_INDEX_MAX,
};

enum
{
    ALS_NVV_CWFA,
    ALS_NVV_CWFB,
    ALS_NVV_CWFC,
    ALS_NVV_F_SPARE0,
    ALS_NVV_F_SPARE1,
    ALS_NVV_F_SPARE2,
    ALS_NVV_F_SPARE3,
    ALS_NVV_F_SPARE4,
    ALS_NVV_F_SPARE5,
    ALS_NVV_F_SPARE6,
    ALS_NVV_F_SPARE7,
    ALS_NVV_F_SPARE8,
    ALS_NVV_F_SPARE9,
    ALS_NVV_F_SPARE10,

    TAG_NVV_F_INDEX_MAX,

};

/*TAG ID*/
#define TID_NVV                                 6
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_NVV_GROUP0  =  BUILD_L2CODE(TID_NVV, 0),     TID_NVV_GROUP1  =  BUILD_L2CODE(TID_NVV, 1),
    TID_NVV_GROUP2  =  BUILD_L2CODE(TID_NVV, 2)
};

/*Group Index 0*/
enum
{
    TID_NVV_UI0_0       = TID_NVV_GROUP0,
    TID_NVV_UI0_1,      TID_NVV_UI0_2,          TID_NVV_UI0_3,          TID_NVV_UI0_4,
    TID_NVV_UI0_5,      TID_NVV_UI0_6,          TID_NVV_UI0_7,          TID_NVV_UI0_8,
    TID_NVV_UI0_9,      TID_NVV_UI0_10,         TID_NVV_UI0_11,         TID_NVV_UI0_12,
    TID_NVV_UI0_13,     TID_NVV_UI0_14,         TID_NVV_UI0_15

};

/*Group Index 1*/
enum
{
    TID_NVV_UI1_0       = TID_NVV_GROUP1,
    TID_NVV_UI1_1,      TID_NVV_UI1_2,          TID_NVV_UI1_3,          TID_NVV_UI1_4,
    TID_NVV_UI1_5,      TID_NVV_UI1_6,          TID_NVV_UI1_7,          TID_NVV_UI1_8,
    TID_NVV_UI1_9,      TID_NVV_UI1_10,         TID_NVV_UI1_11,         TID_NVV_UI1_12,
    TID_NVV_UI1_13,     TID_NVV_UI1_14,         TID_NVV_UI1_15
};

/*Group Index 2*/
enum
{
    TID_NVV_F0_0        = TID_NVV_GROUP2,
    TID_NVV_F0_1,       TID_NVV_F0_2,           TID_NVV_F0_3,           TID_NVV_F0_4,
    TID_NVV_F0_5,       TID_NVV_F0_6,           TID_NVV_F0_7,           TID_NVV_F0_8,
    TID_NVV_F0_9,       TID_NVV_F0_10,          TID_NVV_F0_11,          TID_NVV_F0_12,
    TID_NVV_F0_13,      TID_NVV_F0_14,          TID_NVV_F0_15,
};

typedef enum
{
    TID_NVV_OP2             = TID_NVV_UI0_0,
    TID_NVV_OP3,
    TID_NVV_OP4,

    TID_NVV_PT_CNT          = TID_NVV_UI0_4,
    TID_NVV_TOP_CNT,
    TID_NVV_CL_RST_CNT,
    TID_NVV_BATT_INTV_CNT,

    TID_NVV_FLT_N_CNT       = TID_NVV_UI0_9,
    TID_NVV_ENRC,

    TID_NVV_ENHT            = TID_NVV_UI0_12,
    TID_NVV_FLT_A_CNT,
    TID_NVV_FLT_B_CNT,
    TID_NVV_FLT_C_CNT,

    TID_NVV_ENRT            = TID_NVV_UI1_0,
    TID_NVV_UI_SPARE1,
    TID_NVV_UI_SPARE2,
    TID_NVV_UI_SPARE3,
    TID_NVV_UI_SPARE4,
    TID_NVV_UI_SPARE5,
    TID_NVV_UI_SPARE6,
    TID_NVV_UI_SPARE7,
    TID_NVV_UI_SPARE8,
    TID_NVV_UI_SPARE9,
    TID_NVV_UI_SPARE10,

} TAGID_NVV_UI;

typedef enum
{
    TID_NVV_CWFA            = TID_NVV_F0_0,
    TID_NVV_CWFB,
    TID_NVV_CWFC,
    TID_NVV_F_SPARE0,
    TID_NVV_F_SPARE1,
    TID_NVV_F_SPARE2,
    TID_NVV_F_SPARE3,
    TID_NVV_F_SPARE4,
    TID_NVV_F_SPARE5,
    TID_NVV_F_SPARE6,
    TID_NVV_F_SPARE7,
    TID_NVV_F_SPARE8,
    TID_NVV_F_SPARE9,
    TID_NVV_F_SPARE10,

} TAGID_NVV_F;
#endif /* USERLOGIC_ALIAS_NVV_H_ */
