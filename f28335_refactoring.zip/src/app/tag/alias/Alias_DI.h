/*
 * Alias_DI.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_DI_H_
#define USERLOGIC_ALIAS_DI_H_

enum
{
    ALS_DI_DOOR,
    ALS_DI_HLOCK,
    ALS_DI_SCH,
    ALS_DI_MSA = ALS_DI_SCH+3,
    ALS_DI_MSB,
    ALS_DI_RCLOSE,
    ALS_DI_RTRIP,
    ALS_DI_RRESET = ALS_DI_RTRIP+2,
    ALS_DI_SPARE,


    TAG_DI_INDEX_MAX = 16,
};

/*TAG ID*/
#define TID_DI                                  2
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_DI_GROUP0  =  BUILD_L2CODE(TID_DI, 0),     TID_DI_GROUP1  =  BUILD_L2CODE(TID_DI, 1)
};

/*Group Index 0 is empty*/
enum
{
    TID_DI_RAW0         = TID_DI_GROUP0,
    TID_DI_RAW1,        TID_DI_RAW2,            TID_DI_RAW3,            TID_DI_RAW4,
    TID_DI_RAW5,        TID_DI_RAW6,            TID_DI_RAW7,            TID_DI_RAW8,
    TID_DI_RAW9,        TID_DI_RAW10,           TID_DI_RAW11,           TID_DI_RAW12,
    TID_DI_RAW13,       TID_DI_RAW14,           TID_DI_RAW15
};

/*Group Index 1*/
/*
enum
{

    TID_DI_LOGICAL0     = TID_DI_GROUP1,
    TID_DI_LOGICAL1,    TID_DI_LOGICAL2,        TID_DI_LOGICAL3,        TID_DI_LOGICAL4,
    TID_DI_LOGICAL5,    TID_DI_LOGICAL6,        TID_DI_LOGICAL7,        TID_DI_LOGICAL8,
    TID_DI_LOGICAL9,    TID_DI_LOGICAL10,       TID_DI_LOGICAL11,       TID_DI_LOGICAL12,
    TID_DI_LOGICAL13,   TID_DI_LOGICAL14,       TID_DI_LOGICAL15

};
*/
/*For HMIS*/
typedef enum
{
    /*
    TID_DI_DOOR         = TID_DI_LOGICAL0,
    TID_DI_HLOCK,
    TID_DI_SCH,

    TID_DI_MSA          = TID_DI_LOGICAL5,
    TID_DI_MSB,
    TID_DI_RCLOSE,
    TID_DI_RTRIP,

    TID_DI_RRESET       = TID_DI_LOGICAL10,
    TID_DI_SPARE,
    */
    TID_DI_LOGICAL0     = TID_DI_GROUP1,
    TID_DI_LOGICAL1,    TID_DI_LOGICAL2,        TID_DI_LOGICAL3,        TID_DI_LOGICAL4,
    TID_DI_LOGICAL5,    TID_DI_LOGICAL6,        TID_DI_LOGICAL7,        TID_DI_LOGICAL8,
    TID_DI_LOGICAL9,    TID_DI_LOGICAL10,       TID_DI_LOGICAL11,       TID_DI_LOGICAL12,
    TID_DI_LOGICAL13,   TID_DI_LOGICAL14,       TID_DI_LOGICAL15

} TAGID_DI;

#endif /* USERLOGIC_ALIAS_DI_H_ */
