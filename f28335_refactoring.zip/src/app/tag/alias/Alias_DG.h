/*
 * Alias_DG.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_ALIAS_DG_H_
#define USERLOGIC_ALIAS_ALIAS_DG_H_

#include "Alias_NMV.h"

enum
{
    ALS_DG_CPU_LOAD,
    ALS_DG_CORE_LOAD,
    TAG_DG_INDEX2,
    TAG_DG_INDEX3,
    /*Not in use*/
    ALS_DG_DNP_SR1,
    ALS_DG_LEDPOLY_SRC,
    ALS_DG_LEDPOLY_LOAD,
    TAG_DG_INDEX7,
    TAG_DG_INDEX8,
    TAG_DG_INDEX9,
    TAG_DG_INDEX10,
    TAG_DG_INDEX11,
    TAG_DG_INDEX12,
    TAG_DG_INDEX13,
    TAG_DG_INDEX14,
    TAG_DG_INDEX15,
    TAG_DG_INDEX16,
    TAG_DG_INDEX17,
    TAG_DG_INDEX18,
    ALS_DG_SEQFILE_FLASHERR,

    TAG_DG_INDEX_MAX,
};




#define TID_DG                                  10
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

enum
{
    TID_DG_GROUP0  =  BUILD_L2CODE(TID_DG, 0),          TID_DG_GROUP1  =  BUILD_L2CODE(TID_DG, 1),
    TID_DG_GROUP2  =  BUILD_L2CODE(TID_DG, 2),          TID_DG_GROUP3  =  BUILD_L2CODE(TID_DG, 3)
};


/*For HMIS*/
typedef enum
{
    TID_DG_CPU_LOAD             = TID_DG_GROUP0,
    TID_DG_CORE_LOAD,
    TID_DG_DNP_TCP_CONNSTS,
    TID_DG_DNP_SR0_CONNSTS,
    TID_DG_DNP_SR1_CONNSTS,
    TID_DG_INDV_FLTR_SRC,
    TID_DG_INDV_FLTR_LOAD,

} TAGID_DG_UI;


#endif /* USERLOGIC_ALIAS_ALIAS_DG_H_ */
