/*
 * Alias_BV.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_BV_H_
#define USERLOGIC_ALIAS_BV_H_

enum
{
    ALS_BV_52A,
    ALS_BV_ENCLACNT,
    ALS_BV_59A1,
    ALS_BV_59B1,
    ALS_BV_59C1,
    ALS_BV_50LA,
    ALS_BV_50LB,
    ALS_BV_50LC,
    ALS_BV_50L,
    ALS_BV_BFT,
    ALS_BV_BFA,
    ALS_BV_BFB,
    ALS_BV_BFC,
    ALS_BV_INRPRS,
    ALS_BV_INRGRS,
    ALS_BV_INRPRD,

    ALS_BV_INRP,
    ALS_BV_NON,
    ALS_BV_FLT,
    ALS_BV_TCCTRIP,
    ALS_BV_DEFTRIP,
    ALS_BV_FCCTRIP,
    ALS_BV_EWT,
    ALS_BV_VITTR,
    ALS_BV_CPTR,
    ALS_BV_RS,
    ALS_BV_SYSRESET,
    ALS_BV_VITEN,
    ALS_BV_79CYP,
    ALS_BV_79LOP,
    ALS_BV_79DTL,
    ALS_BV_CF,

    ALS_BV_RCSF,
    ALS_BV_TRF,
    ALS_BV_TRIP,
    ALS_BV_TR,
    ALS_BV_79DLS,
    ALS_BV_79EN,
    ALS_BV_V79LO,
    ALS_BV_79RI,
    ALS_BV_79RIS,
    ALS_BV_50P1,
    ALS_BV_50N1,
    ALS_BV_LOCKTRIP,
    ALS_BV_SCHF,
    ALS_BV_ULCL,
    ALS_BV_VEXOR,
    ALS_BV_DCL,

    ALS_BV_CNCV1,
    ALS_BV_CNOV1,
    ALS_BV_CLT,
    ALS_BV_BLT,
    ALS_BV_BLT1,
    ALS_BV_FCP,
    ALS_BV_OVCN,
    ALS_BV_FCC,
    ALS_BV_FPU,
    ALS_BV_NCTRS,
    ALS_BV_MTR,
    ALS_BV_MRS,
    ALS_BV_ENPR,
    ALS_BV_OT,
    ALS_BV_FCN1,
    ALS_BV_NCOPCNRS,

    ALS_BV_79NCRS,
    ALS_BV_79FRS,
    ALS_BV_MLRS,
    ALS_BV_OP30,
    ALS_BV_OPC,
    ALS_BV_51TCF,
    ALS_BV_50P1A,
    ALS_BV_50P1B,
    ALS_BV_50P1C,
    ALS_BV_51P1A,
    ALS_BV_51P1B,
    ALS_BV_51P1C,
    ALS_BV_50N6,
    ALS_BV_TARR,
    ALS_BV_FIRS,
    ALS_BV_UNBC,

    ALS_BV_UNBVDO,
    ALS_BV_OP40,
    ALS_BV_INRG,
    ALS_BV_CPULED,
    ALS_BV_CTT,
    ALS_BV_IPT,
    ALS_BV_OCCP,
    ALS_BV_OCCL,
    ALS_BV_OVCHV,
    ALS_BV_CHVNORMAL,
    ALS_BV_NONCHV,
    ALS_BV_CHVFAIL,
    ALS_BV_OVOPV,
    ALS_BV_OPVNORMAL,
    ALS_BV_OPVFAIL,
    ALS_BV_NONOPV,

    ALS_BV_UVCHV,
    ALS_BV_UVOPV,
    ALS_BV_UNBV,
    ALS_BV_UNBVTR,
    ALS_BV_EXPOWER,
    ALS_BV_59R1,
    ALS_BV_59S1,
    ALS_BV_59T1,
    ALS_BV_CLPPH,
    ALS_BV_CLPGR,
    ALS_BV_51P1TCF,
    ALS_BV_51P1TCD,
    ALS_BV_51N1TCF,
    ALS_BV_51N1TCD,
    ALS_BV_CLOSE,
    ALS_BV_CL,

    ALS_BV_CLF,
    ALS_BV_PFT,
    ALS_BV_NFT,
    ALS_BV_PDT,
    ALS_BV_NDT,
    ALS_BV_LAMPTEST,
    ALS_BV_CLPSL,
    ALS_BV_RMTP,
    ALS_BV_RMTG,
    ALS_BV_BATTEST,
    ALS_BV_BATTB,
    ALS_BV_BATLOW,
    ALS_BV_LO,
    ALS_BV_CNOV5,
    ALS_BV_EMOL,
    ALS_BV_DSPERR,

    ALS_BV_ADCERR,
    ALS_BV_RTCERR,
    ALS_BV_MEMERR,
    ALS_BV_FLASHERR,
    ALS_BV_CIRVERR,
    ALS_BV_SCERR,
    ALS_BV_PRISETERR,
    ALS_BV_ALTSETERR,
    ALS_BV_EVENTERR,
    ALS_BV_COUNTERR,
    ALS_BV_DOERR,
    ALS_BV_CLOSEERR,
    ALS_BV_TRIPERR,
    ALS_BV_AUX1ERR,
    ALS_BV_AUX2ERR,
    ALS_BV_81P1T,

    ALS_BV_81P2T,
    ALS_BV_47P1T,
    ALS_BV_3P27P1AND,
    ALS_BV_3P27Q1AND,
    ALS_BV_3P59P1AND,
    ALS_BV_3P59P1OR,
    ALS_BV_3P59Q1OR,
    ALS_BV_27P2T,
    ALS_BV_51P5T,
    ALS_BV_51P5RS,
    ALS_BV_3P50L,
    ALS_BV_59P2T,
    ALS_BV_81P3T,
    ALS_BV_32P1T,
    ALS_BV_59N1T,
    ALS_BV_TR2,

    ALS_BV_TR3,
    ALS_BV_TR4,
    ALS_BV_TR9,
    ALS_BV_TR10,
    ALS_BV_79RS,
    ALS_BV_79CY,
    ALS_BV_79LO,
    ALS_BV_SH0,
    ALS_BV_SH1,
    ALS_BV_SH2,
    ALS_BV_SH3,
    ALS_BV_OCP,
    ALS_BV_OCG,
    ALS_BV_HTP,
    ALS_BV_HTG,
    ALS_BV_OLP,

    ALS_BV_OLG,
    ALS_BV_OLS,
    ALS_BV_HLP,
    ALS_BV_HLG,
    ALS_BV_DLS0,
    ALS_BV_DLS1,
    ALS_BV_DLS2,
    ALS_BV_DLS3,
    ALS_BV_LSH0,
    ALS_BV_LSH1,
    ALS_BV_LSH2,
    ALS_BV_LSH3,
    ALS_BV_79E1,
    ALS_BV_79E2,
    ALS_BV_79E3,
    ALS_BV_79LO1,

    ALS_BV_79LO2,
    ALS_BV_79LO3,
    ALS_BV_79LO4,
    ALS_BV_79LO5,
    ALS_BV_79LO6,
    ALS_BV_79LO8,
    ALS_BV_79RSTO,
    ALS_BV_79SEQ,
    ALS_BV_79RST,
    ALS_BV_79BRS,
    ALS_BV_79RSLT,
    ALS_BV_79NORS,
    ALS_BV_79ARS,
    ALS_BV_V79CY,
    ALS_BV_V79RS,
    ALS_BV_51P1F,

    ALS_BV_51N1F,
    ALS_BV_51P1D,
    ALS_BV_51N1D,
    ALS_BV_50P1T,
    ALS_BV_50N1T,
    ALS_BV_SV13,
    ALS_BV_SV15,
    ALS_BV_SV16,
    ALS_BV_79OI1T,
    ALS_BV_79OI2T,
    ALS_BV_79OI3T,
    ALS_BV_79OITO,
    ALS_BV_51P1TF,
    ALS_BV_51P1TD,
    ALS_BV_51N1TF,
    ALS_BV_51N1TD,

    ALS_BV_CNCV2,
    ALS_BV_CNCV3,
    ALS_BV_CNCV4,
    ALS_BV_CNOV2,
    ALS_BV_CNOV3,
    ALS_BV_CNOV4,
    ALS_BV_FCN2,
    ALS_BV_FCN3,
    ALS_BV_FCN4,
    ALS_BV_SOP2,
    ALS_BV_SOP3,
    ALS_BV_SOP4,
    ALS_BV_NONCCL,
    ALS_BV_BOCCL,
    ALS_BV_RSCL,
    ALS_BV_OLT,

    ALS_BV_DTL14,
    ALS_BV_DTL16,
    ALS_BV_DTL15,
    ALS_BV_DTL17,
    ALS_BV_DTL19,
    ALS_BV_DTL23,
    ALS_BV_DTL25,
    ALS_BV_DTL26,
    ALS_BV_DTL27,
    ALS_BV_NOCL,
    ALS_BV_NCCL,
    ALS_BV_VAND,
    ALS_BV_NCT,
    ALS_BV_NCVCP,
    ALS_BV_NOVCP,
    ALS_BV_YCT,

    ALS_BV_NOCN,
    ALS_BV_BPL,
    ALS_BV_PORS,
    ALS_BV_LOVCP,
    ALS_BV_FTIA,
    ALS_BV_FTIB,
    ALS_BV_FTIC,
    ALS_BV_FTIN,
    ALS_BV_FTSEF,
    ALS_BV_WMP,
    ALS_BV_SG1,
    ALS_BV_SG2,
    ALS_BV_51P4,
    ALS_BV_50P4,
    ALS_BV_51N4,
    ALS_BV_51P3,

    ALS_BV_50N4,
    ALS_BV_50P3,
    ALS_BV_27A1,
    ALS_BV_27B1,
    ALS_BV_27C1,
    ALS_BV_27R1,
    ALS_BV_27S1,
    ALS_BV_27T1,
    ALS_BV_67PTC,
    ALS_BV_67NTC,
    ALS_BV_51N3,
    ALS_BV_50N3,
    ALS_BV_50PTC,
    ALS_BV_50NTC,
    ALS_BV_51PTC,
    ALS_BV_51NTC,

    ALS_BV_50N6T,
    ALS_BV_51P1RF,
    ALS_BV_51N1RF,
    ALS_BV_51P1RD,
    ALS_BV_51N1RD,
    ALS_BV_51P1,
    ALS_BV_51N1,
    ALS_BV_OPFB,
    ALS_BV_CPFB,
    ALS_BV_MODFB,
    ALS_BV_CWF,
    ALS_BV_CFB,
    ALS_BV_COCT,
    ALS_BV_ENA2R,
    ALS_BV_ENR2A,
    ALS_BV_CPT,

    ALS_BV_V79OITO,
    ALS_BV_POLYMER_SRC,
    ALS_BV_POLYMER_LOAD,

    TAG_BV_INDEX_MAX,

};

/*TAG ID*/
#define TID_BV                                  4
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
enum
{
    TID_BV_GROUP0   =  BUILD_L2CODE(TID_BV, 0),      TID_BV_GROUP1   =  BUILD_L2CODE(TID_BV, 1),        TID_BV_GROUP2   =  BUILD_L2CODE(TID_BV, 2),
    TID_BV_GROUP3   =  BUILD_L2CODE(TID_BV, 3),      TID_BV_GROUP4   =  BUILD_L2CODE(TID_BV, 4),        TID_BV_GROUP5   =  BUILD_L2CODE(TID_BV, 5),
    TID_BV_GROUP6   =  BUILD_L2CODE(TID_BV, 6),      TID_BV_GROUP7   =  BUILD_L2CODE(TID_BV, 7),        TID_BV_GROUP8   =  BUILD_L2CODE(TID_BV, 8),
    TID_BV_GROUP9   =  BUILD_L2CODE(TID_BV, 9),      TID_BV_GROUP10  =  BUILD_L2CODE(TID_BV, 10),       TID_BV_GROUP11  =  BUILD_L2CODE(TID_BV, 11),
    TID_BV_GROUP12  =  BUILD_L2CODE(TID_BV, 12),     TID_BV_GROUP13  =  BUILD_L2CODE(TID_BV, 13),       TID_BV_GROUP14  =  BUILD_L2CODE(TID_BV, 14),
    TID_BV_GROUP15  =  BUILD_L2CODE(TID_BV, 15),     TID_BV_GROUP16  =  BUILD_L2CODE(TID_BV, 16),       TID_BV_GROUP17  =  BUILD_L2CODE(TID_BV, 17),
    TID_BV_GROUP18  =  BUILD_L2CODE(TID_BV, 18),     TID_BV_GROUP19  =  BUILD_L2CODE(TID_BV, 19)
};

/*Group Index 0*/
enum
{
    TID_BV_G0_0             = TID_BV_GROUP0,
    TID_BV_G0_1,            TID_BV_G0_2,            TID_BV_G0_3,        TID_BV_G0_4,
    TID_BV_G0_5,            TID_BV_G0_6,            TID_BV_G0_7,        TID_BV_G0_8,
    TID_BV_G0_9,            TID_BV_G0_10,           TID_BV_G0_11,       TID_BV_G0_12,
    TID_BV_G0_13,           TID_BV_G0_14,           TID_BV_G0_15

};

/*Group Index 1*/
enum
{
    TID_BV_G1_0             = TID_BV_GROUP1,
    TID_BV_G1_1,            TID_BV_G1_2,            TID_BV_G1_3,        TID_BV_G1_4,
    TID_BV_G1_5,            TID_BV_G1_6,            TID_BV_G1_7,        TID_BV_G1_8,
    TID_BV_G1_9,            TID_BV_G1_10,           TID_BV_G1_11,       TID_BV_G1_12,
    TID_BV_G1_13,           TID_BV_G1_14,           TID_BV_G1_15

};

/*Group Index 2*/
enum
{
    TID_BV_G2_0             = TID_BV_GROUP2,
    TID_BV_G2_1,            TID_BV_G2_2,            TID_BV_G2_3,        TID_BV_G2_4,
    TID_BV_G2_5,            TID_BV_G2_6,            TID_BV_G2_7,        TID_BV_G2_8,
    TID_BV_G2_9,            TID_BV_G2_10,           TID_BV_G2_11,       TID_BV_G2_12,
    TID_BV_G2_13,           TID_BV_G2_14,           TID_BV_G2_15

};

/*Group Index 3*/
enum
{
    TID_BV_G3_0             = TID_BV_GROUP3,
    TID_BV_G3_1,            TID_BV_G3_2,            TID_BV_G3_3,        TID_BV_G3_4,
    TID_BV_G3_5,            TID_BV_G3_6,            TID_BV_G3_7,        TID_BV_G3_8,
    TID_BV_G3_9,            TID_BV_G3_10,           TID_BV_G3_11,       TID_BV_G3_12,
    TID_BV_G3_13,           TID_BV_G3_14,           TID_BV_G3_15

};

/*Group Index 4*/
enum
{
    TID_BV_G4_0             = TID_BV_GROUP4,
    TID_BV_G4_1,            TID_BV_G4_2,            TID_BV_G4_3,        TID_BV_G4_4,
    TID_BV_G4_5,            TID_BV_G4_6,            TID_BV_G4_7,        TID_BV_G4_8,
    TID_BV_G4_9,            TID_BV_G4_10,           TID_BV_G4_11,       TID_BV_G4_12,
    TID_BV_G4_13,           TID_BV_G4_14,           TID_BV_G4_15

};

/*Group Index 5*/
enum
{
    TID_BV_G5_0             = TID_BV_GROUP5,
    TID_BV_G5_1,            TID_BV_G5_2,            TID_BV_G5_3,        TID_BV_G5_4,
    TID_BV_G5_5,            TID_BV_G5_6,            TID_BV_G5_7,        TID_BV_G5_8,
    TID_BV_G5_9,            TID_BV_G5_10,           TID_BV_G5_11,       TID_BV_G5_12,
    TID_BV_G5_13,           TID_BV_G5_14,           TID_BV_G5_15

};

/*Group Index 6*/
enum
{
    TID_BV_G6_0             = TID_BV_GROUP6,
    TID_BV_G6_1,            TID_BV_G6_2,            TID_BV_G6_3,        TID_BV_G6_4,
    TID_BV_G6_5,            TID_BV_G6_6,            TID_BV_G6_7,        TID_BV_G6_8,
    TID_BV_G6_9,            TID_BV_G6_10,           TID_BV_G6_11,       TID_BV_G6_12,
    TID_BV_G6_13,           TID_BV_G6_14,           TID_BV_G6_15

};

/*Group Index 7*/
enum
{
    TID_BV_G7_0             = TID_BV_GROUP7,
    TID_BV_G7_1,            TID_BV_G7_2,            TID_BV_G7_3,        TID_BV_G7_4,
    TID_BV_G7_5,            TID_BV_G7_6,            TID_BV_G7_7,        TID_BV_G7_8,
    TID_BV_G7_9,            TID_BV_G7_10,           TID_BV_G7_11,       TID_BV_G7_12,
    TID_BV_G7_13,           TID_BV_G7_14,           TID_BV_G7_15

};

/*Group Index 8*/
enum
{
    TID_BV_G8_0             = TID_BV_GROUP8,
    TID_BV_G8_1,            TID_BV_G8_2,            TID_BV_G8_3,        TID_BV_G8_4,
    TID_BV_G8_5,            TID_BV_G8_6,            TID_BV_G8_7,        TID_BV_G8_8,
    TID_BV_G8_9,            TID_BV_G8_10,           TID_BV_G8_11,       TID_BV_G8_12,
    TID_BV_G8_13,           TID_BV_G8_14,           TID_BV_G8_15

};

/*Group Index 9*/
enum
{
    TID_BV_G9_0             = TID_BV_GROUP9,
    TID_BV_G9_1,            TID_BV_G9_2,            TID_BV_G9_3,        TID_BV_G9_4,
    TID_BV_G9_5,            TID_BV_G9_6,            TID_BV_G9_7,        TID_BV_G9_8,
    TID_BV_G9_9,            TID_BV_G9_10,           TID_BV_G9_11,       TID_BV_G9_12,
    TID_BV_G9_13,           TID_BV_G9_14,           TID_BV_G9_15

};

/*Group Index 10*/
enum
{
    TID_BV_G10_0            = TID_BV_GROUP10,
    TID_BV_G10_1,           TID_BV_G10_2,           TID_BV_G10_3,       TID_BV_G10_4,
    TID_BV_G10_5,           TID_BV_G10_6,           TID_BV_G10_7,       TID_BV_G10_8,
    TID_BV_G10_9,           TID_BV_G10_10,          TID_BV_G10_11,      TID_BV_G10_12,
    TID_BV_G10_13,          TID_BV_G10_14,          TID_BV_G10_15

};

/*Group Index 11*/
enum
{
    TID_BV_G11_0            = TID_BV_GROUP11,
    TID_BV_G11_1,           TID_BV_G11_2,           TID_BV_G11_3,       TID_BV_G11_4,
    TID_BV_G11_5,           TID_BV_G11_6,           TID_BV_G11_7,       TID_BV_G11_8,
    TID_BV_G11_9,           TID_BV_G11_10,          TID_BV_G11_11,      TID_BV_G11_12,
    TID_BV_G11_13,          TID_BV_G11_14,          TID_BV_G11_15

};

/*Group Index 12*/
enum
{
    TID_BV_G12_0            = TID_BV_GROUP12,
    TID_BV_G12_1,           TID_BV_G12_2,           TID_BV_G12_3,       TID_BV_G12_4,
    TID_BV_G12_5,           TID_BV_G12_6,           TID_BV_G12_7,       TID_BV_G12_8,
    TID_BV_G12_9,           TID_BV_G12_10,          TID_BV_G12_11,      TID_BV_G12_12,
    TID_BV_G12_13,          TID_BV_G12_14,          TID_BV_G12_15

};

/*Group Index 13*/
enum
{
    TID_BV_G13_0            = TID_BV_GROUP13,
    TID_BV_G13_1,           TID_BV_G13_2,           TID_BV_G13_3,       TID_BV_G13_4,
    TID_BV_G13_5,           TID_BV_G13_6,           TID_BV_G13_7,       TID_BV_G13_8,
    TID_BV_G13_9,           TID_BV_G13_10,          TID_BV_G13_11,      TID_BV_G13_12,
    TID_BV_G13_13,          TID_BV_G13_14,          TID_BV_G13_15

};

/*Group Index 14*/
enum
{
    TID_BV_G14_0            = TID_BV_GROUP14,
    TID_BV_G14_1,           TID_BV_G14_2,           TID_BV_G14_3,       TID_BV_G14_4,
    TID_BV_G14_5,           TID_BV_G14_6,           TID_BV_G14_7,       TID_BV_G14_8,
    TID_BV_G14_9,           TID_BV_G14_10,          TID_BV_G14_11,      TID_BV_G14_12,
    TID_BV_G14_13,          TID_BV_G14_14,          TID_BV_G14_15
};

/*Group Index 15*/
enum
{
    TID_BV_G15_0            = TID_BV_GROUP15,
    TID_BV_G15_1,           TID_BV_G15_2,           TID_BV_G15_3,       TID_BV_G15_4,
    TID_BV_G15_5,           TID_BV_G15_6,           TID_BV_G15_7,       TID_BV_G15_8,
    TID_BV_G15_9,           TID_BV_G15_10,          TID_BV_G15_11,      TID_BV_G15_12,
    TID_BV_G15_13,          TID_BV_G15_14,          TID_BV_G15_15

};

/*Group Index 16*/
enum
{
    TID_BV_G16_0            = TID_BV_GROUP16,
    TID_BV_G16_1,           TID_BV_G16_2,           TID_BV_G16_3,       TID_BV_G16_4,
    TID_BV_G16_5,           TID_BV_G16_6,           TID_BV_G16_7,       TID_BV_G16_8,
    TID_BV_G16_9,           TID_BV_G16_10,          TID_BV_G16_11,      TID_BV_G16_12,
    TID_BV_G16_13,          TID_BV_G16_14,          TID_BV_G16_15

};

/*Group Index 17*/
enum
{
    TID_BV_G17_0            = TID_BV_GROUP17,
    TID_BV_G17_1,           TID_BV_G17_2,           TID_BV_G17_3,       TID_BV_G17_4,
    TID_BV_G17_5,           TID_BV_G17_6,           TID_BV_G17_7,       TID_BV_G17_8,
    TID_BV_G17_9,           TID_BV_G17_10,          TID_BV_G17_11,      TID_BV_G17_12,
    TID_BV_G17_13,          TID_BV_G17_14,          TID_BV_G17_15

};

/*Group Index 18*/
enum
{
    TID_BV_G18_0            = TID_BV_GROUP18,
    TID_BV_G18_1,           TID_BV_G18_2,           TID_BV_G18_3,       TID_BV_G18_4,
    TID_BV_G18_5,           TID_BV_G18_6,           TID_BV_G18_7,       TID_BV_G18_8,
    TID_BV_G18_9,           TID_BV_G18_10,          TID_BV_G18_11,      TID_BV_G18_12,
    TID_BV_G18_13,          TID_BV_G18_14,          TID_BV_G18_15

};

/*Group Index 19*/
enum
{
    TID_BV_G19_0            = TID_BV_GROUP19,
    TID_BV_G19_1,           TID_BV_G19_2,           TID_BV_G19_3,       TID_BV_G19_4,
    TID_BV_G19_5,           TID_BV_G19_6

};

/*For HMIS*/
typedef enum
{
    TID_BV_52A              = TID_BV_G0_0,
    TID_BV_ENCLACNT,
    TID_BV_59A1,
    TID_BV_59B1,
    TID_BV_59C1,
    TID_BV_50LA,
    TID_BV_50LB,
    TID_BV_50LC,
    TID_BV_50L,
    TID_BV_BFT,
    TID_BV_BFA,
    TID_BV_BFB,
    TID_BV_BFC,
    TID_BV_INRPRS,
    TID_BV_INRGRS,
    TID_BV_INRPRD,

    TID_BV_INRP             = TID_BV_G1_0,
    TID_BV_NON,
    TID_BV_FLT,
    TID_BV_TCCTRIP,
    TID_BV_DEFTRIP,
    TID_BV_FCCTRIP,
    TID_BV_EWT,
    TID_BV_VITTR,
    TID_BV_CPTR,
    TID_BV_RS,
    TID_BV_SYSRESET,
    TID_BV_VITEN,
    TID_BV_79CYP,
    TID_BV_79LOP,
    TID_BV_79DTL,
    TID_BV_CF,

    TID_BV_RCSF             = TID_BV_G2_0,
    TID_BV_TRF,
    TID_BV_TRIP,
    TID_BV_TR,
    TID_BV_79DLS,
    TID_BV_79EN,
    TID_BV_V79LO,
    TID_BV_79RI,
    TID_BV_79RIS,
    TID_BV_50P1,
    TID_BV_50N1,
    TID_BV_LOCKTRIP,
    TID_BV_SCHF,
    TID_BV_ULCL,
    TID_BV_VEXOR,
    TID_BV_DCL,

    TID_BV_CNCV1            = TID_BV_G3_0,
    TID_BV_CNOV1,
    TID_BV_CLT,
    TID_BV_BLT,
    TID_BV_BLT1,
    TID_BV_FCP,
    TID_BV_OVCN,
    TID_BV_FCC,
    TID_BV_FPU,
    TID_BV_NCTRS,
    TID_BV_MTR,
    TID_BV_MRS,
    TID_BV_ENPR,
    TID_BV_OT,
    TID_BV_FCN1,
    TID_BV_NCOPCNRS,

    TID_BV_79NCRS           = TID_BV_G4_0,
    TID_BV_79FRS,
    TID_BV_MLRS,
    TID_BV_OP30,
    TID_BV_OPC,
    TID_BV_51TCF,
    TID_BV_50P1A,
    TID_BV_50P1B,
    TID_BV_50P1C,
    TID_BV_51P1A,
    TID_BV_51P1B,
    TID_BV_51P1C,
    TID_BV_50N6,
    TID_BV_TARR,
    TID_BV_FIRS,
    TID_BV_UNBC,

    TID_BV_UNBVDO           = TID_BV_G5_0,
    TID_BV_OP40,
    TID_BV_INRG,
    TID_BV_CPULED,
    TID_BV_CTT,
    TID_BV_IPT,
    TID_BV_OCCP,
    TID_BV_OCCL,
    TID_BV_OVCHV,
    TID_BV_CHVNORMAL,
    TID_BV_NONCHV,
    TID_BV_CHVFAIL,
    TID_BV_OVOPV,
    TID_BV_OPVNORMAL,
    TID_BV_OPVFAIL,
    TID_BV_NONOPV,

    TID_BV_UVCHV            = TID_BV_G6_0,
    TID_BV_UVOPV,
    TID_BV_UNBV,
    TID_BV_UNBVTR,
    TID_BV_EXPOWER,
    TID_BV_59R1,
    TID_BV_59S1,
    TID_BV_59T1,
    TID_BV_CLPPH,
    TID_BV_CLPGR,
    TID_BV_51P1TCF,
    TID_BV_51P1TCD,
    TID_BV_51N1TCF,
    TID_BV_51N1TCD,
    TID_BV_CLOSE,
    TID_BV_CL,

    TID_BV_CLF              = TID_BV_G7_0,
    TID_BV_PFT,
    TID_BV_NFT,
    TID_BV_PDT,
    TID_BV_NDT,
    TID_BV_LAMPTEST,
    TID_BV_CLPSL,
    TID_BV_RMTP,
    TID_BV_RMTG,
    TID_BV_BATTEST,
    TID_BV_BATTB,
    TID_BV_BATLOW,
    TID_BV_LO,
    TID_BV_CNOV5,
    TID_BV_EMOL,
    TID_BV_DSPERR,

    TID_BV_ADCERR           = TID_BV_G8_0,
    TID_BV_RTCERR,
    TID_BV_MEMERR,
    TID_BV_FLASHERR,
    TID_BV_CIRVERR,
    TID_BV_SCERR,
    TID_BV_PRISETERR,
    TID_BV_ALTSETERR,
    TID_BV_EVENTERR,
    TID_BV_COUNTERR,
    TID_BV_DOERR,
    TID_BV_CLOSEERR,
    TID_BV_TRIPERR,
    TID_BV_AUX1ERR,
    TID_BV_AUX2ERR,
    TID_BV_81P1T,

    TID_BV_81P2T            = TID_BV_G9_0,
    TID_BV_47P1T,
    TID_BV_3P27P1AND,
    TID_BV_3P27Q1AND,
    TID_BV_3P59P1AND,
    TID_BV_3P59P1OR,
    TID_BV_3P59Q1OR,
    TID_BV_27P2T,
    TID_BV_51P5T,
    TID_BV_51P5RS,
    TID_BV_3P50L,
    TID_BV_59P2T,
    TID_BV_81P3T,
    TID_BV_32P1T,
    TID_BV_59N1T,
    TID_BV_TR2,

    TID_BV_TR3              = TID_BV_G10_0,
    TID_BV_TR4,
    TID_BV_TR9,
    TID_BV_TR10,
    TID_BV_79RS,
    TID_BV_79CY,
    TID_BV_79LO,
    TID_BV_SH0,
    TID_BV_SH1,
    TID_BV_SH2,
    TID_BV_SH3,
    TID_BV_OCP,
    TID_BV_OCG,
    TID_BV_HTP,
    TID_BV_HTG,
    TID_BV_OLP,

    TID_BV_OLG              = TID_BV_G11_0,
    TID_BV_OLS,
    TID_BV_HLP,
    TID_BV_HLG,
    TID_BV_DLS0,
    TID_BV_DLS1,
    TID_BV_DLS2,
    TID_BV_DLS3,
    TID_BV_LSH0,
    TID_BV_LSH1,
    TID_BV_LSH2,
    TID_BV_LSH3,
    TID_BV_79E1,
    TID_BV_79E2,
    TID_BV_79E3,
    TID_BV_79LO1,

    TID_BV_79LO2            = TID_BV_G12_0,
    TID_BV_79LO3,
    TID_BV_79LO4,
    TID_BV_79LO5,
    TID_BV_79LO6,
    TID_BV_79LO8,
    TID_BV_79RSTO,
    TID_BV_79SEQ,
    TID_BV_79RST,
    TID_BV_79BRS,
    TID_BV_79RSLT,
    TID_BV_79NORS,
    TID_BV_79ARS,
    TID_BV_V79CY,
    TID_BV_V79RS,
    TID_BV_51P1F,

    TID_BV_51N1F            = TID_BV_G13_0,
    TID_BV_51P1D,
    TID_BV_51N1D,
    TID_BV_50P1T,
    TID_BV_50N1T,
    TID_BV_SV13,
    TID_BV_SV15,
    TID_BV_SV16,
    TID_BV_79OI1T,
    TID_BV_79OI2T,
    TID_BV_79OI3T,
    TID_BV_79OITO,
    TID_BV_51P1TF,
    TID_BV_51P1TD,
    TID_BV_51N1TF,
    TID_BV_51N1TD,

    TID_BV_CNCV2            = TID_BV_G14_0,
    TID_BV_CNCV3,
    TID_BV_CNCV4,
    TID_BV_CNOV2,
    TID_BV_CNOV3,
    TID_BV_CNOV4,
    TID_BV_FCN2,
    TID_BV_FCN3,
    TID_BV_FCN4,
    TID_BV_SOP2,
    TID_BV_SOP3,
    TID_BV_SOP4,
    TID_BV_NONCCL,
    TID_BV_BOCCL,
    TID_BV_RSCL,
    TID_BV_OLT,

    TID_BV_DTL14            = TID_BV_G15_0,
    TID_BV_DTL16,
    TID_BV_DTL15,
    TID_BV_DTL17,
    TID_BV_DTL19,
    TID_BV_DTL23,
    TID_BV_DTL25,
    TID_BV_DTL26,
    TID_BV_DTL27,
    TID_BV_NOCL,
    TID_BV_NCCL,
    TID_BV_VAND,
    TID_BV_NCT,
    TID_BV_NCVCP,
    TID_BV_NOVCP,
    TID_BV_YCT,

    TID_BV_NOCN             = TID_BV_G16_0,
    TID_BV_BPL,
    TID_BV_PORS,
    TID_BV_LOVCP,
    TID_BV_FTIA,
    TID_BV_FTIB,
    TID_BV_FTIC,
    TID_BV_FTIN,
    TID_BV_FTSEF,
    TID_BV_WMP,
    TID_BV_SG1,
    TID_BV_SG2,
    TID_BV_51P4,
    TID_BV_50P4,
    TID_BV_51N4,
    TID_BV_51P3,

    TID_BV_50N4             = TID_BV_G17_0,
    TID_BV_50P3,
    TID_BV_27A1,
    TID_BV_27B1,
    TID_BV_27C1,
    TID_BV_27R1,
    TID_BV_27S1,
    TID_BV_27T1,
    TID_BV_67PTC,
    TID_BV_67NTC,
    TID_BV_51N3,
    TID_BV_50N3,
    TID_BV_50PTC,
    TID_BV_50NTC,
    TID_BV_51PTC,
    TID_BV_51NTC,

    TID_BV_50N6T            = TID_BV_G18_0,
    TID_BV_51P1RF,
    TID_BV_51N1RF,
    TID_BV_51P1RD,
    TID_BV_51N1RD,
    TID_BV_51P1,
    TID_BV_51N1,
    TID_BV_OPFB,
    TID_BV_CPFB,
    TID_BV_MODFB,
    TID_BV_CWF,
    TID_BV_CFB,
    TID_BV_COCT,
    TID_BV_ENA2R,
    TID_BV_ENR2A,
    TID_BV_CPT,

    TID_BV_V79OITO            = TID_BV_G19_0,
    TID_BV_POLYMER_SRC,
    TID_BV_POLYMER_LOAD,
    TID_BV_USealIn,
    TID_BV_FAULT1,
    TID_BV_FAULT2,
    TID_BV_FAULT3,

} TAGID_BV;





#endif /* USERLOGIC_ALIAS_BV_H_ */
