/*
 * Alias_SIM.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_ALIAS_SIM_H_
#define USERLOGIC_ALIAS_ALIAS_SIM_H_
enum
{
    ALS_SIM_RMS_VA,
    ALS_SIM_RMS_VB,
    ALS_SIM_RMS_VC,
    ALS_SIM_RMS_VR,
    ALS_SIM_RMS_VS,
    ALS_SIM_RMS_VT,
    ALS_SIM_RMS_IA,
    ALS_SIM_RMS_IB,
    ALS_SIM_RMS_IC,
    ALS_SIM_RMS_IN,
};
enum
{
    ALS_SIM_ANG_VA,
    ALS_SIM_ANG_VB,
    ALS_SIM_ANG_VC,
    ALS_SIM_ANG_VR,
    ALS_SIM_ANG_VS,
    ALS_SIM_ANG_VT,
    ALS_SIM_ANG_IA,
    ALS_SIM_ANG_IB,
    ALS_SIM_ANG_IC,
    ALS_SIM_ANG_IN,
};
enum
{
    ALS_SIM_FREQ_VA,
    ALS_SIM_FREQ_VB,
    ALS_SIM_FREQ_VC,
    ALS_SIM_FREQ_VR,
    ALS_SIM_FREQ_VS,
    ALS_SIM_FREQ_VT,
};
enum
{
    ALS_SIM_GPAI_0,
    ALS_SIM_GPAI_1,
    ALS_SIM_GPAI_2,
    ALS_SIM_GPAI_3,
    ALS_SIM_GPAI_4,
    ALS_SIM_GPAI_5,
    ALS_SIM_GPAI_6,
    ALS_SIM_GPAI_7,
    ALS_SIM_GPAI_8,
    ALS_SIM_GPAI_9,
    ALS_SIM_GPAI_10,
    ALS_SIM_GPAI_11,
    ALS_SIM_GPAI_12,
    ALS_SIM_GPAI_13,
    ALS_SIM_GPAI_14,
    ALS_SIM_GPAI_15,
};
enum
{
    ALS_SIM_DI_0,
    ALS_SIM_DI_1,
    ALS_SIM_DI_2,
    ALS_SIM_DI_3,
    ALS_SIM_DI_4,
    ALS_SIM_DI_5,
    ALS_SIM_DI_6,
    ALS_SIM_DI_7,
    ALS_SIM_DI_8,
    ALS_SIM_DI_9,
    ALS_SIM_DI_10,
    ALS_SIM_DI_11,
    ALS_SIM_DI_12,
    ALS_SIM_DI_13,
    ALS_SIM_DI_14,
    ALS_SIM_DI_15,
};

/*TAG ID*/
#define TID_SIM                                  8
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
enum
{
    TID_SIM_GROUP0  =  BUILD_L2CODE(TID_SIM, 0),     TID_SIM_GROUP1  =  BUILD_L2CODE(TID_SIM, 1),      TID_SIM_GROUP2  =  BUILD_L2CODE(TID_SIM, 2),
    TID_SIM_GROUP3  =  BUILD_L2CODE(TID_SIM, 3),     TID_SIM_GROUP4  =  BUILD_L2CODE(TID_SIM, 4)
};

/*Group Index 0*/
enum
{
    TID_SIM_VA_RMS          = TID_SIM_GROUP0,
    TID_SIM_VB_RMS,         TID_SIM_VC_RMS,             TID_SIM_VR_RMS,             TID_SIM_VS_RMS,
    TID_SIM_VT_RMS,         TID_SIM_IA_RMS,             TID_SIM_IB_RMS,             TID_SIM_IC_RMS,
    TID_SIM_IN_RMS
};

/*Group Index 1*/
enum
{
    TID_SIM_VA_ANG          = TID_SIM_GROUP1,
    TID_SIM_VB_ANG,         TID_SIM_VC_ANG,             TID_SIM_VR_ANG,             TID_SIM_VS_ANG,
    TID_SIM_VT_ANG,         TID_SIM_IA_ANG,             TID_SIM_IB_ANG,             TID_SIM_IC_ANG,
    TID_SIM_IN_ANG
};

/*Group Index 2*/
enum
{
    TID_SIM_VA_FREQ         = TID_SIM_GROUP2,
    TID_SIM_VB_FREQ,        TID_SIM_VC_FREQ,            TID_SIM_VR_FREQ,            TID_SIM_VS_FREQ,
    TID_SIM_VT_FREQ,        TID_SIM_IA_FREQ,            TID_SIM_IB_FREQ,            TID_SIM_IC_FREQ,
    TID_SIM_IN_FREQ
};

/*Group Index 3*/
enum
{
    TID_SIM_GPAI_0          = TID_SIM_GROUP3,
    TID_SIM_GPAI_1,         TID_SIM_GPAI_2,             TID_SIM_GPAI_3,             TID_SIM_GPAI_4,
    TID_SIM_GPAI_5,         TID_SIM_GPAI_6,             TID_SIM_GPAI_7,             TID_SIM_GPAI_8,
    TID_SIM_GPAI_9,         TID_SIM_GPAI_10,            TID_SIM_GPAI_11,            TID_SIM_GPAI_12,
    TID_SIM_GPAI_13,        TID_SIM_GPAI_14,            TID_SIM_GPAI_15
};

/*Group Index 4*/
enum
{
    TID_SIM_DI_0            = TID_SIM_GROUP4,
    TID_SIM_DI_1,           TID_SIM_DI_2,               TID_SIM_DI_3,               TID_SIM_DI_4,
    TID_SIM_DI_5,           TID_SIM_DI_6,               TID_SIM_DI_7,               TID_SIM_DI_8,
    TID_SIM_DI_9,           TID_SIM_DI_10,              TID_SIM_DI_11,              TID_SIM_DI_12,
    TID_SIM_DI_13,          TID_SIM_DI_14,              TID_SIM_DI_15,
};

#if 0
/*Group Index 0*/
#define ALS_SIM_RMS_VA                          0//TID_SIM_VA_RMS
#define ALS_SIM_RMS_VB                          1//TID_SIM_VB_RMS
#define ALS_SIM_RMS_VC                          2//TID_SIM_VC_RMS
#define ALS_SIM_RMS_VR                          3//TID_SIM_VR_RMS
#define ALS_SIM_RMS_VS                          4//TID_SIM_VS_RMS
#define ALS_SIM_RMS_VT                          5//TID_SIM_VT_RMS
#define ALS_SIM_RMS_IA                          6//TID_SIM_IA_RMS
#define ALS_SIM_RMS_IB                          7//TID_SIM_IB_RMS
#define ALS_SIM_RMS_IC                          8//TID_SIM_IC_RMS
#define ALS_SIM_RMS_IN                          9//TID_SIM_IN_RMS

/*Group Index 1*/
#define ALS_SIM_ANG_VA                          16//TID_SIM_VA_ANG
#define ALS_SIM_ANG_VB                          17//TID_SIM_VB_ANG
#define ALS_SIM_ANG_VC                          18//TID_SIM_VC_ANG
#define ALS_SIM_ANG_VR                          19//TID_SIM_VR_ANG
#define ALS_SIM_ANG_VS                          20//TID_SIM_VS_ANG
#define ALS_SIM_ANG_VT                          21//TID_SIM_VT_ANG
#define ALS_SIM_ANG_IA                          22//TID_SIM_IA_ANG
#define ALS_SIM_ANG_IB                          23//TID_SIM_IB_ANG
#define ALS_SIM_ANG_IC                          24//TID_SIM_IC_ANG
#define ALS_SIM_ANG_IN                          25//TID_SIM_IN_ANG

/*Group Index 2*/
#define ALS_SIM_FREQ_VA                         32//TID_SIM_VA_FREQ
#define ALS_SIM_FREQ_VB                         33//TID_SIM_VB_FREQ
#define ALS_SIM_FREQ_VC                         34//TID_SIM_VC_FREQ
#define ALS_SIM_FREQ_VR                         35//TID_SIM_VR_FREQ
#define ALS_SIM_FREQ_VS                         36//TID_SIM_VS_FREQ
#define ALS_SIM_FREQ_VT                         37//TID_SIM_VT_FREQ

/*Group Index 3*/
#define ALS_SIM_GPAI_0                          48//TID_SIM_GPAI_0
#define ALS_SIM_GPAI_1                          49//TID_SIM_GPAI_1
#define ALS_SIM_GPAI_2                          50//TID_SIM_GPAI_2
#define ALS_SIM_GPAI_3                          51//TID_SIM_GPAI_3
#define ALS_SIM_GPAI_4                          52//TID_SIM_GPAI_4
#define ALS_SIM_GPAI_5                          53//TID_SIM_GPAI_5
#define ALS_SIM_GPAI_6                          54//TID_SIM_GPAI_6
#define ALS_SIM_GPAI_7                          55//TID_SIM_GPAI_7
#define ALS_SIM_GPAI_8                          56//TID_SIM_GPAI_8
#define ALS_SIM_GPAI_9                          57//TID_SIM_GPAI_9
#define ALS_SIM_GPAI_10                         58//TID_SIM_GPAI_10
#define ALS_SIM_GPAI_11                         59//TID_SIM_GPAI_11
#define ALS_SIM_GPAI_12                         60//TID_SIM_GPAI_12
#define ALS_SIM_GPAI_13                         61//TID_SIM_GPAI_13
#define ALS_SIM_GPAI_14                         62//TID_SIM_GPAI_14
#define ALS_SIM_GPAI_15                         63//TID_SIM_GPAI_15

/*Group Index 4*/
#define ALS_SIM_DI_0                            64//TID_SIM_DI_0
#define ALS_SIM_DI_1                            65//TID_SIM_DI_1
#define ALS_SIM_DI_2                            66//TID_SIM_DI_2
#define ALS_SIM_DI_3                            67//TID_SIM_DI_3
#define ALS_SIM_DI_4                            68//TID_SIM_DI_4
#define ALS_SIM_DI_5                            69//TID_SIM_DI_5
#define ALS_SIM_DI_6                            70//TID_SIM_DI_6
#define ALS_SIM_DI_7                            71//TID_SIM_DI_7
#define ALS_SIM_DI_8                            72//TID_SIM_DI_8
#define ALS_SIM_DI_9                            73//TID_SIM_DI_9
#define ALS_SIM_DI_10                           74//TID_SIM_DI_10
#define ALS_SIM_DI_11                           75//TID_SIM_DI_11
#define ALS_SIM_DI_12                           76//TID_SIM_DI_12
#define ALS_SIM_DI_13                           77//TID_SIM_DI_13
#define ALS_SIM_DI_14                           78//TID_SIM_DI_14
#define ALS_SIM_DI_15                           79//TID_SIM_DI_15
#endif
#endif /* USERLOGIC_ALIAS_ALIAS_SIM_H_ */
