/*
 * Alias_LS.h
 *
 *  Created on: 2023. 11. 10.
 *      Author: ShinSung Industrial Electric
 */

#ifndef USERLOGIC_ALIAS_LS_H_
#define USERLOGIC_ALIAS_LS_H_

/*TAG LS UI*/
enum
{
    ALS_LS_51P1P,
    ALS_LS_51N1P,
    ALS_LS_51P1C,
    ALS_LS_51P1RS,
    ALS_LS_51N1C,
    ALS_LS_51N1RS,
    ALS_LS_51P2C,
    ALS_LS_51P2RS,
    ALS_LS_51N2C,
    ALS_LS_51N2RS,
    ALS_LS_50N6D,
    ALS_LS_OPPH,
    ALS_LS_OPGR,
    ALS_LS_OPLKPH,
    ALS_LS_OPLKGR,
    ALS_LS_OPLKSF,
    ALS_LS_79OI2,
    ALS_LS_79OI3,
    ALS_LS_79RSD,
    ALS_LS_79RSLD,
    ALS_LS_50P1P,
    ALS_LS_HITRPH1,
    ALS_LS_HITRPH2,
    ALS_LS_HITRPH3,
    ALS_LS_HITRPH4,
    ALS_LS_50N1P,
    ALS_LS_HITRGR1,
    ALS_LS_HITRGR2,
    ALS_LS_HITRGR3,
    ALS_LS_HITRGR4,
    ALS_LS_HILKPH,
    ALS_LS_HILKGR,
    ALS_LS_51P4M,
    ALS_LS_50P4M,
    ALS_LS_51N4M,
    ALS_LS_50N4M,
    ALS_LS_LLDD,
    ALS_LS_ENSEQ,
    ALS_LS_GTP,
    ALS_LS_51P3M,
    ALS_LS_50P3M,
    ALS_LS_51N3M,
    ALS_LS_50N3M,
    ALS_LS_E67P,
    ALS_LS_MTAP,
    ALS_LS_V1P0,
    ALS_LS_E67N,
    ALS_LS_MTAN,
    ALS_LS_3V0P0,
    ALS_LS_OPCN,
    ALS_LS_XLD,
    ALS_LS_NCRD,
    ALS_LS_FRD,
    ALS_LS_ENARS,
    ALS_LS_ENLOVLO,
    ALS_LS_ENACL,
    ALS_LS_ENCLACNT,

    TAG_LS_UI_INDEX_MAX = 64,
};
enum
{
    ALS_LS_50N6P,
    ALS_LS_51P1TD,
    ALS_LS_51P1CT,
    ALS_LS_51P1MR,
    ALS_LS_51P1FD,
    ALS_LS_51N1TD,
    ALS_LS_51N1CT,
    ALS_LS_51N1MR,
    ALS_LS_51P1DD,
    ALS_LS_51P2TD,
    ALS_LS_51P2CT,
    ALS_LS_51P2MR,
    ALS_LS_51N1FD,
    ALS_LS_51N2TD,
    ALS_LS_51N2CT,
    ALS_LS_51N2MR,
    ALS_LS_51N1DD,
    ALS_LS_79OI1,
    ALS_LS_50P1D,
    ALS_LS_50N1D,
    ALS_LS_RMTPD,
    ALS_LS_RMTGD,
    ALS_LS_CLPPRS,
    ALS_LS_CLPGRS,
    ALS_LS_INRPRD,
    ALS_LS_INRGRD,
    ALS_LS_TAWP,
    ALS_LS_TAWN,
    ALS_LS_BCD,
    ALS_LS_XDD,
    ALS_LS_TSealIn,

    TAG_LS_F_INDEX_MAX = 32,
};
/*TAG LS0 UI*/
enum
{
    ALS_LS0_51P1P,
    ALS_LS0_51N1P,
    ALS_LS0_51P1C,
    ALS_LS0_51P1RS,
    ALS_LS0_51N1C,
    ALS_LS0_51N1RS,
    ALS_LS0_51P2C,
    ALS_LS0_51P2RS,
    ALS_LS0_51N2C,
    ALS_LS0_51N2RS,
    ALS_LS0_50N6D,
    ALS_LS0_OPPH,
    ALS_LS0_OPGR,
    ALS_LS0_OPLKPH,
    ALS_LS0_OPLKGR,
    ALS_LS0_OPLKSF,
    ALS_LS0_79OI2,
    ALS_LS0_79OI3,
    ALS_LS0_79RSD,
    ALS_LS0_79RSLD,
    ALS_LS0_50P1P,
    ALS_LS0_HITRPH1,
    ALS_LS0_HITRPH2,
    ALS_LS0_HITRPH3,
    ALS_LS0_HITRPH4,
    ALS_LS0_50N1P,
    ALS_LS0_HITRGR1,
    ALS_LS0_HITRGR2,
    ALS_LS0_HITRGR3,
    ALS_LS0_HITRGR4,
    ALS_LS0_HILKPH,
    ALS_LS0_HILKGR,
    ALS_LS0_51P4M,
    ALS_LS0_50P4M,
    ALS_LS0_51N4M,
    ALS_LS0_50N4M,
    ALS_LS0_LLDD,
    ALS_LS0_ENSEQ,
    ALS_LS0_GTP,
    ALS_LS0_51P3M,
    ALS_LS0_50P3M,
    ALS_LS0_51N3M,
    ALS_LS0_50N3M,
    ALS_LS0_E67P,
    ALS_LS0_MTAP,
    ALS_LS0_V1P0,
    ALS_LS0_E67N,
    ALS_LS0_MTAN,
    ALS_LS0_3V0P0,
    ALS_LS0_OPCN,
    ALS_LS0_XLD,
    ALS_LS0_NCRD,
    ALS_LS0_FRD,
    ALS_LS0_ENARS,
    ALS_LS0_ENLOVLO,
    ALS_LS0_ENACL,
    ALS_LS0_ENCLACNT,

    TAG_LS0_UI_INDEX_MAX = TAG_LS_UI_INDEX_MAX,
};
/*TAG LS0 F*/
enum
{
    ALS_LS0_50N6P,
    ALS_LS0_51P1TD,
    ALS_LS0_51P1CT,
    ALS_LS0_51P1MR,
    ALS_LS0_51P1FD,
    ALS_LS0_51N1TD,
    ALS_LS0_51N1CT,
    ALS_LS0_51N1MR,
    ALS_LS0_51P1DD,
    ALS_LS0_51P2TD,
    ALS_LS0_51P2CT,
    ALS_LS0_51P2MR,
    ALS_LS0_51N1FD,
    ALS_LS0_51N2TD,
    ALS_LS0_51N2CT,
    ALS_LS0_51N2MR,
    ALS_LS0_51N1DD,
    ALS_LS0_79OI1,
    ALS_LS0_50P1D,
    ALS_LS0_50N1D,
    ALS_LS0_RMTPD,
    ALS_LS0_RMTGD,
    ALS_LS0_CLPPRS,
    ALS_LS0_CLPGRS,
    ALS_LS0_INRPRD,
    ALS_LS0_INRGRD,
    ALS_LS0_TAWP,
    ALS_LS0_TAWN,
    ALS_LS0_BCD,
    ALS_LS0_XDD,
    ALS_LS0_TSealIn,

    TAG_LS0_F_INDEX_MAX = TAG_LS_F_INDEX_MAX,
};
/*TAG LS1 UI*/
enum
{
    ALS_LS1_51P1P,
    ALS_LS1_51N1P,
    ALS_LS1_51P1C,
    ALS_LS1_51P1RS,
    ALS_LS1_51N1C,
    ALS_LS1_51N1RS,
    ALS_LS1_51P2C,
    ALS_LS1_51P2RS,
    ALS_LS1_51N2C,
    ALS_LS1_51N2RS,
    ALS_LS1_50N6D,
    ALS_LS1_OPPH,
    ALS_LS1_OPGR,
    ALS_LS1_OPLKPH,
    ALS_LS1_OPLKGR,
    ALS_LS1_OPLKSF,
    ALS_LS1_79OI2,
    ALS_LS1_79OI3,
    ALS_LS1_79RSD,
    ALS_LS1_79RSLD,
    ALS_LS1_50P1P,
    ALS_LS1_HITRPH1,
    ALS_LS1_HITRPH2,
    ALS_LS1_HITRPH3,
    ALS_LS1_HITRPH4,
    ALS_LS1_50N1P,
    ALS_LS1_HITRGR1,
    ALS_LS1_HITRGR2,
    ALS_LS1_HITRGR3,
    ALS_LS1_HITRGR4,
    ALS_LS1_HILKPH,
    ALS_LS1_HILKGR,
    ALS_LS1_51P4M,
    ALS_LS1_50P4M,
    ALS_LS1_51N4M,
    ALS_LS1_50N4M,
    ALS_LS1_LLDD,
    ALS_LS1_ENSEQ,
    ALS_LS1_GTP,
    ALS_LS1_51P3M,
    ALS_LS1_50P3M,
    ALS_LS1_51N3M,
    ALS_LS1_50N3M,
    ALS_LS1_E67P,
    ALS_LS1_MTAP,
    ALS_LS1_V1P0,
    ALS_LS1_E67N,
    ALS_LS1_MTAN,
    ALS_LS1_3V0P0,
    ALS_LS1_OPCN,
    ALS_LS1_XLD,
    ALS_LS1_NCRD,
    ALS_LS1_FRD,
    ALS_LS1_ENARS,
    ALS_LS1_ENLOVLO,
    ALS_LS1_ENACL,
    ALS_LS1_ENCLACNT,

    TAG_LS1_UI_INDEX_MAX = TAG_LS_UI_INDEX_MAX,
};
/*TAG LS1 F*/
enum
{
    ALS_LS1_50N6P,
    ALS_LS1_51P1TD,
    ALS_LS1_51P1CT,
    ALS_LS1_51P1MR,
    ALS_LS1_51P1FD,
    ALS_LS1_51N1TD,
    ALS_LS1_51N1CT,
    ALS_LS1_51N1MR,
    ALS_LS1_51P1DD,
    ALS_LS1_51P2TD,
    ALS_LS1_51P2CT,
    ALS_LS1_51P2MR,
    ALS_LS1_51N1FD,
    ALS_LS1_51N2TD,
    ALS_LS1_51N2CT,
    ALS_LS1_51N2MR,
    ALS_LS1_51N1DD,
    ALS_LS1_79OI1,
    ALS_LS1_50P1D,
    ALS_LS1_50N1D,
    ALS_LS1_RMTPD,
    ALS_LS1_RMTGD,
    ALS_LS1_CLPPRS,
    ALS_LS1_CLPGRS,
    ALS_LS1_INRPRD,
    ALS_LS1_INRGRD,
    ALS_LS1_TAWP,
    ALS_LS1_TAWN,
    ALS_LS1_BCD,
    ALS_LS1_XDD,
    ALS_LS1_TSealIn,

    TAG_LS1_F_INDEX_MAX = TAG_LS_F_INDEX_MAX,
};

#define TID_LS                                  8
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
enum
{
    TID_GRP_LS_F0  =  BUILD_L2CODE(TID_LS, 0),     TID_GRP_LS_F1  =  BUILD_L2CODE(TID_LS, 1),      TID_GRP_LS_F2  =  BUILD_L2CODE(TID_LS, 2),
    TID_GRP_LS_F3  =  BUILD_L2CODE(TID_LS, 3),     TID_GRP_LS_F4  =  BUILD_L2CODE(TID_LS, 4),      TID_GRP_LS_F5  =  BUILD_L2CODE(TID_LS, 5),
    TID_GRP_LS_UI0 =  BUILD_L2CODE(TID_LS, 6),     TID_GRP_LS_UI1 =  BUILD_L2CODE(TID_LS, 7),      TID_GRP_LS_UI2 =  BUILD_L2CODE(TID_LS, 8),
    TID_GRP_LS_UI3 =  BUILD_L2CODE(TID_LS, 9),     TID_GRP_LS_UI4 =  BUILD_L2CODE(TID_LS, 10),     TID_GRP_LS_UI5 =  BUILD_L2CODE(TID_LS, 11),

    TID_GRP_LS0_F0  =  BUILD_L2CODE(TID_LS, 0x10), TID_GRP_LS0_F1  =  BUILD_L2CODE(TID_LS, 0x11),  TID_GRP_LS0_F2  =  BUILD_L2CODE(TID_LS, 0x12),
    TID_GRP_LS0_F3  =  BUILD_L2CODE(TID_LS, 0x13), TID_GRP_LS0_F4  =  BUILD_L2CODE(TID_LS, 0x14),  TID_GRP_LS0_F5  =  BUILD_L2CODE(TID_LS, 0x15),
    TID_GRP_LS0_UI0 =  BUILD_L2CODE(TID_LS, 0x16), TID_GRP_LS0_UI1 =  BUILD_L2CODE(TID_LS, 0x17),  TID_GRP_LS0_UI2 =  BUILD_L2CODE(TID_LS, 0x18),
    TID_GRP_LS0_UI3 =  BUILD_L2CODE(TID_LS, 0x19), TID_GRP_LS0_UI4 =  BUILD_L2CODE(TID_LS, 0x1A),  TID_GRP_LS0_UI5 =  BUILD_L2CODE(TID_LS, 0x1B),

    TID_GRP_LS1_F0  =  BUILD_L2CODE(TID_LS, 0x20), TID_GRP_LS1_F1  =  BUILD_L2CODE(TID_LS, 0x21),  TID_GRP_LS1_F2  =  BUILD_L2CODE(TID_LS, 0x22),
    TID_GRP_LS1_F3  =  BUILD_L2CODE(TID_LS, 0x23), TID_GRP_LS1_F4  =  BUILD_L2CODE(TID_LS, 0x24),  TID_GRP_LS1_F5  =  BUILD_L2CODE(TID_LS, 0x25),
    TID_GRP_LS1_UI0 =  BUILD_L2CODE(TID_LS, 0x26), TID_GRP_LS1_UI1 =  BUILD_L2CODE(TID_LS, 0x27),  TID_GRP_LS1_UI2 =  BUILD_L2CODE(TID_LS, 0x28),
    TID_GRP_LS1_UI3 =  BUILD_L2CODE(TID_LS, 0x29), TID_GRP_LS1_UI4 =  BUILD_L2CODE(TID_LS, 0x2A),  TID_GRP_LS1_UI5 =  BUILD_L2CODE(TID_LS, 0x2B)
};

enum
{
    TID_LS_F0_0         = TID_GRP_LS_F0,
    TID_LS_F0_1,        TID_LS_F0_2,            TID_LS_F0_3,            TID_LS_F0_4,
    TID_LS_F0_5,        TID_LS_F0_6,            TID_LS_F0_7,            TID_LS_F0_8,
    TID_LS_F0_9,        TID_LS_F0_10,           TID_LS_F0_11,           TID_LS_F0_12,
    TID_LS_F0_13,       TID_LS_F0_14,           TID_LS_F0_15,
};

enum
{
    TID_LS_F1_0         = TID_GRP_LS_F1,
    TID_LS_F1_1,        TID_LS_F1_2,            TID_LS_F1_3,            TID_LS_F1_4,
    TID_LS_F1_5,        TID_LS_F1_6,            TID_LS_F1_7,            TID_LS_F1_8,
    TID_LS_F1_9,        TID_LS_F1_10,           TID_LS_F1_11,           TID_LS_F1_12,
    TID_LS_F1_13,       TID_LS_F1_14,           TID_LS_F1_15,
};

enum
{
    TID_LS_F2_0         = TID_GRP_LS_F2,
    TID_LS_F2_1,        TID_LS_F2_2,            TID_LS_F2_3,            TID_LS_F2_4,
    TID_LS_F2_5,        TID_LS_F2_6,            TID_LS_F2_7,            TID_LS_F2_8,
    TID_LS_F2_9,        TID_LS_F2_10,           TID_LS_F2_11,           TID_LS_F2_12,
    TID_LS_F2_13,       TID_LS_F2_14,           TID_LS_F2_15,
};

enum
{
    TID_LS_F3_0         = TID_GRP_LS_F3,
    TID_LS_F3_1,        TID_LS_F3_2,            TID_LS_F3_3,            TID_LS_F3_4,
    TID_LS_F3_5,        TID_LS_F3_6,            TID_LS_F3_7,            TID_LS_F3_8,
    TID_LS_F3_9,        TID_LS_F3_10,           TID_LS_F3_11,           TID_LS_F3_12,
    TID_LS_F3_13,       TID_LS_F3_14,           TID_LS_F3_15,
};

enum
{
    TID_LS_F4_0         = TID_GRP_LS_F4,
    TID_LS_F4_1,        TID_LS_F4_2,            TID_LS_F4_3,            TID_LS_F4_4,
    TID_LS_F4_5,        TID_LS_F4_6,            TID_LS_F4_7,            TID_LS_F4_8,
    TID_LS_F4_9,        TID_LS_F4_10,           TID_LS_F4_11,           TID_LS_F4_12,
    TID_LS_F4_13,       TID_LS_F4_14,           TID_LS_F4_15,
};


enum
{
    TID_LS_F5_0        = TID_GRP_LS_F5,
    TID_LS_F5_1,        TID_LS_F5_2,            TID_LS_F5_3,            TID_LS_F5_4,
    TID_LS_F5_5,        TID_LS_F5_6,            TID_LS_F5_7,            TID_LS_F5_8,
    TID_LS_F5_9,        TID_LS_F5_10,           TID_LS_F5_11,           TID_LS_F5_12,
    TID_LS_F5_13,       TID_LS_F5_14,           TID_LS_F5_15,
};


enum
{
    TID_LS_UI0_0        = TID_GRP_LS_UI0,
    TID_LS_UI0_1,       TID_LS_UI0_2,           TID_LS_UI0_3,           TID_LS_UI0_4,
    TID_LS_UI0_5,       TID_LS_UI0_6,           TID_LS_UI0_7,           TID_LS_UI0_8,
    TID_LS_UI0_9,       TID_LS_UI0_10,          TID_LS_UI0_11,          TID_LS_UI0_12,
    TID_LS_UI0_13,      TID_LS_UI0_14,          TID_LS_UI0_15
};

enum
{
    TID_LS_UI1_0        = TID_GRP_LS_UI1,
    TID_LS_UI1_1,       TID_LS_UI1_2,           TID_LS_UI1_3,           TID_LS_UI1_4,
    TID_LS_UI1_5,       TID_LS_UI1_6,           TID_LS_UI1_7,           TID_LS_UI1_8,
    TID_LS_UI1_9,       TID_LS_UI1_10,          TID_LS_UI1_11,          TID_LS_UI1_12,
    TID_LS_UI1_13,      TID_LS_UI1_14,          TID_LS_UI1_15
};

enum
{
    TID_LS_UI2_0        = TID_GRP_LS_UI2,
    TID_LS_UI2_1,       TID_LS_UI2_2,           TID_LS_UI2_3,           TID_LS_UI2_4,
    TID_LS_UI2_5,       TID_LS_UI2_6,           TID_LS_UI2_7,           TID_LS_UI2_8,
    TID_LS_UI2_9,       TID_LS_UI2_10,          TID_LS_UI2_11,          TID_LS_UI2_12,
    TID_LS_UI2_13,      TID_LS_UI2_14,          TID_LS_UI2_15
};

enum
{
    TID_LS_UI3_0        = TID_GRP_LS_UI3,
    TID_LS_UI3_1,       TID_LS_UI3_2,           TID_LS_UI3_3,           TID_LS_UI3_4,
    TID_LS_UI3_5,       TID_LS_UI3_6,           TID_LS_UI3_7,           TID_LS_UI3_8,
    TID_LS_UI3_9,       TID_LS_UI3_10,          TID_LS_UI3_11,          TID_LS_UI3_12,
    TID_LS_UI3_13,      TID_LS_UI3_14,          TID_LS_UI3_15
};

enum
{
    TID_LS_UI4_0        = TID_GRP_LS_UI4,
    TID_LS_UI4_1,       TID_LS_UI4_2,           TID_LS_UI4_3,           TID_LS_UI4_4,
    TID_LS_UI4_5,       TID_LS_UI4_6,           TID_LS_UI4_7,           TID_LS_UI4_8,
    TID_LS_UI4_9,       TID_LS_UI4_10,          TID_LS_UI4_11,          TID_LS_UI4_12,
    TID_LS_UI4_13,      TID_LS_UI4_14,          TID_LS_UI4_15
};

enum
{
    TID_LS_UI5_0        = TID_GRP_LS_UI5,
    TID_LS_UI5_1,       TID_LS_UI5_2,           TID_LS_UI5_3,           TID_LS_UI5_4,
    TID_LS_UI5_5,       TID_LS_UI5_6,           TID_LS_UI5_7,           TID_LS_UI5_8,
    TID_LS_UI5_9,       TID_LS_UI5_10,          TID_LS_UI5_11,          TID_LS_UI5_12,
    TID_LS_UI5_13,      TID_LS_UI5_14,          TID_LS_UI5_15
};


enum
{
    TID_LS0_F0_0        = TID_GRP_LS0_F0,
    TID_LS0_F0_1,       TID_LS0_F0_2,           TID_LS0_F0_3,           TID_LS0_F0_4,
    TID_LS0_F0_5,       TID_LS0_F0_6,           TID_LS0_F0_7,           TID_LS0_F0_8,
    TID_LS0_F0_9,       TID_LS0_F0_10,          TID_LS0_F0_11,          TID_LS0_F0_12,
    TID_LS0_F0_13,      TID_LS0_F0_14,          TID_LS0_F0_15
};

enum
{
    TID_LS0_F1_0        = TID_GRP_LS0_F1,
    TID_LS0_F1_1,       TID_LS0_F1_2,           TID_LS0_F1_3,           TID_LS0_F1_4,
    TID_LS0_F1_5,       TID_LS0_F1_6,           TID_LS0_F1_7,           TID_LS0_F1_8,
    TID_LS0_F1_9,       TID_LS0_F1_10,          TID_LS0_F1_11,          TID_LS0_F1_12,
    TID_LS0_F1_13,      TID_LS0_F1_14,          TID_LS0_F1_15
};

enum
{
    TID_LS0_F2_0        = TID_GRP_LS0_F2,
    TID_LS0_F2_1,       TID_LS0_F2_2,           TID_LS0_F2_3,           TID_LS0_F2_4,
    TID_LS0_F2_5,       TID_LS0_F2_6,           TID_LS0_F2_7,           TID_LS0_F2_8,
    TID_LS0_F2_9,       TID_LS0_F2_10,          TID_LS0_F2_11,          TID_LS0_F2_12,
    TID_LS0_F2_13,      TID_LS0_F2_14,          TID_LS0_F2_15
};

enum
{
    TID_LS0_F3_0        = TID_GRP_LS0_F3,
    TID_LS0_F3_1,       TID_LS0_F3_2,           TID_LS0_F3_3,           TID_LS0_F3_4,
    TID_LS0_F3_5,       TID_LS0_F3_6,           TID_LS0_F3_7,           TID_LS0_F3_8,
    TID_LS0_F3_9,       TID_LS0_F3_10,          TID_LS0_F3_11,          TID_LS0_F3_12,
    TID_LS0_F3_13,      TID_LS0_F3_14,          TID_LS0_F3_15
};

enum
{
    TID_LS0_F4_0        = TID_GRP_LS0_F4,
    TID_LS0_F4_1,       TID_LS0_F4_2,           TID_LS0_F4_3,           TID_LS0_F4_4,
    TID_LS0_F4_5,       TID_LS0_F4_6,           TID_LS0_F4_7,           TID_LS0_F4_8,
    TID_LS0_F4_9,       TID_LS0_F4_10,          TID_LS0_F4_11,          TID_LS0_F4_12,
    TID_LS0_F4_13,      TID_LS0_F4_14,          TID_LS0_F4_15
};

enum
{
    TID_LS0_F5_0        = TID_GRP_LS0_F5,
    TID_LS0_F5_1,       TID_LS0_F5_2,           TID_LS0_F5_3,           TID_LS0_F5_4,
    TID_LS0_F5_5,       TID_LS0_F5_6,           TID_LS0_F5_7,           TID_LS0_F5_8,
    TID_LS0_F5_9,       TID_LS0_F5_10,          TID_LS0_F5_11,          TID_LS0_F5_12,
    TID_LS0_F5_13,      TID_LS0_F5_14,          TID_LS0_F5_15
};

enum
{
    TID_LS0_UI0_0       = TID_GRP_LS0_UI0,
    TID_LS0_UI0_1,      TID_LS0_UI0_2,          TID_LS0_UI0_3,          TID_LS0_UI0_4,
    TID_LS0_UI0_5,      TID_LS0_UI0_6,          TID_LS0_UI0_7,          TID_LS0_UI0_8,
    TID_LS0_UI0_9,      TID_LS0_UI0_10,         TID_LS0_UI0_11,         TID_LS0_UI0_12,
    TID_LS0_UI0_13,     TID_LS0_UI0_14,         TID_LS0_UI0_15
};

enum
{
    TID_LS0_UI1_0       = TID_GRP_LS0_UI1,
    TID_LS0_UI1_1,      TID_LS0_UI1_2,          TID_LS0_UI1_3,          TID_LS0_UI1_4,
    TID_LS0_UI1_5,      TID_LS0_UI1_6,          TID_LS0_UI1_7,          TID_LS0_UI1_8,
    TID_LS0_UI1_9,      TID_LS0_UI1_10,         TID_LS0_UI1_11,         TID_LS0_UI1_12,
    TID_LS0_UI1_13,     TID_LS0_UI1_14,         TID_LS0_UI1_15
};

enum
{
    TID_LS0_UI2_0       = TID_GRP_LS0_UI2,
    TID_LS0_UI2_1,      TID_LS0_UI2_2,          TID_LS0_UI2_3,          TID_LS0_UI2_4,
    TID_LS0_UI2_5,      TID_LS0_UI2_6,          TID_LS0_UI2_7,          TID_LS0_UI2_8,
    TID_LS0_UI2_9,      TID_LS0_UI2_10,         TID_LS0_UI2_11,         TID_LS0_UI2_12,
    TID_LS0_UI2_13,     TID_LS0_UI2_14,         TID_LS0_UI2_15
};

enum
{
    TID_LS0_UI3_0       = TID_GRP_LS0_UI3,
    TID_LS0_UI3_1,      TID_LS0_UI3_2,          TID_LS0_UI3_3,          TID_LS0_UI3_4,
    TID_LS0_UI3_5,      TID_LS0_UI3_6,          TID_LS0_UI3_7,          TID_LS0_UI3_8,
    TID_LS0_UI3_9,      TID_LS0_UI3_10,         TID_LS0_UI3_11,         TID_LS0_UI3_12,
    TID_LS0_UI3_13,     TID_LS0_UI3_14,         TID_LS0_UI3_15
};

enum
{
    TID_LS0_UI4_0       = TID_GRP_LS0_UI4,
    TID_LS0_UI4_1,      TID_LS0_UI4_2,          TID_LS0_UI4_3,          TID_LS0_UI4_4,
    TID_LS0_UI4_5,      TID_LS0_UI4_6,          TID_LS0_UI4_7,          TID_LS0_UI4_8,
    TID_LS0_UI4_9,      TID_LS0_UI4_10,         TID_LS0_UI4_11,         TID_LS0_UI4_12,
    TID_LS0_UI4_13,     TID_LS0_UI4_14,         TID_LS0_UI4_15
};

enum
{
    TID_LS0_UI5_0       = TID_GRP_LS0_UI5,
    TID_LS0_UI5_1,      TID_LS0_UI5_2,          TID_LS0_UI5_3,          TID_LS0_UI5_4,
    TID_LS0_UI5_5,      TID_LS0_UI5_6,          TID_LS0_UI5_7,          TID_LS0_UI5_8,
    TID_LS0_UI5_9,      TID_LS0_UI5_10,         TID_LS0_UI5_11,         TID_LS0_UI5_12,
    TID_LS0_UI5_13,     TID_LS0_UI5_14,         TID_LS0_UI5_15
};

enum
{
    TID_LS1_F0_0        = TID_GRP_LS1_F0,
    TID_LS1_F0_1,       TID_LS1_F0_2,           TID_LS1_F0_3,           TID_LS1_F0_4,
    TID_LS1_F0_5,       TID_LS1_F0_6,           TID_LS1_F0_7,           TID_LS1_F0_8,
    TID_LS1_F0_9,       TID_LS1_F0_10,          TID_LS1_F0_11,          TID_LS1_F0_12,
    TID_LS1_F0_13,      TID_LS1_F0_14,          TID_LS1_F0_15
};

enum
{
    TID_LS1_F1_0        = TID_GRP_LS1_F1,
    TID_LS1_F1_1,       TID_LS1_F1_2,           TID_LS1_F1_3,           TID_LS1_F1_4,
    TID_LS1_F1_5,       TID_LS1_F1_6,           TID_LS1_F1_7,           TID_LS1_F1_8,
    TID_LS1_F1_9,       TID_LS1_F1_10,          TID_LS1_F1_11,          TID_LS1_F1_12,
    TID_LS1_F1_13,      TID_LS1_F1_14,          TID_LS1_F1_15
};

enum
{
    TID_LS1_F2_0        = TID_GRP_LS1_F2,
    TID_LS1_F2_1,       TID_LS1_F2_2,           TID_LS1_F2_3,           TID_LS1_F2_4,
    TID_LS1_F2_5,       TID_LS1_F2_6,           TID_LS1_F2_7,           TID_LS1_F2_8,
    TID_LS1_F2_9,       TID_LS1_F2_10,          TID_LS1_F2_11,          TID_LS1_F2_12,
    TID_LS1_F2_13,      TID_LS1_F2_14,          TID_LS1_F2_15
};

enum
{
    TID_LS1_F3_0        = TID_GRP_LS1_F3,
    TID_LS1_F3_1,       TID_LS1_F3_2,           TID_LS1_F3_3,           TID_LS1_F3_4,
    TID_LS1_F3_5,       TID_LS1_F3_6,           TID_LS1_F3_7,           TID_LS1_F3_8,
    TID_LS1_F3_9,       TID_LS1_F3_10,          TID_LS1_F3_11,          TID_LS1_F3_12,
    TID_LS1_F3_13,      TID_LS1_F3_14,          TID_LS1_F3_15
};

enum
{
    TID_LS1_F4_0        = TID_GRP_LS1_F4,
    TID_LS1_F4_1,       TID_LS1_F4_2,           TID_LS1_F4_3,           TID_LS1_F4_4,
    TID_LS1_F4_5,       TID_LS1_F4_6,           TID_LS1_F4_7,           TID_LS1_F4_8,
    TID_LS1_F4_9,       TID_LS1_F4_10,          TID_LS1_F4_11,          TID_LS1_F4_12,
    TID_LS1_F4_13,      TID_LS1_F4_14,          TID_LS1_F4_15
};

enum
{
    TID_LS1_F5_0        = TID_GRP_LS1_F5,
    TID_LS1_F5_1,       TID_LS1_F5_2,           TID_LS1_F5_3,           TID_LS1_F5_4,
    TID_LS1_F5_5,       TID_LS1_F5_6,           TID_LS1_F5_7,           TID_LS1_F5_8,
    TID_LS1_F5_9,       TID_LS1_F5_10,          TID_LS1_F5_11,          TID_LS1_F5_12,
    TID_LS1_F5_13,      TID_LS1_F5_14,          TID_LS1_F5_15
};

enum
{
    TID_LS1_UI0_0       = TID_GRP_LS1_UI0,
    TID_LS1_UI0_1,      TID_LS1_UI0_2,          TID_LS1_UI0_3,          TID_LS1_UI0_4,
    TID_LS1_UI0_5,      TID_LS1_UI0_6,          TID_LS1_UI0_7,          TID_LS1_UI0_8,
    TID_LS1_UI0_9,      TID_LS1_UI0_10,         TID_LS1_UI0_11,         TID_LS1_UI0_12,
    TID_LS1_UI0_13,     TID_LS1_UI0_14,         TID_LS1_UI0_15
};

enum
{
    TID_LS1_UI1_0       = TID_GRP_LS1_UI1,
    TID_LS1_UI1_1,      TID_LS1_UI1_2,          TID_LS1_UI1_3,          TID_LS1_UI1_4,
    TID_LS1_UI1_5,      TID_LS1_UI1_6,          TID_LS1_UI1_7,          TID_LS1_UI1_8,
    TID_LS1_UI1_9,      TID_LS1_UI1_10,         TID_LS1_UI1_11,         TID_LS1_UI1_12,
    TID_LS1_UI1_13,     TID_LS1_UI1_14,         TID_LS1_UI1_15
};

enum
{
    TID_LS1_UI2_0       = TID_GRP_LS1_UI2,
    TID_LS1_UI2_1,      TID_LS1_UI2_2,          TID_LS1_UI2_3,          TID_LS1_UI2_4,
    TID_LS1_UI2_5,      TID_LS1_UI2_6,          TID_LS1_UI2_7,          TID_LS1_UI2_8,
    TID_LS1_UI2_9,      TID_LS1_UI2_10,         TID_LS1_UI2_11,         TID_LS1_UI2_12,
    TID_LS1_UI2_13,     TID_LS1_UI2_14,         TID_LS1_UI2_15
};

enum
{
    TID_LS1_UI3_0       = TID_GRP_LS1_UI3,
    TID_LS1_UI3_1,      TID_LS1_UI3_2,          TID_LS1_UI3_3,          TID_LS1_UI3_4,
    TID_LS1_UI3_5,      TID_LS1_UI3_6,          TID_LS1_UI3_7,          TID_LS1_UI3_8,
    TID_LS1_UI3_9,      TID_LS1_UI3_10,         TID_LS1_UI3_11,         TID_LS1_UI3_12,
    TID_LS1_UI3_13,     TID_LS1_UI3_14,         TID_LS1_UI3_15
};

enum
{
    TID_LS1_UI4_0       = TID_GRP_LS1_UI4,
    TID_LS1_UI4_1,      TID_LS1_UI4_2,          TID_LS1_UI4_3,          TID_LS1_UI4_4,
    TID_LS1_UI4_5,      TID_LS1_UI4_6,          TID_LS1_UI4_7,          TID_LS1_UI4_8,
    TID_LS1_UI4_9,      TID_LS1_UI4_10,         TID_LS1_UI4_11,         TID_LS1_UI4_12,
    TID_LS1_UI4_13,     TID_LS1_UI4_14,         TID_LS1_UI4_15
};

enum
{
    TID_LS1_UI5_0       = TID_GRP_LS1_UI5,
    TID_LS1_UI5_1,      TID_LS1_UI5_2,          TID_LS1_UI5_3,          TID_LS1_UI5_4,
    TID_LS1_UI5_5,      TID_LS1_UI5_6,          TID_LS1_UI5_7,          TID_LS1_UI5_8,
    TID_LS1_UI5_9,      TID_LS1_UI5_10,         TID_LS1_UI5_11,         TID_LS1_UI5_12,
    TID_LS1_UI5_13,     TID_LS1_UI5_14,         TID_LS1_UI5_15
};

typedef enum
{
    TID_LS_51P1P        = TID_LS_UI0_0,
    TID_LS_51N1P,
    TID_LS_51P1C,
    TID_LS_51P1RS,
    TID_LS_51N1C,
    TID_LS_51N1RS,
    TID_LS_51P2C,
    TID_LS_51P2RS,
    TID_LS_51N2C,
    TID_LS_51N2RS,
    TID_LS_50N6D,
    TID_LS_OPPH,
    TID_LS_OPGR,
    TID_LS_OPLKPH,
    TID_LS_OPLKGR,
    TID_LS_OPLKSF,

    TID_LS_79OI2        = TID_LS_UI1_0,
    TID_LS_79OI3,
    TID_LS_79RSD,
    TID_LS_79RSLD,
    TID_LS_50P1P,
    TID_LS_HITRPH1,
    TID_LS_HITRPH2,
    TID_LS_HITRPH3,
    TID_LS_HITRPH4,
    TID_LS_50N1P,
    TID_LS_HITRGR1,
    TID_LS_HITRGR2,
    TID_LS_HITRGR3,
    TID_LS_HITRGR4,
    TID_LS_HILKPH,
    TID_LS_HILKGR,

    TID_LS_51P4M        = TID_LS_UI2_0,
    TID_LS_50P4M,
    TID_LS_51N4M,
    TID_LS_50N4M,
    TID_LS_LLDD,
    TID_LS_ENSEQ,
    TID_LS_GTP,
    TID_LS_51P3M,
    TID_LS_50P3M,
    TID_LS_51N3M,
    TID_LS_50N3M,
    TID_LS_E67P,
    TID_LS_MTAP,
    TID_LS_V1P0,
    TID_LS_E67N,
    TID_LS_MTAN,

    TID_LS_3V0P0        = TID_LS_UI3_0,
    TID_LS_OPCN,
    TID_LS_XLD,
    TID_LS_NCRD,
    TID_LS_FRD,
    TID_LS_ENARS,
    TID_LS_ENLOVLO,
    TID_LS_ENACL,
    TID_LS_ENCLACNT,

} TAGID_LS_UI;

typedef enum
{
    TID_LS_50N6P        = TID_LS_F0_0,
    TID_LS_51P1TD,
    TID_LS_51P1CT,
    TID_LS_51P1MR,
    TID_LS_51P1FD,
    TID_LS_51N1TD,
    TID_LS_51N1CT,
    TID_LS_51N1MR,
    TID_LS_51P1DD,
    TID_LS_51P2TD,
    TID_LS_51P2CT,
    TID_LS_51P2MR,
    TID_LS_51N1FD,
    TID_LS_51N2TD,
    TID_LS_51N2CT,
    TID_LS_51N2MR,

    TID_LS_51N1DD       = TID_LS_F1_0,
    TID_LS_79OI1,
    TID_LS_50P1D,
    TID_LS_50N1D,
    TID_LS_RMTPD,
    TID_LS_RMTGD,
    TID_LS_CLPPRS,
    TID_LS_CLPGRS,
    TID_LS_INRPRD,
    TID_LS_INRGRD,
    TID_LS_TAWP,
    TID_LS_TAWN,
    TID_LS_BCD,
    TID_LS_XDD,
    TID_LS_TSealIn,

} TAGID_LS_F;

typedef enum
{
    TID_LS0_51P1P       = TID_LS0_UI0_0,
    TID_LS0_51N1P,
    TID_LS0_51P1C,
    TID_LS0_51P1RS,
    TID_LS0_51N1C,
    TID_LS0_51N1RS,
    TID_LS0_51P2C,
    TID_LS0_51P2RS,
    TID_LS0_51N2C,
    TID_LS0_51N2RS,
    TID_LS0_50N6D,
    TID_LS0_OPPH,
    TID_LS0_OPGR,
    TID_LS0_OPLKPH,
    TID_LS0_OPLKGR,
    TID_LS0_OPLKSF,

    TID_LS0_79OI2       = TID_LS0_UI1_0,
    TID_LS0_79OI3,
    TID_LS0_79RSD,
    TID_LS0_79RSLD,
    TID_LS0_50P1P,
    TID_LS0_HITRPH1,
    TID_LS0_HITRPH2,
    TID_LS0_HITRPH3,
    TID_LS0_HITRPH4,
    TID_LS0_50N1P,
    TID_LS0_HITRGR1,
    TID_LS0_HITRGR2,
    TID_LS0_HITRGR3,
    TID_LS0_HITRGR4,
    TID_LS0_HILKPH,
    TID_LS0_HILKGR,

    TID_LS0_51P4M       = TID_LS0_UI2_0,
    TID_LS0_50P4M,
    TID_LS0_51N4M,
    TID_LS0_50N4M,
    TID_LS0_LLDD,
    TID_LS0_ENSEQ,
    TID_LS0_GTP,
    TID_LS0_51P3M,
    TID_LS0_50P3M,
    TID_LS0_51N3M,
    TID_LS0_50N3M,
    TID_LS0_E67P,
    TID_LS0_MTAP,
    TID_LS0_V1P0,
    TID_LS0_E67N,
    TID_LS0_MTAN,

    TID_LS0_3V0P0       = TID_LS0_UI3_0,
    TID_LS0_OPCN,
    TID_LS0_XLD,
    TID_LS0_NCRD,
    TID_LS0_FRD,
    TID_LS0_ENARS,
    TID_LS0_ENLOVLO,
    TID_LS0_ENACL,
    TID_LS0_ENCLACNT,

} TAGID_LS0_UI;

typedef enum
{
    TID_LS0_50N6P       = TID_LS0_F0_0,
    TID_LS0_51P1TD,
    TID_LS0_51P1CT,
    TID_LS0_51P1MR,
    TID_LS0_51P1FD,
    TID_LS0_51N1TD,
    TID_LS0_51N1CT,
    TID_LS0_51N1MR,
    TID_LS0_51P1DD,
    TID_LS0_51P2TD,
    TID_LS0_51P2CT,
    TID_LS0_51P2MR,
    TID_LS0_51N1FD,
    TID_LS0_51N2TD,
    TID_LS0_51N2CT,
    TID_LS0_51N2MR,

    TID_LS0_51N1DD      = TID_LS0_F1_0,
    TID_LS0_79OI1,
    TID_LS0_50P1D,
    TID_LS0_50N1D,
    TID_LS0_RMTPD,
    TID_LS0_RMTGD,
    TID_LS0_CLPPRS,
    TID_LS0_CLPGRS,
    TID_LS0_INRPRD,
    TID_LS0_INRGRD,
    TID_LS0_TAWP,
    TID_LS0_TAWN,
    TID_LS0_BCD,
    TID_LS0_XDD,
    TID_LS0_TSealIn,

} TAGID_LS0_F;

typedef enum
{
    TID_LS1_51P1P       = TID_LS1_UI0_0,
    TID_LS1_51N1P,
    TID_LS1_51P1C,
    TID_LS1_51P1RS,
    TID_LS1_51N1C,
    TID_LS1_51N1RS,
    TID_LS1_51P2C,
    TID_LS1_51P2RS,
    TID_LS1_51N2C,
    TID_LS1_51N2RS,
    TID_LS1_50N6D,
    TID_LS1_OPPH,
    TID_LS1_OPGR,
    TID_LS1_OPLKPH,
    TID_LS1_OPLKGR,
    TID_LS1_OPLKSF,

    TID_LS1_79OI2       = TID_LS1_UI1_0,
    TID_LS1_79OI3,
    TID_LS1_79RSD,
    TID_LS1_79RSLD,
    TID_LS1_50P1P,
    TID_LS1_HITRPH1,
    TID_LS1_HITRPH2,
    TID_LS1_HITRPH3,
    TID_LS1_HITRPH4,
    TID_LS1_50N1P,
    TID_LS1_HITRGR1,
    TID_LS1_HITRGR2,
    TID_LS1_HITRGR3,
    TID_LS1_HITRGR4,
    TID_LS1_HILKPH,
    TID_LS1_HILKGR      = TID_LS1_UI2_0,

    TID_LS1_51P4M,
    TID_LS1_50P4M,
    TID_LS1_51N4M,
    TID_LS1_50N4M,
    TID_LS1_LLDD,
    TID_LS1_ENSEQ,
    TID_LS1_GTP,
    TID_LS1_51P3M,
    TID_LS1_50P3M,
    TID_LS1_51N3M,
    TID_LS1_50N3M,
    TID_LS1_E67P,
    TID_LS1_MTAP,
    TID_LS1_V1P0,
    TID_LS1_E67N,
    TID_LS1_MTAN,

    TID_LS1_3V0P0       = TID_LS1_UI3_0,
    TID_LS1_OPCN,
    TID_LS1_XLD,
    TID_LS1_NCRD,
    TID_LS1_FRD,
    TID_LS1_ENARS,
    TID_LS1_ENLOVLO,
    TID_LS1_ENACL,
    TID_LS1_ENCLACNT,

} TAGID_LS1_UI;

typedef enum
{
    TID_LS1_50N6P       = TID_LS1_F0_0,
    TID_LS1_51P1TD,
    TID_LS1_51P1CT,
    TID_LS1_51P1MR,
    TID_LS1_51P1FD,
    TID_LS1_51N1TD,
    TID_LS1_51N1CT,
    TID_LS1_51N1MR,
    TID_LS1_51P1DD,
    TID_LS1_51P2TD,
    TID_LS1_51P2CT,
    TID_LS1_51P2MR,
    TID_LS1_51N1FD,
    TID_LS1_51N2TD,
    TID_LS1_51N2CT,
    TID_LS1_51N2MR,

    TID_LS1_51N1DD      = TID_LS1_F1_0,
    TID_LS1_79OI1,
    TID_LS1_50P1D,
    TID_LS1_50N1D,
    TID_LS1_RMTPD,
    TID_LS1_RMTGD,
    TID_LS1_CLPPRS,
    TID_LS1_CLPGRS,
    TID_LS1_INRPRD,
    TID_LS1_INRGRD,
    TID_LS1_TAWP,
    TID_LS1_TAWN,
    TID_LS1_BCD,
    TID_LS1_XDD,
    TID_LS1_TSealIn,

} TAGID_LS1_F;

#endif /* USERLOGIC_ALIAS_LS_H_ */
