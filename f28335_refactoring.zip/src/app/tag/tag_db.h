/*
 * TagDBTypes.h
 *
 *  Created on: 2023. 11. 13.
 *      Author: ShinSung Industrial Electric
 */
#pragma once
#ifndef COMPONENTS_TAGDB_TAGDBTYPES_H_
#define COMPONENTS_TAGDB_TAGDBTYPES_H_

#include "types.h"
#include "file.h"
#include "src/app/tag/tag_header.h"



/*SIM*/
#define SIM_DI_INDEX_MAX                16
/*VA VB VC VR VS VT IA IB IC IN*/
#define SIM_RMS_INDEX_MAX               10

/*VA VB VC VR VS VT IA IB IC IN*/
#define SIM_ANGLE_INDEX_MAX             10
#define SIM_FREQ_INDEX_MAX              6
/*0 ~ 16*/
#define SIM_GPAI_INDEX_MAX              16

typedef struct
{
    float32     *AI[TAG_AI_INDEX_MAX];

} TAG_AI;

typedef struct
{
    uint16      DI[TAG_DI_INDEX_MAX];

} TAG_DI;

typedef struct
{
    uint16      DO[TAG_DO_INDEX_MAX];

} TAG_DO;

typedef struct
{
    uint16      BV[TAG_BV_INDEX_MAX];

} TAG_BV;


typedef struct
{
    uint16      NMV_UI[TAG_NMV_UI_INDEX_MAX];
    float32     NMV_F[TAG_NMV_F_INDEX_MAX];

} TAG_NMV;

typedef struct
{
    uint16      NVV_UI[TAG_NVV_UI_INDEX_MAX];
    float32     NVV_F[TAG_NVV_F_INDEX_MAX];

} TAG_NVV;

typedef struct
{
    uint16      RCM[TAG_RCM_INDEX_MAX];

} TAG_RCM;

typedef struct
{
    uint16      LS_UI[TAG_LS_UI_INDEX_MAX];
    float32     LS_F[TAG_LS_F_INDEX_MAX];

} TAG_LS_UI_F;

typedef struct
{
    /*Internal Logic Setting*/
    TAG_LS_UI_F     LS_INTERNAL;

    /*For Group 1*/
    TAG_LS_UI_F     LS_GROUP1;

    /*For Group 2*/
    TAG_LS_UI_F     LS_GROUP2;

} TAG_LS;

typedef struct
{
    uint16      SC_UI[TAG_SC_UI_INDEX_MAX];
    float32     SC_F[TAG_SC_F_INDEX_MAX];

} TAG_SC;

typedef struct
{
    uint16      SIM_DI[SIM_DI_INDEX_MAX];

    float32     SIM_RMS[SIM_RMS_INDEX_MAX];
    float32     SIM_ANG[SIM_ANGLE_INDEX_MAX];
    float32     SIM_FREQ[SIM_FREQ_INDEX_MAX];
    float32     SIM_GPAI[SIM_GPAI_INDEX_MAX];

} TAG_SIM;

/*Diagnostics*/
typedef struct
{
    uint16      DG_UI[TAG_DG_INDEX_MAX];

} TAG_DG;

/*MMI*/
typedef struct
{
    uint16      MMI_UI[TAG_ACC_INDEX_MAX];

} TAG_MMI;

typedef struct
{
    float32     ACC[TAG_ACC_INDEX_MAX];

} TAG_ACC;
/*DNP*/
typedef struct
{
    uint16  DNP232_UI[TAG_DNP232_UI_INDEX_MAX];
    uint16  DNPETH_UI[TAG_DNPETH_UI_INDEX_MAX];

    float32 DNP232_F[TAG_DNP232_F_INDEX_MAX];
    float32 DNPETH_F[TAG_DNPETH_F_INDEX_MAX];

} TAG_DNP;

/**/
typedef struct
{
    TAG_AI      AI;

    TAG_DI      DI;
    TAG_DO      DO;

    TAG_BV      BV;

    TAG_NMV     NMV;
    TAG_NVV     NVV;

    TAG_RCM     RCM;

    TAG_LS      LS;
    TAG_SC      SC;

    TAG_SIM     SIM;

    TAG_DG      DG;

    uint16      MMI[TAG_MMI_INDEX_MAX];

    TAG_ACC     ACC;

    TAG_DNP     DNP;

} TAG_DB;

TAG_DB* TagDB_Get(void);
void TagPointer_Get(TAG_GROUP TagGroup);



/*Interface*/
void TagDB_Init(void);



void* TagDataAddr_Get(TagData* pTagData);

void TagDataName_Get(TagData* pTagData,char* pBuf);


void FramTagGroupCRC_Update(TAG_GROUP TagGroup);


void LsData_Copy(uint16 LsGroup);


#endif /* COMPONENTS_TAGDB_TAGDBTYPES_H_ */
