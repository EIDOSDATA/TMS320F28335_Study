/*
 * TagDB_Macro.h
 *
 *  Created on: 2023. 11. 13.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_TAGDB_INTERFACE_TAGDB_MACRO_H_
#define COMPONENTS_TAGDB_INTERFACE_TAGDB_MACRO_H_

#include "src/app/tag/tag_db.h"
#include "src/app/logging/event.h"


extern float32** pTAG_AI;
extern uint16*  pTAG_DI;
extern uint16*  pTAG_DO;
extern uint16*  pTAG_BV;

extern uint16*  pTAG_NMV_UI;
extern float32* pTAG_NMV_F;

extern uint16*  pTAG_NVV_UI;
extern float32* pTAG_NVV_F;

extern uint16*  pTAG_RCM;
extern uint16*  pTAG_LS_UI;
extern float32* pTAG_LS_F;

extern uint16*  pTAG_SC_UI;
extern float32* pTAG_SC_F;

extern uint16*  pTAG_SC_SYSTEM_INFO;
extern uint16*  pTAG_SC_SCFG_UI;
extern float32* pTAG_SC_SCFG_F;

extern uint16*  pTAG_SC_UCFG_UI;
extern float32* pTAG_SC_UCFG_F;

extern uint16*  pTAG_SIM_UI;
extern float32* pTAG_SIM_F;

extern uint16*  pTAG_DG;

extern uint16* pTAG_MMI;

#define DO_ADDRESS              0x004201
#define CLR_DO(Bit)             *((volatile uint16 *)DO_ADDRESS) &= ~Bit
#define SET_DO(Bit)             *((volatile uint16 *)DO_ADDRESS) |= Bit

/*TAG AI*/
#define GET_TAG_AI_F(Index)                             **(pTAG_AI + Index)
#define SET_TAG_AI_F(Index, Value)                      **(pTAG_AI + Index) = Value

/*TAG DI*/
#define GET_TAG_DI(Index)                               *(pTAG_DI + Index)

/*TAG DO*/
#define GET_TAG_DO(Index)                               *(pTAG_DO + Index)
#define SET_TAG_DO(Index, Value)                        if(GET_TAG_DO(Index) != Value){         \
                                                        if(Value){                              \
                                                        SET_DO(Index%16);}                      \
                                                        else{                                   \
                                                        CLR_DO(Index%16);}                      \
                                                        *(pTAG_DO + Index) = Value;             \
                                                        SeqEvt_Push(TID_DO, Index, Value);}

/*TAG BV*/
#define GET_TAG_BV(Index)                               *(pTAG_BV + Index)
#define SET_TAG_BV(Index, Value)                        if(GET_TAG_BV(Index) != Value){         \
                                                        *(pTAG_BV + Index) = Value;             \
                                                        SeqEvt_Push(TID_BV, Index, Value); }

#define SET_TAG_BV_WO_EV(Index, Value)                  if(GET_TAG_BV(Index) != Value){         \
                                                        *(pTAG_BV + Index) = Value;}

/*TAG NMV*/
#define GET_TAG_NMV_UI(Index)                          *(pTAG_NMV_UI + Index)
#define SET_TAG_NMV_UI(Index, Value)                   *(pTAG_NMV_UI + Index) = Value

#define GET_TAG_NMV_F(Index)                           *(pTAG_NMV_F + Index)
#define SET_TAG_NMV_F(Index, Value)                    *(pTAG_NMV_F + Index) = Value

/*TAG NVV*/
#define GET_TAG_NVV_UI(Index)                          *(pTAG_NVV_UI + Index)
#define SET_TAG_NVV_UI(Index, Value)                   if(GET_TAG_NVV_UI(Index) != Value){          \
                                                       *(pTAG_NVV_UI + Index) = Value;              \
                                                       SeqEvt_Push(TID_NVV, Index, Value);          \
                                                       FramTagEvt_Push(TAG_GRP_NVV_UI, Index);}
/*without sequential event*/
#define SET_TAG_NVV_UI_WO_EV(Index, Value)             if(GET_TAG_NVV_UI(Index) != Value){          \
                                                        *(pTAG_NVV_UI + Index) = Value;             \
                                                        FramTagEvt_Push(TAG_GRP_NVV_UI, Index);}

#define GET_TAG_NVV_F(Index)                           *(pTAG_NVV_F + Index)
#define SET_TAG_NVV_F(Index, Value)                    if(GET_TAG_NVV_F(Index) != Value){          \
                                                       *(pTAG_NVV_F + Index) = Value;              \
                                                       SeqEvt_Push(TID_NVV, Index, Value);         \
                                                       FramTagEvt_Push(TAG_GRP_NVV_F, Index);}

/*without sequential event*/
#define SET_TAG_NVV_F_WO_EV(Index, Value)              if(GET_TAG_NVV_F(Index) != Value){          \
                                                       *(pTAG_NVV_F + Index) =  Value;            \
                                                       FramTagEvt_Push(TAG_GRP_NVV_F, Index);}


/*TAG RCM*/
#define GET_TAG_RCM(Index)                             *(pTAG_RCM + Index)
#define SET_TAG_RCM(Index, Value)                      if(GET_TAG_RCM(Index) != Value){          \
                                                       *(pTAG_RCM + Index) =  Value;            \
                                                       SeqEvt_Push(TID_RCM, Index, Value);}

/*TAG LS*/
#define GET_TAG_LS_UI(Index)                           *(pTAG_LS_UI + Index)
#define SET_TAG_LS_UI(Index, Value)                    *(pTAG_LS_UI + Index) = Value

#define GET_TAG_LS_F(Index)                            *(pTAG_LS_F + Index)
#define SET_TAG_LS_F(Index, Value)                     *(pTAG_LS_F + Index)  = Value


/*TAG SC*/
#define GET_TAG_SC_UI(Index)                           *(pTAG_SC_UI + Index)
#define SET_TAG_SC_UI(Index, Value)                    *(pTAG_SC_UI + Index) = Value

#define GET_TAG_SC_F(Index)                            *(pTAG_SC_F + Index)
#define SET_TAG_SC_F(Index, Value)                     *(pTAG_SC_F + Index) = Value

#define GET_TAG_SC_SCFG_UI(Index)                      GET_TAG_SC_UI(Index)

#define SET_TAG_SC_SCFG_UI(Index, Value)               if(GET_TAG_SC_UI(Index) != Value){        \
                                                        SET_TAG_SC_UI(Index, Value);             \
                                                        SeqEvt_Push(TAG_GRP_SC_UI, Index, Value);\
                                                        FramTagEvt_Push(TAG_GRP_SC_UI, Index);}

#define GET_TAG_SC_SCFG_F(Index)                       GET_TAG_SC_F(Index)
#define SET_TAG_SC_SCFG_F(Index, Value)                 if(GET_TAG_SC_F(Index) != Value){        \
                                                        SET_TAG_SC_F(Index, Value);             \
                                                        SeqEvt_Push(TAG_GRP_SC_F, Index, Value);\
                                                        FramTagEvt_Push(TAG_GRP_SC_F, Index);}

#define GET_TAG_SC_UCFG_UI(Index)                      GET_TAG_SC_UI(Index)
#define SET_TAG_SC_UCFG_UI(Index, Value)               if(GET_TAG_SC_UI(Index) != Value){        \
                                                        SET_TAG_SC_UI(Index, Value);             \
                                                        SeqEvt_Push(TAG_GRP_SC_UI, Index, Value);\
                                                        FramTagEvt_Push(TAG_GRP_SC_UI, Index);}

#define GET_TAG_SC_UCFG_F(Index)                       GET_TAG_SC_F(Index)
#define SET_TAG_SC_UCFG_F(Index, Value)                if(GET_TAG_SC_F(Index) != Value){        \
                                                       SET_TAG_SC_F(Index, Value);             \
                                                       SeqEvt_Push(TAG_GRP_SC_F, Index, Value);\
                                                       FramTagEvt_Push(TAG_GRP_SC_F, Index);}

/*TAG DG*/
#define GET_TAG_DG_UI(Index)                           *(pTAG_DG + Index)
#define SET_TAG_DG_UI(Index, Value)                    *(pTAG_DG + Index) = Value

/*TAG MMI*/
#define GET_TAG_MMI(Index)                             *(pTAG_MMI +Index)
#define SET_TAG_MMI(Index, Value)                      *(pTAG_MMI +Index) = Value

#endif /* COMPONENTS_TAGDB_INTERFACE_TAGDB_MACRO_H_ */
