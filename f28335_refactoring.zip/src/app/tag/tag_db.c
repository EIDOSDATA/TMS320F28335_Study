/*
 * TagDB.c
 *
 *  Created on: 2023. 11. 12.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>

#include "def.h"

#include "src/app/tag/tag_db.h"
#include "src/port/decoder.h"
#include "src/port/tmwDNP/targDatabase.h"

#include "src/app/tag/tag_default.h"
#include "src/app/tag/tag_name.h"


#define _USE_CLI

#ifdef _USE_CLI
#include "src/app/shell/cli.h"
#include "src/app/tag/tag_debug.h"
#include "src/app/tag/tag_db_macro.h"
#endif

#pragma DATA_SECTION (TagDB,      "ZONE6DATA")

#pragma DATA_SECTION (pBV_Alis_Name,          "ZONE6DATA")
#pragma DATA_SECTION (pTAG_SC_Alias_Name,          "ZONE6DATA")

#define TAG_DATA_FRAM_OFFSET_INDEX               FRAM_INDEX30

#define TAG_DATA_FRAM_CRC_SIZE       2     //1 Word
enum
{
    STORAGE_INDEX0  = TAG_DATA_FRAM_OFFSET_INDEX,
    STORAGE_INDEX1,     STORAGE_INDEX2,    STORAGE_INDEX3,     STORAGE_INDEX4,
    STORAGE_INDEX5,     STORAGE_INDEX6,     STORAGE_INDEX7,    STORAGE_INDEX8,     STORAGE_INDEX9,
    STORAGE_INDEX10,    STORAGE_INDEX11,    STORAGE_INDEX12,   STORAGE_INDEX13,    STORAGE_INDEX14,
    STORAGE_INDEX15,    STORAGE_INDEX16,    STORAGE_INDEX17,   STORAGE_INDEX18,    STORAGE_INDEX19,

    STORAGE_INDEX20,    STORAGE_INDEX21,    STORAGE_INDEX22,   STORAGE_INDEX23,
    STORAGE_INDEX24,    STORAGE_INDEX25,    STORAGE_INDEX26,   STORAGE_INDEX27,    STORAGE_INDEX28,
    STORAGE_INDEX29,    STORAGE_INDEX30,    STORAGE_INDEX31,   STORAGE_INDEX32,    STORAGE_INDEX33,
    STORAGE_INDEX34,    STORAGE_INDEX35,    STORAGE_INDEX36,   STORAGE_INDEX37,    STORAGE_INDEX38,

    /*Reserved*/
};

enum
{
    /*Tag Data FRAM address*/
    FRAM_TAG_SC_UI_ADDR     = (STORAGE_INDEX0*FRAM_BLOCK_SIZE),
    FRAM_TAG_SC_F_ADDR      = (STORAGE_INDEX1*FRAM_BLOCK_SIZE),
    FRAM_TAG_LS0_UI_ADDR    = (STORAGE_INDEX2*FRAM_BLOCK_SIZE),
    FRAM_TAG_LS0_F_ADDR     = (STORAGE_INDEX3*FRAM_BLOCK_SIZE),
    FRAM_TAG_LS1_UI_ADDR    = (STORAGE_INDEX4*FRAM_BLOCK_SIZE),
    FRAM_TAG_LS1_F_ADDR     = (STORAGE_INDEX5*FRAM_BLOCK_SIZE),
    FRAM_TAG_NMV_UI_ADDR    = (STORAGE_INDEX6*FRAM_BLOCK_SIZE),
    FRAM_TAG_NMV_F_ADDR     = (STORAGE_INDEX7*FRAM_BLOCK_SIZE),
    FRAM_TAG_NVV_UI_ADDR    = (STORAGE_INDEX8*FRAM_BLOCK_SIZE),
    FRAM_TAG_NVV_F_ADDR     = (STORAGE_INDEX9*FRAM_BLOCK_SIZE),
    FRAM_TAG_DNP232_UI_ADDR = (STORAGE_INDEX10*FRAM_BLOCK_SIZE),
    FRAM_TAG_DNP232_F_ADDR  = (STORAGE_INDEX11*FRAM_BLOCK_SIZE),
    FRAM_TAG_DNPETH_UI_ADDR = (STORAGE_INDEX12*FRAM_BLOCK_SIZE),
    FRAM_TAG_DNPETH_F_ADDR  = (STORAGE_INDEX13*FRAM_BLOCK_SIZE),
};



void TAG_Interface(cli_args_t *args);
void FRAM_TEST(cli_args_t *args);

static void TagNonVolatileData_Load(void);




void FRAM_Interface(cli_args_t *args);

static float32 TAG_AI_Dummy = 0.0F;
static TAG_DB TagDB;

/*For TAG DB Interface*/
float32** pTAG_AI = (float32**)&TagDB.AI.AI;
uint16*  pTAG_DI  = (uint16*)&TagDB.DI.DI;
uint16*  pTAG_DO  = (uint16*)&TagDB.DO.DO;
uint16*  pTAG_BV  = (uint16*)&TagDB.BV.BV;

uint16*  pTAG_NMV_UI = (uint16*)&TagDB.NMV.NMV_UI;
float32* pTAG_NMV_F  = (float32*)&TagDB.NMV.NMV_F;

uint16*  pTAG_NVV_UI = (uint16*)&TagDB.NVV.NVV_UI;;
float32* pTAG_NVV_F  = (float32*)&TagDB.NVV.NVV_F;

uint16* pTAG_RCM = (uint16*)&TagDB.RCM.RCM;

uint16*  pTAG_LS_UI = (uint16*)&TagDB.LS.LS_INTERNAL.LS_UI;
float32* pTAG_LS_F  = (float32*)&TagDB.LS.LS_INTERNAL.LS_F;

uint16*  pTAG_LS0_UI = (uint16*)&TagDB.LS.LS_GROUP1.LS_UI;
float32* pTAG_LS0_F  = (float32*)&TagDB.LS.LS_GROUP1.LS_F;

uint16*  pTAG_LS1_UI = (uint16*)&TagDB.LS.LS_GROUP2.LS_UI;
float32* pTAG_LS1_F  = (float32*)&TagDB.LS.LS_GROUP2.LS_F;

uint16*  pTAG_SC_UI = (uint16*)&TagDB.SC.SC_UI;
float32* pTAG_SC_F = (float32*)&TagDB.SC.SC_F;

uint16*  pTAG_SIM_DI    = (uint16*)&TagDB.SIM.SIM_DI;
float32* pTAG_SIM_RMS   = (float32*)&TagDB.SIM.SIM_RMS;
float32* pTAG_SIM_ANGLE = (float32*)&TagDB.SIM.SIM_ANG;
float32* pTAG_SIM_GPAI  = (float32*)&TagDB.SIM.SIM_GPAI;
float32* pTAG_SIM_FREQ  = (float32*)&TagDB.SIM.SIM_FREQ;

uint16* pTAG_DG = (uint16*)&TagDB.DG.DG_UI;

uint16* pTAG_MMI = (uint16*)&TagDB.MMI;

float32* pTAG_ACC = (float32*)&TagDB.ACC;

uint16* pTAG_DNP232_UI = (uint16*)&TagDB.DNP.DNP232_UI;
float32* pTAG_DNP232_F = (float32*)&TagDB.DNP.DNP232_F;

uint16* pTAG_DNPETH_UI = (uint16*)&TagDB.DNP.DNPETH_UI;
float32* pTAG_DNPETH_F = (uint16*)&TagDB.DNP.DNPETH_F;

TAG_DB* TagDB_Get(void)
{
    return &TagDB;
}


uint16 FramTagGroupAddr_Get(TAG_GROUP TagGroup);
void FramTagGroupCRC_Write(uint16 FramAddr, uint16 CRC);
uint16 FramTagGroupCRC_Read(uint16 FramAddr);

void TagDB_Init(void)
{
    uint16 i;
    memset(&TagDB, 0, sizeof(TAG_DB));

    /*Init TAG Pointer*/
    for(i=0; i<TAG_AI_INDEX_MAX; i++)
    {
        TagDB.AI.AI[i] = &TAG_AI_Dummy;
    }

    /*Load TAG SC, LS(non-volatile data) from FRAM*/
    TagNonVolatileData_Load();

    SdnpTagDbAddress_Get(&TagDB);


    /*Cli*/
    cliAdd("tag", TAG_Interface);
}

void* TagDataAddr_Get(TagData* pTagData)
{
    switch(pTagData->TagGroup)
    {
        case TAG_GRP_AI:
            return pTAG_AI[pTagData->TagIndex];
        case TAG_GRP_DI:
            return &pTAG_DI[pTagData->TagIndex];
        case TAG_GRP_DO:
            return &pTAG_DO[pTagData->TagIndex];
        case TAG_GRP_BV:
            return &pTAG_BV[pTagData->TagIndex];
        case TAG_GRP_NMV_UI:
            return &pTAG_NMV_UI[pTagData->TagIndex];
        case TAG_GRP_NMV_F:
            return &pTAG_NMV_F[pTagData->TagIndex];
        case TAG_GRP_NVV_UI:
            return &pTAG_NVV_UI[pTagData->TagIndex];
        case TAG_GRP_NVV_F:
            return &pTAG_NVV_F[pTagData->TagIndex];
        case TAG_GRP_RCM:
            return &pTAG_RCM[pTagData->TagIndex];
        case TAG_GRP_LS_UI:
            return &pTAG_LS_UI[pTagData->TagIndex];
        case TAG_GRP_LS_F:
            return &pTAG_LS_F[pTagData->TagIndex];
        case TAG_GRP_LS0_UI:
            return &pTAG_LS0_UI[pTagData->TagIndex];
        case TAG_GRP_LS0_F:
            return &pTAG_LS0_F[pTagData->TagIndex];
        case TAG_GRP_LS1_UI:
            return &pTAG_LS1_UI[pTagData->TagIndex];
        case TAG_GRP_LS1_F:
            return &pTAG_LS1_F[pTagData->TagIndex];
        case TAG_GRP_SC_UI:
            return &pTAG_SC_UI[pTagData->TagIndex];
        case TAG_GRP_SC_F:
            return &pTAG_SC_F[pTagData->TagIndex];
        case TAG_GRP_SIM_DI:
            return &pTAG_SIM_DI[pTagData->TagIndex];
        case TAG_GRP_SIM_RMS:
            return &pTAG_SIM_RMS[pTagData->TagIndex];
        case TAG_GRP_SIM_ANG:
            return &pTAG_SIM_ANGLE[pTagData->TagIndex];
        case TAG_GRP_SIM_FREQ:
            return &pTAG_SIM_FREQ[pTagData->TagIndex];
        case TAG_GRP_SIM_GPAI:
            return &pTAG_SIM_GPAI[pTagData->TagIndex];
        case TAG_GRP_DG:
            return &pTAG_DG[pTagData->TagIndex];
        case TAG_GRP_MMI:
            return &pTAG_MMI[pTagData->TagIndex];
        case TAG_GRP_ACC:
            return &pTAG_ACC[pTagData->TagIndex];
        case TAG_GRP_DNP232_UI:
            return &pTAG_DNP232_UI[pTagData->TagIndex];
        case TAG_GRP_DNP232_F:
            return &pTAG_DNP232_F[pTagData->TagIndex];
        case TAG_GRP_DNPETH_UI:
            return &pTAG_DNPETH_UI[pTagData->TagIndex];
        case TAG_GRP_DNPETH_F:
            return &pTAG_DNPETH_F[pTagData->TagIndex];
    }
    return NULL;
}


static void FramTagData_Load(TAG_GROUP TagGroup, void* pBuf, void* pDefaultFile, uint16 Size)
{
    uint16 FramAddr, PrevCRC, ComputedCRC;

    FramAddr = FramTagGroupAddr_Get(TagGroup);
    PrevCRC  = FramTagGroupCRC_Read(FramAddr);

    FramFile_Read(FramAddr+TAG_DATA_FRAM_CRC_SIZE,
                  pBuf, Size);

    ComputedCRC = Compute_DNP_CRC(pBuf, Size);

    if(PrevCRC != ComputedCRC)
    {
        /*save default tag data to FRAM*/
        DEBUG_Msg("invalid tag data save default tag data to FRAM\n");

        if(pDefaultFile != NULL)
            memcpy(pBuf, pDefaultFile, Size);
        else
            memset(pBuf, 0, Size);

        ComputedCRC = Compute_DNP_CRC(pBuf, Size);

        FramTagGroupCRC_Write(FramAddr, ComputedCRC);

        FramFile_Write(FramAddr+TAG_DATA_FRAM_CRC_SIZE,
                       pBuf, Size);
    }
}
static void TagNonVolatileData_Load(void)
{
    DEBUG_Msg("Load TAG SC UI data from FRAM...\n");
    FramTagData_Load(TAG_GRP_SC_UI, &TagDB.SC.SC_UI[0], (void*)&TagScDefaultValue.SC_UI[0], sizeof(TagScDefaultValue.SC_UI));
    DEBUG_Msg("Load TAG SC F data from FRAM...\n");
    FramTagData_Load(TAG_GRP_SC_F, &TagDB.SC.SC_F[0],   (void*)&TagScDefaultValue.SC_F[0], sizeof(TagScDefaultValue.SC_F));

    DEBUG_Msg("Load TAG LS0 UI data from FRAM...\n");
    FramTagData_Load(TAG_GRP_LS0_UI, &TagDB.LS.LS_GROUP1.LS_UI[0],   (void*)&TagLsDefaultValue.LS_UI[0], sizeof(TagLsDefaultValue.LS_UI));
    DEBUG_Msg("Load TAG LS0 F data from FRAM...\n");
    FramTagData_Load(TAG_GRP_LS0_F,  &TagDB.LS.LS_GROUP1.LS_F[0],    (void*)&TagLsDefaultValue.LS_F[0],  sizeof(TagLsDefaultValue.LS_F));

    DEBUG_Msg("Load TAG LS1 UI data from FRAM...\n");
    FramTagData_Load(TAG_GRP_LS1_UI, &TagDB.LS.LS_GROUP2.LS_UI[0],   (void*)&TagLsDefaultValue.LS_UI[0], sizeof(TagLsDefaultValue.LS_UI));
    DEBUG_Msg("Load TAG LS1 F data from FRAM...\n");
    FramTagData_Load(TAG_GRP_LS1_F,  &TagDB.LS.LS_GROUP2.LS_F[0],    (void*)&TagLsDefaultValue.LS_F[0],  sizeof(TagLsDefaultValue.LS_F));

     /*TAG LS UI*/
     switch(pTAG_SC_UI[ALS_SC_STGRP])
     {
         /*Copy LS0 -> LS*/
         case 0:
             memcpy(&TagDB.LS.LS_INTERNAL, &TagDB.LS.LS_GROUP1, sizeof(TAG_LS_UI_F));
             break;
         /*Cop LS1 -> LS*/
         case 1:
             memcpy(&TagDB.LS.LS_INTERNAL, &TagDB.LS.LS_GROUP2, sizeof(TAG_LS_UI_F));
             break;
     }

     DEBUG_Msg("Load TAG NVV UI data from FRAM...\n");
     FramTagData_Load(TAG_GRP_NVV_UI, &TagDB.NVV.NVV_UI[0],   NULL, sizeof(TagDB.NVV.NVV_UI));
     DEBUG_Msg("Load TAG NVV F data from FRAM...\n");
     FramTagData_Load(TAG_GRP_NVV_F,  &TagDB.NVV.NVV_F[0],    NULL, sizeof(TagDB.NVV.NVV_F));


     DEBUG_Msg("Load TAG DNP232 UI data from FRAM...\n");
     FramTagData_Load(TAG_GRP_DNP232_UI, &TagDB.DNP.DNP232_UI[0],     (void*)&TagDnpDefaultValue.DNP232_UI, sizeof(TagDB.DNP.DNP232_UI));
     DEBUG_Msg("Load TAG DNP232 F data from FRAM...\n");
     FramTagData_Load(TAG_GRP_DNP232_F,  &TagDB.DNP.DNP232_F[0],      (void*)&TagDnpDefaultValue.DNP232_F, sizeof(TagDB.DNP.DNP232_F));

     DEBUG_Msg("Load TAG DNPETH UI data from FRAM...\n");
     FramTagData_Load(TAG_GRP_DNPETH_UI, &TagDB.DNP.DNPETH_UI[0],     (void*)&TagDnpDefaultValue.DNPETH_UI, sizeof(TagDB.DNP.DNPETH_UI));
     DEBUG_Msg("Load TAG DNPETH F data from FRAM...\n");
     FramTagData_Load(TAG_GRP_DNPETH_F,  &TagDB.DNP.DNPETH_F[0],      (void*)&TagDnpDefaultValue.DNPETH_F, sizeof(TagDB.DNP.DNPETH_F));

}



void FramTagGroupCRC_Write(uint16 FramAddr, uint16 CRC)
{
    Zone7BusTake(FRAM);

    FRAM_WordWrite(FramAddr, CRC);

    Zone7BusRelease();

}

uint16 FramTagGroupCRC_Read(uint16 FramAddr)
{
    uint16 CRC = 0;

    Zone7BusTake(FRAM);

    CRC = FRAM_WordRead(FramAddr);

    Zone7BusRelease();

    return CRC;
}

void FramTagGroupCRC_Update(TAG_GROUP TagGroup)
{
    void* pAddr;
    uint16 Length = 0;

    switch(TagGroup)
    {
        case TAG_GRP_SC_UI:
            pAddr   = pTAG_SC_UI;
            Length = TAG_SC_UI_INDEX_MAX;
            break;
        case TAG_GRP_SC_F:
            pAddr   = pTAG_SC_F;
            Length = TAG_SC_F_INDEX_MAX*2;
            break;
        case TAG_GRP_LS0_UI:
            pAddr   = pTAG_LS0_UI;
            Length = TAG_LS0_UI_INDEX_MAX;
            break;
        case TAG_GRP_LS0_F:
            pAddr  = pTAG_LS0_F;
            Length = TAG_LS0_F_INDEX_MAX*2;
            break;
        case TAG_GRP_LS1_UI:
            pAddr   = pTAG_LS1_UI;
            Length = TAG_LS1_UI_INDEX_MAX;
            break;
        case TAG_GRP_LS1_F:
            pAddr  = pTAG_LS1_F;
            Length = TAG_LS1_F_INDEX_MAX*2;
            break;
        case TAG_GRP_NMV_UI:
            pAddr  = pTAG_NMV_UI;
            Length = TAG_NMV_UI_INDEX_MAX;
            break;
        case TAG_GRP_NMV_F:
            pAddr  = pTAG_NMV_F;
            Length = TAG_NMV_F_INDEX_MAX*2;
            break;
        case TAG_GRP_NVV_UI:
            pAddr  = pTAG_NVV_UI;
            Length = TAG_NVV_UI_INDEX_MAX;
            break;
        case TAG_GRP_NVV_F:
            pAddr  = pTAG_NVV_F;
            Length = TAG_NVV_F_INDEX_MAX*2;
            break;
        case TAG_GRP_DNP232_UI:
            pAddr  = pTAG_DNP232_UI;
            Length = TAG_DNP232_UI_INDEX_MAX;
            break;
        case TAG_GRP_DNP232_F:
            pAddr  = pTAG_DNP232_F;
            Length = TAG_DNP232_F_INDEX_MAX*2;
            break;
        case TAG_GRP_DNPETH_UI:
            pAddr  = pTAG_DNPETH_UI;
            Length = TAG_DNPETH_UI_INDEX_MAX;
            break;
        case TAG_GRP_DNPETH_F:
            pAddr  = pTAG_DNPETH_F;
            Length = TAG_DNPETH_F_INDEX_MAX*2;
            break;
    }
    if(Length > 0)
    {
        uint16 FramAddr, CRC;

        CRC = Compute_DNP_CRC(pAddr, Length);

        FramAddr = FramTagGroupAddr_Get(TagGroup);

        FramTagGroupCRC_Write(FramAddr, CRC);

        CLI_Printf("Update Fram tag group crc\r\n");
    }
}
static uint16 FRAM_TagIntDataRead(TAG_GROUP TagGroup, uint16 Index)
{
    uint16 FramAddr = FRAM_UI_OFFSET * Index;
    uint16 Rtn;

    switch(TagGroup)
    {
        case TAG_GRP_SC_UI:
            FramAddr += FRAM_TAG_SC_UI_ADDR;
            break;
        case TAG_GRP_LS0_UI:
            FramAddr += FRAM_TAG_LS0_UI_ADDR;
            break;
        case TAG_GRP_LS1_UI:
            FramAddr += FRAM_TAG_LS1_UI_ADDR;
            break;
        case TAG_GRP_NVV_UI:
            FramAddr += FRAM_TAG_NVV_UI_ADDR;
            break;
        case TAG_GRP_DNP232_UI:
            FramAddr += FRAM_TAG_DNP232_UI_ADDR;
            break;
        case TAG_GRP_DNPETH_UI:
            FramAddr += FRAM_TAG_DNPETH_UI_ADDR;
            break;
        default:
            return false;
    }
    Zone7BusTake(FRAM);

    Rtn = FRAM_WordRead(FramAddr);

    Zone7BusRelease();
    return Rtn;
}

static float32 FRAM_TagFloatDataRead(TAG_GROUP TagGroup, uint16 Index)
{
    FramData FramReadData;

    uint16 FramAddr = FRAM_F_OFFSET * Index;

    switch(TagGroup)
    {
        case TAG_GRP_SC_F:
            FramAddr += FRAM_TAG_SC_F_ADDR;
            break;
        case TAG_GRP_LS0_F:
            FramAddr += FRAM_TAG_LS0_F_ADDR;
            break;
        case TAG_GRP_LS1_F:
            FramAddr += FRAM_TAG_LS1_F_ADDR;
            break;
        case TAG_GRP_NVV_F:
            FramAddr += FRAM_TAG_NVV_F_ADDR;
            break;
        case TAG_GRP_DNP232_F:
            FramAddr += FRAM_TAG_DNP232_F_ADDR;
            break;
        case TAG_GRP_DNPETH_F:
            FramAddr += FRAM_TAG_DNPETH_F_ADDR;
            break;
        default:
            return 0.0;
    }

    Zone7BusTake(FRAM);

    FramReadData.FramUI[0] = FRAM_WordRead(FramAddr);
    FramAddr += 2;
    FramReadData.FramUI[1] = FRAM_WordRead(FramAddr);

    Zone7BusRelease();
    return FramReadData.FramF;
}


void FRAM_Interface(cli_args_t *args)
{
    if(args->isStr(0, "read"))
    {
        uint16 Block = args->getData(1);
        uint16 Index = args->getData(2);
        TAG_GROUP TagGroup;
        switch(Block)
        {
            case 0:
                TagGroup = TAG_GRP_SC_UI;
                break;
            case 1:
                TagGroup = TAG_GRP_SC_F;
                break;
            case 2:
                TagGroup = TAG_GRP_LS_UI;
                break;
            case 3:
                TagGroup = TAG_GRP_LS_F;
                break;
        }

        if(Block%2 == 0)
        {
            CLI_Printf("Index %d = %d\r\n", Index, FRAM_TagIntDataRead(TagGroup, Index));
        }
        else
        {
            CLI_Printf("Index %d = %.2f\r\n", Index, FRAM_TagFloatDataRead(TagGroup, Index));
        }

    }
}



/*Tag Interface TEST Using CLI*/
void TAG_Interface(cli_args_t *args)
{
  if(args->isStr(0, "get"))
        {
            if(args->isStr(1, "ai"))
            {
                uint16 i;

                for(i=0; i<TAG_AI_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %.2f\r\n", pAI_Alias[i], i, GET_TAG_AI_F(i));
                }
            }

            else if(args->isStr(1, "bv"))
            {
                uint16 i;
                uint16 TAG_BV_UI[TAG_BV_INDEX_MAX];

                for(i=0;i<TAG_BV_INDEX_MAX;i++)
                {
                    TAG_BV_UI[i] = GET_TAG_BV(i);
                    CLI_Printf("TAG BV Index %d = %d\r\n", i, TAG_BV_UI[i]);
                }
            }
            else if(args->isStr(1, "nvv"))
            {
                uint16 i;

                for(i=0;i<TAG_NVV_UI_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG NVV UI Index %d = %d\r\n", i, pTAG_NVV_UI[i]);
                }
                for(i = 0; i<TAG_NVV_F_INDEX_MAX; i++)
                {
                    CLI_Printf("TAG NVV F Index %d = %f\r\n", i, pTAG_NVV_F[i]);
                }
            }
            else if(args->isStr(1, "nmv"))
            {
                uint16 i;

                for(i=0;i<TAG_NMV_UI_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG NMV UI Index %d = %d\r\n", i, pTAG_NMV_UI[i]);
                }
                for(i = 0; i<TAG_NMV_F_INDEX_MAX; i++)
                {
                    CLI_Printf("TAG NMV F Index %d = %f\r\n", i, pTAG_NMV_F[i]);
                }
            }
            else if(args->isStr(1, "rcm"))
            {
                uint16 i;
                for(i = 0; i<TAG_RCM_INDEX_MAX; i++)
                {
                    CLI_Printf("RCM Index %d = %d\r\n", i, GET_TAG_RCM(i));
                }
            }

            else if(args->isStr(1, "ls"))
            {
                uint16 i;
                for(i=0;i<TAG_LS_UI_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS UI Index %d = %d\r\n", i, pTAG_LS_UI[i]);
                }
                for(i=0;i<TAG_LS_F_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS F Index %d = %f\r\n", i, pTAG_LS_F[i]);
                }

            }
            else if(args->isStr(1, "ls0"))
            {
                uint16 i;

                for(i=0;i<TAG_LS_UI_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS0 UI Index %d = %d\r\n", i, pTAG_LS0_UI[i]);
                }
                for(i=0;i<TAG_LS_F_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS F Index %d = %f\r\n", i, pTAG_LS0_F[i]);
                }
            }
            else if(args->isStr(1, "ls1"))
            {
                uint16 i;

                for(i=0;i<TAG_LS_UI_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS0 UI Index %d = %d\r\n", i, pTAG_LS1_UI[i]);
                }
                for(i=0;i<TAG_LS_F_INDEX_MAX;i++)
                {
                    CLI_Printf("TAG LS F Index %d = %f\r\n", i, pTAG_LS1_F[i]);
                }
            }
            else if(args->isStr(1, "sc_ui"))
            {
                uint16 i;
                for(i = 0; i<TAG_SC_UI_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pTAG_SC_UI_Alias[i], i, pTAG_SC_UI[i]);
                }
            }
            else if(args->isStr(1, "sc_f"))
            {
                uint16 i;
                for(i = 0; i<TAG_SC_F_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %.2f\r\n", pTAG_SC_F_Alias[i], i, pTAG_SC_F[i]);
                }
            }
            else if(args->isStr(1, "mmi"))
             {
                uint16 i;
                for(i = 0; i<TAG_MMI_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pMMI_Alis[i], i, pTAG_MMI[i]);
                }
             }
            else if(args->isStr(1, "dnp"))
             {
                uint16 i;
                for(i = 0; i<TAG_DNP232_UI_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pDNP232_UI_Alis[i], i, pTAG_DNP232_UI[i]);
                }
                CLI_Printf(SCI_C,"\r\n");
                for(i = 0; i<TAG_DNP232_F_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pDNP232_F_Alis[i], i, pTAG_DNP232_F[i]);
                }
                for(i = 0; i<TAG_DNPETH_UI_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pDNPETH_UI_Alis[i], i, pTAG_DNPETH_UI[i]);
                }
                CLI_Printf(SCI_C,"\r\n");
                for(i = 0; i<TAG_DNPETH_F_INDEX_MAX; i++)
                {
                    CLI_Printf("%s\t%d = %d\r\n", pDNPETH_F_Alis[i], i, pTAG_DNPETH_F[i]);
                }
             }
        }

  else if(args->isStr(0, "set"))
        {
            if(args->isStr(1, "ai"))
            {
                uint16  Index = args->getData(2);
                float32 Value = args->getData(3);

                SET_TAG_AI_F(Index, Value);

                CLI_Printf("TAG AI Index %d = %f\r\n", Index, GET_TAG_AI_F(Index));
            }
            else if(args->isStr(1, "di"))
            {
                uint16  Index = args->getData(2);
                bool    Value = args->getData(3);

                *(pTAG_DI+Index) =  Value;

                CLI_Printf("TAG DI Index %d = %d\r\n", Index, pTAG_DI[Index]);
            }

            else if(args->isStr(1, "do"))
            {
                uint16 Index = args->getData(2);
                bool   Value = args->getData(3);

                SET_TAG_DO(Index, Value);

                CLI_Printf("TAG DO Index %d = %d\r\n", Index, GET_TAG_DO(Index));
            }
            else if(args->isStr(1, "bv"))
            {
                uint16  Index = args->getData(2);
                bool    Value = args->getData(3);

                SET_TAG_BV(Index, Value);

                CLI_Printf("TAG BV Index %d = %d\r\n", Index, GET_TAG_BV(Index));
            }
            else if(args->isStr(1, "nmv_ui"))
            {
                uint16  Index = args->getData(2);
                uint16  Value = args->getData(3);

                SET_TAG_NMV_UI(Index, Value);

                CLI_Printf("TAG NMV UI Index %d = %d\r\n", Index, GET_TAG_NMV_UI(Index));
            }
            else if(args->isStr(1, "nmv_f"))
            {
                uint16  Index = args->getData(2);
                float32 Value = args->getFloat(3);

                SET_TAG_NMV_F(Index, Value);

                CLI_Printf("TAG NMV F Index %d = %f\r\n", Index, GET_TAG_NMV_F(Index));
            }
            else if(args->isStr(1, "nvv_ui"))
            {
                uint16  Index = args->getData(2);
                uint16  Value = args->getData(3);

                SET_TAG_NVV_UI(Index, Value);

                CLI_Printf("TAG NVV UI Index %d = %d\r\n", Index, GET_TAG_NVV_UI(Index));
            }
            else if(args->isStr(1, "nvv_f"))
            {
                uint16  Index = args->getData(2);
                float32 Value = args->getFloat(3);

                SET_TAG_NVV_F(Index, Value);

                CLI_Printf("TAG NVV F Index %d = %f\r\n", Index, GET_TAG_NVV_F(Index));
            }
            else if(args->isStr(1, "rcm"))
            {
                uint16 Index = args->getData(2);
                uint16 Value = args->getData(3);

                SET_TAG_RCM(Index, Value);

                CLI_Printf("TAG RCM Index %d = %d\r\n", Index, GET_TAG_RCM(Index));
            }

            else if(args->isStr(1, "sc_ui"))
            {
                uint16 Index = args->getData(2);
                uint16 Value = args->getFloat(3);
                SET_TAG_SC_SCFG_UI(Index, Value);

                CLI_Printf("TAG SC UI Index %d = %d\r\n", Index, GET_TAG_SC_SCFG_UI(Index));
            }
            else if(args->isStr(1, "sc_f"))
            {
                uint16 Index = args->getData(2);
                float32 Value = args->getFloat(3);

                SET_TAG_SC_SCFG_F(Index, Value);

                CLI_Printf("TAG SC F Index %d = %d\r\n", Index, GET_TAG_SC_SCFG_F(Index));
            }

            else if(args->isStr(1, "sim"))
            {

            }
            else if(args->isStr(1, "dg"))
            {

            }
            else if(args->isStr(1, "mmi"))
            {
                uint16 Index = args->getData(2);
                bool   Value = args->getData(3);

                SET_TAG_MMI(Index, Value);
                Value = GET_TAG_MMI(Index);
                CLI_Printf("%s\t%d = %d\r\n", pMMI_Alis[Index],Index, Value);

            }
#if 0       /*for Sequential event ALS_BV_LAMPTEST*/
            else if(args->isStr(1, "lamp"))
            {
                uint16 i;
                bool Value = 1;

                for(i=0; i<15;i++)
                {
                    SET_TAG_MMI(ALS_MMI_PBTARR, Value);
                    TASK_SLEEP(100);
                    CLI_Printf("MMI_PBTARR = %d\r\n", Value);
                    Value ^= 1;
                }
                SET_TAG_MMI(ALS_MMI_PBTARR, 0);
            }
#endif


    }
}
uint16 FramTagGroupAddr_Get(TAG_GROUP TagGroup)
{
    uint16 FramAddr = 0;
    switch(TagGroup)
    {
        case TAG_GRP_SC_UI:
            FramAddr = FRAM_TAG_SC_UI_ADDR;
            break;
        case TAG_GRP_SC_F:
            FramAddr = FRAM_TAG_SC_F_ADDR;
            break;
        case TAG_GRP_LS0_UI:
            FramAddr = FRAM_TAG_LS0_UI_ADDR;
            break;
        case TAG_GRP_LS0_F:
            FramAddr = FRAM_TAG_LS0_F_ADDR;
            break;
        case TAG_GRP_LS1_UI:
            FramAddr = FRAM_TAG_LS1_UI_ADDR;
            break;
        case TAG_GRP_LS1_F:
            FramAddr = FRAM_TAG_LS1_F_ADDR;
            break;
        case TAG_GRP_NVV_UI:
            FramAddr = FRAM_TAG_NVV_UI_ADDR;
            break;
        case TAG_GRP_NVV_F:
            FramAddr = FRAM_TAG_NVV_F_ADDR;
            break;
        case TAG_GRP_DNP232_UI:
            FramAddr = FRAM_TAG_DNP232_UI_ADDR;
            break;
        case TAG_GRP_DNP232_F:
            FramAddr = FRAM_TAG_DNP232_F_ADDR;
            break;
        case TAG_GRP_DNPETH_UI:
            FramAddr = FRAM_TAG_DNPETH_UI_ADDR;
            break;
        case TAG_GRP_DNPETH_F:
            FramAddr = FRAM_TAG_DNPETH_F_ADDR;
            break;
    }
    return FramAddr;
}

void FRAM_TagIntDataWrite(TAG_GROUP TagGroup, uint16 Index)
{

    uint16 FramAddr = (FRAM_UI_OFFSET * Index) + TAG_DATA_FRAM_CRC_SIZE;
    uint16 Data;

    switch(TagGroup)
    {
        case TAG_GRP_SC_UI:
            FramAddr += FRAM_TAG_SC_UI_ADDR;
            Data = pTAG_SC_UI[Index];
            break;
        case TAG_GRP_LS0_UI:
            FramAddr += FRAM_TAG_LS0_UI_ADDR;
            Data = pTAG_LS0_UI[Index];
            break;
        case TAG_GRP_LS1_UI:
            FramAddr += FRAM_TAG_LS1_UI_ADDR;
            Data = pTAG_LS1_UI[Index];
            break;
        case TAG_GRP_NVV_UI:
            FramAddr += FRAM_TAG_NVV_UI_ADDR;
            Data = pTAG_NVV_UI[Index];
            break;
        case TAG_GRP_NMV_UI:
            FramAddr += FRAM_TAG_NMV_UI_ADDR;
            Data = pTAG_NMV_UI[Index];
            break;
        case TAG_GRP_DNP232_UI:
            FramAddr += FRAM_TAG_DNP232_UI_ADDR;
            Data = pTAG_DNP232_UI[Index];
            break;
        case TAG_GRP_DNPETH_UI:
            FramAddr += FRAM_TAG_DNPETH_UI_ADDR;
            Data = pTAG_DNPETH_UI[Index];
            break;
        default:
            return;
    }

    Zone7BusTake(FRAM);
    FRAM_WordWrite(FramAddr, Data);
    Zone7BusRelease();

}

void FRAM_TagFloatDataWrite(TAG_GROUP TagGroup, uint16 Index)
{
    FramData FramSaveData;
    uint16 FramAddr = (FRAM_F_OFFSET * Index) +TAG_DATA_FRAM_CRC_SIZE;

    switch(TagGroup)
    {
        case TAG_GRP_SC_F:
            FramAddr += FRAM_TAG_SC_F_ADDR;
            FramSaveData.FramF = pTAG_SC_F[Index];
            break;
        case TAG_GRP_LS0_F:
            FramAddr += FRAM_TAG_LS0_F_ADDR;
            FramSaveData.FramF = pTAG_LS0_F[Index];
            break;
        case TAG_GRP_LS1_F:
            FramAddr += FRAM_TAG_LS1_F_ADDR;
            FramSaveData.FramF = pTAG_LS1_F[Index];
            break;
        case TAG_GRP_NVV_F:
            FramAddr += FRAM_TAG_NVV_F_ADDR;
            FramSaveData.FramF = pTAG_NVV_F[Index];
            break;
        case TAG_GRP_NMV_F:
            FramAddr += FRAM_TAG_NMV_F_ADDR;
            FramSaveData.FramF = pTAG_NMV_F[Index];
            break;
        case TAG_GRP_DNP232_F:
            FramAddr += FRAM_TAG_DNP232_F_ADDR;
            FramSaveData.FramF = pTAG_DNP232_F[Index];
            break;
        case TAG_GRP_DNPETH_F:
            FramAddr += FRAM_TAG_DNPETH_F_ADDR;
            FramSaveData.FramF = pTAG_DNPETH_F[Index];
            break;
        default:
            return;
    }
    Zone7BusTake(FRAM);

    FRAM_WordWrite(FramAddr, FramSaveData.FramUI[0]);
    FramAddr += 2;
    FRAM_WordWrite(FramAddr, FramSaveData.FramUI[1]);

    Zone7BusRelease();

}

void TagDataName_Get(TagData* pTagData,char* pBuf)
{
    switch(pTagData->TagGroup)
    {
        case 2:
            memcpy(pBuf, pDI_Alias_Name[pTagData->TagIndex], strlen(pDI_Alias_Name[pTagData->TagIndex]));
            return;
        case 3:
            memcpy(pBuf, pDO_Alias_Name[pTagData->TagIndex], strlen(pDO_Alias_Name[pTagData->TagIndex]));
            return;
        case 4:
            memcpy(pBuf, pBV_Alis_Name[pTagData->TagIndex], strlen(pBV_Alis_Name[pTagData->TagIndex]));
            return;
        case 6:
            memcpy(pBuf, pNVV_Alias_Name[pTagData->TagIndex], strlen(pNVV_Alias_Name[pTagData->TagIndex]));
            return;
        case 7:
            memcpy(pBuf, pRCM_Alias_Name[pTagData->TagIndex], strlen(pRCM_Alias_Name[pTagData->TagIndex]));
            return;
        case 8:
            if(pTagData->TagIndex>153)
            {
                memcpy(pBuf,"Reserved",strlen("Reserved"));
            }
            else
            {
                memcpy(pBuf, pTAG_LS_Alias_Name[pTagData->TagIndex], strlen(pTAG_LS_Alias_Name[pTagData->TagIndex]));
            }
            return;
        case 9:
            memcpy(pBuf, pTAG_SC_Alias_Name[pTagData->TagIndex], strlen(pTAG_SC_Alias_Name[pTagData->TagIndex]));
            return;
    }
    return NULL;
}
