/*
 * Cli.h
 *
 *  Created on: 2023. 9. 12.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_CLI_INTERFACE_CLI_H_
#define COMPONENTS_CLI_INTERFACE_CLI_H_

#include "def.h"

#define CLI_CMD_NAME_MAX 32
#define CLI_LINE_BUF_MAX 32
#define CLI_CMD_LIST_MAX 16

typedef struct
{
    uint16      argc;
    uint16      **argv;

    uint16_t    (*getData)(uint16 index);
    float32     (*getFloat)(uint16 index);
    char        *(*getStr)(uint16 index);
    bool        (*isStr)(uint16 index, char *p_str);

} cli_args_t;

/*
 * Public Function
 */
void Cli_Task(UArg arg0, UArg arg1);

void CLI_Printf(char *fmt, ...);
bool cliAdd(const char *cmd_str, void (*p_func)(cli_args_t *));

void CliInit(void);
bool cliOpen(uint16 ch, uint32 baudrate);


void TEST_Printf(void* buf, uint16 len);
#endif /* COMPONENTS_CLI_INTERFACE_CLI_H_ */
