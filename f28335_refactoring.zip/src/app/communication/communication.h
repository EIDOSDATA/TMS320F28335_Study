/*
 * Comm.h
 *
 *  Created on: 2023. 10. 25.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_COMM_INTERFACE_COMM_H_
#define COMPONENTS_COMM_INTERFACE_COMM_H_


void Comm_Task(UArg arg0, UArg arg1);
void SciB_SendTask(UArg arg0, UArg arg1);
void SciC_SendTask(UArg arg0, UArg arg1);
#endif /* COMPONENTS_COMM_INTERFACE_COMM_H_ */
