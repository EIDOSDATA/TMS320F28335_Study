/*
 * Comm.c
 *
 *  Created on: 2023. 10. 23.
 *      Author: ShinSung Industrial Electric
 */

#include "src/utils/ringbuf.h"
#include "def.h"

#include "src/port/tmwDNP/CommConfig.h"
#include "src/port/tmwDNP/targphyinterface.h"
#include "src/app/shell/cli.h"

#include "src/port/uart.h"

#include "3rdParty/w5100/wsocket.h"

#include "src/app/tag/tag_db.h"
#define  DNP_STACK
#define  USE_CLI


#pragma DATA_SECTION(CommCtx,       "ZONE6DATA")

/*
 * OS instance
 */
extern Mailbox_Handle   mailbox0;
extern Mailbox_Handle   mailbox1;

extern Task_Handle   Task_Sampling;

extern void resetFunc(void);

typedef struct
{
    uint16 TaskPeriod;
#ifdef DNP_STACK
    TMWAPPL*            pDnpApplContext;
    SdnpDbHandle        SdnpDataBaseHd[SDNP_DB_TYPE_MAX];
    TARGIO_Channel      TARGIoChannel[SDNP_CH_MAX];
    SDNP_FileContext*   pSdnpFileHandle;
    TAG_DNP*            pTagDnp;
#endif

} CommunicationContext;


CommunicationContext CommCtx;



MSG_Block MSG_Box[2];

static void    DATA_Receive(SCI_CH ch, Ringbuf_t *phandle, uint16 size);

TMWAPPL* TmwSdnpStack_Init(void)
{
    tmwappl_initSCL();
    tmwtimer_initialize();

    return tmwappl_initApplication();
}

TMWCHNL* TmwSdnpCh_Open(TMWAPPL* pTmwApplCtx, uint16 ChType, void* pMyIoConfig, TAG_DNP* pTagDnp)
{
    if(pTmwApplCtx == NULL)
       return NULL;

    TMWCHNL* pTmwCh;

    DNPCHNL_CONFIG  DnpChConfig;
    DNPTPRT_CONFIG  DnpTpConfig;
    DNPLINK_CONFIG  DnpLinkConfig;
    TMWPHYS_CONFIG  DnpPhysConfig;

    TMWTARG_CONFIG  DnpTargConfig;

    memset(&DnpChConfig,    0,  sizeof(DNPCHNL_CONFIG));
    memset(&DnpTpConfig,    0,  sizeof(DNPTPRT_CONFIG));
    memset(&DnpLinkConfig,  0,  sizeof(DNPLINK_CONFIG));
    memset(&DnpPhysConfig,  0,  sizeof(TMWPHYS_CONFIG));
    memset(&DnpTargConfig,  0,  sizeof(TMWTARG_CONFIG));

    dnpchnl_initConfig(&DnpChConfig, &DnpTpConfig, &DnpLinkConfig, &DnpPhysConfig);

    tmwtarg_initConfig(&DnpTargConfig);
    /*DNP Link Layer User Config*/
    DnpLinkConfig.confirmMode       = TMWDEFS_LINKCNFM_ALWAYS;
    DnpLinkConfig.maxRetries        = 5;
    DnpLinkConfig.confirmTimeout    = 10000;

    if(ChType == UART_CH)
        DnpLinkConfig.networkType       = DNPLINK_NETWORK_NO_IP;

    else if(ChType == ETHERNET_CH)
        DnpLinkConfig.networkType       = DNPLINK_NETWORK_TCP_ONLY;

    pTmwCh = dnpchnl_openChannel(pTmwApplCtx,     &DnpChConfig,   &DnpTpConfig,
                                 &DnpLinkConfig,  &DnpPhysConfig, pMyIoConfig,
                                 &DnpTargConfig);
    return pTmwCh;
}
TMWSESN* SdnpLocalSesn_Open(TMWCHNL* pTmwCh, void* pMyDbHandle)
{
    if(pTmwCh == NULL)
        return NULL;

    SDNPSESN_CONFIG SdnpSesnConfig;

    memset(&SdnpSesnConfig, 0,  sizeof(SDNPSESN_CONFIG));

    sdnpsesn_initConfig(&SdnpSesnConfig);

    return sdnpsesn_openSession(pTmwCh, &SdnpSesnConfig, pMyDbHandle);
}
TMWSESN* SdnpScadaSesn_Open(TMWCHNL* pTmwCh, void* pMyDbHandle)
{
    if(pTmwCh == NULL)
        return NULL;

    SdnpDbHandle* pSdnpDbHandle = (SdnpDbHandle*)pMyDbHandle;

    SDNPSESN_CONFIG SdnpSesnConfig;

    memset(&SdnpSesnConfig, 0,  sizeof(SDNPSESN_CONFIG));

    sdnpsesn_initConfig(&SdnpSesnConfig);

    if(pSdnpDbHandle->DatabaseType == SCADA_DB)
    {
        /*Event Scan Period TEST 2 Sec*/
        SdnpSesnConfig.binaryInputMaxEvents  = 100;
        SdnpSesnConfig.binaryInputScanPeriod = 2000;
        SdnpSesnConfig.analogInputMaxEvents  = 100;
        SdnpSesnConfig.analogInputScanPeriod = 2000;

        /*For SCADA SOE*/
        SdnpSesnConfig.obj02DefaultVariation = 0;
        SdnpSesnConfig.obj32DefaultVariation = 0;
    }

    return sdnpsesn_openSession(pTmwCh, &SdnpSesnConfig, pMyDbHandle);
}
TMWCHNL* SdnpSerialLocalCh_Open(TMWAPPL* pTmwApplContext, void* pTargIoChannel, TAG_DNP* pTagDnp)
{
    TMWCHNL* pTmwCh;
    TARGUART_CONFIG UartConfig;

    memset(&UartConfig, 0, sizeof(TARGUART_CONFIG));

    UartConfig.type             = TMWTARGIO_TYPE_232;
    UartConfig.pTargIOChannel   = pTargIoChannel;

    UartConfig.targ232.PortType     = SCI_C;
    UartConfig.targ232.portMode     = MODE_NONE;
    UartConfig.targ232.baudRate     = 19200;
    UartConfig.targ232.parity       = PARITY_NONE;
    UartConfig.targ232.numDataBits  = DATA_BITS_8;
    UartConfig.targ232.numStopBits  = STOP_BITS_1;
    UartConfig.targ232.bModbusRTU   = false;

    pTmwCh = TmwSdnpCh_Open(pTmwApplContext, UART_CH, &UartConfig, pTagDnp);

    if(pTmwCh == NULL)
        DEBUG_Msg("fail to open local serial ch\n");

    return pTmwCh;
}
TMWCHNL* SdnpSerialScadaCh_Open(TMWAPPL* pTmwApplContext, void* pTargIoChannel, TAG_DNP* pTagDnp)
{
    TMWCHNL* pTmwCh;
    TARGUART_CONFIG UartConfig;

    memset(&UartConfig, 0, sizeof(TARGUART_CONFIG));

    UartConfig.type             = TMWTARGIO_TYPE_232;
    UartConfig.pTargIOChannel   = pTargIoChannel;

    UartConfig.targ232.PortType     = SCI_B;
    UartConfig.targ232.portMode     = MODE_NONE;
    UartConfig.targ232.baudRate     = 19200;
    UartConfig.targ232.parity       = PARITY_NONE;
    UartConfig.targ232.numDataBits  = DATA_BITS_8;
    UartConfig.targ232.numStopBits  = STOP_BITS_1;
    UartConfig.targ232.bModbusRTU   = false;

    pTmwCh = TmwSdnpCh_Open(pTmwApplContext, UART_CH, &UartConfig, pTagDnp);

    if(pTmwCh == NULL)
        DEBUG_Msg("fail to open local serial ch\n");

    return pTmwCh;
}

TMWCHNL* SdnpEthLocalCh_Open(TMWAPPL* pTmwApplContext, void* pTargIoChannel, TAG_DNP* pTagDnp)
{
    TMWCHNL* pTmwCh;
    TARGETH_CONFIG  EthConfig;

    memset(&EthConfig, 0,  sizeof(TARGETH_CONFIG));

    EthConfig.type              = TMWTARGIO_TYPE_TCP;
    EthConfig.pTargIOChannel    = pTargIoChannel;

    /*set ip address*/
    EthConfig.targTCP.SoureceIp[0]  = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR0];
    EthConfig.targTCP.SoureceIp[1]  = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR1];
    EthConfig.targTCP.SoureceIp[2]  = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR2];
    EthConfig.targTCP.SoureceIp[3]  = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR3];
    /*set gateway*/
    EthConfig.targTCP.GateWay[0]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR0];
    EthConfig.targTCP.GateWay[1]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR1];
    EthConfig.targTCP.GateWay[2]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR2];
    EthConfig.targTCP.GateWay[3]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR3];
    /*set subnetmask*/
    EthConfig.targTCP.SubnetMask[0] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK0];
    EthConfig.targTCP.SubnetMask[1] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK1];
    EthConfig.targTCP.SubnetMask[2] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK2];
    EthConfig.targTCP.SubnetMask[3] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK3];

    /*Local ethernet channel*/
    EthConfig.targTCP.PortNumber = 10000;
    EthConfig.targTCP.Socket     = SOCKET_0;

    pTmwCh = TmwSdnpCh_Open(pTmwApplContext, ETHERNET_CH, &EthConfig, pTagDnp);

    if(pTmwCh == NULL)
        CLI_Printf("fail to open Sdnp channel\r\n");

    return pTmwCh;
}

TMWCHNL* SdnpEthScadaCh_Open(TMWAPPL* pTmwApplContext, void* pTargIoChannel, TAG_DNP* pTagDnp)
{
    TMWCHNL* pTmwCh;
    TARGETH_CONFIG  EthConfig;

    memset(&EthConfig, 0,  sizeof(TARGETH_CONFIG));

    EthConfig.type = TMWTARGIO_TYPE_TCP;
    EthConfig.pTargIOChannel = pTargIoChannel;
    /*set ip address*/
    EthConfig.targTCP.SoureceIp[0] = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR0];
    EthConfig.targTCP.SoureceIp[1] = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR1];
    EthConfig.targTCP.SoureceIp[2] = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR2];
    EthConfig.targTCP.SoureceIp[3] = pTagDnp->DNPETH_UI[ALS_DNPETH_IPADDR3];
    /*set gateway*/
    EthConfig.targTCP.GateWay[0]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR0];
    EthConfig.targTCP.GateWay[1]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR1];
    EthConfig.targTCP.GateWay[2]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR2];
    EthConfig.targTCP.GateWay[3]    = pTagDnp->DNPETH_UI[ALS_DNPETH_GWIPADDR3];
    /*set subnetmask*/
    EthConfig.targTCP.SubnetMask[0] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK0];
    EthConfig.targTCP.SubnetMask[1] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK1];
    EthConfig.targTCP.SubnetMask[2] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK2];
    EthConfig.targTCP.SubnetMask[3] = pTagDnp->DNPETH_UI[ALS_DNPETH_SUBNETMASK3];

    /*Scada ethernet channel*/
    EthConfig.targTCP.PortNumber = pTagDnp->DNPETH_UI[ALS_DNPETH_TCPPORT];
    EthConfig.targTCP.Socket     = SOCKET_1;

    pTmwCh = TmwSdnpCh_Open(pTmwApplContext, ETHERNET_CH, &EthConfig, pTagDnp);

    if(pTmwCh == NULL)
        CLI_Printf("fail to open Sdnp channel\r\n");

    return pTmwCh;
}

CommunicationContext* Comm_Init(void)
{
    CommunicationContext* pContext = &CommCtx;

    memset(pContext, 0, sizeof(CommunicationContext));

    pContext->TaskPeriod = 5;
#ifdef DNP_STACK
    TAG_DB* pTagDB = TagDB_Get();

    pContext->pTagDnp = &pTagDB->DNP;
    pContext->pDnpApplContext = TmwSdnpStack_Init();
    pContext->pSdnpFileHandle = SDNPFileHandle_Get();

    /*Ethernet Local (W5100 Socket 0)*/
    pContext->SdnpDataBaseHd[LOCAL_DB].DatabaseType = LOCAL_DB;
    pContext->TARGIoChannel[LOCAL_ETHERNET_CH].type     = TMWTARGIO_TYPE_TCP;
    pContext->TARGIoChannel[LOCAL_ETHERNET_CH].pTmwCh   = SdnpEthLocalCh_Open(pContext->pDnpApplContext,
                                                                              &pContext->TARGIoChannel[LOCAL_ETHERNET_CH],
                                                                              pContext->pTagDnp);
    pContext->TARGIoChannel[LOCAL_ETHERNET_CH].pTmwSesn = SdnpLocalSesn_Open(pContext->TARGIoChannel[LOCAL_ETHERNET_CH].pTmwCh,
                                                                             (void*)&pContext->SdnpDataBaseHd[LOCAL_DB]);

    tmwsesn_setUserDataPtr(pContext->TARGIoChannel[LOCAL_ETHERNET_CH].pTmwSesn, pContext->pSdnpFileHandle);

    /*Ethernet SCADA (W5100 Socket 1)*/
    pContext->SdnpDataBaseHd[SCADA_DB].DatabaseType = LOCAL_DB;
    pContext->TARGIoChannel[SCADA_ETHERNET_CH].type     = TMWTARGIO_TYPE_TCP;
    pContext->TARGIoChannel[SCADA_ETHERNET_CH].pTmwCh   = SdnpEthScadaCh_Open(pContext->pDnpApplContext,
                                                                              &pContext->TARGIoChannel[SCADA_ETHERNET_CH],
                                                                              pContext->pTagDnp);
    pContext->TARGIoChannel[SCADA_ETHERNET_CH].pTmwSesn = SdnpScadaSesn_Open(pContext->TARGIoChannel[SCADA_ETHERNET_CH].pTmwCh,
                                                          (void*)&pContext->SdnpDataBaseHd[SCADA_DB]);

    tmwsesn_setUserDataPtr(pContext->TARGIoChannel[SCADA_ETHERNET_CH].pTmwSesn, pContext->pSdnpFileHandle);
#if 0
    /*UART SCADA (SCI-B)*/
    pContext->SdnpDataBaseHd[SCADA_DB].DatabaseType = LOCAL_DB;
    pContext->TARGIoChannel[SCADA_UART_CH].type     = TMWTARGIO_TYPE_232;

    MSG_Box[0].MSG_Handle = mailbox0;
    pContext->TARGIoChannel[SCADA_UART_CH].pMessage = &MSG_Box[0];
    pContext->TARGIoChannel[SCADA_UART_CH].pTmwCh   = SdnpSerialScadaCh_Open(pContext->pDnpApplContext,
                                                                             &pContext->TARGIoChannel[SCADA_UART_CH]);
    pContext->TARGIoChannel[SCADA_UART_CH].pTmwSesn = SdnpLocalSesn_Open(pContext->TARGIoChannel[SCADA_UART_CH].pTmwCh,
                                                                           (void*)&pContext->SdnpDataBaseHd[SCADA_DB]);

    tmwsesn_setUserDataPtr(pContext->TARGIoChannel[SCADA_UART_CH].pTmwSesn, pContext->pSdnpFileHandle);

    /*UART Local (SCI-C)*/
    pContext->SdnpDataBaseHd[LOCAL_DB].DatabaseType = LOCAL_DB;
    pContext->TARGIoChannel[LOCAL_UART_CH].type     = TMWTARGIO_TYPE_232;

    MSG_Box[1].MSG_Handle = mailbox1;
    pContext->TARGIoChannel[LOCAL_UART_CH].pMessage = &MSG_Box[1];
    pContext->TARGIoChannel[LOCAL_UART_CH].pTmwCh   = SdnpSerialLocalCh_Open(pContext->pDnpApplContext,
                                                                             &pContext->TARGIoChannel[LOCAL_UART_CH]);
    pContext->TARGIoChannel[LOCAL_UART_CH].pTmwSesn = SdnpScadaSesn_Open(pContext->TARGIoChannel[LOCAL_UART_CH].pTmwCh,
                                                                           (void*)&pContext->SdnpDataBaseHd[LOCAL_DB]);
#endif

#endif

    return &CommCtx;
}

static void DATA_Receive(SCI_CH ch, Ringbuf_t *phandle, uint16 size)
{
    uint16 Buf[16];


    uint16 ReadSize = UART_Read(ch, Buf);

    Ringbuf_Write(phandle, Buf, ReadSize);

}

void Comm_Task(UArg arg0, UArg arg1)
{
    uint16 TaskCount = 0, UartRxCount = 0;

    CommunicationContext* pContext = Comm_Init();

    SERIAL_IO_CHANNEL*  pUartLocal = pContext->TARGIoChannel[LOCAL_UART_CH].pMyCommCh;
    SERIAL_IO_CHANNEL*  pUartScada = pContext->TARGIoChannel[SCADA_UART_CH].pMyCommCh;
    TCP_IO_CHANNEL*     pEthLocal  = pContext->TARGIoChannel[LOCAL_ETHERNET_CH].pMyCommCh;
    TCP_IO_CHANNEL*     pEthScada  = pContext->TARGIoChannel[SCADA_ETHERNET_CH].pMyCommCh;

    TASK_SET_PRI(Task_Sampling, 4);

    pContext->pSdnpFileHandle->pTaskPeriod = &pContext->TaskPeriod;

    while(1)
    {
        TASK_SLEEP(pContext->TaskPeriod);

        /*Receive UART*/
#if 0
       UartRxCount = UARTRx_Check(pUartLocal->PortType);

        if(UartRxCount)
            DATA_Receive(pUartLocal->PortType, pUartLocal->pRxRingbufHd, UartRxCount);


        /*Receive UART*/
        UartRxCount = UARTRx_Check(pUartScada->PortType);

        if(UartRxCount)
            DATA_Receive(pUartScada->PortType, pUartScada->pRxRingbufHd, UartRxCount);
#endif
        if(pContext->pSdnpFileHandle->DownLoadFlag == true)
        {
            /*Local(Socket 0)*/
            TargTCP_accept(pEthLocal);
            /*SCADA(Socket 1)*/
            TargTCP_accept(pEthScada);
            tmwpltmr_checkTimer();
            tmwappl_checkForInput(pContext->pDnpApplContext);

        }
        else
        {
            if(TaskCount == 10)
            {
                /*Local(Socket 0)*/
                TargTCP_accept(pEthLocal);
                /*SCADA(Socket 1)*/
                TargTCP_accept(pEthScada);
                tmwpltmr_checkTimer();
                tmwappl_checkForInput(pContext->pDnpApplContext);

                TaskCount = 0;
            }
            else
            {
                TaskCount++;
            }
        }

        if(pContext->pSdnpFileHandle->UpdateFlag == true)
        {
            resetFunc();
        }
    }

}

void SciB_SendTask(UArg arg0, UArg arg1)
{
    Message_t *pMsg = NULL;

    while(1)
    {
        if(MAILBOX_PEND(mailbox0, &pMsg, WAIT_FOREVER))
        {
            uint16* pBuff    = pMsg->pBuff;
            uint16 Remaining = pMsg->Send_Bytes;
            uint16 Send_Bytes = 0;

            while(Remaining)
            {
                Send_Bytes = UART_Write(SCI_B, pBuff, Remaining);
                pBuff += Send_Bytes;
                Remaining -= Send_Bytes;

                if(Remaining)
                    TASK_SLEEP(5);
            }
        }
    }
}

void SciC_SendTask(UArg arg0, UArg arg1)
{
    Message_t *pMsg = NULL;

    while(1)
    {
        if(MAILBOX_PEND(mailbox1, &pMsg, WAIT_FOREVER))
        {
            uint16* pBuff    = pMsg->pBuff;
            uint16 Remaining = pMsg->Send_Bytes;
            uint16 Send_Bytes = 0;

            while(Remaining)
            {
                Send_Bytes = UART_Write(SCI_C, pBuff, Remaining);
                pBuff += Send_Bytes;
                Remaining -= Send_Bytes;

                if(Remaining)
                    TASK_SLEEP(5);
            }
        }
    }
}

