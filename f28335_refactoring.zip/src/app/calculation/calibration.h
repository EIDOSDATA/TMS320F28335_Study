/*
 * calibration.h
 *
 *  Created on: 2024. 5. 3.
 *      Author: ShinSung Industrial Electric
 */

#ifndef CALCULATION_CALIBRATION_H_
#define CALCULATION_CALIBRATION_H_

#include "def.h"
#include "src/app/calculation/calculation.h"
#include "src/app/calculation/calculation_macro.h"

typedef enum
{
  CALIBRATION_READY,

  CALIBRATION_IN_PROGRESS,

  CALIBRATION_COMPLETED,

  CALIBRATION_ERROR,

} CALIBRATION_STATUS;

typedef struct
{
    bool                        IsInit;

    uint16                      SamplingCount;

    /* If the flag value of the respective channel is 1,
     * it indicates that the channel has been selected for calibration
     * */
    bool                        CalibrationFlag[Cal_CH_MAX];

    /*If the corresponding channel flag value is 1, modify the values belonging to the ptctcorrinfo file*/
    bool                        ChGainChangeFlag[Cal_CH_MAX];

    uint16                      AdcChAPeakValue[ADC_CHA_MAX];
    uint16                      AdcChBPeakValue[ADC_CHB_MAX];

    ADC_Raw_t*                  pADC_Raw;

    float32                     TargetRMS[Cal_CH_MAX];

    float32                     ChannelAGain[ADC_CHA_MAX];
    float32                     ChannelBGain[ADC_CHB_MAX];

    float32                     ConvertedAnaglogChA[ADC_CHA_MAX];
    float32                     ConvertedAnaglogChB[ADC_CHB_MAX];

    CalibraitonQuaterDataNode*  pNode;

    ComplexQuantity_t           DftResult[Cal_CH_MAX];

    void*                       pChannelConfigsFile;
    void*                       pCalibrationFile;

    /*point to calculation component ch config*/
    void*                       pCalculationChA_Config;
    void*                       pCalculationChB_Config;

    /*logging component*/
    uint16*                     pCalibrationFileSaveFlag;

} CalibrationContext;


CALIBRATION_STATUS ExecuteCalibration(void);
void Calibration_Init(void* pADC_Raw, void* pAdcChA_Config, void* pAdcChB_Config);
















#endif /* CALCULATION_CALIBRATION_H_ */
