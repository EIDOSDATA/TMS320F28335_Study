/*
 * calibration.c
 *
 *  Created on: 2024. 5. 3.
 *      Author: ShinSung Industrial Electric
 */

#include "src/app/calculation/calibration.h"
#include "src/app/logging/logging.h"
#include "src/common/file.h"

/*If the average value of the sampled 8 values exceeds this threshold, it is selected.*/
#define CALIBRATION_THRESHOLD           1000U

#define CALIBRATION_DEFAULT_GAIN        0.01F
#define CALIBRATION_TIMEOUT             12000

/*For Calibration*/
static CalibrationContext           CalibrationCxt;
static CalibraitonOneCycleData      CalibrationOneCycleBuf;
static CalibraitonQuaterDataNode    CalDataNode[QUATER_CYCLE];

static int32 ADC_ChA_Summation[ADC_CHA_MAX];
static int32 ADC_ChB_Summation[ADC_CHB_MAX];


static void ResetCalibrationChGain(CalibrationContext* pCalibrationCtx)
{
    uint16 i;

    for(i=Cal_VA; i<Cal_CH_MAX; i++)
    {
        CalibrationCxt.ChannelAGain[i] = CALIBRATION_DEFAULT_GAIN;
        CalibrationCxt.ChannelBGain[i] = CALIBRATION_DEFAULT_GAIN;
    }
}

static bool SetTargetRMS(CalibrationContext* pCalibrationCtx)
{
    ChannelConfigs* pChannelConfig = (ChannelConfigs*)pCalibrationCtx->pChannelConfigsFile;

    if(pChannelConfig == NULL)
    {
        DEBUG_Msg("[calibration] fail to set Target rms value channelconfig pointer is null\n");
        return false;
    }

    /*set target RMS value*/

    pCalibrationCtx->TargetRMS[Cal_VA] = pChannelConfig->VaVrReference_RMS;
    pCalibrationCtx->TargetRMS[Cal_VR] = pChannelConfig->VaVrReference_RMS;

    pCalibrationCtx->TargetRMS[Cal_VB] = pChannelConfig->VbVsReference_RMS;
    pCalibrationCtx->TargetRMS[Cal_VS] = pChannelConfig->VbVsReference_RMS;

    pCalibrationCtx->TargetRMS[Cal_VC] = pChannelConfig->VcVtReference_RMS;
    pCalibrationCtx->TargetRMS[Cal_VT] = pChannelConfig->VcVtReference_RMS;

    /*current channel*/
    pCalibrationCtx->TargetRMS[Cal_IA] = pChannelConfig->IaReference_RMS;
    pCalibrationCtx->TargetRMS[Cal_IB] = pChannelConfig->IbReference_RMS;
    pCalibrationCtx->TargetRMS[Cal_IC] = pChannelConfig->IcReference_RMS;

    return true;
}




static void GetAdcPeak(CalibrationContext* pCalibrationCtx)
{
    uint16  i;
    uint32 AdcSum;
    uint16* pADCRawBuf = (uint16*)&pCalibrationCtx->pADC_Raw->ADCINA0[0];

    /*Voltage Ch(ADC Ch A)*/
    for(i=VA_CH; i<=VT_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChA_Summation[i], pADCRawBuf);

        AdcSum = fabs(ADC_ChA_Summation[i]);

        if(pCalibrationCtx->AdcChAPeakValue[i] < AdcSum)
        {
            /*Update peak value*/
            pCalibrationCtx->AdcChAPeakValue[i] = AdcSum;
        }
        pADCRawBuf += SAMPLING_SIZE;
    }

    pADCRawBuf = (uint16*)&pCalibrationCtx->pADC_Raw->ADCINB0[0];

    /*Current Ch(ADC Ch B)*/
    for(i=IA_CH; i<=IN_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChB_Summation[i], pADCRawBuf);

        AdcSum = fabs(ADC_ChB_Summation[i]);

        if(pCalibrationCtx->AdcChBPeakValue[i] < AdcSum)
        {
            /*Update peak value*/
            pCalibrationCtx->AdcChBPeakValue[i] = AdcSum;
        }

        pADCRawBuf += SAMPLING_SIZE;
    }
}

static void SelectCalibrationChannel(CalibrationContext* pCalibrationCtx)
{
    uint16 i;
    /*ADC Channel A*/
    for(i=VA_CH; i<=VT_CH; i++)
    {
        if(pCalibrationCtx->AdcChAPeakValue[i] > CALIBRATION_THRESHOLD)
        {
            /*select ch*/
            pCalibrationCtx->CalibrationFlag[i] = true;
        }
    }
    /*ADC Channel B*/
    for(i=IA_CH; i<=IN_CH; i++)
    {
        if(pCalibrationCtx->AdcChBPeakValue[i] > CALIBRATION_THRESHOLD)
        {
            /*select ch*/
            pCalibrationCtx->CalibrationFlag[i+Cal_IA] = true;
        }
    }
}

static void AdjustGain(CalibrationContext* pCalibrationCtx)
{
    uint16 Ch;

    float32 TargetRMS, CurrentRMS, Diff,  AbsolDiff, Sign = 1.0F, Gain = 0.0F;

    for(Ch = Cal_VA; Ch<= Cal_IN; Ch++)
    {
        if(pCalibrationCtx->CalibrationFlag[Ch] == false)
            continue;

        TargetRMS   = pCalibrationCtx->TargetRMS[Ch];
        CurrentRMS  = pCalibrationCtx->DftResult[Ch].Magnitude;

        Diff        = TargetRMS-CurrentRMS;
        AbsolDiff   = fabsf(Diff);

        if(Diff < 0.0F)
            Sign = -1.0F;


        if(AbsolDiff > 1)
        {
            Gain = 1.0F;
        }
        else if(AbsolDiff > 0.1F)
        {
            Gain = 0.5F;
        }
        else if(AbsolDiff > 0.01F)
        {
            Gain = 0.001F;
        }
        else
        {
            pCalibrationCtx->ChGainChangeFlag[Ch] = true;
            pCalibrationCtx->CalibrationFlag[Ch] = false;
            continue;
        }

        Gain *= Sign;

        if(Ch <= Cal_VT)
        {
            /*voltage channel*/
            pCalibrationCtx->ChannelAGain[Ch] += Gain;
        }
        else if(Ch <= Cal_IC)
        {
            /*current channel*/
            uint16 CurrentCh = Ch - Cal_IA;

            uint16 AmpCh = CurrentCh + AMP_OFFSET;
            float32 ChGain = pCalibrationCtx->ChannelBGain[CurrentCh];
            ChGain += Gain;
            pCalibrationCtx->ChannelBGain[CurrentCh]    = ChGain;
            pCalibrationCtx->ChannelBGain[AmpCh] = ChGain*AMP_DAMPING_RATIO;
        }
        else
        {
            /*Neutral current channel*/
            uint16 CurrentCh = Ch - Cal_IA;

            uint16 AmpCh = CurrentCh + AMP_OFFSET;
            float32 ChGain = pCalibrationCtx->ChannelBGain[CurrentCh];
            ChGain += Gain;
            pCalibrationCtx->ChannelBGain[CurrentCh]    = ChGain;
            pCalibrationCtx->ChannelBGain[AmpCh]        = ChGain*NEUTRAL_AMP_DAMPING_RATIO;
        }
    }
}

static void ComputeDftWithWindow(CalibrationContext* pCalibrationCtx)
{
    CALIBRATION_CH Ch;
    CalibraitonQuaterDataNode* pDataNode  = pCalibrationCtx->pNode->next;
    pCalibrationCtx->pNode                = pDataNode;
    ComplexQuantity_t       *pDftResult   = &pCalibrationCtx->DftResult[0];

    /*compute dft*/
    for(Ch = CALIBRATION_VA; Ch<=CALIBRATION_IN; Ch++)
    {
        if(pCalibrationCtx->CalibrationFlag[Ch] == false)
            continue;

        DFT_Processing(Ch, pDataNode, &pDftResult[Ch]);
    }
}

static void CalculateWindowData(CalibrationContext* pCalibrationCtx)
{
    uint16 i, Count = pCalibrationCtx->SamplingCount%4;
    uint16* pADCRawBuf = (uint16*)pCalibrationCtx->pADC_Raw;
    CalibraitonQuaterCycleData* pQuaterBuf = pCalibrationCtx->pNode->data;
    float32* pQuaterData = &pQuaterBuf->CalibrationVA_Raw[Count];

    float32* pSave = &pCalibrationCtx->ConvertedAnaglogChA[VA_CH];
    float32 Temp;

    /*Voltage Channel*/
    for(i=VA_CH; i<=VT_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChA_Summation[i], pADCRawBuf);
        Temp         = (float32)ADC_ChA_Summation[i];
        Temp        *= GAIN_RESOLUTION_FACTOR;
        Temp        *= pCalibrationCtx->ChannelAGain[i];
        pSave[i]     = Temp;
        pADCRawBuf  += SAMPLING_SIZE;
    }

    /*Store analog-converted data in a quarter-cycle buffer*/
    SAVE_ChADATA(pQuaterData, pSave);

    pSave       = &pCalibrationCtx->ConvertedAnaglogChB[IA_CH];
    pQuaterData = &pQuaterBuf->CalibrationIA_Raw[Count];
    pADCRawBuf  = &pCalibrationCtx->pADC_Raw->ADCINB0[0];

    /* Current Channel
     * The current channel is calculated using only the non-amplified channel
     */
    for(i=IA_CH; i<=IN_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChB_Summation[i], pADCRawBuf);
        Temp         = (float32)ADC_ChB_Summation[i];
        Temp        *= GAIN_RESOLUTION_FACTOR;
        Temp        *= pCalibrationCtx->ChannelBGain[i];
        pSave[i]     = Temp;
        pADCRawBuf  += SAMPLING_SIZE;
    }

    /*Store analog-converted data in a quarter-cycle buffer*/
    SAVE_ChBCAL_DATA(pQuaterData, pSave);

    if(Count == 3)
    {
        ComputeDftWithWindow(pCalibrationCtx);
    }
}
static void UpdateOriginalChGain(CalibrationContext* pCalibrationCtx)
{
    CALIBRATION_CH i;


    float32* pChannelA_Gain = &pCalibrationCtx->ChannelAGain[0];
    float32* pChannelB_Gain = &pCalibrationCtx->ChannelBGain[0];

    ADCChannelConfig_t* pChannelA_Config =  (ADCChannelConfig_t*)pCalibrationCtx->pCalculationChA_Config;
    ADCChannelConfig_t* pChannelB_Config =  (ADCChannelConfig_t*)pCalibrationCtx->pCalculationChB_Config;

    for(i= CALIBRATION_VA; i<= CALIBRATION_VT; i++)
    {
        if(pCalibrationCtx->ChGainChangeFlag[i] == false)
            continue;

        pChannelA_Config[i].TotalGain = pChannelA_Gain[i];
    }

    for(i= CALIBRATION_IA; i<= CALIBRATION_IN; i++)
    {
        if(pCalibrationCtx->ChGainChangeFlag[i] == false)
            continue;

        pChannelB_Config[i-CALIBRATION_IA].TotalGain             = pChannelB_Gain[i-CALIBRATION_IA];
        pChannelB_Config[i-CALIBRATION_IA+AMP_OFFSET].TotalGain  = pChannelB_Gain[i-CALIBRATION_IA+AMP_OFFSET];
    }
}
static void UpdateCalibrationFile(CalibrationContext* pCalibrationCtx)
{
    PtctCorrInfo* pCalibrationFile = (PtctCorrInfo*)pCalibrationCtx->pCalibrationFile;

    float32* pChannelA_Gain = &pCalibrationCtx->ChannelAGain[0];
    float32* pChannelB_Gain = &pCalibrationCtx->ChannelBGain[0];

    CALIBRATION_CH i;

    for(i= CALIBRATION_VA; i<= CALIBRATION_VT; i++)
    {
        if(pCalibrationCtx->ChGainChangeFlag[i] == false)
            continue;

        pCalibrationFile->CalibrationParameter[i].ChannelGain = pChannelA_Gain[i];
    }

    for(i= CALIBRATION_IA; i<= CALIBRATION_IN; i++)
    {
        if(pCalibrationCtx->ChGainChangeFlag[i] == false)
            continue;

        pCalibrationFile->CalibrationParameter[i].ChannelGain = pChannelB_Gain[i-CALIBRATION_IA];

        pCalibrationFile->CalibrationParameter[i+AMP_OFFSET].ChannelGain = pChannelB_Gain[i-CALIBRATION_IA+AMP_OFFSET];
    }
}

static void FinalizeCalibration(CalibrationContext* pCalibrationCtx)
{
    /*Completed calibration Update ptctcorrinfo.bin file*/
    UpdateCalibrationFile(pCalibrationCtx);
    UpdateOriginalChGain(pCalibrationCtx);

    pCalibrationCtx->SamplingCount = 0;

    /*When the flag becomes 1, save the Calibration file to external memory in the logging task.*/
    *pCalibrationCtx->pCalibrationFileSaveFlag = true;
}

CALIBRATION_STATUS ExecuteCalibration(void)
{
    CalibrationContext* pCalibrationCtx = &CalibrationCxt;

    if(pCalibrationCtx->IsInit == false)
    {
        DEBUG_Msg("Calibration context initialization is not completed\n");
        return CALIBRATION_ERROR;
    }

    if(pCalibrationCtx->SamplingCount == 0)
    {
        /*Clear prior data*/
        memset(&pCalibrationCtx->ChGainChangeFlag[0], 0, Cal_CH_MAX);
        memset(&pCalibrationCtx->CalibrationFlag[0],  0, Cal_CH_MAX);
        memset(&pCalibrationCtx->AdcChAPeakValue[0],  0, ADC_CHA_MAX);
        memset(&pCalibrationCtx->AdcChBPeakValue[0],  0, ADC_CHB_MAX);
        memset(&pCalibrationCtx->DftResult[0],        0, sizeof(ComplexQuantity_t));
        ResetCalibrationChGain(pCalibrationCtx);

        if(SetTargetRMS(pCalibrationCtx) == false)
            return CALIBRATION_ERROR;
    }

    if(pCalibrationCtx->SamplingCount <= ONE_CYCLE_COUNT)
    {
        GetAdcPeak(pCalibrationCtx);

        if(pCalibrationCtx->SamplingCount == ONE_CYCLE_COUNT)
        {
            SelectCalibrationChannel(pCalibrationCtx);
        }
    }
    else
    {
        CalculateWindowData(pCalibrationCtx);

        if(pCalibrationCtx->SamplingCount%ONE_CYCLE_COUNT == false)
        {
            ComputeDftWithWindow(pCalibrationCtx);
            AdjustGain(pCalibrationCtx);
        }
    }

    if(pCalibrationCtx->SamplingCount == CALIBRATION_TIMEOUT)
    {
        FinalizeCalibration(pCalibrationCtx);
        return CALIBRATION_COMPLETED;
    }
    else
    {
      pCalibrationCtx->SamplingCount++;
    }

    return CALIBRATION_IN_PROGRESS;
}

void Calibration_Init(void* pADC_Raw, void* pAdcChA_Config, void* pAdcChB_Config)
{
    memset(&CalibrationCxt, 0, sizeof(CalibrationContext));

    /*Calibration Part*/
    memset(&CalibrationOneCycleBuf, 0, sizeof(CalibraitonOneCycleData));

    CalDataNode[0].data = &CalibrationOneCycleBuf.QuaterData[0];
    CalDataNode[0].next = &CalDataNode[1];
    CalDataNode[1].data = &CalibrationOneCycleBuf.QuaterData[1];
    CalDataNode[1].next = &CalDataNode[2];
    CalDataNode[2].data = &CalibrationOneCycleBuf.QuaterData[2];
    CalDataNode[2].next = &CalDataNode[3];
    CalDataNode[3].data = &CalibrationOneCycleBuf.QuaterData[3];
    CalDataNode[3].next = &CalDataNode[0];

    CalibrationCxt.pNode = &CalDataNode[0];

    CalibrationCxt.pADC_Raw                       = (ADC_Raw_t*)pADC_Raw;
    CalibrationCxt.pCalculationChA_Config         = pAdcChA_Config;
    CalibrationCxt.pCalculationChB_Config         = pAdcChB_Config;

    CalibrationCxt.pChannelConfigsFile = GetChannelConfigFileAddr();
    CalibrationCxt.pCalibrationFile    = GetPtctCorrInfoFileAddr();

    ResetCalibrationChGain(&CalibrationCxt);

    CalibrationCxt.pCalibrationFileSaveFlag = GetCalibrationSaveFlagAddr();

    CalibrationCxt.IsInit = true;

}
