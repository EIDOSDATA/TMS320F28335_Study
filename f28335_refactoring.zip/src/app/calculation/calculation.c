/*
 * Calculation.c
 *
 *  Created on: 2023. 9. 21.
 *      Author: ShinSung Industrial Electric
 */
#include <math.h>

#include "def.h"
#include "src/app/calculation/calculation.h"
#include "src/app/calculation/calculation_macro.h"

/*For Calibration TEST*/
#include "src/app/shell/cli.h"

#define RADIAN                  57.29579143F
#define CALIBRATION_COUNT       100

#pragma CODE_SECTION(Phasor_Estimation, ".TI.ramfunc")

extern Semaphore_Handle SemLogic;

typedef enum
{
    PHASE_ROTATION_ABC,
    PHASE_ROTATION_CBA,

} PHASE_ROTATION;

typedef enum
{
    REFERENCE_PHASE_A,
    REFERENCE_PHASE_B,
    REFERENCE_PHASE_C,

} REFERENCE_PHASE;

typedef enum
{
    FORWARD_DIRECTION,
    REVERSE_DIRECTION,

} FLOW_DIRECTION;
                                                      /*VA              VB              VC*/
static const float32 RMS_CutOff[Cal_CH_MAX] = {VA_RMS_CUTOFF,   VB_RMS_CUTOFF,  VC_RMS_CUTOFF,
                                               /*VR              VS              VT*/
                                               VR_RMS_CUTOFF,   VS_RMS_CUTOFF,  VT_RMS_CUTOFF,
                                               /*IA              IB              IC              IN*/
                                               IA_RMS_CUTOFF,   IB_RMS_CUTOFF,  IC_RMS_CUTOFF,  IN_RMS_CUTOFF};


/*
 * Twiddle Factor for DFT
 * Rotation : ABC
 */

                                    /*Sin 0     Sin 22.5        Sin 45      Sin 67.5*/
static const float32 SinTableABC[8] = {0,         0.382683,       0.707106,   0.923879,
                                    /*Sin 90   Sin 112.5       Sin 135     Sin 157.5 */
                                       1,         0.923879,       0.707106,   0.382683};

                                    /*Cos 0     Cos 22.5        Cos 45      Cos 67.5 */
static const float32 CosTableABC[8] = {1,         0.923879,       0.707106,   0.382683,
                                    /*Cos 90    Cos 112.5       Cos 135     Cos 157.5 */
                                       0,         -0.382683,      -0.707106,  -0.923879};
/*
 * Twiddle Factor for DFT
 * Rotation : CBA
 */
                                    /*Sin 157.5     Sin 135        Sin 112.5      Sin 90*/
static const float32 SinTableCBA[8] = {0.382683,         0.707106,       0.923879,   1,
                                    /*Sin 67.5   Sin 45       Sin 22.5     Sin 0 */
                                       0.923879,         0.707106,       0.382683,   0};

                                    /*Cos 157.5     Cos 135        Cos 112.5      Cos 90 */
static const float32 CosTableCBA[8] = {-0.923879,         -0.707106,       -0.382683,   0,
                                    /*Cos 67.5    Cos 45       Cos 22.5     Cos 0 */
                                       0.382683,          0.707106,      0.923879,  1};

static void FrequencyCapture(ECAP_Register *pECAP, float32 *pFrequency);

static bool Phasor_Estimation(uint16 Ch, PHASE_ROTATION Rotation, FLOW_DIRECTION FlowDirection,/*2024.05.07 add*/
                              QuaterDataNode_t *pNode, ComplexQuantity_t *pResult)
{
    float32 CutOffValue = RMS_CutOff[Ch];
    const float32* pSin_Filter;
    const float32* pCos_Filter;

    switch(Rotation)
    {
        case PHASE_ROTATION_ABC:
            pSin_Filter = &SinTableABC[0];
            pCos_Filter = &CosTableABC[0];
            break;
        case PHASE_ROTATION_CBA:
            pSin_Filter = &SinTableCBA[0];
            pCos_Filter = &CosTableCBA[0];
            break;
        default:
            /*Error*/
            break;
    }
    QuaterDataNode_t *pPos_a = pNode;
    QuaterDataNode_t *pPos_b = pNode->next->next;

    float32 *pBufA  = pPos_a->data->VA_Raw;
             pBufA += Ch*QUATER_CYCLE;

    float32 *pBufB  = pPos_b->data->VA_Raw;
             pBufB += Ch*QUATER_CYCLE;

    float32 Real = 0, Imag = 0;

    float32 Radian = 0.0, Degree = 0.0;
    uint16 i;

    /*Half Cycle*/
    for(i=0; i< 4; i++)
    {
        Real += (((*pBufA)   -  (*pBufB))   * pCos_Filter[i]);
        Imag += (((*pBufA++) -  (*pBufB++)) * pSin_Filter[i]);
    }

    pBufA  = pPos_a->next->data->VA_Raw;
    pBufA += Ch*QUATER_CYCLE;

    pBufB  = pPos_b->next->data->VA_Raw;
    pBufB += Ch*QUATER_CYCLE;

    /*Half Cycle*/
    for(i=0; i< 4; i++)
    {
        Real += (((*pBufA)   -  (*pBufB))   * pCos_Filter[i+4]);
        Imag += (((*pBufA++) -  (*pBufB++)) * pSin_Filter[i+4]);
    }

    /*Multiplying 2/N(2/16 = 1/8) for Fundamental frequency*/
    Real *= 0.125;
    Imag *= 0.125;

    if(FlowDirection == REVERSE_DIRECTION)
    {
        Real *= 1.0F;
        Imag *= 1.0F;
    }

    pResult->Real       = Real;
    pResult->Imaginary  = Imag;

    pResult->Magnitude  = sqrtf((Real*Real) + (Imag*Imag));

    Radian = atan2f(Imag, Real);

    /*Radian �� Degree*/
    Degree = Radian * RADIAN;

    if(Degree < 0.0)
    {
        Degree += 360.0;
    }

    pResult->Phase = Degree;

    if(pResult->Magnitude < CutOffValue)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/*
 * Description : Calculate Line Voltage
 * Parameter   :
 */
static void Line_Voltage(ComplexQuantity_t *pPhase1, ComplexQuantity_t *pPhase2, PhasorValue_t *pResult)
{
    float32 Degree = 0.0;
    float32 Real = pPhase1->Real - pPhase2->Real;
    float32 Imag = pPhase1->Imaginary - pPhase2->Imaginary;

    pResult->Magnitude = sqrtf((Real*Real) + (Imag*Imag));

    Degree = atan2f(Imag, Real);
    Degree = Degree * RADIAN;

    if(Degree < 0.0)        Degree += 360.0;

    pResult->Phase = Degree;
}

/* Function    : Symmetrical_Components
 * Description :
 * Parameter   :
 */

static void Symmetrical_Components(ComplexQuantity_t* pPhase1, ComplexQuantity_t* pPhase2,
                                   ComplexQuantity_t* pPhase3, SymmetricalComponents_t* pComponents)
{
    const float32 cos120 = -0.5, cos30 = 0.866025;

    float32 RealA = pPhase1->Real,      RealB = pPhase2->Real,      RealC = pPhase3->Real;
    float32 ImagA = pPhase1->Imaginary, ImagB = pPhase2->Imaginary, ImagC = pPhase3->Imaginary;

    float32 Real = 0.0, Imag = 0.0;
    float32 Degree = 0.0;
    float32 Temp;
    /*Zero Sequence*/
    PhasorValue_t *pSelect = (PhasorValue_t*)&pComponents->Zero_Sequence;

    Real = RealA + RealB + RealC;
    Real = Real/3.0;

    Imag = ImagA + ImagB + ImagC;
    Imag = Imag/3.0;

    pSelect->Magnitude = sqrtf((Real*Real) + (Imag*Imag));

    Temp = Imag/Real;
    Degree = atanf(Temp);
    Degree = Degree * RADIAN;

    pSelect->Phase = Degree;

    /*Positive Sequence*/
    pSelect = (PhasorValue_t*)&pComponents->Positive_Sequence;

    Real = RealA + ((RealB + RealC) * cos120) + ((ImagC - ImagB) * cos30);
    Real = Real/3.0;

    Imag = ImagA + ((ImagB + ImagC) * cos120) + ((RealB - RealC) * cos30);
    Imag = Imag/3.0;

    pSelect->Magnitude = sqrtf((Real*Real) + (Imag*Imag));

    Temp = Imag/Real;
    Degree = atanf(Temp);
    Degree = Degree * RADIAN;

    pSelect->Phase = Degree;

    /*Negative Sequence*/
    pSelect = (PhasorValue_t *)&pComponents->Negative_Sequence;

    Real = RealA + ((RealB + RealC) * cos120) + ((ImagB - ImagC) * cos30);
    Real = Real/3.0;

    Imag = ImagA + ((ImagB + ImagC) * cos120) + ((RealC - RealB) * cos30);
    Imag = Imag/3.0;

    pSelect->Magnitude = sqrtf((Real*Real) + (Imag*Imag));

    Temp = Imag/Real;
    Degree = atanf(Temp);
    Degree = Degree * RADIAN;

    pSelect->Phase = Degree;
}


/*
 * Description :
 * Parameter   :
 */
static void Power_Triangle(ComplexQuantity_t* pPhaseVoltage, ComplexQuantity_t* pPhaseCurrent,
                           PowerQuantity_t* pResult)
{
    float32 Angle1 = pPhaseVoltage->Phase, Angle2 = pPhaseCurrent->Phase;
    float32 Diff_Radian = (Angle1-Angle2)*(PI/180);
    float32 Apprent     = pPhaseVoltage->Magnitude * pPhaseCurrent->Magnitude;
    float32 PF          = cos(Diff_Radian);
    float32 Active      = Apprent * PF;
    float32 Reactive    = Apprent * sin(Diff_Radian);

    /*No signal*/
    if(Apprent == 0.0F)
    {
        memset(pResult, 0, sizeof(PowerQuantity_t));
        return;
    }
    pResult->Apparent_Power = Apprent;
    pResult->Active_Power   = Active;
    pResult->Reactive_Power = Reactive;
    pResult->Power_Factor   = PF;
}

static void Power_Total(PowerQuantity_t* pParam)
{
    uint16 i;
    float32 Apparent_Sum = 0.0, Active_Sum = 0.0, Reactive_Sum = 0.0;

    for(i=PowerPhase_A; i<=PowerPhase_C; i++)
    {
        Apparent_Sum    += pParam[i].Apparent_Power;
        Active_Sum      += pParam[i].Active_Power;
        Reactive_Sum    += pParam[i].Reactive_Power;
    }

    pParam[PowerPhase_Total].Apparent_Power = Apparent_Sum;
    pParam[PowerPhase_Total].Active_Power   = Active_Sum;
    pParam[PowerPhase_Total].Reactive_Power = Reactive_Sum;
    pParam[PowerPhase_Total].Power_Factor   = Active_Sum/Apparent_Sum;
}

void DftResultCorrection(float32 Ratio,              float32 AngleOffset,       float32 ReferenceAngle,
                         ComplexQuantity_t* pSource, ComplexQuantity_t* pDestination)
{
    float32 Radian = 0.0;
    float32 RMS = pSource->Magnitude,  Angle = ReferenceAngle - pSource->Phase;
    if(Angle > 0)
    {
        while(Angle > 360.0)
        {
            Angle -= 360.0;
        }
    }
    else if(Angle < 0)
    {
        do
        {
            Angle += 360.0;
        }
        while(Angle < 0);
    }
    /*Reference Config*/
    pSource->Phase = Angle;
    Radian = Angle *(PI/180.0);
    pSource->Real      = RMS * cos(Radian);
    pSource->Imaginary = RMS * sin(Radian);

    if(AngleOffset != 0.0F)
    {
        Angle += AngleOffset;
    }

    /*Correction Value*/
    pDestination->Phase = Angle;
    RMS *= Ratio;
    pDestination->Magnitude = RMS;
    pDestination->Real      = RMS * cos(Radian);
    pDestination->Imaginary = RMS * sin(Radian);
}
static void NeutralAngleCorrection(float32 Ratio,              float32 AngleOffset,        float32 CorrectionAngle,
                                   ComplexQuantity_t* pSource, ComplexQuantity_t* pDestination)
{
    float32 Radian = 0.0;

    float32 RMS = pSource->Magnitude;

    if(CorrectionAngle > 0)
     {
         while(CorrectionAngle > 360.0)
         {
             CorrectionAngle -= 360.0;
         }
     }
     else if(CorrectionAngle < 0)
     {
         do
         {
             CorrectionAngle += 360.0;
         }
         while(CorrectionAngle < 0);
     }

     if(AngleOffset != 0.0F)
     {
         CorrectionAngle += AngleOffset;
     }

     /*Correction Value*/
     pDestination->Phase = CorrectionAngle;
     RMS                    *= Ratio;
     pDestination->Magnitude = RMS;
     pDestination->Real      = RMS * cos(Radian);
     pDestination->Imaginary = RMS * sin(Radian);
}
void Calculating_Processing(CalculationContext_t *pSamplingCtx)
{
    uint16 i;
    QuaterDataNode_t        *pDataNode       = pSamplingCtx->pNode->next;
    pSamplingCtx->pNode                      = pDataNode;
    bool                     SimMode         = *pSamplingCtx->pTagSimMode;
    CalculationResult_t     *pCalculation    = &pSamplingCtx->CalculationData;
    ComplexQuantity_t*       pDftResult      = &pCalculation->DFT_Result[0];
    ComplexQuantity_t*       pReference      = &pCalculation->CorrectionResult[0];
    SymmetricalComponents_t *pSymmetric      = &pCalculation->SymmetricalData[0];
    PowerQuantity_t         *pPower          = &pCalculation->PowerData[0];

    /*Simulation Mode*/
    if(SimMode)
    {
        float32  Radian = 0.0;
        TAG_SIM* pTAG_SIM       = &pSamplingCtx->pTagDB->SIM;
        uint16*  pSIM_DI        = &pTAG_SIM->SIM_DI[0];
        float32* pSIM_RMS       = &pTAG_SIM->SIM_RMS[0];
        float32* pSIM_ANG       = &pTAG_SIM->SIM_ANG[0];
        float32* pSIM_FREQ      = &pTAG_SIM->SIM_FREQ[0];
        float32* pSIM_GPAI      = &pTAG_SIM->SIM_GPAI[0];

        for(i=Cal_VA; i<=Cal_IN; i++)
        {
            (pReference+i)->Magnitude = *(pSIM_RMS + i);
            (pReference+i)->Phase     = *(pSIM_ANG + i);

            Radian = ((pReference+i)->Phase *(PI/180.0));

            (pReference+i)->Real       = (pReference+i)->Magnitude * cos(Radian);
            (pReference+i)->Imaginary  = (pReference+i)->Magnitude * sin(Radian);
        }

        for(i=FREQUENCY_VA; i<=FREQUENCY_VT; i++)
        {
            pCalculation->Frequency[i] = *(pSIM_FREQ + i);
        }
        /*Copy From TAG SIM DI to TAG DI*/
        memcpy(pSamplingCtx->pTagDI, pSIM_DI, TAG_DI_INDEX_MAX);
        /*Copy From TAG SIM GPAI to GPAI Data in Calculation Result*/
        memcpy(&pSamplingCtx->GPAI[0], pSIM_GPAI, sizeof(float32)*GPAI_CH_MAX);

        if(pSamplingCtx->SamplingCount == 32)
        {
            pSamplingCtx->SamplingCount = 16;
        }
    }

    /*Normal Mode*/
    else
    {
        PHASE_ROTATION  PhaseRotation = (PHASE_ROTATION)*pSamplingCtx->pPhaseRotation;
        REFERENCE_PHASE RefPhase      = (REFERENCE_PHASE)*pSamplingCtx->pRefPhase;
        bool            FlowDirection = *pSamplingCtx->pFlowDirection;
        if(pSamplingCtx->SamplingCount == 32)
        {
            FrequencyCapture(pSamplingCtx->pECAP, &pCalculation->Frequency[FREQUENCY_VA]);
            pSamplingCtx->SamplingCount = 16;
        }

        for(i=Cal_VA; i<= Cal_IN; i++)
        {
            pCalculation->CutOffFlag[i] = Phasor_Estimation(i, PhaseRotation, FlowDirection, pDataNode, &pDftResult[i]);
        }


        float32 PtRatio = *pSamplingCtx->pPtRatio;
        float32 CtRatio = *pSamplingCtx->pCtRatio;
        float32 VoltageRefAngle, CurrentRefAngle, CurrentNeutralAngle = 0.0F;
        float32 AngleOffset;
        pDftResult        = &pCalculation->DFT_Result[0];
        pReference     = &pCalculation->CorrectionResult[0];

        switch(RefPhase)
        {
            case REFERENCE_PHASE_A:
                VoltageRefAngle = pDftResult[Cal_VA].Phase;
                CurrentRefAngle = pDftResult[Cal_IA].Phase;
                break;
            case REFERENCE_PHASE_B:
                VoltageRefAngle = pDftResult[Cal_VB].Phase;
                CurrentRefAngle = pDftResult[Cal_IB].Phase;
                break;
            case REFERENCE_PHASE_C:
                VoltageRefAngle = pDftResult[Cal_VC].Phase;
                CurrentRefAngle = pDftResult[Cal_IC].Phase;
                break;
            default:
                /*Error*/
                break;
        }

        /*Voltage Channel*/
        for(i=Cal_VA; i<=Cal_VT; i++)
        {
            AngleOffset = *pCalculation->pAngleOffset[i];
            if(pCalculation->CutOffFlag[i])
            {
                /*Clear*/
                memset(&pDftResult[i], 0, sizeof(ComplexQuantity_t));
                memset(&pReference[i], 0, sizeof(ComplexQuantity_t));
            }
            else
            {
                DftResultCorrection(PtRatio, AngleOffset, VoltageRefAngle, &pDftResult[i], &pReference[i]);
            }
        }
        /*Current Channel*/
        for(i=Cal_IA; i<=Cal_IN; i++)
        {
            AngleOffset = *pCalculation->pAngleOffset[i];
            if(pCalculation->CutOffFlag[i])
            {
                /*Clear*/
                memset(&pDftResult[i], 0, sizeof(ComplexQuantity_t));
                memset(&pReference[i], 0, sizeof(ComplexQuantity_t));
            }
            else
            {
                if(i < Cal_IN)
                {
                    DftResultCorrection(CtRatio, AngleOffset, CurrentRefAngle, &pDftResult[i], &pReference[i]);
                    CurrentNeutralAngle += pReference[i].Phase;
               }
                else
                {
                    /*The phase of the neutral current is determined by summing the phases of each phase after phase correction*/
                    NeutralAngleCorrection(CtRatio, AngleOffset, CurrentNeutralAngle, &pDftResult[i], &pReference[i]);
                }
            }
        }
    }

    /*Line Voltage*/
    PhasorValue_t   *pLineVoltage = &pCalculation->LineVoltage[LineVoltage_VAB];

    Line_Voltage(pReference+Cal_VA, pReference+Cal_VB, pLineVoltage+LineVoltage_VAB);
    Line_Voltage(pReference+Cal_VB, pReference+Cal_VC, pLineVoltage+LineVoltage_VBC);
    Line_Voltage(pReference+Cal_VC, pReference+Cal_VA, pLineVoltage+LineVoltage_VCA);
    Line_Voltage(pReference+Cal_VR, pReference+Cal_VS, pLineVoltage+LineVoltage_VRS);
    Line_Voltage(pReference+Cal_VS, pReference+Cal_VT, pLineVoltage+LineVoltage_VST);
    Line_Voltage(pReference+Cal_VT, pReference+Cal_VR, pLineVoltage+LineVoltage_VTR);

    /*Symmetric*/

    Symmetrical_Components(pReference+Cal_VA, pReference+Cal_VB, pReference+Cal_VC, pSymmetric+SYMMETRICAL_SOURCE_SIDE);
    Symmetrical_Components(pReference+Cal_VR, pReference+Cal_VS, pReference+Cal_VT, pSymmetric+SYMMETRICAL_LOAD_SIDE);
    Symmetrical_Components(pReference+Cal_IA, pReference+Cal_IB, pReference+Cal_IC, pSymmetric+SYMMETRICAL_CURRENT);

    /*Power*/
    Power_Triangle(pReference+Cal_VA, pReference+Cal_IA, pPower+PowerPhase_A);
    Power_Triangle(pReference+Cal_VB, pReference+Cal_IB, pPower+PowerPhase_B);
    Power_Triangle(pReference+Cal_VC, pReference+Cal_IC, pPower+PowerPhase_C);

    Power_Total(pPower);

    SEMAPHORE_POST(SemLogic);
}

static void FrequencyCapture(ECAP_Register *pECAP, float32 *pFrequency)
{
    uint16 i;
    uint32 Data = 0;

    float32 Result = 0;

    ECAP_Register *pECAP_Register = pECAP;

    for(i=VA_CH; i<=VT_CH; i++)
    {
        if(pECAP_Register->ECFLG.bit.CEVT1)
        {
            pECAP_Register->ECCLR.bit.CEVT1 = 1;
            Data = pECAP_Register->CAP1;
            /*System Clock 150MHz */
            Result = 150E6/Data;
        }
        if(pECAP_Register->ECFLG.bit.CEVT2)
        {
            pECAP_Register->ECCLR.bit.CEVT2 = 1;
            Data = pECAP_Register->CAP2;
            /*System Clock 150MHz */
            Result = 150E6/Data;
        }
        if(pECAP_Register->ECFLG.bit.CEVT3)
        {
            pECAP_Register->ECCLR.bit.CEVT3 = 1;
            Data = pECAP_Register->CAP3;
            /*System Clock 150MHz */
            Result = 150E6/Data;
        }
        if(pECAP_Register->ECFLG.bit.CEVT4)
        {
            pECAP_Register->ECCLR.bit.CEVT4 = 1;
            Data = pECAP_Register->CAP4;
            /*System Clock 150MHz */
            Result = 150E6/Data;
        }

        if(Result > 0)
        {
            pFrequency[i] = Result;
            Result = 0;
        }
        else
        {
            pFrequency[i] = 0;
        }

        pECAP_Register++;
    }
}

void DFT_Processing(uint16 Ch, CalibraitonQuaterDataNode* pNode, ComplexQuantity_t* pResult)
{
    const float32* pSin_Filter = &SinTableABC[0];
    const float32* pCos_Filter = &CosTableABC[0];

    CalibraitonQuaterDataNode* pPos_a = pNode;
    CalibraitonQuaterDataNode* pPos_b = pNode->next->next;

    float32 *pBufA  = pPos_a->data->CalibrationVA_Raw;
             pBufA += Ch*QUATER_CYCLE;

    float32 *pBufB  = pPos_b->data->CalibrationVA_Raw;
             pBufB += Ch*QUATER_CYCLE;

    float32 Real = 0, Imag = 0;

    float32 Radian = 0.0, Degree = 0.0;
    uint16 i;

    /*Half Cycle*/
    for(i=0; i< 4; i++)
    {
        Real += (((*pBufA)   -  (*pBufB))   * pCos_Filter[i]);
        Imag += (((*pBufA++) -  (*pBufB++)) * pSin_Filter[i]);
    }

    pBufA  = pPos_a->next->data->CalibrationVA_Raw;
    pBufA += Ch*QUATER_CYCLE;

    pBufB  = pPos_b->next->data->CalibrationVA_Raw;
    pBufB += Ch*QUATER_CYCLE;

    /*Half Cycle*/
    for(i=0; i< 4; i++)
    {
        Real += (((*pBufA)   -  (*pBufB))   * pCos_Filter[i+4]);
        Imag += (((*pBufA++) -  (*pBufB++)) * pSin_Filter[i+4]);
    }

    /*Multiplying 2/N for Fundamental frequency*/
    Real *= 0.125;
    Imag *= 0.125;

    pResult->Real = Real;
    pResult->Imaginary = Imag;

    pResult->Magnitude = sqrtf((Real*Real) + (Imag*Imag));

    Radian = atan2f(Imag, Real);

    /*Radian �� Degree*/
    Degree = Radian * RADIAN;

    if(Degree < 0.0)        Degree += 360.0;

    pResult->Phase = Degree;

}


