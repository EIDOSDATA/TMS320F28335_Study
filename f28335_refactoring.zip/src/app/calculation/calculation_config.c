/*
 * CalculationConfig.c
 *
 *  Created on: 2023. 9. 18.
 *      Author: ShinSung Industrial Electric
 * Description:
 *
 */
#include <string.h>
#include "def.h"
#include "src/common/file.h"
#include "src/app/tag/tag_header.h"
#include "src/app/calculation/calculation.h"
#include "src/app/tag/tag_db.h"




#pragma DATA_SECTION (ADC_RawBuf,       "DMARAML7")
#pragma DATA_SECTION (Record_RawData,   "ZONE6DATA")
#pragma DATA_SECTION (CalibrationCxt,   "ZONE6DATA")


/*ADC Raw Data DMA Destination*/
static ADC_Raw_t  ADC_RawBuf;

/*1 Cycle Data Buffer Inner RAM*/
static OneCycleData_t OneCycleBuf;

/*Node Object*/
static QuaterDataNode_t Dnode[QUATER_CYCLE];
/*Data Buffer For Temporary Save in External SRAM*/
static ExtSRAMRawData_t Record_RawData;

static ADCChannelConfig_t           ChannelA_Config[ADC_CHA_MAX];
static ADCChannelConfig_t           ChannelB_Config[ADC_CHB_MAX];


/*
 * Function Forward declare
 */
static void ADCChannelConfig_Load(CalculationContext_t *pContext);
static void Peripheral_Init(CalculationContext_t *pContext);
static void TagDB_Mapping(CalculationContext_t *pContext);



/*TagDB */
extern TAG_DB* TagDB_Get(void);

/*  Function       : Sampling_Init
 *  Description    : Buffer Clear, Correction Factor Initialize
 */
bool Sampling_Init(CalculationContext_t *pContext)
{
    if(!pContext)
        return false;

    /*ADC Raw Data Buffer Clear*/
    pContext->pADC_Raw = &ADC_RawBuf;

    /*Calculation Data Clear*/
    memset(&pContext->CalculationData, 0, sizeof(CalculationResult_t));

    /*GPAI Data Buffer Clear*/
    memset(pContext->GPAI, 0, sizeof(float32)*GPAI_CH_MAX);

    /*1 Cycle Data Buffer Clear*/
    memset(&OneCycleBuf, 0, sizeof(OneCycleData_t));

    Dnode[0].data = &OneCycleBuf.QuaterData[0];
    Dnode[0].next = &Dnode[1];
    Dnode[1].data = &OneCycleBuf.QuaterData[1];
    Dnode[1].next = &Dnode[2];
    Dnode[2].data = &OneCycleBuf.QuaterData[2];
    Dnode[2].next = &Dnode[3];
    Dnode[3].data = &OneCycleBuf.QuaterData[3];
    Dnode[3].next = &Dnode[0];

    pContext->pNode =  &Dnode[0];

    ADCChannelConfig_Load(pContext);

    /*SRAM Data Buffer Clear*/
    memset(&Record_RawData, 0, sizeof(ExtSRAMRawData_t));
    pContext->pSRAMRawBuf = &Record_RawData;

    pContext->pTagDB   = TagDB_Get();
    pContext->pPtRatio = &pContext->pTagDB->SC.SC_F[ALS_SC_PT_RATIO];
    pContext->pCtRatio = &pContext->pTagDB->SC.SC_F[ALS_SC_CT_RATIO];

    pContext->pTagDI                = &pContext->pTagDB->DI.DI[0];
    pContext->pTagSimMode           = &pContext->pTagDB->RCM.RCM[ALS_RCM_SIM_MODE_ON];
    pContext->pTagCalibrationMode   = &pContext->pTagDB->RCM.RCM[ALS_RCM_GO_CAL];
    pContext->pDebounce             = &pContext->pTagDB->SC.SC_UI[ALS_SC_DICHAT];
    pContext->pSytemFrequency       = &pContext->pTagDB->SC.SC_UI[ALS_SC_TARGSYS_FREQ];
    pContext->pPhaseRotation        = &pContext->pTagDB->SC.SC_UI[ALS_SC_ROTATION];
    pContext->pRefPhase             = &pContext->pTagDB->SC.SC_UI[ALS_SC_REF_PHASE];
    pContext->pFlowDirection        = &pContext->pTagDB->SC.SC_UI[ALS_SC_FLOWDIR];

    /*Point to AI Data in TAG AI Pointer Array*/
    TagDB_Mapping(pContext);

    Peripheral_Init(pContext);

    pContext->SamplingCount = 0;

    /*Interface*/
    pContext->pfSampling_Start = InitEPwm;
    pContext->pfSampling_Stop  = StopEPwm;

    return true;
}

/*  Function       : ADCChannelConfig_Load
 *  Description    : Load ADC Channel Configuration Data
 */
static void ADCChannelConfig_Load(CalculationContext_t *pContext)
{
    uint16 i;
    PtctCorrInfo*         pPtctCorrInfoFile = (PtctCorrInfo*)GetPtctCorrInfoFileAddr();

    pContext->pCalibrationFile  = (void*)pPtctCorrInfoFile;
    pContext->pGpaiCorrInfofile = GetGpaiCorrInfoFileAddr();

    memset(&ChannelA_Config[VA_CH], 0, sizeof(ADCChannelConfig_t)*ADC_CHA_MAX);
    memset(&ChannelB_Config[IA_CH], 0, sizeof(ADCChannelConfig_t)*ADC_CHB_MAX);

    for(i=VA_CH; i<ADC_CHA_MAX; i++)
    {
        //ChannelA_Config[i].TotalGain = DAC_GAIN;
        ChannelA_Config[i].TotalGain = pPtctCorrInfoFile->CalibrationParameter[i].ChannelGain;
        ChannelA_Config[i].GainUnit  = ChannelA_Config[i].TotalGain/DAC_GAIN;
    }
    for(i=IA_CH; i<ADC_CHB_MAX; i++)
    {
        //ChannelB_Config[i].TotalGain = DAC_GAIN;
        ChannelB_Config[i].TotalGain = pPtctCorrInfoFile->CalibrationParameter[i+CALIBRATION_IA].ChannelGain;
        ChannelB_Config[i].GainUnit  = ChannelB_Config[i].TotalGain/DAC_GAIN;
    }

    pContext->pChannelA_Config = &ChannelA_Config[VA_CH];
    pContext->pChannelB_Config = &ChannelB_Config[IA_CH];


    /*Angle Offset*/
    for(i=CALIBRATION_VA; i<=CALIBRATION_IN; i++)
    {
        pContext->CalculationData.pAngleOffset[i] = &pPtctCorrInfoFile->CalibrationParameter[i].AngleOffset;
    }


}

static void Peripheral_Init(CalculationContext_t *pContext)
{
    InitAdc();

    DMAInitialize();

    /*DMA 1CH For moving ADC Raw Data From ADC Result Register to Inner RAM*/
    volatile uint16 *DMA1CH_Destination = (volatile uint16*)&ADC_RawBuf;

    DMACH1AddrConfig(DMA1CH_Destination, &AdcMirror.ADCRESULT0);

    DMACH1BurstConfig(15, 1, SAMPLING_SIZE);
    DMACH1TransferConfig(7, -15, -119);
    DMACH1ModeConfig(DMA_SEQ1INT,PERINT_ENABLE,ONESHOT_DISABLE,CONT_ENABLE,
                     SYNC_DISABLE, SYNC_SRC, OVRFLOW_DISABLE,SIXTEEN_BIT,
                     CHINT_END, CHINT_ENABLE);

    /*DMA 2CH For moving ADC Raw Data From Inner RAM to External RAM*/
#if 0  /*Need to Implement*/
    volatile uint16 *DMA2CH_Source = (volatile uint16 *)&Erase;
    volatile uint16 *DMA2CH_Destination = (volatile uint16 *)&ADC_AverageData;

    DMACH2AddrConfig(DMA2CH_Destination, DMA2CH_Source);
#endif
    StartDMACH1();

    /*ECAP Init*/
    InitECap((void*)&pContext->pECAP);
}
static void TagDB_Mapping(CalculationContext_t *pContext)
{
    uint16 i;
    CalculationResult_t     *pCalResult             = &pContext->CalculationData;
    SymmetricalComponents_t *pSymmetricalComponent  = &pCalResult->SymmetricalData[SYMMETRICAL_SOURCE_SIDE];
    TAG_DB *pTagDbHd = (TAG_DB*)pContext->pTagDB;

    float32 **pTAG_AI = &pTagDbHd->AI.AI[0];

    /*Point to RMS MAX Data (VA VB VC IA IB IC IN) */
    for(i=0; i< 7; i++)
    {
        *(pTAG_AI+i) = &pCalResult->RMS_MAX[i];
    }

    /*Point to RMS & Angle Data (Source VA VB VC IA IB IC IN) */
    for(i=0; i<Cal_CH_MAX; i++)
    {
        *(pTAG_AI+(i+7)) =  &pCalResult->CorrectionResult[i].Magnitude;
        *(pTAG_AI+(i+17)) = &pCalResult->CorrectionResult[i].Phase;
    }

    /*Point to Frequency Data (Source VA VB VC VR VS VT) */
    for(i=FREQUENCY_VA; i<=FREQUENCY_VT; i++)
    {
        *(pTAG_AI+(i+27)) = &pCalResult->Frequency[i];
    }

    /*Point to Line Voltage RMS & Angle Data (Source VAB VBC VCA) */
    *(pTAG_AI+ALS_AI_RMS_VAB) = &pContext->CalculationData.LineVoltage[LineVoltage_VAB].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VAB) = &pContext->CalculationData.LineVoltage[LineVoltage_VAB].Phase;
    *(pTAG_AI+ALS_AI_RMS_VBC) = &pContext->CalculationData.LineVoltage[LineVoltage_VBC].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VBC) = &pContext->CalculationData.LineVoltage[LineVoltage_VBC].Phase;
    *(pTAG_AI+ALS_AI_RMS_VCA) = &pContext->CalculationData.LineVoltage[LineVoltage_VCA].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VCA) = &pContext->CalculationData.LineVoltage[LineVoltage_VCA].Phase;
    *(pTAG_AI+ALS_AI_RMS_VRS) = &pContext->CalculationData.LineVoltage[LineVoltage_VRS].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VRS) = &pContext->CalculationData.LineVoltage[LineVoltage_VRS].Phase;
    *(pTAG_AI+ALS_AI_RMS_VST) = &pContext->CalculationData.LineVoltage[LineVoltage_VST].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VST) = &pContext->CalculationData.LineVoltage[LineVoltage_VST].Phase;
    *(pTAG_AI+ALS_AI_RMS_VTR) = &pContext->CalculationData.LineVoltage[LineVoltage_VTR].Magnitude;
    *(pTAG_AI+ALS_AI_ANG_VTR) = &pContext->CalculationData.LineVoltage[LineVoltage_VTR].Phase;


    /*Point to Symmetrical RMS & Angle Data*/
    /*Source Side*/
    *(pTAG_AI+51) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Zero_Sequence.Magnitude;            /*RMS V0*/
    *(pTAG_AI+52) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Positive_Sequence.Magnitude;        /*RMS V1*/
    *(pTAG_AI+53) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Negative_Sequence.Magnitude;        /*RMS V2*/

    *(pTAG_AI+57) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Zero_Sequence.Phase;                /*ANG V0*/
    *(pTAG_AI+58) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Positive_Sequence.Phase;            /*ANG V1*/
    *(pTAG_AI+59) = &pSymmetricalComponent[SYMMETRICAL_SOURCE_SIDE].Negative_Sequence.Phase;            /*ANG V2*/

    /*Load Side*/
    *(pTAG_AI+54) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Zero_Sequence.Magnitude;              /*RMS VR0*/
    *(pTAG_AI+55) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Positive_Sequence.Magnitude;          /*RMS VR1*/
    *(pTAG_AI+56) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Negative_Sequence.Magnitude;          /*RMS VR2*/

    *(pTAG_AI+60) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Zero_Sequence.Phase;                  /*ANG V0*/
    *(pTAG_AI+61) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Positive_Sequence.Phase;              /*ANG V1*/
    *(pTAG_AI+62) = &pSymmetricalComponent[SYMMETRICAL_LOAD_SIDE].Negative_Sequence.Phase;              /*ANG V2*/

    /*Current*/
    *(pTAG_AI+63) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Zero_Sequence.Magnitude;                /*RMS I0*/
    *(pTAG_AI+64) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Positive_Sequence.Magnitude;            /*RMS I1*/
    *(pTAG_AI+65) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Negative_Sequence.Magnitude;            /*RMS I2*/

    *(pTAG_AI+66) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Zero_Sequence.Phase;                    /*ANG I0*/
    *(pTAG_AI+67) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Positive_Sequence.Phase;                /*ANG I1*/
    *(pTAG_AI+68) = &pSymmetricalComponent[SYMMETRICAL_CURRENT].Negative_Sequence.Phase;                /*ANG I2*/

    /*Point to Power Data*/
    for(i=0; i<PowerPhase_MAX; i++)
    {
        *(pTAG_AI+(i+69)) = &pContext->CalculationData.PowerData[i].Apparent_Power;
        *(pTAG_AI+(i+73)) = &pContext->CalculationData.PowerData[i].Active_Power;
        *(pTAG_AI+(i+77)) = &pContext->CalculationData.PowerData[i].Reactive_Power;
        *(pTAG_AI+(i+81)) = &pContext->CalculationData.PowerData[i].Power_Factor;
    }

    /*Point to GPAI Data*/
    *(pTAG_AI+(ALS_AI_12VAN))   = &pContext->GPAI[GPAI1_12VAN];
    *(pTAG_AI+(ALS_AI_AIMODFB)) = &pContext->GPAI[GPAI2_AIMODFB];
    *(pTAG_AI+(ALS_AI_12VAP))   = &pContext->GPAI[GPAI3_12VAP];
    *(pTAG_AI+(ALS_AI_AICPFB))  = &pContext->GPAI[GPAI4_AICPFB];
    *(pTAG_AI+(ALS_AI_REF_DP))  = &pContext->GPAI[GPAI5_REF_DP];
    *(pTAG_AI+(ALS_AI_AIOPFB))  = &pContext->GPAI[GPAI6_AIOPFB];
    *(pTAG_AI+(ALS_AI_CTEMP))   = &pContext->GPAI[GPAI7_CTEMP];
    *(pTAG_AI+(ALS_AI_AIBATV))  = &pContext->GPAI[GPAI8_BATV];
    *(pTAG_AI+(ALS_AI_AICHV))   = &pContext->GPAI[GPAI10_AICHV];
    *(pTAG_AI+(ALS_AI_AIOPV))   = &pContext->GPAI[GPAI12_AIOPV];

}

