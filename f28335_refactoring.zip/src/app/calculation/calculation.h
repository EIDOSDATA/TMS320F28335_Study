/*
 * Calcualation.h
 *
 *  Created on: 2023. 9. 9.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENT_SAMPLING_INTERFACE_CALCULATION_H_
#define COMPONENT_SAMPLING_INTERFACE_CALCULATION_H_

#include "def.h"
#include "src/app/tag/tag_db.h"

#define ADC_CH_MAX              16

#define DI_MAX                  12

#define SAMPLING_SIZE           8
#define ONE_CYCLE_COUNT                16

#define AMP_OFFSET              4

#define RAW_COUNT               8

#define QUATER_CYCLE            4
#define RECORD_CYCLE            80              /* 16 x 5 = 80 */

#define SOURCE_VOLTAGE_NUMBER           3       /*VA, VB, VC*/
#define CURRENT_NUMBER                  4       /*A, B, C, N*/

#define PI          3.141592


/*
 * Enumeration
 */



enum
{
    Cal_VA,     Cal_VB,     Cal_VC,
    Cal_VR,     Cal_VS,     Cal_VT,
    Cal_IA,     Cal_IB,     Cal_IC,
    Cal_IN,

    Cal_CH_MAX = 10
};

enum
{
    FREQUENCY_VA,       FREQUENCY_VB,       FREQUENCY_VC,
    FREQUENCY_VR,       FREQUENCY_VS,       FREQUENCY_VT,
    FREQUENCY_CH_MAX = 6
};
enum
{
    LineVoltage_VAB,        LineVoltage_VBC,        LineVoltage_VCA,
    LineVoltage_VRS,        LineVoltage_VST,        LineVoltage_VTR,

    LineVoltage_MAX = 6
};
enum
{
    SYMMETRICAL_SOURCE_SIDE,
    SYMMETRICAL_LOAD_SIDE,
    SYMMETRICAL_CURRENT,

    SYMMETRICAL_MAX = 3
};
enum
{
    PowerPhase_A,           PowerPhase_B,
    PowerPhase_C,           PowerPhase_Total,
    PowerPhase_MAX = 4
};

typedef enum
{
    CALCULATION_NO_COMMAND,

    CALCULATION_CALIBRATION,
    CALCULATION_GAIN_UPDATE,

} CALICULATION_COMMAND;
/*
 * Type
 */

typedef struct ECAP_REGS    ECAP_Register;


/*
 * Sampling Part
 */

/* DMA 1CH Destination Memory*/
typedef struct
{
    uint16 ADCINA0[SAMPLING_SIZE];  /*VA*/
    uint16 ADCINA1[SAMPLING_SIZE];  /*VB*/
    uint16 ADCINA2[SAMPLING_SIZE];  /*VC*/
    uint16 ADCINA3[SAMPLING_SIZE];  /*VR*/
    uint16 ADCINA4[SAMPLING_SIZE];  /*VS*/
    uint16 ADCINA5[SAMPLING_SIZE];  /*VT*/
    uint16 ADCINA6[SAMPLING_SIZE];  /*MUX2*/
    uint16 ADCINA7[SAMPLING_SIZE];  /*MUX1*/

    uint16 ADCINB0[SAMPLING_SIZE];  /*IA*/
    uint16 ADCINB1[SAMPLING_SIZE];  /*IB*/
    uint16 ADCINB2[SAMPLING_SIZE];  /*IC*/
    uint16 ADCINB3[SAMPLING_SIZE];  /*IN*/
    uint16 ADCINB4[SAMPLING_SIZE];  /*IAM*/
    uint16 ADCINB5[SAMPLING_SIZE];  /*IBM*/
    uint16 ADCINB6[SAMPLING_SIZE];  /*ICM*/
    uint16 ADCINB7[SAMPLING_SIZE];  /*INM*/

} ADC_Raw_t;

typedef struct
{
    /*Factor value multiplied for DAC*/
    float32 Slope;
    /*Offset value due to circuit configuration*/
    float32 Offset;
    /*either PT or CT*/
    float32 Ratio;

} ADC_CHConfig_t;

typedef struct
{
    float32 VA_Raw[QUATER_CYCLE];
    float32 VB_Raw[QUATER_CYCLE];
    float32 VC_Raw[QUATER_CYCLE];

    float32 VR_Raw[QUATER_CYCLE];
    float32 VS_Raw[QUATER_CYCLE];
    float32 VT_Raw[QUATER_CYCLE];

    float32 IA_Raw[QUATER_CYCLE];
    float32 IB_Raw[QUATER_CYCLE];
    float32 IC_Raw[QUATER_CYCLE];
    float32 IN_Raw[QUATER_CYCLE];

} QuaterCycleData_t;

typedef struct
{
    QuaterCycleData_t QuaterData[QUATER_CYCLE];

} OneCycleData_t;

typedef struct __node
{
    struct __node       *next;
    QuaterCycleData_t   *data;

} QuaterDataNode_t;


/* For temporary storage External SRAM*/
typedef struct
{
    float32 VA_Buf[RECORD_CYCLE];
    float32 VB_Buf[RECORD_CYCLE];
    float32 VC_Buf[RECORD_CYCLE];

    float32 VR_Buf[RECORD_CYCLE];
    float32 VS_Buf[RECORD_CYCLE];
    float32 VT_Buf[RECORD_CYCLE];

    float32 IA_Buf[RECORD_CYCLE];
    float32 IB_Buf[RECORD_CYCLE];
    float32 IC_Buf[RECORD_CYCLE];
    float32 IN_Buf[RECORD_CYCLE];

} ExtSRAMRawData_t;

typedef struct
{
    float32 Real;
    float32 Imaginary;

    /*RMS*/
    float32 Magnitude;
    /* Angle Unit Degree*/
    float32 Phase;

} ComplexQuantity_t;

typedef struct
{
    float32 Real;
    float32 Imaginary;

    /*RMS*/
    float32 Magnitude;
    /* Angle Unit Degree*/
    float32 Phase;

} DftCorrection;


typedef struct
{
    bool    Flag;

    float32* pTargetRMS;
    float32* pTargetAangle;

} ADC_ChCalibration;

typedef struct
{
    float32 Magnitude;
    float32 Phase;

} PhasorValue_t;

typedef struct
{
    PhasorValue_t Zero_Sequence;
    PhasorValue_t Positive_Sequence;
    PhasorValue_t Negative_Sequence;

} SymmetricalComponents_t;

typedef struct
{
    float32 Apparent_Power;
    float32 Active_Power;
    float32 Reactive_Power;

    float32 Power_Factor;
//    uint16  Quadrant;

} PowerQuantity_t;

typedef struct
{
    bool                        CutOffFlag[Cal_CH_MAX];

    float32*                    pAngleOffset[Cal_CH_MAX];
    /*VA, VB, VC, VR, VS, VT, IA, IB, IC, IN*/
    ComplexQuantity_t           DFT_Result[Cal_CH_MAX];

    /*VA, VB, VC, VR, VS, VT, IA, IB, IC, IN*/
    ComplexQuantity_t           CorrectionResult[Cal_CH_MAX];

    /*VA, VB, VC, IA, IB, IC, IN*/
    float32                     RMS_MAX[7];

    /*VAB, VBC, VCA, VRS, VST, VTR*/
    PhasorValue_t               LineVoltage[LineVoltage_MAX];

    /*Source Side Voltage, Load Side Voltage, Current*/
    SymmetricalComponents_t     SymmetricalData[SYMMETRICAL_MAX];

    /*Phase A, Phase B, Phase C, Total*/
    PowerQuantity_t             PowerData[PowerPhase_MAX];

    float32                     Frequency[FREQUENCY_CH_MAX];

    float32                     Energy_Data;

    float32                     Demand_Data;


} CalculationResult_t;

/*Calibration*/
typedef struct
{
    float32 CalibrationVA_Raw[QUATER_CYCLE];
    float32 CalibrationVB_Raw[QUATER_CYCLE];
    float32 CalibrationVC_Raw[QUATER_CYCLE];

    float32 CalibrationVR_Raw[QUATER_CYCLE];
    float32 CalibrationVS_Raw[QUATER_CYCLE];
    float32 CalibrationVT_Raw[QUATER_CYCLE];

    float32 CalibrationIA_Raw[QUATER_CYCLE];
    float32 CalibrationIB_Raw[QUATER_CYCLE];
    float32 CalibrationIC_Raw[QUATER_CYCLE];
    float32 CalibrationIN_Raw[QUATER_CYCLE];

    float32 CalibrationIAM_Raw[QUATER_CYCLE];
    float32 CalibrationIBM_Raw[QUATER_CYCLE];
    float32 CalibrationICM_Raw[QUATER_CYCLE];
    float32 CalibrationINM_Raw[QUATER_CYCLE];


} CalibraitonQuaterCycleData;

typedef struct
{
    CalibraitonQuaterCycleData QuaterData[QUATER_CYCLE];

} CalibraitonOneCycleData;

typedef struct _CalibrationNode
{
    struct _CalibrationNode*        next;
    CalibraitonQuaterCycleData*     data;

} CalibraitonQuaterDataNode;


typedef struct
{
    uint16                  SamplingCount;
    uint16                  MuxSetCount;

    bool                    QuaterCylceFlag;

    uint16                  CurrentSelectFlag[4];

    /*
     * ECAP  Register   Address Range
     * ECAP1 Register : 0x00 6A00 - 0x00 6A1F
     * ECAP2 Register : 0x00 6A20 - 0x00 6A3F
     * ECAP3 Register : 0x00 6A40 - 0x00 6A5F
     * ECAP4 Register : 0x00 6A60 - 0x00 6A7F
     * ECAP5 Register : 0x00 6A80 - 0x00 6A9F
     * ECAP6 Register : 0x00 6AA0 - 0x00 6ABF
     */
    ECAP_Register           *pECAP;

    ADC_Raw_t               *pADC_Raw;

    QuaterDataNode_t        *pNode;

    ExtSRAMRawData_t        *pSRAMRawBuf;

    /*Calibrated data after 8 samples*/
    float32                 ADC_ChACorration[ADC_CHA_MAX];
    float32                 ADC_ChBCorration[ADC_CHB_MAX];

    /*ADC Channel Config*/
    ADCChannelConfig_t*     pChannelA_Config;
    ADCChannelConfig_t*     pChannelB_Config;

    CalculationResult_t     CalculationData;

    float32*                pPtRatio;
    float32*                pCtRatio;

    /*TAG DB*/
    TAG_DB*                 pTagDB;

    /*TAG DI*/
    uint16*                 pTagDI;

    /*TAG RCM*/
    uint16*                 pTagSimMode;
    uint16*                 pTagCalibrationMode;
    /*TAG SC*/
    uint16*                 pSytemFrequency;
    uint16*                 pPhaseRotation;
    uint16*                 pRefPhase;
    uint16*                 pFlowDirection;
    uint16*                 pDebounce;

    /*Ch gain update flag*/
    bool                    ChGainUpdateFlag;
    void*                   pCalibrationFile;

    /*GPAI Data*/
    float32                 GPAI[GPAI_CH_MAX];
    void*                   pGpaiCorrInfofile;



    /*DI*/
    uint16                  DiDebounceCount[DI_MAX];

    void (*pfSampling_Start)(uint16 Freq);
    void (*pfSampling_Stop) (void);


} CalculationContext_t;


/*
 *
 */
CalculationContext_t* CalculationContext_Get(void);

bool Sampling_Init(CalculationContext_t *phandle);


void Calculating_Processing(CalculationContext_t *pContext);

void DFT_Processing(uint16 Ch, CalibraitonQuaterDataNode* pNode, ComplexQuantity_t* pResult);

void Calculation_Task(UArg arg0, UArg arg1);
void DMA1CH_Hwi(UArg arg0, UArg arg1);
void Sampling_Stop(void);

void DftResultCorrection(float32 Ratio,              float32 AngleOffset,       float32 ReferenceAngle,
                         ComplexQuantity_t* pSource, ComplexQuantity_t* pDestination);

#endif /* COMPONENT_SAMPLING_INTERFACE_SAMPLING_H_ */
