/*
 * Sampling.c
 *
 *  Created on: 2023. 9. 5.
 *      Author: ShinSung Industrial Electric
 *
 */
#include <stdlib.h>
#include <math.h>

#include "def.h"

#include "src/app/calculation/calculation.h"
#include "src/app/calculation/calculation_macro.h"
#include "src/app/calculation/calibration.h"
#include "src/app/shell/cli.h"



#pragma CODE_SECTION(Sampling_Processing, ".TI.ramfunc")
/*
 * OS instance
 * see app.cfg
 */
extern Task_Handle   Task_Sampling, Task_Mmi, Task_Metering, Task_Communication;

CalculationContext_t SamplingCtx;

/*Calibration CLI TEST*/
uint16*                  pCalibrationMode;

extern Semaphore_Handle SemSampling;

volatile uint16 *pDMA_Destination;
volatile uint16 *pDMA_Source = &AdcMirror.ADCRESULT0;
static void Sampling_Processing(CalculationContext_t *pContext);
static void MUX_Set(uint16 select);

static int32 ADC_ChA_Summation[ADC_CHA_MAX];
static int32 ADC_ChB_Summation[ADC_CHB_MAX];

static float32 GpaiData[GPAI_CH_MAX];
#if 0
static const float32 GpaiGain[GPAI_CH_MAX] = {
  /*GPAI0_RESERVED,         GPAI1_12VAN,          GPAI2_AIMODFB,             GPAI3_12VAP*/
    0,                      -0.0073259999F,       0.0146520147F,             0.00532F,
  /*GPAI4_AICPFB,           GPAI5_REF_D,          GPAI6_AIOPFB,              GPAI7_CTEMP*/
    0.0146520147F,          0.719110012F,         0.0146520147F,             0.0732600763F,
  /*GPAI8_BATV,             GPAI9_RESERVED,       GPAI10_AICHV,              GPAI11_RESERVED*/
    0.0146520147F,          0.0F,                 0.0146520147F,                 0.0F,
  /*GPAI12_AIOPV,           GPAI13_RESERVED,      GPAI14_RESERVED,           GPAI15_RESERVED*/
    0.0146520147F,          0.0F,                 0.0F,                      0.0F,
};
#endif
/*
 * Description : Main Thread of Calculation Component
 *
 */
static void DI_debouncing(CalculationContext_t *pContext);


/*
 * DMA 1CH Interrupt
 *
 * Description :
 *      (1) Reconfig DMA 1ch destination address after 8 Sampling Complete
 *      (2) Event post to Task Thread
 */

void DMA1CH_Hwi(UArg arg0, UArg arg1)
{
    DMACH1Int_Clear();
    DMACH1AddrConfig(pDMA_Destination, pDMA_Source);
    SEMAPHORE_POST(SemSampling);
}
static float32 CurrentChannel_Select(CalculationContext_t *pContext, uint16 ch)
{
    uint16  Select_Ch = ch;
    uint16  Amp_Ch;
    float32 Rtn;
    uint16  FlagCompare = PHASE_LINE_FLAG;
    ADCChannelConfig_t *pADCConfig = pContext->pChannelB_Config;

    float32 NormalReference = I_REFERENCE;
    float32 AmpReference    = I_AMP_REFERENCE;

    if(ch == IN_CH)
    {
        FlagCompare         = NEUTRAL_LINE_FLAG;
        NormalReference     = IN_REFERENCE;
        AmpReference        = IN_AMP_REFERENCE;
    }

    if(pContext->CurrentSelectFlag[ch] <= FlagCompare)
    {
        /*Unstable state*/
        if(abs(ADC_ChB_Summation[ch]) < NormalReference)
        {
            pContext->CurrentSelectFlag[ch]++;
        }
        else
        {
            pContext->CurrentSelectFlag[ch] = 0;
        }
    }
    else
    {
        /*Stable state*/
        Amp_Ch = ch + AMP_OFFSET;
        if(abs(ADC_ChB_Summation[Amp_Ch]) > AmpReference)
        {
            pContext->CurrentSelectFlag[ch] = 0;
        }
        else
        {
            Select_Ch = Amp_Ch;
        }
    }

    Rtn = (float32)ADC_ChB_Summation[Select_Ch];

    Rtn *= GAIN_RESOLUTION_FACTOR;              /*For RMS gain resolution*/
    Rtn *= pADCConfig[Select_Ch].TotalGain;

    return Rtn;
}

static void Sampling_Processing(CalculationContext_t* pContext)
{
    uint16 i;
    bool   SimMode       = *pContext->pTagSimMode;
    uint16 count         = pContext->SamplingCount%4;
    uint16 GpaiIndex     = pContext->MuxSetCount*2;

    QuaterCycleData_t *pQuaterBuf = pContext->pNode->data;
    float32* pQuaterData = (float32*)pQuaterBuf;
    pQuaterData += count;

    float32 Temp;
    float32* pSave;

    /*ADC Channel A*/
    uint16* pADCRawBuf = (uint16*)&pContext->pADC_Raw->ADCINA0[0];
    ADCChannelConfig_t *pADCConfig = pContext->pChannelA_Config;

    /*Voltage Part*/
    for(i = VA_CH; i<= VT_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChA_Summation[i], pADCRawBuf);
        Temp  = (float32)ADC_ChA_Summation[i];
        Temp *= GAIN_RESOLUTION_FACTOR;                     /*For RMS gain resolution*/
        Temp *= pADCConfig[i].TotalGain;                    /*Multiply voltage channel gain*/
        pContext->ADC_ChACorration[i] = Temp;
        pADCRawBuf += SAMPLING_SIZE;
    }

      pSave = &pContext->ADC_ChACorration[VA_CH];

      SAVE_ChADATA(pQuaterData, pSave);                     /*save voltage adc data to quater cycle buffer*/

    if(SimMode == false)
    {
        GpaiParam* pGpaiChGain = (GpaiParam*)pContext->pGpaiCorrInfofile;
        /*GPAI Part*/
        pADCRawBuf = (uint16*)&pContext->pADC_Raw->ADCINA7[0];
        for(i= MUX1_CH; i >= MUX2_CH; i--)
        {
            GET_GPAI_CH_SUM(ADC_ChA_Summation[i], pADCRawBuf);
            Temp  = (float32)ADC_ChA_Summation[i];
            pContext->ADC_ChACorration[i] = Temp;
            pADCRawBuf -= SAMPLING_SIZE;
        }

        /*GPAI Part*/
        GpaiData[GpaiIndex]       = pContext->ADC_ChACorration[MUX1_CH];
        pContext->GPAI[GpaiIndex] = GpaiData[GpaiIndex] * pGpaiChGain[GpaiIndex].GpaiCh_Gain;

        GpaiIndex++;

        GpaiData[GpaiIndex]       = pContext->ADC_ChACorration[MUX2_CH];
        pContext->GPAI[GpaiIndex] = GpaiData[GpaiIndex] * pGpaiChGain[GpaiIndex].GpaiCh_Gain;

        if(GpaiIndex == GPAI7_CTEMP)
        {
            /*In the case of GPAI_CTEMP, an offset is -50. This was written in a previous project*/

            pContext->GPAI[GpaiIndex] += pGpaiChGain[GpaiIndex].GpaiCh_Offset;
        }
    }

    /*ADC Channel B*/
    pADCRawBuf = (uint16 *)&pContext->pADC_Raw->ADCINB0[0];

    /*Current Part*/
    for(i = IA_CH; i<= INM_CH; i++)
    {
        GET_VI_CH_SUM(ADC_ChB_Summation[i], pADCRawBuf);
        pADCRawBuf += SAMPLING_SIZE;
    }

    pQuaterData = &pQuaterBuf->IA_Raw[count];
    pSave = &pContext->ADC_ChBCorration[IA_CH];

    /*Select Current*/
    for(i = IA_CH; i<= IN_CH; i++)
    {
        pContext->ADC_ChBCorration[i] = CurrentChannel_Select(pContext, i);
    }

    SAVE_ChBDATA(pQuaterData, pSave);

    if(count ==3)
        pContext->QuaterCylceFlag = 1;

    pContext->SamplingCount++;
    pContext->MuxSetCount++;

    if(pContext->MuxSetCount>7)
        pContext->MuxSetCount = 0;
}

static void MUX_Set(uint16 select)
{
    switch(select)
    {
    case 0:     /*A2 : 0 A1 : 0 A0 : 0*/
        GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;   //MUX A2
        GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;   //MUX A1
        GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;   //MUX A0
        break;
    case 1:     /*A2 : 0 A1 : 0 A0 : 1*/
        GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;   //MUX A2
        GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;   //MUX A1
        GpioDataRegs.GPASET.bit.GPIO20 = 1;     //MUX A0
        break;
    case 2:     /*A2 : 0 A1 : 1 A0 : 0*/
        GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;   //MUX A2
        GpioDataRegs.GPASET.bit.GPIO19 = 1;     //MUX A1
        GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;   //MUX A0
        break;
    case 3:     /*A2 : 0 A1 : 1 A0 : 1*/
        GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;   //MUX A2
        GpioDataRegs.GPASET.bit.GPIO19 = 1;     //MUX A1
        GpioDataRegs.GPASET.bit.GPIO20 = 1;     //MUX A0
        break;
    case 4:     /*A2 : 1 A1 : 0 A0 : 0*/
        GpioDataRegs.GPASET.bit.GPIO18 = 1;     //MUX A2
        GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;   //MUX A1
        GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;   //MUX A0
        break;
    case 5:     /*A2 : 1 A1 : 0 A0 : 1*/
        GpioDataRegs.GPASET.bit.GPIO18 = 1;     //MUX A2
        GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;   //MUX A1
        GpioDataRegs.GPASET.bit.GPIO20 = 1;     //MUX A0
        break;
    case 6:     /*A2 : 1 A1 : 1 A0 : 0*/
        GpioDataRegs.GPASET.bit.GPIO18  = 1;     //MUX A2
        GpioDataRegs.GPASET.bit.GPIO19  = 1;     //MUX A1
        GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;   //MUX A0
        break;
    case 7:     /*A2 : 1 A1 : 1 A0 : 1*/
        GpioDataRegs.GPASET.bit.GPIO18 = 1;     //MUX A2
        GpioDataRegs.GPASET.bit.GPIO19 = 1;     //MUX A1
        GpioDataRegs.GPASET.bit.GPIO20 = 1;     //MUX A0
        break;
    }
}

static void DI_debouncing(CalculationContext_t *pContext)
{
    uint16 i;
    uint16 DebountCount = *pContext->pDebounce;

    /*Read DI Block*/
    uint16 DI_Raw = ~READ_DI_BLOCK;

    for(i=0;i<DI_MAX;i++)
    {
        if(DI_Raw&0x01 == true)
        {
            if(pContext->DiDebounceCount[i] < DebountCount)
                pContext->DiDebounceCount[i]++;
            else
                pContext->pTagDI[i] = true;
        }
        else
        {
            /*Clear*/
            pContext->DiDebounceCount[i] = 0;
            pContext->pTagDI[i] = false;
        }
        DI_Raw >>= 1;
    }
}

static void UpdateChConfig(CalculationContext_t *pContext)
{
    CALIBRATION_CH i;
    PtctCorrInfo* pCalibrationFile = (PtctCorrInfo*)pContext->pCalibrationFile;

    for(i = CALIBRATION_VA; i<=CALIBRATION_VT; i++)
    {
        pContext->pChannelA_Config[i].TotalGain   = pCalibrationFile->CalibrationParameter[i].ChannelGain;
    }
    for(i = CALIBRATION_IA; i<=CALIBRATION_INM; i++)
    {
        pContext->pChannelB_Config[i-CALIBRATION_IA].TotalGain = pCalibrationFile->CalibrationParameter[i].ChannelGain;
    }
}


/*
 *
 */



void Calculation_Task(UArg arg0, UArg arg1)
{
    CalculationContext_t* pContext = &SamplingCtx;
    memset(pContext, 0, sizeof(CalculationContext_t));

    if(Sampling_Init(pContext) == 0)
        DEBUG_Msg("Sampling Context Load Fail\n");

    pDMA_Destination = &pContext->pADC_Raw->ADCINA0[0];

    Calibration_Init(pContext->pADC_Raw, pContext->pChannelA_Config, pContext->pChannelB_Config);

    pCalibrationMode = pContext->pTagCalibrationMode;

    TASK_SET_PRI(Task_Metering, 1);
    TASK_SET_PRI(Task_Mmi, 1);
    TASK_SET_PRI(Task_Communication, 1);

    TASK_SET_PRI(Task_Sampling, -1);
    TASK_SLEEP(100);

    /*Start sampling*/
    pContext->pfSampling_Start(*pContext->pSytemFrequency);

    while(1)
    {
        SEMAPHORE_PEND(SemSampling, WAIT_FOREVER);

        /*Sampling Processing*/
        if(*pCalibrationMode == false)
        {
            Sampling_Processing(pContext);
            DI_debouncing(pContext);
            MUX_Set(pContext->MuxSetCount);

            if(pContext->QuaterCylceFlag)
            {
                pContext->QuaterCylceFlag = 0;

                if(pContext->SamplingCount < 16)
                {
                    QuaterDataNode_t *pDataNode = pContext->pNode->next;
                    pContext->pNode = pDataNode;
                }
                else
                {
                    Calculating_Processing(pContext);
                }
            }
        }
        else
        {
            /*Calibration*/
            CALIBRATION_STATUS CalibrationStatus = ExecuteCalibration();

            switch(CalibrationStatus)
            {
                case CALIBRATION_READY:
                case CALIBRATION_IN_PROGRESS:
                    break;
                case CALIBRATION_COMPLETED:
                    pContext->SamplingCount = 0;
                    *pCalibrationMode       = false;
                    break;
                case CALIBRATION_ERROR:
                    /*TAG DG ?*/
                    break;
            }
        }

        if(pContext->ChGainUpdateFlag == true)
        {
            pContext->ChGainUpdateFlag = false;
            pContext->SamplingCount     = 0;
            UpdateChConfig(pContext);
        }



    }
}

void* GetChUpdateFlagAddr(void)
{
    return &SamplingCtx.ChGainUpdateFlag;
}


void Sampling_Stop(void)
{
    StopEPwm();
}
