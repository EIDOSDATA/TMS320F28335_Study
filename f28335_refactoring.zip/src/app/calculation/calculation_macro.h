/*
 * macro.h
 *
 *  Created on   : 2023. 9. 26.
 *      Author   : ShinSung Industrial Electric
 *  Description  : Macro Function for code execution performance
 */

#ifndef COMPONENTS_CALCULATION_IMPLEMENTATION_MACRO_H_
#define COMPONENTS_CALCULATION_IMPLEMENTATION_MACRO_H_
#include "def.h"
#define BIT_CHECK(Data)         Data&0x01

#define ZONE0_OFFSET            0x004000
#define DI_ADDRESS              (ZONE0_OFFSET + 0x000100)

#define READ_DI_BLOCK           (*(volatile uint16 *)DI_ADDRESS)

/*Gain resolution factor (HMIS)*/
#define GAIN_RESOLUTION_FACTOR   0.0001F

/*Current reference for select*/
#define I_REFERENCE         100
#define I_AMP_REFERENCE     2000

#define IN_REFERENCE        150
#define IN_AMP_REFERENCE    2000

#define PHASE_LINE_FLAG     16
#define NEUTRAL_LINE_FLAG   20

/*ADC Channel Cut off RMS Value*/
#define VA_RMS_CUTOFF       0.1F
#define VB_RMS_CUTOFF       0.1F
#define VC_RMS_CUTOFF       0.1F

#define VR_RMS_CUTOFF       0.1F
#define VS_RMS_CUTOFF       0.1F
#define VT_RMS_CUTOFF       0.1F

#define IA_RMS_CUTOFF       0.005F
#define IB_RMS_CUTOFF       0.005F
#define IC_RMS_CUTOFF       0.005F
#define IN_RMS_CUTOFF       0.0005F

/*ADC Channel Calibration Reference RMS*/
#define VA_RMS_REF       0.06F
#define VB_RMS_REF       0.06F
#define VC_RMS_REF       0.06F

#define VR_RMS_REF       0.06F
#define VS_RMS_REF       0.06F
#define VT_RMS_REF       0.06F

#define IA_RMS_REF       0.06F
#define IB_RMS_REF       0.06F
#define IC_RMS_REF       0.06F
#define IN_RMS_REF       0.06F

/*ADC Channel Calibration Reference Angle*/
#define VA_ANGLE_REF       0.F
#define VB_ANGLE_REF       120.F
#define VC_ANGLE_REF       240.F

#define VR_ANGLE_REF       0.F
#define VS_ANGLE_REF       120.F
#define VT_ANGLE_REF       240.F

#define IA_ANGLE_REF       0.F
#define IB_ANGLE_REF       120.F
#define IC_ANGLE_REF       240.F
#define IN_ANGLE_REF       0.F


/*
 * Reference Voltage 1.5V
 * Description : ADC Input Voltage 1.5
 * ADC Result(Sampling) = 4096 X (1.5V/3V) = 2048
 * Accumulated value of sampling 2048 x 8 = 16384
 */
#define ZERO_VALUE      -16384

/*ADC Average Macro Function*/
#define GET_GPAI_CH_SUM(result, buf)          result = 0;         \
                                              result += buf[0];   \
                                              result += buf[1];   \
                                              result += buf[2];   \
                                              result += buf[3];   \
                                              result += buf[4];   \
                                              result += buf[5];   \
                                              result += buf[6];   \
                                              result += buf[7];   \
                                              result >>= 3;

#define GET_VI_CH_SUM(result, buf)            result = ZERO_VALUE;\
                                              result += buf[0];   \
                                              result += buf[1];   \
                                              result += buf[2];   \
                                              result += buf[3];   \
                                              result += buf[4];   \
                                              result += buf[5];   \
                                              result += buf[6];   \
                                              result += buf[7];   \
                                              result >>= 3;


/*Data Save Macro From Average Data to Quater data Buffer*/
#define SAVE_ChADATA(destination, pSource)        *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource;


/*Normal*/
#define SAVE_ChBDATA(destination, pSource)        *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource;
/*Calibration*/
#define SAVE_ChBCAL_DATA(destination, pSource)    *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource++;    \
                                                  destination += QUATER_CYCLE;  \
                                                  *destination = *pSource;    \



#endif /* COMPONENTS_CALCULATION_IMPLEMENTATION_MACRO_H_ */
