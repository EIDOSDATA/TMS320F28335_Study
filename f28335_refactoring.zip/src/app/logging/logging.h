/*
 * logging.h
 *
 *  Created on: 2023. 11. 7.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_RECORD_INTERFACE_LOGGING_H_
#define COMPONENTS_RECORD_INTERFACE_LOGGING_H_

#include "time.h"

void Logging_Task(UArg arg0, UArg arg1);

void* GetCalibrationSaveFlagAddr(void);
#endif /* COMPONENTS_RECORD_INTERFACE_LOGGING_H_ */
