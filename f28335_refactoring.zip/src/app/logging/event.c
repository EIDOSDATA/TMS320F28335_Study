/*
 * event.c
 *
 *  Created on: 2023. 11. 27.
 *      Author: ShinSung Industrial Electric
 */


#include "def.h"
#include "src/app/logging/event.h"
#include "src/app/tag/tag_db_macro.h"

#include "src/app/logging/tagid.h"
/*Event Format Size(word)*/
#define SEQ_EVT_SIZE            7
#define SEQ_EVT_FORMAT          8

#define FLT_EVT_SIZE            21
#define FLT_EVT_FORMAT          22

#define TAG_EVT_SIZE            2

#define DMD_EVT_FORMAT          70

/*For sequtial event HMIS */
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))
#define EXTRACT_GROUP(TAGID) (((TAGID) & 0xF000) >> 12)
#define EXTRACT_INDEX_DIVISION(TAGID) (((TAGID) & 0x0FF0) >> 4)
#define EXTRACT_INDEX_MOD(TAGID) (TAGID & 0x000F)

#define TAG_BUFSIZE             4096

#define SEQEVT_BUFSIZE          4096
#define FLTEVT_BUFSIZE          4096
#define DMDEVT_BUFSIZE          4096
#define ENGEVT_BUFSIZE          4096

#pragma DATA_SECTION (Seq_Buf,      "ZONE6DATA")
#pragma DATA_SECTION (Flt_Buf,      "ZONE6DATA")
#pragma DATA_SECTION (Dmd_Buf,      "ZONE6DATA")
#pragma DATA_SECTION (Eng_Buf,      "ZONE6DATA")

#pragma DATA_SECTION (EvtRingbufHd, "ZONE6DATA")
#pragma DATA_SECTION (EventHdObject,  "ZONE6DATA")

#pragma DATA_SECTION (TempFileBuf,  "ZONE6DATA")

#pragma DATA_SECTION (FramTagRingBufHd, "ZONE6DATA")
#pragma DATA_SECTION (FramTagBuf,       "ZONE6DATA")

enum
{
   /*Sequential*/
   SEQ_EVT_FIRST_FILE = FILE_SEQ_EVENT0,
   SEQ_EVT_LAST_FILE  = SEQ_EVT_FIRST_FILE + FILE_SEQ_EVENT_MAX-1,
   SEQ_EVT_PER_FILE   = FILE_SEQ_EVENT_SIZE/SEQ_EVT_FORMAT,
   SEQ_EVT_TOTAL_SIZE = SEQ_EVT_PER_FILE*FILE_SEQ_EVENT_MAX,

   /*Fault*/
   FLT_EVT_FIRST_FILE = FILE_FLT_EVENT0,
   FLT_EVT_LAST_FILE  = FLT_EVT_FIRST_FILE + FILE_FLT_EVENT_MAX-1,
   FLT_EVT_PER_FILE   = FILE_FLT_EVENT_SIZE/FLT_EVT_FORMAT,
   FLT_EVT_TOTAL_SIZE = FLT_EVT_PER_FILE*FILE_FLT_EVENT_MAX,

   /*Demand*/
   DMD_EVT_FIRST_FILE = FILE_LOAD_PROFILE0,
   DMD_EVT_LAST_FILE  = DMD_EVT_FIRST_FILE + FILE_DMD_EVENT_MAX-1,
   DMD_EVT_PER_FILE   = FILE_DMD_EVENT_SIZE/DMD_EVT_FORMAT,
   DMD_EVT_TOTAL_SIZE = DMD_EVT_PER_FILE*FILE_DMD_EVENT_MAX,

   /*Energy*/
   ENG_EVT_FIRST_FILE = FILE_ENERGY_LOG0,
   ENG_EVT_LAST_FILE  = ENG_EVT_FIRST_FILE + FILE_ENERGY_LOG_MAX-1,
};

/*For sequential event*/
static uint16*  pTagID[TAG_GRP_MAX] =
{
 /* GRP_NULL,   GRP_AI,         GRP_DI,         GRP_DO */
     NULL,      NULL,           DI_TID,         DO_TID,
 /* GRP_BV,     GRP_NMV_UI,     GRP_NMV_F,      GRP_NVV_UI,     GRP_NVV_F */
     BV_TID,    NMV_UI_TID,     NMV_F_TID,      NVV_UI_TID,     NVV_F_TID,
 /* GRP_RCM,    GRP_LS_UI,      GRP_LS_F,       GRP_LS0_UI,     GRP_LS0_F       GRP_LS1_UI,     GRP_LS1_F*/
     RCM_TID,   LS_UI_TID,      LS_F_TID,       LS0_UI_TID,     LS0_F_TID,      LS1_UI_TID,     LS1_F_TID,
 /* GRP_SC_UI,  GRP_SC_F,       GRP_SIM_DI,     GRP_SIM_RMS,    GRP_SIM_ANG     GRP_SIM_FREQ,   GRP_SIM_GPAI*/
     SC_UI_TID, SC_F_TID,       DI_TID,         NULL,           NULL,           NULL,           NULL,
 /* GRP_DG,     GRP_MMI,        GRP_ACC,        GRP_DNP232_UI,  GRP_DNP232_F    GRP_DNPETH_UI,  GRP_DNPETH_F*/
     DG_UI_TID, NULL,           NULL,           NULL,           NULL,           NULL,           NULL
};

static uint16    Seq_Buf[SEQEVT_BUFSIZE];
static uint16    Flt_Buf[FLTEVT_BUFSIZE];
static uint16    Dmd_Buf[DMDEVT_BUFSIZE];
static uint16    Eng_Buf[ENGEVT_BUFSIZE];

uint16           TempFileBuf[2048];

static Ringbuf_t EvtRingbufHd[EVENT_MAX];

static Ringbuf_t FramTagRingBufHd[FRAM_TAG_GROUP_MAX];
static uint16    FramTagBuf[FRAM_TAG_GROUP_MAX][TAG_BUFSIZE];

static EventHandle EventHdObject[EVENT_MAX];

extern void FRAM_TagIntDataWrite(TAG_GROUP TagGroup, uint16 Index);
extern void FRAM_TagFloatDataWrite(TAG_GROUP TagGroup, uint16 Index);

/*Sequential Event*/
#if 0
bool SeqEvt_Push(uint16 Group, uint16 Index, uint16 Value)
{
    uint16 TagID = BUILD_L2CODE(Group, Index/16)+(Index%16);

    Ringbuf_t* pRingbuf = EventHdObject[EVENT_SEQUENTIAL].pRingBufHandle;

    SeqEvtFormat   Instance;

    Instance.TagID  = TagID;
    Instance.Value  = Value;

    HMIS_TimeStamping(&Instance.TimeData);

    Instance.DNP_CRC = Compute_DNP_CRC((uint16*)&Instance, SEQ_EVT_SIZE);

    if(Ringbuf_Write(pRingbuf, &Instance, SEQ_EVT_FORMAT) == true)
    {
        return true;
    }

    return false;
}
#else
bool SeqEvt_Push(uint16 Group, uint16 Index, uint16 Value)
{
    uint16* pTagIdGrp = pTagID[Group];
    uint16  TagID;

    if(pTagIdGrp == NULL)
    {
        return false;
    }

    TagID = pTagIdGrp[Index];

    Ringbuf_t* pRingbuf = EventHdObject[EVENT_SEQUENTIAL].pRingBufHandle;

    SeqEvtFormat   Instance;

    Instance.TagID  = TagID;
    Instance.Value  = Value;

    HMIS_TimeStamping(&Instance.TimeData);

    Instance.DNP_CRC = Compute_DNP_CRC((uint16*)&Instance, SEQ_EVT_SIZE);

    if(Ringbuf_Write(pRingbuf, &Instance, SEQ_EVT_FORMAT) == true)
    {
        return true;
    }

    return false;
}
#endif
bool SeqEvt_Save(EventHandle* pHandle)
{
    bool Rtn = false;
    uint16 ReadCount;
    uint16 FlashWriteBuf[SEQ_EVT_FORMAT];
    FileDescriptor* pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_NULL);

    /*Check file available*/
    if(pFile->Free == 0)
    {
        /*No space available*/
        if(++pHandle->CurrentIndex > pHandle->LastIndex)
        {
            pHandle->CurrentIndex = pHandle->FirstIndex;
        }
        /*Check next file*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_WRITE);

        pHandle->EvtCount -= SEQ_EVT_PER_FILE;
        CLI_Printf("erase file index %d\r\n", pFile->FileIndex);
    }
    else
    {
        /*space available*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_APPEND);
    }
    /*read temporary event data from ringbuf*/
    ReadCount = Ringbuf_Read(pHandle->pRingBufHandle, &FlashWriteBuf[0], SEQ_EVT_FORMAT);

    if(ReadCount == SEQ_EVT_FORMAT)
    {
        /*save event data to flash*/
        Rtn = File_Write(pFile, &FlashWriteBuf[0], SEQ_EVT_FORMAT);
    }

    /*close event file*/
    File_Close(pFile);

    if(Rtn)
        pHandle->EvtCount++;

    return Rtn;
}
/*Fault Event*/
bool FltEvt_Push(FaultType Type,
                 float32 VA, float32 VB, float32 VC,
                 float32 IA, float32 IB, float32 IC, float32 IN)
{
    Ringbuf_t* pRingbuf = EventHdObject[EVENT_FAULT].pRingBufHandle;

    FltEvtFormat   Instance;

    Instance.Type   = Type;

    Instance.VA_RMS = VA;
    Instance.VB_RMS = VB;
    Instance.VC_RMS = VC;
    Instance.IA_RMS = IA;
    Instance.IB_RMS = IB;
    Instance.IC_RMS = IC;
    Instance.IN_RMS = IN;

    HMIS_TimeStamping(&Instance.TimeData);

    Instance.DNP_CRC = Compute_DNP_CRC((uint16*)&Instance, FLT_EVT_SIZE);

    if(Ringbuf_Write(pRingbuf, &Instance, FLT_EVT_FORMAT))
        return true;

    return false;
}

bool FltEvt_Save(EventHandle* pHandle)
{
    bool Rtn = false;
    uint16 ReadCount;
    uint16 FlashWriteBuf[FLT_EVT_FORMAT];

    FileDescriptor* pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_NULL);

    /*Check file available*/
    if(pFile->Free == 0)
    {
        /*No space*/
        if(++pHandle->CurrentIndex > pHandle->LastIndex)
        {
            pHandle->CurrentIndex = pHandle->FirstIndex;
        }

        /*Check next file*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_WRITE);

        pHandle->EvtCount -= FLT_EVT_PER_FILE;
        CLI_Printf("erase file index %d\r\n", pFile->FileIndex);
    }
    else
    {
        /*space available*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_APPEND);
    }
    /*read temporary event data from ringbuf*/
    ReadCount = Ringbuf_Read(pHandle->pRingBufHandle, &FlashWriteBuf[0], FLT_EVT_FORMAT);

    if(ReadCount == FLT_EVT_FORMAT)
        Rtn = File_Write(pFile, &FlashWriteBuf[0], FLT_EVT_FORMAT);

    File_Close(pFile);

    if(Rtn)
        pHandle->EvtCount++;

    return Rtn;
}

bool DmdEvt_Push(EventHandle* pHandle, DmdEvtFormat* pBuf)
{
    if((pHandle == NULL)||(pBuf == NULL))
        return false;

    HMIS_TimeStamping(&pBuf->TimeData);

    pBuf->CheckCode = 0xABCDDCBA;

    if(Ringbuf_Write(pHandle->pRingBufHandle, pBuf, DMD_EVT_FORMAT) == true)
    {
        CLI_Printf("push the demand data to buffer\r\n");
        return true;
    }

    return false;
}

bool DmdEvt_Save(EventHandle* pHandle)
{
    bool Rtn = false;
    uint16 ReadCount;
    uint16 FlashWriteBuf[DMD_EVT_FORMAT];

    FileDescriptor* pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_NULL);

    if(pFile->Free == 0)
    {
        /*No space*/
        if(++pHandle->CurrentIndex > pHandle->LastIndex)
        {
            pHandle->CurrentIndex = pHandle->FirstIndex;
        }
        /*Check next file*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_WRITE);

        pHandle->EvtCount -= DMD_EVT_PER_FILE;
        CLI_Printf("erase demand file index %d\r\n", pFile->FileIndex);
    }
    else
    {
        /*space available*/
        pFile = File_Open((FileIndex)pHandle->CurrentIndex, MODE_APPEND);
    }
    ReadCount = Ringbuf_Read(pHandle->pRingBufHandle, &FlashWriteBuf[0], DMD_EVT_FORMAT);

    if(ReadCount == DMD_EVT_FORMAT)
        Rtn = File_Write(pFile, &FlashWriteBuf[0], DMD_EVT_FORMAT);

    File_Close(pFile);

    if(Rtn)
        pHandle->EvtCount++;

    return Rtn;
}

void FramTagEvt_Push(TAG_GROUP TagGroup, uint16 Index)
{
    TagData Instance;
    Ringbuf_t* pRingBufHd = NULL;

    Instance.TagGroup = TagGroup;
    Instance.TagIndex = Index;

    /*Select Tag ringbuf object*/
    switch(TagGroup)
    {
        case TAG_GRP_SC_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_SC_UI];
            break;
        case TAG_GRP_SC_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_SC_F];
            break;
        case TAG_GRP_NMV_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_NMV_UI];
            break;
        case TAG_GRP_NMV_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_NMV_F];
            break;
        case TAG_GRP_NVV_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_NVV_UI];
            break;
        case TAG_GRP_NVV_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_NVV_F];
            break;
        case TAG_GRP_LS0_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_LS0_UI];
            break;
        case TAG_GRP_LS0_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_LS0_F];
            break;
        case TAG_GRP_LS1_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_LS1_UI];
            break;
        case TAG_GRP_LS1_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_LS1_F];
            break;
        case TAG_GRP_DNP232_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_DNP232_UI];
            break;
        case TAG_GRP_DNP232_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_DNP232_F];
            break;
        case TAG_GRP_DNPETH_UI:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_DNPETH_UI];
            break;
        case TAG_GRP_DNPETH_F:
            pRingBufHd = &FramTagRingBufHd[FRAM_TAG_DNPETH_F];
            break;
    }

    if(pRingBufHd != NULL)
    {
        Ringbuf_Write(pRingBufHd, &Instance, sizeof(TagData));
    }
}



void TagEvt_Save(TagData* pParam)
{
    switch(pParam->TagGroup)
    {
        case TAG_GRP_SC_UI:
        case TAG_GRP_LS0_UI:
        case TAG_GRP_LS1_UI:
        case TAG_GRP_NMV_UI:
        case TAG_GRP_NVV_UI:
        case TAG_GRP_DNP232_UI:
        case TAG_GRP_DNPETH_UI:
            FRAM_TagIntDataWrite(pParam->TagGroup, pParam->TagIndex);
            break;
        case TAG_GRP_SC_F:
        case TAG_GRP_LS0_F:
        case TAG_GRP_LS1_F:
        case TAG_GRP_NMV_F:
        case TAG_GRP_NVV_F:
        case TAG_GRP_DNP232_F:
        case TAG_GRP_DNPETH_F:
            FRAM_TagFloatDataWrite(pParam->TagGroup, pParam->TagIndex);
            break;
    }
}

EventHandle* Event_Init(void)
{
    memset(&EventHdObject[0], 0, sizeof(EventHandle)* EVENT_MAX);

    uint16  i, FileIndex;
    uint16* pEvtBuf[EVENT_MAX]    = {Seq_Buf, Flt_Buf, Dmd_Buf, Eng_Buf};
    uint16  EvtBufSize[EVENT_MAX] = {SEQEVT_BUFSIZE, FLTEVT_BUFSIZE, DMDEVT_BUFSIZE, ENGEVT_BUFSIZE};
    uint16  EvtFormatSize[EVENT_MAX] = {SEQ_EVT_FORMAT, FLT_EVT_FORMAT, DMD_EVT_FORMAT, 1};

    uint16  EvtFileFirstIndex[EVENT_MAX] = {SEQ_EVT_FIRST_FILE, FLT_EVT_FIRST_FILE, DMD_EVT_FIRST_FILE, ENG_EVT_FIRST_FILE};
    uint16  EvtFileLastIndex[EVENT_MAX]  = {SEQ_EVT_LAST_FILE, FLT_EVT_LAST_FILE, DMD_EVT_LAST_FILE, ENG_EVT_LAST_FILE};

    FileDescriptor* pFile;

    for(i=0; i<EVENT_MAX; i++)
    {
        if(Ringbuf_Create(&EvtRingbufHd[i], pEvtBuf[i], EvtBufSize[i]))
            EventHdObject[i].pRingBufHandle = &EvtRingbufHd[i];

        else
            DEBUG_Msg("fail to create event ringbuf\n");

        EventHdObject[i].FirstIndex = EvtFileFirstIndex[i];
        EventHdObject[i].LastIndex  = EvtFileLastIndex[i];
        EventHdObject[i].CurrentIndex  = EventHdObject[i].FirstIndex;

        for(FileIndex = EventHdObject[i].FirstIndex;
            FileIndex <=  EventHdObject[i].LastIndex; FileIndex++)
        {
            pFile = File_Open(FileIndex, MODE_NULL);

            if(pFile->Used)
            {
                EventHdObject[i].EvtCount += pFile->Used/EvtFormatSize[i];

                if(pFile->Used < pFile->Size)
                    EventHdObject[i].CurrentIndex = FileIndex;
            }
        }
    }

    EventHdObject[EVENT_SEQUENTIAL].pEventSave = SeqEvt_Save;
    EventHdObject[EVENT_FAULT].pEventSave      = FltEvt_Save;
    EventHdObject[EVENT_DEMAND].pEventSave     = DmdEvt_Save;

    return &EventHdObject[0];
}
Ringbuf_t* FramTagRingBuf_Init(void)
{
    FRAM_TAG_GROUP Index;

    for(Index = 0; Index<FRAM_TAG_GROUP_MAX; Index++)
    {
        if(Ringbuf_Create(&FramTagRingBufHd[Index], &FramTagBuf[Index], TAG_BUFSIZE) == false)
        {
            CLI_Printf("fail to create tag ringbuf\r\n");
            return NULL;
        }
    }
    return &FramTagRingBufHd[0];
}

EventHandle* EventHandle_Get(EVENT_TYPE EventType)
{
    return &EventHdObject[EventType];
}


uint16 SequentialEventFile_Load(SeqEvtFormat* pTargetBuffer)
{
    FileDescriptor*     pSequentialFileDescriptor;

    uint16*             pTempFileBuf=&TempFileBuf;

    uint16              SequentialEvent_Count;

    uint16              i;

    EventHandle* pSequentialEventHandle = SeqEventHandleGet();

    memset(pTempFileBuf, 0, sizeof(TempFileBuf));

    //�ֽ� �̺�Ʈ ���� Open
    pSequentialFileDescriptor=File_Open(pSequentialEventHandle->CurrentIndex,MODE_READ);

    if(pSequentialFileDescriptor==NULL) return 0;

    SequentialEvent_Count = pSequentialFileDescriptor->Used/SEQ_EVT_FORMAT;


    if(SequentialEvent_Count>=50)
    {
        File_Read(pSequentialFileDescriptor, pTempFileBuf, pSequentialFileDescriptor->Used);

        pTempFileBuf += (SequentialEvent_Count-1)*SEQ_EVT_FORMAT; //Last Data

        SequentialEvent_Count=50;
        for(i=0;i<SequentialEvent_Count;i++)
        {
            memcpy(&pTargetBuffer[i], pTempFileBuf, sizeof(SeqEvtFormat));
            pTempFileBuf -=SEQ_EVT_FORMAT;
        }

        File_Close(pSequentialFileDescriptor);

    }
    else if(SequentialEvent_Count<50 && (pSequentialEventHandle->EvtCount>SequentialEvent_Count))
    {
        File_Read(pSequentialFileDescriptor, pTempFileBuf, pSequentialFileDescriptor->Used);

        pTempFileBuf += (SequentialEvent_Count-1)*SEQ_EVT_FORMAT; //Last Data

        for(i=0;i<SequentialEvent_Count;i++)
        {
            memcpy(&pTargetBuffer[i], pTempFileBuf, sizeof(SeqEvtFormat));
            pTempFileBuf -=SEQ_EVT_FORMAT;

        }

        File_Close(pSequentialFileDescriptor);

        FileIndex  BeforeFileIndex=pSequentialEventHandle->CurrentIndex-1;

        if(BeforeFileIndex<FILE_SEQ_EVENT0)
        {
            BeforeFileIndex = FILE_SEQ_EVENT9;
        }

        FileDescriptor*     pBeforeSequentialFileDescriptor = File_Open(BeforeFileIndex,MODE_READ);


        pTempFileBuf = &TempFileBuf; //return init position

        File_Read(pBeforeSequentialFileDescriptor, pTempFileBuf, pBeforeSequentialFileDescriptor->Used);

        pTempFileBuf += pBeforeSequentialFileDescriptor->Used;
        pTempFileBuf -=SEQ_EVT_FORMAT;

        for(i=SequentialEvent_Count;i<50;i++)
        {
            memcpy(&pTargetBuffer[i], pTempFileBuf, sizeof(SeqEvtFormat));
            pTempFileBuf -=SEQ_EVT_FORMAT;
        }

        SequentialEvent_Count=50;
        File_Close(pBeforeSequentialFileDescriptor);

    }
    else
    {
        File_Read(pSequentialFileDescriptor, pTempFileBuf, pSequentialFileDescriptor->Used);

        pTempFileBuf += (SequentialEvent_Count-1)*SEQ_EVT_FORMAT; //Last Data

        for(i=0;i<SequentialEvent_Count;i++)
        {
            memcpy(&pTargetBuffer[i], pTempFileBuf, sizeof(SeqEvtFormat));
            pTempFileBuf -=SEQ_EVT_FORMAT;

        }

            File_Close(pSequentialFileDescriptor);
    }


    return SequentialEvent_Count;
}

uint16 FaultEventFile_Load(FltEvtFormat* pTargetBuffer)
{
    FileDescriptor*     pFaultFileDescriptor;

    uint16*             pTempFileBuf=&TempFileBuf;

    uint16              FaultEvent_Count;

    uint16              i;

    EventHandle* pFaultEventHandle = FltEventHandleGet();

    memset(pTempFileBuf, 0, sizeof(TempFileBuf));

    pFaultFileDescriptor=File_Open(pFaultEventHandle->CurrentIndex,MODE_READ);

    if(pFaultFileDescriptor==NULL) return 0;

    File_Read(pFaultFileDescriptor, pTempFileBuf, pFaultFileDescriptor->Used);

    FaultEvent_Count = pFaultFileDescriptor->Used/FLT_EVT_FORMAT;

    pTempFileBuf += (FaultEvent_Count-1)*FLT_EVT_FORMAT; //Last Data

    for(i=0;i<FaultEvent_Count;i++)
    {
        memcpy(&pTargetBuffer[i], pTempFileBuf, sizeof(FltEvtFormat));
        pTempFileBuf -=FLT_EVT_FORMAT;

    }

    File_Close(pFaultFileDescriptor);


    return FaultEvent_Count;
}

uint16 FaultWaveEventFile_Check(void)
{
    FileDescriptor*     pFaultWaveFileDescriptor;

    int                 FaultWaveEvent_Flag=0;
    int                 i;

    for(i=FILE_FLTWAVE_EVENT0;i<=FILE_FLTWAVE_EVENT9;i++)
    {
        pFaultWaveFileDescriptor=File_Open(FILE_FLT_EVENT9,MODE_READ);

        if(pFaultWaveFileDescriptor==NULL) continue;

        if(pFaultWaveFileDescriptor->Used>0)
        {
            File_Close(pFaultWaveFileDescriptor);
            return 1;
        }
    }

    return 0;
}

void TagData_Extract(TagData* output,uint16 TagID)
{
    output->TagGroup =  EXTRACT_GROUP(TagID);

    uint16 TagIndex_Division = EXTRACT_INDEX_DIVISION(TagID);
    uint16 TagIndex_Mod = EXTRACT_INDEX_MOD(TagID);
    output->TagIndex = (TagIndex_Division*16) + TagIndex_Mod;

}

