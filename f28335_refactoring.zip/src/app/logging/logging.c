/*
 * logging.c
 *
 *  Created on: 2023. 11. 7.
 *      Author: ShinSung Industrial Electric
 */

#include <string.h>

#include "def.h"
#include "file.h"
#include "time.h"

#include "src/app/calculation/calculation.h"
#include "src/app/logging/event.h"
#include "src/app/shell/cli.h"

#include "src/app/metering/metering.h"

#include "src/utils/ringbuf.h"

#define _USE_CLI

#pragma DATA_SECTION(TESTBuf, "ZONE6DATA")

void Seq_Test(cli_args_t *args);
void Flt_Test(cli_args_t *args);
void Time_Check(cli_args_t *args);
void File_Check(cli_args_t *args);
void Crc_Test(cli_args_t *args);

char TESTBuf[4096];

typedef struct
{
    uint16       IsInit;

    EventHandle*    pEventHandle;

    Ringbuf_t*      pTagRingbuf;

    uint16      CalibrationFileIndex;
    void*       pCalibrationFileAddr;


    bool           CalibrationSaveFlag;

    uint16*        pAppVersion; //TAG SC UI

} LoggingContext;

extern uint16 PECAPP_VER;

LoggingContext LoggingCtx;
/*Firmware verity test*/
bool FirmwareFileSendFlag = 0;
/*Demand event test*/

LoggingContext* Logging_Init(void)
{
    TAG_DB* pTagDB = TagDB_Get();

    memset(&LoggingCtx, 0, sizeof(LoggingContext));

    LoggingCtx.pEventHandle = Event_Init();
    LoggingCtx.pTagRingbuf  = FramTagRingBuf_Init();

    LoggingCtx.pAppVersion = &pTagDB->SC.SC_UI[ALS_SC_PECAPP_VERSION];

    return &LoggingCtx;
}

EventHandle* SeqEventHandleGet(void)
{
    return &LoggingCtx.pEventHandle[EVENT_SEQUENTIAL];
}

EventHandle* FltEventHandleGet(void)
{
    return &LoggingCtx.pEventHandle[EVENT_FAULT];
}


void EventDataLogging(EventHandle* pEventHandle)
{
    uint16 i;
    Ringbuf_t* pRingbuf;

    for(i = 0; i<EVENT_MAX; i++)
    {
        pRingbuf = pEventHandle[i].pRingBufHandle;

        do
        {
            if(Ringbuf_Length(pRingbuf))
            {
                if(pEventHandle[i].pEventSave != NULL)
                {
                    if(pEventHandle[i].pEventSave(&pEventHandle[i]) == false)
                        CLI_Printf("[event] %n fail to save event data to flash \r\n", i);
                }
            }
        }   while(Ringbuf_Length(pRingbuf));
    }
}

void TagDataLogging(Ringbuf_t* pRingbuf)
{
    FRAM_TAG_GROUP Index = FRAM_TAG_SC_UI;
    uint16 Len;
    TagData Instance;

    for(;Index<FRAM_TAG_GROUP_MAX; Index++)
    {
        if(pRingbuf+Index != NULL)
        {
            Len = Ringbuf_Length(pRingbuf+Index);

            if(Len > 0)
            {
                do
                {
                    Len -= Ringbuf_Read(pRingbuf+Index, &Instance, sizeof(TagData));

                    TagEvt_Save(&Instance);
                    CLI_Printf("Tag Grp : %d, Index : %d", Instance.TagGroup, Instance.TagIndex);
                    CLI_Printf("write tag event to fram\r\n");

                }   while(Len > 0);
                /*Update Fram tag group CRC*/
                FramTagGroupCRC_Update(Instance.TagGroup);
            }
        }
        else
        {
            CLI_Printf("Fram tag ringbuffer handle addr is null\r\n");
        }
    }
}

bool CalibrationDataLogging(LoggingContext* pContext)
{
    bool Result = false;

    FileDescriptor *pFile = File_Open(FILE_PTCT_CORR, MODE_WRITE);

    Result = File_Write(pFile, pFile->pFileCache, pFile->Size);

    if(Result == false)
        CLI_Printf("fail to save save ptctcorrinfo.bin\r\n");

    else
        CLI_Printf("save ptctcorrinfo.bin\r\n");

    File_Close(pFile);

    return Result;
}

void Logging_Task(UArg arg0, UArg arg1)
{
    LoggingContext* pContext      = Logging_Init();

#ifdef _USE_CLI
    cliAdd("file",  File_Check);
    cliAdd("time",  Time_Check);
    cliAdd("seq",   Seq_Test);
    cliAdd("flt",   Flt_Test);

    cliAdd("crc",   Crc_Test);
#endif

    /*Check app version, power*/
    if(*pContext->pAppVersion != PECAPP_VER)
    {
        *pContext->pAppVersion = PECAPP_VER;
        FramTagEvt_Push(TAG_GRP_SC_UI, ALS_SC_PECAPP_VERSION);
    }

    FileIndex i = FILE_SECTOR_H_1;//FILE_UPDATE0;

    while(1)
    {
        TASK_SLEEP(400);

        /*event(sequential, fault, load profile, energy) logging*/

        EventDataLogging(pContext->pEventHandle);

        /*Synchronize the modified tag data from other task*/
        TagDataLogging(pContext->pTagRingbuf);

        /*Check calibration save flag*/
        if(pContext->CalibrationSaveFlag)
        {
            pContext->CalibrationSaveFlag = false;
            /*Synchronize the modified calibration file from the calculation*/
            if(CalibrationDataLogging(pContext) == false)
            {
                /*Error*/
            }
        }
        /*TEST Code*/
#if 0
        if(FirmwareFileSendFlag == true)
        {
            FileDescriptor* pFile = File_Open(i, MODE_NULL);

            if(pFile->Used > 0)
            {
                pFile = File_Open(i, MODE_READ);

                if(File_Read(pFile, pFile->pFileCache, pFile->Used))
                {
                    FileDataUnpacking(TESTBuf, pFile->pFileCache, pFile->Used);
                    TEST_Printf(TESTBuf, pFile->Used<<1);
                }
                File_Close(pFile);
                i++;
            }
            else
            {
                FirmwareFileSendFlag = false;
                CLI_Printf("finished reading all update files\r\n");
                i = FILE_UPDATE0;
            }
        }
#endif
    }
}

void* GetCalibrationSaveFlagAddr(void)
{
    return (void*)&LoggingCtx.CalibrationSaveFlag;
}





/*
 * CLI TEST
 */
void Time_Check(cli_args_t *args)
{
    if(args->argc == 1 && args->isStr(0, "get"))
    {
        SystemTime_t * pTime = TimeObjectGet();

        CLI_Printf("Date %d. %d. %d  Time %d : %d: %d : %d\r\n", pTime->tm_year + 1900, pTime->tm_mon, pTime->tm_mday, pTime->tm_hour,
                                                             pTime->tm_min, pTime->tm_sec, pTime->tm_ms);
    }
}
void Seq_Test(cli_args_t *args)
{
    uint16 i, EventCnt = args->getData(0);
    bool status = 0;
    CLI_Printf("seq event count %d\r\n", EventCnt);

    for(i=0; i<EventCnt; i++)
    {

        if(SeqEvt_Push(4, i, status) == false)
            CLI_Printf("fail to push the seq event data\r\n");
        status ^= 1;
    }
}

void Flt_Test(cli_args_t *args)
{
    uint16 i, EventCnt = args->getData(0);
    bool status = 0;
    CLI_Printf("flt event count %d\r\n", EventCnt);

    for(i=0; i<EventCnt; i++)
    {
        if(FltEvt_Push(FAULT_TCCTRIP,
                       180.7510, 180.00, 180.00,
                       180.00, 180.00, 180.00, 180.00) == false)
            CLI_Printf("fail to push the seq event data\r\n");
    }
}

void File_Check(cli_args_t *args)
{
    if(args->isStr(0, "info"))
    {
        FileIndex FileIndex = args->getData(1);
        FileDescriptor *pFile = File_Open(FileIndex, MODE_NULL);

        CLI_Printf("\r\nFile Index %d\r\n"           , FileIndex);
        CLI_Printf("File Base Address : 0x%lx\r\n"   , pFile->BaseAddr);
        CLI_Printf("File Size : %d Word\r\n"         , pFile->Size);
        CLI_Printf("File Used : %d Word\r\n"         , pFile->Used);
        CLI_Printf("File Free : %d Word\r\n"         , pFile->Free);
    }
    else if(args->isStr(0, "delete"))
    {
        if(args->isStr(1, "update"))
        {
            FileIndex i = FILE_SECTOR_H_1;//FILE_UPDATE0;
            FileDescriptor *pFile;

            CLI_Printf("\r\n", pFile->Sector);

            if(UpdataFile_Erase() == true)
            {
                CLI_Printf("delete update file\r\n");
            }
            else
            {
                CLI_Printf("fail to delete update file\r\n");
            }
        }
    }
    else if(args->isStr(0, "read"))
    {

        if(args->isStr(1, "update"))
        {
            FirmwareFileSendFlag = true;
            CLI_Printf("\r\n");
            CLI_Printf("reading update files\r\n");
        }
        else
        {
            FileIndex idx = args->getData(1);

            FileDescriptor* pFile = File_Open(idx, MODE_READ);

            memset(TESTBuf, 0, 4096);

            File_Read(pFile, TESTBuf, pFile->Size);

            TEST_Printf(TESTBuf, pFile->Used<<1);

            File_Close(pFile);
            FileDataUnpacking(TESTBuf, pFile->pFileCache, pFile->Used);
            CLI_Printf("\r\n");
            CLI_Printf("reading sector %d\r\n", pFile->Sector);
        }
    }
}

void Crc_Test(cli_args_t *args)
{
    if(args->isStr(0, "cal"))
    {
        uint16* pBuf = args->getStr(1);

        uint16 Len = strlen(pBuf);
        uint16 Crc8 = ComputeCrc8(pBuf, Len);

        CLI_Printf("CRC-8 = 0x%x\r\n",  Crc8);
    }
    else if(args->isStr(0, "new"))
    {
        uint16 NewData = 0x0001;
        uint16 PrevCrc = 0xA887;
        uint16 NewCrc = CRC_Update(&NewData, 1, PrevCrc);

        CLI_Printf("New Crc = 0x%x\r\n",  NewCrc);
    }

}
