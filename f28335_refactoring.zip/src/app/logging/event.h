/*
 * event.h
 *
 *  Created on: 2023. 11. 27.
 *      Author: ShinSung Industrial Electric
 */

#ifndef COMPONENTS_LOGGING_IMPLEMENTATION_EVENT_H_
#define COMPONENTS_LOGGING_IMPLEMENTATION_EVENT_H_

#include "time.h"
#include "file.h"
#include "src/utils/ringbuf.h"
#include "src/app/tag/tag_db.h"
#include <src/app/logging/logging.h>



/*
 * Event Data List
 *
 * Sequential Event
 * File list   : seqevents0.bin ~ seqevents9.bin
 * File Size   : 2048 Word
 * Format Size : 8 Word (16 Bytes)
 * Event Size  : (seq event file size / seq event format) x seq event file number
 *                2048/8 x 10 = 2560
 * Fault Event
 * File list   : fltevents0.bin ~ fltevents9.bin
 * File Size   : 2000 Word
 * Format Size :
 * Description :
 *
 */
/*Event Format Size(word)*/
#define SEQ_EVT_SIZE            7
#define SEQ_EVT_FORMAT          8
#define SEQ_EVT_DATA_MAX        50


#define FLT_EVT_SIZE            21
#define FLT_EVT_FORMAT          22
#define FLT_EVT_DATA_MAX        93

#define TAG_EVT_SIZE            2

#define DMD_EVT_FORMAT          70

/*For Event Data*/
#define BUILD_L2CODE(L1CODE, L2CODE)            (unsigned int)(((unsigned int)(L1CODE << 12) & 0xF000) | (unsigned int)((L2CODE << 4) & 0x0FF0))

typedef enum
{
    EVENT_SEQUENTIAL,
    EVENT_FAULT,

    //EVENT_FAULT_WAVE,
    EVENT_DEMAND,
    EVENT_ENERGY,

    EVENT_MAX,
} EVENT_TYPE;

/*Enumeration*/
typedef enum
{
    FAULT_TCCTRIP = 0x01,           FAULT_DEFTRIP = 0x02,
    FAULT_FCN1    = 0x04,              FAULT_FCN2 = 0x08,
    FAULT_FCN3    = 0x10,              FAULT_FCN4 = 0x20

} FaultType;


/*
 * Sequential Event Format
 * Size : 8 Word
 */
typedef struct
{
    HMIS_TimeStamp      TimeData;

    uint16              TagID;
    uint16              Value;
    uint16              Padding;                /*Padding Field is just padding*/
    uint16              DNP_CRC;

} SeqEvtFormat;

/*
 * Fault Event Format
 * Size : 22 Word
 */
typedef struct
{
    HMIS_TimeStamp      TimeData;

    FaultType           Type;

    float32             VA_RMS;
    float32             VB_RMS;
    float32             VC_RMS;
    float32             IA_RMS;
    float32             IB_RMS;
    float32             IC_RMS;
    float32             IN_RMS;

    uint16              Padding;
    uint16              DNP_CRC;

} FltEvtFormat;

/*
 * Load Profile Event Format
 * Size : 70 Word
 */

typedef struct
{
    HMIS_TimeStamp      TimeData;

    /*Demand Active Power*/
    float32             DemandActPowerA;
    float32             DemandActPowerB;
    float32             DemandActPowerC;
    float32             DemandActPowerTotal;

    /*Demand Reactive Power*/
    float32             DemandRctPowerA;
    float32             DemandRctPowerB;
    float32             DemandRctPowerC;
    float32             DemandRctPowerTotal;

    /*Peak Demand Active Power*/
    float32             PeakDemandActPowerA;
    float32             PeakDemandActPowerB;
    float32             PeakDemandActPowerC;
    float32             PeakDemandActPowerTotal;

    /*Peak Demand Reactive Power*/
    float32             PeakDemandRctPowerA;
    float32             PeakDemandRctPowerB;
    float32             PeakDemandRctPowerC;
    float32             PeakDemandRctPowerTotal;

    /*Demand Current*/
    float32             DemandIA;
    float32             DemandIB;
    float32             DemandIC;
    float32             DemandIN;
    float32             Demand3I0;
    float32             Demand3I2;

    /*Peak Demand Current*/
    float32             PeakDemandIA;
    float32             PeakDemandIB;
    float32             PeakDemandIC;
    float32             PeakDemandIN;
    float32             PeakDemand3I0;
    float32             PeakDemand3I2;

    float32             Reserved[4];
    /*Constant*/
    uint32              CheckCode;
} DmdEvtFormat;

/*Forward Declaration*/
typedef struct _EventHandle _EventHandle;


typedef struct _EventHandle
{
    uint16            EvtCount;
    Ringbuf_t*        pRingBufHandle;

    uint16           FirstIndex;
    uint16           LastIndex;

    /*Current file index*/
    uint16          CurrentIndex;
    bool            (*pEventSave)(_EventHandle* pHandle);

} EventHandle;

typedef enum
{
    FRAM_TAG_SC_UI,
    FRAM_TAG_SC_F,
    FRAM_TAG_LS0_UI,
    FRAM_TAG_LS0_F,
    FRAM_TAG_LS1_UI,
    FRAM_TAG_LS1_F,
    FRAM_TAG_NMV_UI,
    FRAM_TAG_NMV_F,
    FRAM_TAG_NVV_UI,
    FRAM_TAG_NVV_F,
    FRAM_TAG_DNP232_UI,
    FRAM_TAG_DNP232_F,
    FRAM_TAG_DNPETH_UI,
    FRAM_TAG_DNPETH_F,

    FRAM_TAG_GROUP_MAX,

} FRAM_TAG_GROUP;

/*For Logic*/
bool SeqEvt_Push(uint16 Group, uint16 Index, uint16 Value);
/*For other task*/
void FramTagEvt_Push(TAG_GROUP Group, uint16 Index);
//void TagEvt_Save(Ringbuf_t* pHandle);

/*For logging*/
//EventHandle* Event_Init(Ringbuf_t** pTagRingBuf);
EventHandle* Event_Init(void);
Ringbuf_t* FramTagRingBuf_Init(void);
void TagEvt_Save(TagData* pParam);

/*For MMI*/
void TagData_Extract(TagData* output,uint16 TagID);
uint16 SequentialEventFile_Load(SeqEvtFormat* pTargetBuffer);
uint16 FaultEventFile_Load(FltEvtFormat* pTargetBuffer);
uint16 FaultWaveEventFile_Check(void);

EventHandle* SeqEventHandleGet(void);
EventHandle* FltEventHandleGet(void);

bool FltEvt_Push(FaultType Type,
                 float32 VA, float32 VB, float32 VC,
                 float32 IA, float32 IB, float32 IC, float32 IN);
bool DmdEvt_Push(EventHandle* pHandle, DmdEvtFormat* pBuf);


EventHandle* EventHandle_Get(EVENT_TYPE EventType);

#endif /* COMPONENTS_LOGGING_IMPLEMENTATION_EVENT_H_ */
