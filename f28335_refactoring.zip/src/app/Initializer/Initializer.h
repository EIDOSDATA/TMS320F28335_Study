/*
 * Initializer.h
 *
 *  Created on: 2024. 2. 8.
 *      Author: ShinSung Industrial Electric
 */

#ifndef INITIALIZER_INITIALIZER_H_
#define INITIALIZER_INITIALIZER_H_


void SpecPhyPlatform_Init(void);
void PecAppVersion_Set(uint16 Major, uint16 Minor, uint16 Patch);
#endif /* INITIALIZER_INITIALIZER_H_ */
