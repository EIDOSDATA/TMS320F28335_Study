/*
 * Initializer.c
 *
 *  Created on: 2024. 2. 8.
 *      Author: ShinSung Industrial Electric
 */


#include "def.h"
#include "time.h"
#include "file.h"

#include "src/app/tag/tag_db.h"
#include "src/app/tag/tag_db_macro.h"
#include "src/port/tmwDNP/CommConfig.h"

#include "src/app/Initializer/file_default.h"

/*Driver*/
#include "src/port/clcd.h"
#define _USE_CLI

#ifdef _USE_CLI
#include "src/app/shell/cli.h"
#endif

uint16 PECAPP_VER;


void resetFunc(void)
{
    // interrupt clear
    IER = 0x0000;
    IFR = 0x0000;

    EALLOW;
    SysCtrlRegs.WDCR &= (0 << 6);
    EDIS;

    PieCtrlRegs.PIEIER1.bit.INTx8 = 1;

    // enable the PIE module and CPU interrupts
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;
    // Enables PIE to drive a pulse into the CPU
    PieCtrlRegs.PIEACK.all = 0xFFFF;
    // Enable Interrupts at the CPU level
    EINT;
    IER |= M_INT1;

    // reset the watchdog timer
    EALLOW;
    SysCtrlRegs.WDKEY = 0x0055;
    SysCtrlRegs.WDKEY = 0x00AA;
    EDIS;

    while(1);
}

void SpecPhyPlatform_Init(void)
{
    CliInit();

    CLI_Printf("\r\nenter application\r\n");

    cliAdd("reset", resetFunc);

    TimeObject_Init();

    CLCD_Init();

    Ethernet_Init();

    /*Initialize TAG DB*/
    TagDB_Init();

    FileModule_Init();

    /*Load System file*/
    SystemFile_Load(FILE_SYSTEM_INFO,    (void*)&FactorySystemInfo);
    SystemFile_Load(FILE_CHANNEL_CONFIG, (void*)&FactoryChannelConfig);
    SystemFile_Load(FILE_PTCT_CORR,      (void*)&FactoryPtctCorrInfo);
    SystemFile_Load(FILE_GPAI_CORR,      (void*)&FactoryGpaiCorrInfo);

    /*Load SCADA configuration file*/
    SystemFile_Load(FILE_SCADA_CONFIG_AI,    NULL);
    SystemFile_Load(FILE_SCADA_CONFIG_AO,    NULL);
    SystemFile_Load(FILE_SCADA_CONFIG_BI,    NULL);
    SystemFile_Load(FILE_SCADA_CONFIG_BO,    NULL);


}


void PecAppVersion_Set(uint16 Major, uint16 Minor, uint16 Patch)
{
    PECAPP_VER = (Major<<12) & 0xF000 | (Minor<<8) & 0x0F00 | Patch & 0x00FF;
}
