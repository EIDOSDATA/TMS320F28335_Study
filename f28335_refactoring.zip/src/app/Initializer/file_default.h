/*
 * file_default.h
 *
 *  Created on: 2024. 5. 8.
 *      Author: ShinSung Industrial Electric
 */

#ifndef FILE_DEFAULT_H_
#define FILE_DEFAULT_H_

#include "file.h"

/*Factory initial Value*/
const static SystemInformation FactorySystemInfo = {.SerialNumber = "SSIEC-PECPHY", .ModelNumber  = "SSIEC-PECAPP" ,.Identifier   = "123456"};
const static ChannelConfigs    FactoryChannelConfig = {
.VaVrReference_RMS = 1.33,    .VaVrReference_Angle = 0,    .VbVsReference_RMS = 1.33,    .VbVsReference_Angle = 240,    .VcVtReference_RMS = 1.33,    .VcVtReference_Angle = 120,
.IaReference_RMS = 0.5,       .IaReference_Angle = 0,      .IbReference_RMS = 0.5,       .IbReference_Angle = 240,      .IcReference_RMS = 0.5,       .IcReference_Angle = 120,
.InReference_RMS = 0.008,     .InReference_Angle = 240,
.IaAmpReference_RMS = 0.5,    .IaAmpReference_Angle = 0,   .IbAmpReference_RMS = 0.502,  .IbAmpReference_Angle = 240,   .IcAmpReference_RMS = 0.5,    .IcAmpReference_Angle = 120,
.InAmpReference_RMS = 0.002,  .InAmpReference_Angle = 240,
};
const static PtctCorrInfo      FactoryPtctCorrInfo = {
.CalibrationParameter[CALIBRATION_VA] = {.ChannelGain = VA_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_VB] = {.ChannelGain = VB_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_VC] = {.ChannelGain = VC_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_VR] = {.ChannelGain = VR_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_VS] = {.ChannelGain = VS_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_VT] = {.ChannelGain = VT_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IA] = {.ChannelGain = IA_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IB] = {.ChannelGain = IB_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IC] = {.ChannelGain = IC_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IN] = {.ChannelGain = IN_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IAM] = {.ChannelGain = IAM_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_IBM] = {.ChannelGain = IBM_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_ICM] = {.ChannelGain = ICM_DEFAULT_GAIN},
.CalibrationParameter[CALIBRATION_INM] = {.ChannelGain = INM_DEFAULT_GAIN}};


const static GpaiCorrInfo FactoryGpaiCorrInfo = {
.GpaiChParameter[GPAI0_RESERVED]    = {0.0F,            0.0F},
.GpaiChParameter[GPAI1_12VAN]       = {-0.0073259999F,  0.0F},
.GpaiChParameter[GPAI2_AIMODFB]     = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI3_12VAP]       = {0.00532F,        0.0F},
.GpaiChParameter[GPAI4_AICPFB]      = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI5_REF_DP]      = {0.719110012F,    0.0F},
.GpaiChParameter[GPAI6_AIOPFB]      = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI7_CTEMP]       = {0.0732600763F,   -50.0F},
.GpaiChParameter[GPAI8_BATV]        = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI9_RESERVED]    = {0.0F,            0.0F},
.GpaiChParameter[GPAI10_AICHV]      = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI11_RESERVED]   = {0.0F,            0.0F},
.GpaiChParameter[GPAI12_AIOPV]      = {0.0146520147F,   0.0F},
.GpaiChParameter[GPAI13_RESERVED]   = {0.0F,            0.0F},
.GpaiChParameter[GPAI14_RESERVED]   = {0.0F,            0.0F},
.GpaiChParameter[GPAI15_RESERVED]   = {0.0F,            0.0F}};

#endif /* FILE_DEFAULT_H_ */
