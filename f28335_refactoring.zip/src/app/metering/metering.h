/*
 * metering.h
 *
 *  Created on: 2023. 12. 22.
 *      Author: ShinSung Industrial Electric
 */

#ifndef METERING_METERING_H_
#define METERING_METERING_H_

#include "src/app/tag/tag_db.h"
#include "src/utils/circularbuf.h"


#define THERMAL_DEMAND_5MIN_CONSTANT    0.99233720239F
#define THERMAL_DEMAND_10MIN_CONSTANT   0.99616123313F
#define THERMAL_DEMAND_15MIN_CONSTANT   0.99744572297F
#define THERMAL_DEMAND_30MIN_CONSTANT   0.99871877019F


#define ROLLING_5M_CNT   300
#define DEMAND_5M_UNIT   5
#define ENERGY_LIMIT     3600

typedef enum
{
    DEMAND_5MIN = 5,
    DEMAND_10MIN = 10,
    DEMAND_15MIN = 15,
    DEMAND_30MIN = 30,
    DEMAND_60MIN = 60,

    DEMAND_TIME_MAX,

} DEMAND_TIME;

typedef enum
{
    DEMAND_RECORD_5MIN = 5,
    DEMAND_RECORD_10MIN = 10,
    DEMAND_RECORD_15MIN = 15,
    DEMAND_RECORD_30MIN = 30,
    DEMAND_RECORD_60MIN = 60,

} DEMAND_RECORD_TIME;

typedef enum
{
    DEMAND_ROLLING,
    DEMAND_THERMAL,

    DEMAND_TYPE_MAX,

} DEMAND_TYPE;

typedef enum
{
    /*Active Power*/
    DEMAND_KWA,
    DEMAND_KWB,
    DEMAND_KWC,
    DEMAND_KWTOTAL,

    /*Reactive Power*/
    DEMAND_KVARA,
    DEMAND_KVARB,
    DEMAND_KVARC,
    DEMAND_KVARTOTAL,

    DEMAND_IA,
    DEMAND_IB,
    DEMAND_IC,
    DEMAND_IN,
    DEMAND_3I0,
    DEMAND_3I2,

    DEMAND_MEASURING_MAX,

} DEMAND_MEASURING;


typedef enum
{
    ENERGY_APP_A = 0,
    ENERGY_APP_B,
    ENERGY_APP_C,
    ENERGY_APP_TOTAL,
    ENERGY_ACT_A,
    ENERGY_ACT_B,
    ENERGY_ACT_C,
    ENERGY_ACT_TOTAL,
    ENERGY_RCT_A,
    ENERGY_RCT_B,
    ENERGY_RCT_C,
    ENERGY_RCT_TOTAL,

    ENERGY_MEASURING_MAX,
} ENERGY_MEASURING;


typedef struct
{
    /*Time*/
    uint16                  SecCount;
    uint16                  DemandCntBySec;

    uint16                  DemandTimeout;

    DEMAND_TIME             DemandTime;
    DEMAND_TYPE             DemandType;

    DEMAND_RECORD_TIME      RecordTime;
    uint16                  LoadProfileTimeout;

    /*Point to TAG SC(ALS_SC_TIME)*/
    DEMAND_TIME*            pDemandTime;
    /*Point to TAG SC(ALS_SC_TYPE)*/
    DEMAND_TYPE*            pDemandType;
    /*Point to TAG SC(ALS_SC_LPTIME)*/
    DEMAND_RECORD_TIME*     pRecordTime;

    float32                 DemandCoefficient[DEMAND_MEASURING_MAX];
    CircularBuffer          CircularBuf[DEMAND_MEASURING_MAX];

    /*Demand Input(Point to the address the TAG AI is pointing to)*/
    float32*                pDemandInput[DEMAND_MEASURING_MAX];
    float32                 DemandSum[DEMAND_MEASURING_MAX];
    /*Demand Output(Point to TAG ACC)*/
    float32*                pDemandOutput[DEMAND_MEASURING_MAX];
    float32*                pDemandPeak[DEMAND_MEASURING_MAX];

    /*Energy Input*/
    float32*                pEnergyInput[ENERGY_MEASURING_MAX];
    /*Energy Output*/
    float32*                pEnergyInflow[ENERGY_MEASURING_MAX];
    float32*                pEnergyOutflow[ENERGY_MEASURING_MAX];

    /*Load profile*/
    EventHandle*            pDmdEvtHandle;
    EventHandle*            pEngEvtHandle;

    /*Point to TAG SC(ALS_DG_CPU_LOAD)*/
    uint16*                 pCpuLoad;

    /*Energy reset flag point to TAG RCM(ALS_RCM_ENG_ERASE)*/
    uint16*                 pEnergyReset;

} MeteringContext_t;

void Metering_Task(UArg arg0, UArg arg1);

MeteringContext_t* MeteringCtx_Get(void);
#endif /* METERING_METERING_H_ */
