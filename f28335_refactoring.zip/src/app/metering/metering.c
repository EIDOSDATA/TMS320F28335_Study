/*
 * metering.c
 *
 *  Created on: 2023. 12. 22.
 *      Author: ShinSung Industrial Electric
 */
#include <string.h>
#include "def.h"
#include "src/app/logging/event.h"
#include <src/app/calculation/calculation.h>
#include "src/app/metering/metering.h"


/*TagDB */
extern TAG_DB* TagDB_Get(void);

#define ONE_MIN     60

#pragma DATA_SECTION(MeteringCtx,   "ZONE6DATA")
#pragma DATA_SECTION(DemandAvgBuf,  "ZONE6DATA")

static float32 DemandAvgBuf[DEMAND_MEASURING_MAX][12];

static MeteringContext_t    MeteringCtx;

static void Metering_Init(MeteringContext_t*pMeteringCtx);
static void DemandProcessing(MeteringContext_t* pContext);
static void EnergyProcessing(MeteringContext_t* pContext);
static void ClearEnergy(void);


static void ClearEnergy(void)
{
    TAG_DB*  pTagDB  = TagDB_Get();

    memset(&pTagDB->ACC.ACC[0], 0, sizeof(float32)*(ALS_ACC_RCT_ETOTAL_OUT+1));

    SeqEvt_Push(TAG_GRP_RCM, ALS_RCM_ENG_ERASE, false);
}

MeteringContext_t* MeteringCtx_Get(void)
{
    return &MeteringCtx;
}

static void RollingDemand(MeteringContext_t* pContext)
{
    uint16 i;

    if(pContext->DemandCntBySec < 300)
    {
        float32** pDemandInput = pContext->pDemandInput;
        float32*  pCoefficient = &pContext->DemandCoefficient[0];

        for(i=DEMAND_KWA; i<DEMAND_MEASURING_MAX; i++)
        {
            pContext->DemandSum[i] += ((*pDemandInput[i])*(pCoefficient[i]));
        }

        pContext->DemandCntBySec++;

    }
    else
    {
        uint16 i,j;

        float32 Sum, Temp, PrevData;
        uint16  windowCnt =  pContext->DemandTime/5;
        float32 Avg = (float32)windowCnt;
        for(i=0; i<DEMAND_MEASURING_MAX; i++)
        {
            /*Pop previous data*/
            Sum = 0.0F;
            for(j = 1; j< windowCnt; j++)
            {
                CircularBufferPrevious_Get(&pContext->CircularBuf[i], &PrevData, j);
                Sum += PrevData;
            }

            Temp = pContext->DemandSum[i]/(float32)pContext->DemandCntBySec;
            Sum += Temp;
            pContext->DemandSum[i] = 0.0F;
            CircularBuffer_Push(&pContext->CircularBuf[i], &Temp);

            /*Update tag acc(average data)*/
            *pContext->pDemandOutput[i] = Sum/Avg;
        }
        pContext->DemandCntBySec = 0;
    }
}
static void ThermalDemand(MeteringContext_t* pContext)
{
    uint16    i;
    float32   PrevData, InputData, ThermalDemandTimeConst;
    float32*  pCoefficient = &pContext->DemandCoefficient[0];
    switch(*pContext->pDemandTime)
    {
        case DEMAND_5MIN:
            ThermalDemandTimeConst = THERMAL_DEMAND_5MIN_CONSTANT;
            break;
        case DEMAND_10MIN:
            ThermalDemandTimeConst = THERMAL_DEMAND_10MIN_CONSTANT;
            break;
        case DEMAND_15MIN:
            ThermalDemandTimeConst = THERMAL_DEMAND_15MIN_CONSTANT;
            break;
        case DEMAND_30MIN:
            ThermalDemandTimeConst = THERMAL_DEMAND_30MIN_CONSTANT;
            break;
        default:
            ThermalDemandTimeConst = 1.0F;
            break;
    }

    for(i=DEMAND_KWA; i<=DEMAND_3I2; i++)
    {
        InputData = ((*pContext->pDemandInput[i])*pCoefficient[i]);
        PrevData  = *pContext->pDemandOutput[i];

        PrevData += InputData;
        PrevData *= ThermalDemandTimeConst;

       *pContext->pDemandOutput[i] = PrevData + InputData;
    }

}
static void DemandProcessing(MeteringContext_t* pContext)
{
    uint16 i;

    switch(pContext->DemandType)
    {
        case DEMAND_ROLLING:
            RollingDemand(pContext);
            break;
        case DEMAND_THERMAL:
            ThermalDemand(pContext);
            break;
        default:
            /*Error Handling*/
            break;
    }

    /*Check Peak*/
    for(i=DEMAND_KWA; i<=DEMAND_3I2; i++)
    {
        if(fabsf(*pContext->pDemandPeak[i]) < fabsf(*pContext->pDemandOutput[i]))
        {
            *pContext->pDemandPeak[i] = *pContext->pDemandOutput[i];
        }
    }

    /*push loadprofile data*/
    if(pContext->SecCount == pContext->LoadProfileTimeout)
    {
        /*Record demand data(loadprofile data)*/
        DmdEvtFormat Instance;

        Instance.DemandActPowerA     = *pContext->pDemandOutput[DEMAND_KWA];
        Instance.DemandActPowerB     = *pContext->pDemandOutput[DEMAND_KWB];
        Instance.DemandActPowerC     = *pContext->pDemandOutput[DEMAND_KWC];
        Instance.DemandActPowerTotal = *pContext->pDemandOutput[DEMAND_KWTOTAL];

        Instance.DemandRctPowerA     = *pContext->pDemandOutput[DEMAND_KVARA];
        Instance.DemandRctPowerB     = *pContext->pDemandOutput[DEMAND_KVARB];
        Instance.DemandRctPowerC     = *pContext->pDemandOutput[DEMAND_KVARC];
        Instance.DemandRctPowerTotal = *pContext->pDemandOutput[DEMAND_KVARTOTAL];

        Instance.PeakDemandActPowerA     = *pContext->pDemandPeak[DEMAND_KWA];
        Instance.PeakDemandActPowerB     = *pContext->pDemandPeak[DEMAND_KWB];
        Instance.PeakDemandActPowerC     = *pContext->pDemandPeak[DEMAND_KWC];
        Instance.PeakDemandActPowerTotal = *pContext->pDemandPeak[DEMAND_KWTOTAL];

        Instance.PeakDemandRctPowerA     = *pContext->pDemandPeak[DEMAND_KVARA];
        Instance.PeakDemandRctPowerB     = *pContext->pDemandPeak[DEMAND_KVARB];
        Instance.PeakDemandRctPowerC     = *pContext->pDemandPeak[DEMAND_KVARC];
        Instance.PeakDemandRctPowerTotal = *pContext->pDemandPeak[DEMAND_KVARTOTAL];

        Instance.DemandIA  = *pContext->pDemandOutput[DEMAND_IA];
        Instance.DemandIB  = *pContext->pDemandOutput[DEMAND_IB];
        Instance.DemandIC  = *pContext->pDemandOutput[DEMAND_IC];
        Instance.DemandIN  = *pContext->pDemandOutput[DEMAND_IN];
        Instance.Demand3I0 = *pContext->pDemandOutput[DEMAND_3I0];
        Instance.Demand3I2 = *pContext->pDemandOutput[DEMAND_3I2];

        Instance.PeakDemandIA  = *pContext->pDemandPeak[DEMAND_IA];
        Instance.PeakDemandIB  = *pContext->pDemandPeak[DEMAND_IB];
        Instance.PeakDemandIC  = *pContext->pDemandPeak[DEMAND_IC];
        Instance.PeakDemandIN  = *pContext->pDemandPeak[DEMAND_IN];
        Instance.PeakDemand3I0 = *pContext->pDemandPeak[DEMAND_3I0];
        Instance.PeakDemand3I2 = *pContext->pDemandPeak[DEMAND_3I2];

        DmdEvt_Push(pContext->pDmdEvtHandle, &Instance);

        pContext->SecCount = 0;
    }
}

static void EnergyProcessing(MeteringContext_t* pContext)
{
    uint16 i;

    float32 Data;
    float32 PrevOutValue;
    for(i=ENERGY_APP_A; i<=ENERGY_RCT_TOTAL; i++)
    {
        Data = *pContext->pEnergyInput[i];
        Data /= 3600.0F;
        Data *= 0.001F;
        if(i<= ENERGY_APP_TOTAL)
        {
            *pContext->pEnergyOutflow[i] += Data;
        }
        else
        {
            if(Data > 0.0)
            {
                PrevOutValue = *pContext->pEnergyInflow[i];
                *pContext->pEnergyInflow[i] = PrevOutValue + Data;
            }
            else
            {
                PrevOutValue = *pContext->pEnergyOutflow[i];
                *pContext->pEnergyOutflow[i] = PrevOutValue + fabsf(Data);
            }
        }
    }

}


static void checkMeteringParameterChange(MeteringContext_t* pContext)
{
    /*demand type*/
    if(pContext->DemandType != *pContext->pDemandType)
    {
        pContext->DemandType = *pContext->pDemandType;
    }
    /*demand timeout*/
    if(pContext->DemandTime != *pContext->pDemandTime)
    {
        pContext->DemandTime    = *pContext->pDemandTime;
        pContext->DemandTimeout = ONE_MIN*pContext->DemandTime;
    }
    /*loadprofile timeout*/
    if(pContext->RecordTime != *pContext->pRecordTime)
    {
        pContext->RecordTime         = *pContext->pRecordTime;
        pContext->LoadProfileTimeout = ONE_MIN*pContext->RecordTime;
    }
}




static void Metering_Init(MeteringContext_t* pContext)
{
    uint16 DemandIndex, TagAI_Index, TagACC_Index, TagDemandPeakIndex;
    uint16 EnergyIndex;
    uint16 windowSize;

    memset(pContext, 0, sizeof(MeteringContext_t));

    TAG_DB* pTagDB = TagDB_Get();

    float32** pTagAI  = &pTagDB->AI.AI[0];
    float32*  pTagACC = &pTagDB->ACC.ACC[0];

    pContext->pDemandTime       = &pTagDB->SC.SC_UI[ALS_SC_TIME];
    pContext->pDemandType       = &pTagDB->SC.SC_UI[ALS_SC_TYPE];
    /*Set demand type*/
    pContext->DemandType        = *pContext->pDemandType;

    /*Set loadprofile timeout*/
    pContext->pRecordTime   = &pTagDB->SC.SC_UI[ALS_SC_LPTIME];
    DEMAND_RECORD_TIME RecordTime = *pContext->pRecordTime;
    pContext->LoadProfileTimeout  = ONE_MIN*RecordTime;

    //pContext->pCpuLoad      = &pTagDB->DG.DG_UI[ALS_DG_CPU_LOAD];
    pContext->pCpuLoad      = &pTagDB->DG.DG_UI[ALS_DG_CORE_LOAD];
    pContext->pEnergyReset  = &pTagDB->RCM.RCM[ALS_RCM_ENG_ERASE];

    DEMAND_TIME DemandTime  = *pContext->pDemandTime;

    /*Set demand time*/
    pContext->DemandTimeout = ONE_MIN*DemandTime;

    /*Point to Active, Reactive Power data*/
    for(DemandIndex = DEMAND_KWA,            TagAI_Index = ALS_AI_ACTIVE_A,
        TagACC_Index = ALS_ACC_DMD_ACT_PA,   TagDemandPeakIndex = ALS_ACC_PKDMD_ACT_PA;
        DemandIndex<=DEMAND_KVARTOTAL;)
    {
        pContext->pDemandInput[DemandIndex]        = pTagAI[TagAI_Index++];
        pContext->pDemandOutput[DemandIndex]       = &pTagACC[TagACC_Index++];
        pContext->pDemandPeak[DemandIndex]         = &pTagACC[TagDemandPeakIndex++];
        pContext->DemandCoefficient[DemandIndex++] = 0.001F;
    }
    /*Point to Current*/
    for(DemandIndex = DEMAND_IA,              TagAI_Index = ALS_AI_RMS_IA,
        TagACC_Index = ALS_ACC_DMD_IA,        TagDemandPeakIndex = ALS_ACC_PKDMD_IA;
        DemandIndex<=DEMAND_IN;)
    {
        pContext->pDemandInput[DemandIndex]        = pTagAI[TagAI_Index++];
        pContext->pDemandOutput[DemandIndex]       = &pTagACC[TagACC_Index++];
        pContext->pDemandPeak[DemandIndex]         = &pTagACC[TagDemandPeakIndex++];
        pContext->DemandCoefficient[DemandIndex++] = 1.0F;
    }

    /*Point to Symmetric*/
    pContext->pDemandInput[DEMAND_3I0]        = pTagAI[ALS_AI_RMS_I0];
    pContext->pDemandOutput[DEMAND_3I0]       = &pTagACC[ALS_ACC_DMD_3I0];
    pContext->pDemandPeak[DEMAND_3I0]         = &pTagACC[ALS_ACC_PKDMD_3I0];
    pContext->DemandCoefficient[DEMAND_3I0]   = 3.0F;

    pContext->pDemandInput[DEMAND_3I2]        = pTagAI[ALS_AI_RMS_I2];
    pContext->pDemandOutput[DEMAND_3I2]       = &pTagACC[ALS_ACC_DMD_3I2];
    pContext->pDemandPeak[DEMAND_3I2]         = &pTagACC[ALS_ACC_PKDMD_3I2];
    pContext->DemandCoefficient[DEMAND_3I2]   = 3.0F;

    /*
     * Energy
     */
    for(EnergyIndex = ENERGY_APP_A, TagAI_Index = ALS_AI_APPARENT_A, TagACC_Index = ALS_ACC_APP_EA;
        EnergyIndex<= ENERGY_RCT_TOTAL; )
    {
        if(EnergyIndex <= ENERGY_APP_TOTAL)
        {
            pContext->pEnergyInput[EnergyIndex]     = pTagAI[TagAI_Index++];
            pContext->pEnergyInflow[EnergyIndex]    = NULL;
            pContext->pEnergyOutflow[EnergyIndex++] = &pTagACC[TagACC_Index++];
        }
        else
        {
            pContext->pEnergyInput[EnergyIndex]     = pTagAI[TagAI_Index++];
            pContext->pEnergyInflow[EnergyIndex]    = &pTagACC[TagACC_Index++];
            pContext->pEnergyOutflow[EnergyIndex++] = &pTagACC[TagACC_Index++];
        }
    }

    /* Get event handle
     * Demand event -> load profile
     * Energy event -> energy log
     */
    pContext->pDmdEvtHandle = EventHandle_Get(EVENT_DEMAND);

    for(DemandIndex = DEMAND_KWA; DemandIndex < DEMAND_MEASURING_MAX; DemandIndex++)
    {
        CircularBufCreate(&pContext->CircularBuf[DemandIndex], FLOAT_TYPE, &DemandAvgBuf[DemandIndex][0], 12);
    }

}

void Metering_Task(UArg arg0, UArg arg1)
{
    MeteringContext_t* pContext = &MeteringCtx;

    Metering_Init(pContext);

    while(1)
    {
        TASK_SLEEP(1000);

        DemandProcessing(pContext);
        EnergyProcessing(pContext);

        pContext->SecCount++;
        /*Update CPU Load*/
        *pContext->pCpuLoad = CPU_LOAD_GET();

        /*Check Energy reset button(HMIS)*/
        if(*pContext->pEnergyReset == true)
        {
            *pContext->pEnergyReset = false;
            /*clear apparent, active, reactive energy*/
            ClearEnergy();
        }

        checkMeteringParameterChange(pContext);

    }
}
