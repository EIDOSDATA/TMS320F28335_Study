/*
 * mmiDisplay.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: ShinSung Industrial Electric
 */

#ifndef MMI_MMI_DISPLAY_H_
#define MMI_MMI_DISPLAY_H_

#include "def.h"
#include "time.h"
#include "src/app/tag/tag_db.h"
#include "src/common/file.h"
#include "src/app/logging/event.h"


#define COMMAND_BUF_SIZE        50

#define GLOBAL_MAX_CNT      19
#define CB_MAX_CNT          73
#define VIT_MAX_CNT         10
#define SCADA0_MAX_CNT      18
#define SCADA1_MAX_CNT      24

#define LINE_LARGE_MAX_CNT      25
#define LINE_MEDIUM_MAX_CNT     15
#define LINE_SMALL_MAX_CNT      5

#define PAGE_CONTENTS_LARGE_MAX_CNT     13
#define PAGE_CONTENTS_MEDIUM_MAX_CNT    30
#define PAGE_CONTENTS_SMALL_MAX_CNT     84

#define PARAM_DESC_RANGE_MAX_CNT            16
#define PARAM_DESC_RANGE_DUAL_MAX_CNT       2
#define PARAM_DESC_RANGE_OFF_MAX_CNT        28
#define PARAM_DESC_RANGE_CURSOR_MAX_CNT     85
#define PARAM_DESC_SELECT_MAX_CNT           5
#define PARAM_DESC_SELECT_NAME_MAX_CNT      36
#define PARAM_DESC_NAME_MAX_CNT             4

#define MmiTimeStartPosition                4
#define MmiTimeOffset                       3



typedef enum
{
    MMI_MODE_DISPLAY,
    MMI_MODE_EDIT,
    MMI_MODE_NOTICE_SUCCESS,
    MMI_MODE_NOTICE_FAIL,
    MMI_MODE_LAMP_TEST,
    MMI_MODE_BAT_TEST,

    MMI_MODE_MAX,

} MmiLCDModeEnum;

typedef enum
{
    MMI_YEAR_ONE  =4,    //�⵵�� ���� �ڸ��� ��ġ
    MMI_MONTH_ONE =7,    //����  ���� �ڸ��� ��ġ
    MMI_DAY_ONE   =10,   //����  ���� �ڸ��� ��ġ

    MMI_HOUR_ONE  =13,    //
    MMI_MIN_ONE   =16,    //
    MMI_SEC_ONE   =19,    //

} MmiTimePositionEnum;

// for type
typedef enum
{
    LCD_LEFT,
    LCD_RIGHT,
    LCD_UP,
    LCD_DOWN,
    LCD_MENU,
    LCD_ENTER,

} LCD_BUTTON_TYPE;

typedef enum
{
    PAGE_CTNS_TYPE_NONE,
    PAGE_CTNS_TYPE_SMALL,
    PAGE_CTNS_TYPE_MEDIUM,
    PAGE_CTNS_TYPE_LARGE,

    PAGE_CTNS_TYPE_MAX,

} PageContentsType;

typedef enum
{
    DISP_DATA_UINT = 0,
    DISP_DATA_FLOAT_0,
    DISP_DATA_FLOAT_1,
    DISP_DATA_FLOAT_2,

    DISP_DATA_FORMAT_MAX,
} DisplayDataType;

typedef enum
{
    LINE_CONTENTS_TYPE_A,
    LINE_CONTENTS_TYPE_B,
    LINE_CONTENTS_TYPE_C,

    LINE_CONTENTS_TYPE_MAX

} LineContentsType;

typedef enum
{
    PARAM_DESC_TYPE_NONE,

    PARAM_DESC_RANGE_TYPE,
    PARAM_DESC_RANGE_DUAL_TYPE,
    PARAM_DESC_RANGE_OFF_TYPE,
    PARAM_DESC_RANGE_CURSOR_TYPE,
    PARAM_DESC_SELECT_TYPE,
    PARAM_DESC_SELECT_NAME_TYPE,
    PARAM_DESC_NAME_TYPE,
    PARAM_TIME_TYPE,
    PARAM_PASSWORD_TYPE,


    PARAM_DESC_TYPE_MAX,

} ParamDescType;

// for property
typedef enum
{
    LINE_PRT_NONE = 0,
    LINE_PRT_TITLE,
    LINE_PRT_SELECT,
    LINE_PRT_INFO,
    LINE_PRT_DISPLAY_COMMON,
    LINE_PRT_SETTING_COMMON,

    LINE_PRT_SETTING_U,
    LINE_PRT_SETTING_F_0,
    LINE_PRT_SETTING_F_1,
    LINE_PRT_SETTING_F_2,

    LINE_PRT_DISPLAY_U,
    LINE_PRT_DISPLAY_F_0,
    LINE_PRT_DISPLAY_F_1,
    LINE_PRT_DISPLAY_F_2,

    LINE_PRT_MAX

} LineProperty;

typedef enum
{
    PAGE_PRT_NONE,
    PAGE_PRT_MEASURE,

    PAGE_PRT_DEFAULT,
    PAGE_PRT_SETTING,


    PAGE_PRT_GRP_COPY,
    PAGE_PRT_SAVE_SETTING,

    PAGE_PRT_PASSWORD,
    PAGE_PRT_SETTING_PASSWORD,

    PAGE_PRT_TIME,
    PAGE_PRT_SEQ_EVENT,
    PAGE_PRT_FLT_EVENT,
    PAGE_PRT_FLTWV_EVENT,
    PAGE_PRT_HW_INFO,
    PAGE_PRT_MODEL_NUM,
    PAGE_PRT_IDENTIFIER,
    PAGE_PRT_VERSION,
    PAGE_PRT_BAT_TEST,

    PAGE_PRT_MAX,

} PageProperty;

typedef enum
{
    TIME_SET_YEAR,
    TIME_SET_MON,
    TIME_SET_DAY,
    TIME_SET_HOUR,
    TIME_SET_MIN,
    TIME_SET_SEC,

    TIME_SET_MAX
} TimeSettingType;

//typedef enum
//{
//    PW_LEVEL_1,
//    PW_LEVEL_2,
//    PW_LEVEL_3,
//    PW_LEVEL_4,
//
//    PW_LEVEL_MAX,
//
//} PassWordType;

typedef struct
{
    float32**       pTAG_AI;
    uint16*         pTAG_DI;
    uint16*         pTAG_DO;
    uint16*         pTAG_BV;

    uint16*         pTAG_NMV_UI;
    float32*        pTAG_NMV_F;

    uint16*         pTAG_NVV_UI;
    float32*        pTAG_NVV_F;

    uint16*         pTAG_RCM;

    uint16*         pTAG_LS_UI;
    float32*        pTAG_LS_F;

    uint16*         pTAG_SC_UI;
    float32*        pTAG_SC_F;

    uint16*         pTAG_SIM_DI;
    float32*        pTAG_SIM_RMS;
    float32*        pTAG_SIM_ANGLE;
    float32*        pTAG_SIM_GPAI;

    uint16*         pTAG_DG;

    uint16*         pTAG_MMI;

} TagPointer;

//typedef struct
//{
//    TAG_GROUP               TagGroup;
//    uint16                  TagIndex;
//
//} TagData;

typedef struct
{
    TagData   Global[GLOBAL_MAX_CNT];
    TagData   Cb1[CB_MAX_CNT];
    TagData   Cb2[CB_MAX_CNT];
    TagData   Vit1[VIT_MAX_CNT];
    TagData   Vit2[VIT_MAX_CNT];
    TagData   Scada0[SCADA0_MAX_CNT];
    TagData   Scada1[SCADA1_MAX_CNT];

}GroupDataContents;
typedef struct
{
    LineProperty            property;

    union
    {
        uint32              ChildPageCode;
        TagData             TagParam;
    };

} LineParameter;

// for display contents

typedef struct
{
    char*                   pStr;
    LineParameter           LineParameter;

} LineContents_TypeA;

typedef struct
{
    char*                   pStr;
    LineParameter           LineParameter[2];

} LineContents_TypeB;

typedef struct
{
    char*                   pStr;
    LineParameter           LineParameter[3];

} LineContents_TypeC;

typedef struct
{
    LineContentsType    type;
    union {
        LineContents_TypeA  line_contents_A;
        LineContents_TypeB  line_contents_B;
        LineContents_TypeC  line_contents_C;
    };
} LineContents;

typedef struct
{
    PageProperty            property;
    uint32                  page_code;
    uint32                  parent_page_code;
    uint16                  line_content_cnt;
    LineContents            line_content[LINE_LARGE_MAX_CNT];
} PageContentsLarge;

typedef struct
{
    PageProperty            property;
    uint32                  page_code;
    uint32                  parent_page_code;
    uint16                  line_content_cnt;
    LineContents            line_content[LINE_MEDIUM_MAX_CNT];
} PageContentsMedium;

typedef struct
{
    PageProperty            property;
    uint32                  page_code;
    uint32                  parent_page_code;
    uint16                  line_content_cnt;
    LineContents            line_content[LINE_SMALL_MAX_CNT];
} PageContentsSmall;

typedef struct
{
    PageContentsSmall       page_content_s[PAGE_CONTENTS_SMALL_MAX_CNT];
    PageContentsMedium      page_content_m[PAGE_CONTENTS_MEDIUM_MAX_CNT];
    PageContentsLarge       page_content_l[PAGE_CONTENTS_LARGE_MAX_CNT];
} PageContents;

// for Line Parameter description contents

typedef struct {
    TagData             TagData;
    DisplayDataType     data_type;
    float32             min_val;
    float32             max_val;
    float32             Step;
    uint16              level;
    char*               pUnit;
} RangeTypeDesc;

typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             min_val_positive;
    float32             max_val_positive;
    float32             min_val_negative;
    float32             max_val_negative;
    float32             Step;
    uint16              level;
    char*               pUnit;
} RangeDualTypeDesc;

typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             min_val;
    float32             max_val;
    float32             Step;
    uint16              level;
    char*               pUnit;
} RangeOffTypeDesc;

typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             min_val;
    float32             max_val;
    float32             Step;
    uint16              level;
    char*               pUnit;
} RangeCursorTypeDesc;

typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             val[5];
    uint16              max_buf_cnt;
    uint16              level;
    char*               pUnit;
} SelectTypeDesc;


typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             val[3];
    char*               val_name[3];
    uint16              max_buf_cnt;
    uint16              level;
    char*               pUnit;
} SelectNameTypeDesc;

typedef struct
{
    TagData             TagData;
    DisplayDataType     data_type;
    float32             min_val;
    float32             max_val;
    uint16              level;
    char*               pUnit;
} NameTypeDesc;

typedef struct
{
    RangeTypeDesc       range_type[PARAM_DESC_RANGE_MAX_CNT];
    RangeDualTypeDesc   range_dual_type[PARAM_DESC_RANGE_DUAL_MAX_CNT];
    RangeOffTypeDesc    range_off_type[PARAM_DESC_RANGE_OFF_MAX_CNT];
    RangeCursorTypeDesc range_cursor_type[PARAM_DESC_RANGE_CURSOR_MAX_CNT];
    SelectTypeDesc      select_type[PARAM_DESC_SELECT_MAX_CNT];
    SelectNameTypeDesc  select_name_type[PARAM_DESC_SELECT_NAME_MAX_CNT];
    NameTypeDesc        name_type[PARAM_DESC_NAME_MAX_CNT];

} ParamDescContents;

// for setting context
typedef struct
{
    TagData                TagData;

    DisplayDataType         DisplayDataType;

    union
    {
        uint32              IntValue;
        float32             FloatValue;
    } ParameterValue;

} SettingBuf;

typedef struct
{
    SettingBuf              TempData[COMMAND_BUF_SIZE];
//    uint16                TempDataBufCnt;
} SettingContext;

//typedef struct _MmiPassword {
//    char                    password[PW_LEVEL_MAX][4];
//} MmiPassword;

typedef struct
{
    MmiPassword             setting_pw;
    bool                    setting_flag;
    PassWordType            setting_pw_level;
} PasswordSettingCtx;


typedef struct
{
//    bool                    IsEditing;

    union
    {
        int16               IntValue;
        float32             FloatValue;
    } ParameterValue;

    uint16                  TextLength;

    uint16                  EditLine;
    /*
     * MaximumDigit : 1    Value = 0    ~ 9
     * MaximumDigit : 2    Value = 10   ~ 99
     * MaximumDigit : 3    Value = 100  ~ 999
     * MaximumDigit : 4    Value = 1000 ~ 9999
     */
    uint16                  MaximumDigit;
    uint16                  CursorPosition;
    /*Only Float Value*/
    uint16                  DotPosition;
    uint16                  EndPosition;

    DisplayDataType         DisplayDataType;

    /*Select Name Type*/
    uint16                  SelectValueIndex;
    uint16                  SelectCnt;


    ParamDescContents*      pParamDescContents;

    uint16                  GroupNumber;

    ParamDescType           param_desc_type;
    float32                 param_step;
    float32                 param_maximum_value;
    float32*                pStep;
    char*                   pUnit;
    void*                   pData;
    TagData                 Current_TagData;


    RangeTypeDesc           *p_range_type;
    RangeDualTypeDesc       *p_range_dual_type;
    RangeOffTypeDesc        *p_range_off_type;
    RangeCursorTypeDesc     *p_range_cursor_type;
    SelectTypeDesc          *p_select_type;
    SelectNameTypeDesc      *p_select_name_type;
    NameTypeDesc            *p_name_type;

    PasswordSettingCtx       Password_Setting_Context;

} ParamEditContext;


typedef struct _SequentialEventContext {

    int          maxcount;
    int          currntindex;

    SeqEvtFormat*      pBuf;


} SequentialEventContext;

typedef struct _FaultEventContext {

    int          maxcount;
    int          currntindex;
    int          scrollflag;

    FltEvtFormat*      pBuf;


} FaultEventContext;

typedef struct _FaultWaveEventContext {

    int eventflag;

} FaultWaveEventContext;

typedef struct _CommonSettingCtx {
    TimeSettingType         current_setting_time_type;
    //struct tm               setting_time;
} CommonSettingCtx;




typedef struct
{
    MmiLCDModeEnum          mode;

    /*Time Pointer Info*/
    Mmi_TimeStamp*          pTime;
    Mmi_TimeStamp           SettingTime;


    /*Point to User Info*/
    PageContents            *p_page_content;
    GroupDataContents       *p_group_data_content;

    /*Current Page Info*/
    PageProperty            CurrentPageProperty;
    uint32                  CurrentPageCode;
    PageContentsType        current_page_type;
    PageContentsSmall       *p_latest_page_s;
    PageContentsMedium      *p_latest_page_m;
    PageContentsLarge       *p_latest_page_l;

    /*Current Line Info*/
    LineContentsType        CurrentLineContentsType;
    uint16                  CurrentLineMax;
    LineContents*           pLineContents;

    // for display context
    uint16                  CurrentPageLevel;
    uint16                  ViewCursorLevel1;
    uint16                  LineCursorLevel1;
    uint16                  ViewCursorLevel2;
    uint16                  LineCursorLevel2;
    uint16                  ViewCursorLevel3;
    uint16                  LineCursorLevel3;
    uint16                  ViewCursorLevel4;
    uint16                  LineCursorLevel4;
    uint16                  ViewCursorLevel5;
    uint16                  LineCursorLevel5;

    uint16                  view_cursor;
    uint16                  line_cursor;

    const char*             pBlank;


    uint16                  SettingLastIndex;
    SettingContext          SettingContext;
    ParamEditContext        param_edit_ctx_;

    uint16                  MainView_Scroll_Flag;

    MmiPassword             PasswordInfo;
    uint16                  LoginLevel;

    /*Event Page Info*/
    SequentialEventContext  SequentialEventContext;
    FaultEventContext       FaultEventContext;
    FaultWaveEventContext   FaultWaveEventContext;


} MmiDisplayContext;

/*
 * Interface
 */
MmiDisplayContext* MmiDisplayContext_Create(void* pMmiBlock4);
uint16* MmiTagPointer_Get(void);
uint16* BvTagPointer_Get(void);

void ParentPage_Search(MmiDisplayContext* pDisplayContext);
void ChildPage_Search(MmiDisplayContext* pDisplayContext);
void Page_Search(MmiDisplayContext* pDisplayContext,uint32 PageCode);


void MmiCursorMoveUp(MmiDisplayContext* pDisplayContext);
void MmiCursorMoveDown(MmiDisplayContext* pDisplayContext);

void MmiEditPageCursorMoveUp(MmiDisplayContext* pDisplayContext);
void MmiEditPageCursorMoveDown(MmiDisplayContext* pDisplayContext);

uint16 ParamCursorSet(MmiDisplayContext* pDisplayContext);

void ParamDescLine_Print(ParamEditContext* pParamEditContext);
void MainView_Display(MmiDisplayContext* pDisplayContext);

void TimePage_Print(MmiDisplayContext* pDisplayContext);
void ListPage_Print(MmiDisplayContext* pDisplayContext);
void SavePage_Print(MmiDisplayContext* pDisplayContext);
void BatteryTestPage_Print(MmiDisplayContext* pDisplayContext,uint16 count);
void SequentialEventPage_Print(MmiDisplayContext* pDisplayContext);
void FaultEventPage_Print(MmiDisplayContext* pDisplayContext);
void FaultWaveEventPage_Print(MmiDisplayContext* pDisplayContext);
void FW_VersionPage_Print(MmiDisplayContext* pDisplayContext);
void SystemInformationPage_Print(MmiDisplayContext* pDisplayContext,PageProperty Pagetype);


void SequentialPage_Set(MmiDisplayContext* pDisplayContext);
void FaultPage_Set(MmiDisplayContext* pDisplayContext);
void FaultWavePage_Set(MmiDisplayContext* pDisplayContext);

void MmiMenu_Scroll(MmiDisplayContext* pDisplayContext, LineContents* pLineContents, uint16 StrIndex);
void PageSearch(MmiDisplayContext* pDisplayContext, PageProperty PageProperty);

void Setting_Cancel(MmiDisplayContext* pDisplayContext);

void EditMode_Exit(MmiDisplayContext* pDisplayContext);
void EditPage_Print(MmiDisplayContext* pDisplayContext);

uint16 MmiTagData_AllSet(MmiDisplayContext* pDisplayContext);

uint16 GetParentpageCode(MmiDisplayContext* pDisplayContext);
uint16 MoveToMainMenuPage(MmiDisplayContext* pDisplayContext);


void TimeEditSet(MmiDisplayContext* pDisplayContext);
void PWEditSet(MmiDisplayContext* pDisplayContext);

void LoadPassword(MmiDisplayContext* pDisplayContext);

uint16 isEqualTagData(TagData* data1,TagData* data2);

/*
 * EditMode Handler
 */
void RangeTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void RangeDualTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void RangeOffTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void RangeCursorTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void SelectTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void SelectNameTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void NameTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
void TimeTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command);
#endif /* MMI_MMI_DISPLAY_H_ */
