/*
 * Mmi_macro.h
 *
 *  Created on: 2024. 1. 27.
 *      Author: ShinSung Industrial Electric
 */

#ifndef MMI_MMI_MACRO_H_
#define MMI_MMI_MACRO_H_

#include "src/app/tag/alias/Alias_MMI.h"

#define MMI_BLOCK0_GET(Block, Addr)               \
    Block  = *(Addr + ALS_MMI_LEDAC);             \
    Block |= (*(Addr + ALS_MMI_LEDCPU)<<1);       \
    Block |= (*(Addr + ALS_MMI_LED79RS)<<2);      \
    Block |= (*(Addr + ALS_MMI_LED79CY)<<3);      \
    Block |= (*(Addr + ALS_MMI_LED79LO)<<4);      \
    Block |= (*(Addr + ALS_MMI_LEDFLTA)<<5);      \
    Block |= (*(Addr + ALS_MMI_LEDFLTB)<<6);      \
    Block |= (*(Addr + ALS_MMI_LEDFLTC)<<7);      \
    Block =  ~Block

#define MMI_BLOCK1_GET(Block, Addr)                \
    Block  =  *(Addr + ALS_MMI_LEDFLTN);           \
    Block |= (*(Addr + ALS_MMI_LEDFLTSEF)<<1);     \
    Block |= (*(Addr + ALS_MMI_LEDBATTB)<<2);      \
    Block |= (*(Addr + ALS_MMI_LEDHLOCK)<<3);      \
    Block |= (*(Addr + ALS_MMI_LEDLOAD)<<4);       \
    Block |= (*(Addr + ALS_MMI_LEDBUMP)<<5);       \
    Block |= (*(Addr + ALS_MMI_LEDABC)<<6);        \
    Block |= (*(Addr + ALS_MMI_LEDOC)<<7);         \
    Block =  ~Block

#define MMI_BLOCK2_GET(Block, Addr)                \
    Block  =  *(Addr + ALS_MMI_LEDHIGH);           \
    Block |= (*(Addr + ALS_MMI_LED81)<<1);         \
    Block |= (*(Addr + ALS_MMI_LEDDIAGNOSFAIL)<<2);\
    Block |= (*(Addr + ALS_MMI_LEDSCH)<<3);        \
    Block |= (*(Addr + ALS_MMI_LEDLOV)<<4);        \
    Block |= (*(Addr + ALS_MMI_LEDSOURCE)<<5);     \
    Block |= (*(Addr + ALS_MMI_LEDCBA)<<6);        \
    Block |= (*(Addr + ALS_MMI_LEDPROT)<<7);       \
    Block  = ~Block

#define MMI_BLOCK3_GET(Block, Addr)                \
    Block  =  *(Addr + ALS_MMI_LEDRC);             \
    Block |= (*(Addr + ALS_MMI_LEDGND)<<1);        \
    Block |= (*(Addr + ALS_MMI_LEDSEF)<<2);        \
    Block |= (*(Addr + ALS_MMI_LEDRT)<<3);         \
    Block |= (*(Addr + ALS_MMI_LEDCLP)<<4);        \
    Block |= (*(Addr + ALS_MMI_LEDCLOSE)<<5);      \
    Block |= (*(Addr + ALS_MMI_LEDHT)<<6);         \
    Block |= (*(Addr + ALS_MMI_LEDRNC)<<7);        \
    Block =  ~Block

#define MMI_BLOCK4_GET(Block, Addr)                \
    Block  =  *(Addr + ALS_MMI_LEDLNC);            \
    Block |= (*(Addr + ALS_MMI_LEDLNO)<<1);        \
    Block |= (*(Addr + ALS_MMI_LEDA2R)<<2);        \
    Block |= (*(Addr + ALS_MMI_LEDR2A)<<3);        \
    Block |= (*(Addr + ALS_MMI_LEDTRIP)<<4);       \
    Block =  ~Block

#define MMI_BLOCK6_GET(Block, Addr)                \
    Block  =  *(Addr + ALS_MMI_LEDFLTA_Y);         \
    Block |= (*(Addr + ALS_MMI_LEDFLTB_Y)<<1);     \
    Block |= (*(Addr + ALS_MMI_LEDFLTC_Y)<<2);     \
    Block |= (*(Addr + ALS_MMI_LEDFLTN_Y)<<3);     \
    Block |= (*(Addr + ALS_MMI_LEDSG1)<<4);        \
    Block |= (*(Addr + ALS_MMI_LEDSG2)<<5);        \
    Block |= (*(Addr + ALS_MMI_LEDV79RS)<<6);      \
    Block |= (*(Addr + ALS_MMI_LEDV79CY)<<7);      \
    Block =  ~Block


#endif /* MMI_MMI_MACRO_H_ */
