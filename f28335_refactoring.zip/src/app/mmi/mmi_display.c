/*
 * MmiDisplay.c
 *
 *  Created on: 2024. 1. 23.
 *      Author: ShinSung Industrial Electric
 */
#include <src/app/mmi/mmi_display.h>
#include <stdio.h>
#include "def.h"
#include "src/port/clcd.h"

#include "Application/MmiParam.h"

#include "Application/UserLogicDefault.h"

#define MMI_PRINTF_BUFFER_SIZE      21
/*Floating Point*/
#define EXTRACT_HUNDREDTHS_PLACE(Value) ((int32)(Value*100)%10)
#define EXTRACT_TENTHS_PLACE(Value)     ((int32)(Value*10)%10)
#define EXTRACT_ONES_PLACE(Value)       (((int32)Value)%10)
#define EXTRACT_TENS_PLACE(Value)       ((int32)(Value/10)%10)
#define EXTRACT_HUNDREDS_PLACE(Value)   ((int32)(Value/100)%10)
#define EXTRACT_THOUSANDS_PLACE(Value)  ((int32)(Value/1000)%10)

static const char* pBlank = "                    ";

static MmiDisplayContext   MmiDisplayContextObject;
static CLCD_Module* pLCD_Device;
static TagPointer   TagPointerObject;


static uint16 ParamDescLine_Make(ParamEditContext*   pParamEditContext, char* pLineBuf);

static void LineInfo_Update(MmiDisplayContext* pDisplayContext);
static void Mmi_Printf(char *fmt, ...);
static uint16 Mmi_Vsprintf(char* pBuf, char *fmt, ...);
static void ParamDesc_Search(ParamEditContext*  pParamEditContext, TagData* pTagData);
static uint16 SelectNameTypeValue_Check(LineProperty LineProperty, float32* pDescValue, void* pData);
static int NameType_Print(ParamEditContext* pParamEditContext,char* pBuf);
static uint16 LineString_Make(LineProperty LineProperty, char* pBuf, void* pData);
//static void* MmiTagDataAddr_Get(TagData* pTagData);

static uint16 Format_Print(DisplayDataType DisplayType, char* pBuf, void* pData);

uint16 GetParentpageCode(MmiDisplayContext* pDisplayContext)
{
    uint16 ParentPageCode=0;

    if(pDisplayContext->current_page_type==PAGE_CTNS_TYPE_SMALL)
        ParentPageCode=pDisplayContext->p_latest_page_s->parent_page_code;
    else if(pDisplayContext->current_page_type==PAGE_CTNS_TYPE_MEDIUM)
        ParentPageCode=pDisplayContext->p_latest_page_m->parent_page_code;
    else if(pDisplayContext->current_page_type==PAGE_CTNS_TYPE_LARGE)
        ParentPageCode=pDisplayContext->p_latest_page_l->parent_page_code;

    return ParentPageCode;
}

uint16 MoveToMainMenuPage(MmiDisplayContext* pDisplayContext)
{
    pDisplayContext->view_cursor = 1;
    pDisplayContext->line_cursor = 1;
    pDisplayContext->CurrentPageLevel=1;

    while(!(pDisplayContext->CurrentPageCode==MAIN_VIEW))
    {
        ParentPage_Search(pDisplayContext);
    }
}


static inline void Mmi_Goto(uint16 y, uint16 x)
{
    pLCD_Device->pfLCD_Goto(y, x);
}

static void MmiCursorLine_Move(uint16 DeleteLine, uint16 AddLine)
{
    Mmi_Goto(DeleteLine, 0);
    Mmi_Printf(" ");

    Mmi_Goto(AddLine, 0);
    Mmi_Printf(">");
}

void MmiCursorMoveUp(MmiDisplayContext* pDisplayContext)
{

    if (pDisplayContext->CurrentLineMax <= 2) return; //Error process
    else if(pDisplayContext->CurrentLineMax <= 3)
    {
        pDisplayContext->line_cursor--;
        if(pDisplayContext->line_cursor == 0)
        {
            pDisplayContext->view_cursor = pDisplayContext->CurrentLineMax-1;
            pDisplayContext->line_cursor = pDisplayContext->view_cursor;
            MmiMenu_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor-1);
            MmiCursorLine_Move(pDisplayContext->view_cursor, 2);
        }
        else
        {
                MmiCursorLine_Move(pDisplayContext->view_cursor, --pDisplayContext->view_cursor);
        }

    }
    else
    {

    pDisplayContext->line_cursor--;

    if(pDisplayContext->line_cursor == 0)
    {
        pDisplayContext->view_cursor = 3;
        pDisplayContext->line_cursor = pDisplayContext->CurrentLineMax - 1;
        MmiMenu_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor-2);
        MmiCursorLine_Move(pDisplayContext->view_cursor, 3);
    }
    else
    {
        if (pDisplayContext->view_cursor > 1)
        {
            MmiCursorLine_Move(pDisplayContext->view_cursor, --pDisplayContext->view_cursor);
        }
        else
        {
            MmiMenu_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor);
            MmiCursorLine_Move(pDisplayContext->view_cursor, pDisplayContext->view_cursor);
        }
    }
    }
}

void MmiCursorMoveDown(MmiDisplayContext* pDisplayContext)
{
    if (pDisplayContext->CurrentLineMax <= 1) return; //Error process

    pDisplayContext->line_cursor++;
        if(pDisplayContext->line_cursor == pDisplayContext->CurrentLineMax)
        {
            pDisplayContext->view_cursor = 1;
            pDisplayContext->line_cursor = 1;
            MmiMenu_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor);
            MmiCursorLine_Move(3, 1);
        }
        else
        {

            if (pDisplayContext->view_cursor < 3)
            {
                MmiCursorLine_Move(pDisplayContext->view_cursor, ++pDisplayContext->view_cursor);
            }
            else
            {
                MmiMenu_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor-2);
                MmiCursorLine_Move(pDisplayContext->view_cursor, pDisplayContext->view_cursor);
            }
        }
}

void MmiEditPageCursorMoveUp(MmiDisplayContext* pDisplayContext)
{
    if (pDisplayContext->CurrentLineMax > 2)
    {
           pDisplayContext->line_cursor--;

           if (pDisplayContext->line_cursor == 0) //First Line in current Page
               {
               pDisplayContext->line_cursor = pDisplayContext->CurrentLineMax - 1; //Set Last Line in Current Page
               pDisplayContext->view_cursor = 2; // ">" position move to second line (because third line is parameter line)
               MmiEdit_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor - 1);
               MmiCursorLine_Move(pDisplayContext->view_cursor, 2);
               }
           else
           {
               if (pDisplayContext->view_cursor == 1)
               {
               MmiEdit_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor);
               MmiCursorLine_Move(pDisplayContext->view_cursor, pDisplayContext->view_cursor);
               }
               else
                   MmiCursorLine_Move(pDisplayContext->view_cursor--, pDisplayContext->view_cursor);

           }

    }
}

void MmiEditPageCursorMoveDown(MmiDisplayContext* pDisplayContext)
{
    if (pDisplayContext->CurrentLineMax > 2)
    {
           pDisplayContext->line_cursor++;

           if (pDisplayContext->view_cursor == 2) //Do Scroll
           {
               if (pDisplayContext->line_cursor == pDisplayContext->CurrentLineMax) //Last Line in current Page
               {
                   pDisplayContext->line_cursor = 1; //Set First Line in Current Page
                   pDisplayContext->view_cursor = 1; // ">" position move to first line
                   MmiEdit_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor);
                   MmiCursorLine_Move(2, 1);
               }
               else
               {
                   MmiEdit_Scroll(pDisplayContext, pDisplayContext->pLineContents, pDisplayContext->line_cursor - 1);
                   MmiCursorLine_Move(pDisplayContext->view_cursor, pDisplayContext->view_cursor);
               }
           }
           else
           {
               MmiCursorLine_Move(pDisplayContext->view_cursor++, pDisplayContext->view_cursor);
           }
    }
}

uint16 isLS_TagData(uint16 TagGroup)
{
    return (TagGroup == TAG_GRP_LS_UI || TagGroup == TAG_GRP_LS_F) ? 1 : 0;
}
void SetLSGroupTagData(uint16 GroupNum,TagData* pTagData)
{
            switch(GroupNum)
            {
                 case 1:
                     if(pTagData->TagGroup==TAG_GRP_LS_UI)
                         pTagData->TagGroup=TAG_GRP_LS0_UI;
                     else
                         pTagData->TagGroup=TAG_GRP_LS0_F;
                     break;
                 case 2:
                     if(pTagData->TagGroup==TAG_GRP_LS_UI)
                         pTagData->TagGroup=TAG_GRP_LS1_UI;
                     else
                         pTagData->TagGroup=TAG_GRP_LS1_F;
                     break;
                 default:
                     break;
             }
}

static void ParamDescContents_Search(ParamEditContext* pParamEditContext, TagData* pTagData)
{
    uint16 i;
    uint16 GroupNum = pParamEditContext->GroupNumber;
    ParamDescContents*  pParamDescContents = pParamEditContext->pParamDescContents;

    pParamEditContext->p_range_type         = NULL;
    pParamEditContext->p_range_dual_type    = NULL;
    pParamEditContext->p_range_off_type     = NULL;
    pParamEditContext->p_range_cursor_type  = NULL;
    pParamEditContext->p_select_type        = NULL;
    pParamEditContext->p_select_name_type   = NULL;
    pParamEditContext->p_name_type          = NULL;

    /*Range Type*/
    for(i=0;i<PARAM_DESC_RANGE_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->range_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type = PARAM_DESC_RANGE_TYPE;
            pParamEditContext->param_maximum_value = pParamDescContents->range_type[i].max_val;
            pParamEditContext->p_range_type    = &pParamDescContents->range_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->range_type[i].data_type;

            pParamEditContext->pStep                = &pParamDescContents->range_type[i].Step;
            pParamEditContext->pUnit                = pParamDescContents->range_type[i].pUnit;
        }
    }
    /*Range Dual Type*/
    for(i=0;i<PARAM_DESC_RANGE_DUAL_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->range_dual_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type   = PARAM_DESC_RANGE_DUAL_TYPE;
            pParamEditContext->param_maximum_value = pParamDescContents->range_dual_type[i].max_val_positive;
            pParamEditContext->p_range_dual_type = &pParamDescContents->range_dual_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->range_dual_type[i].data_type;

            pParamEditContext->pStep                = &pParamDescContents->range_dual_type[i].Step;
            pParamEditContext->pUnit                = pParamDescContents->range_dual_type[i].pUnit;
        }
    }
    /*Range Off Type*/
    for(i=0;i<PARAM_DESC_RANGE_OFF_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->range_off_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type  = PARAM_DESC_RANGE_OFF_TYPE;
            pParamEditContext->param_maximum_value = pParamDescContents->range_off_type[i].max_val;
            pParamEditContext->p_range_off_type = &pParamDescContents->range_off_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->range_off_type[i].data_type;

            pParamEditContext->pStep                = &pParamDescContents->range_off_type[i].Step;
            pParamEditContext->pUnit                = pParamDescContents->range_off_type[i].pUnit;
        }
    }
    /*Range Cursor Type*/
    for(i=0;i<PARAM_DESC_RANGE_CURSOR_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->range_cursor_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type     = PARAM_DESC_RANGE_CURSOR_TYPE;
            pParamEditContext->param_maximum_value = pParamDescContents->range_cursor_type[i].max_val;
            pParamEditContext->p_range_cursor_type = &pParamDescContents->range_cursor_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->range_cursor_type[i].data_type;

            pParamEditContext->pStep                = &pParamDescContents->range_cursor_type[i].Step;
            pParamEditContext->pUnit                = pParamDescContents->range_cursor_type[i].pUnit;
        }
    }
    /*Select Type*/
    for(i=0;i<PARAM_DESC_SELECT_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->select_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type = PARAM_DESC_SELECT_TYPE;
            pParamEditContext->param_maximum_value = pParamDescContents->select_type[i].val[4];
            *pParamEditContext->pStep = 0;
            pParamEditContext->p_select_type   = &pParamDescContents->select_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->select_type[i].data_type;

            pParamEditContext->pUnit                = pParamDescContents->select_type[i].pUnit;
        }
    }
    /*Select Name Type*/
    for(i=0;i<PARAM_DESC_SELECT_NAME_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->select_name_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type    = PARAM_DESC_SELECT_NAME_TYPE;
            pParamEditContext->param_maximum_value = strlen(pParamDescContents->select_name_type[i].val_name[0]);
            *pParamEditContext->pStep = 0;
            pParamEditContext->SelectCnt          = pParamDescContents->select_name_type[i].max_buf_cnt;
            pParamEditContext->p_select_name_type = &pParamDescContents->select_name_type[i];

            pParamEditContext->DisplayDataType      = pParamDescContents->select_name_type[i].data_type;
            pParamEditContext->pUnit                = pParamDescContents->select_name_type[i].pUnit;
        }
    }
    /*Name Type*/
    for(i=0;i<PARAM_DESC_NAME_MAX_CNT; i++)
    {
        if(memcmp(pTagData, &pParamDescContents->name_type[i].TagData, sizeof(TagData)) == 0)
        {
            pParamEditContext->param_desc_type = PARAM_DESC_NAME_TYPE;
            pParamEditContext->param_maximum_value = 1;
            *pParamEditContext->pStep = 0;
            pParamEditContext->p_name_type     = &pParamDescContents->name_type[i];
            pParamEditContext->DisplayDataType = pParamDescContents->name_type[i].data_type;

            pParamEditContext->pUnit                = pParamDescContents->name_type[i].pUnit;
        }
    }
    return;
}

uint16 ParamCursorSet(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    LineContents*     pLineContents = pDisplayContext->pLineContents;
    float32 value;

    /*The Settings page line only has Type A.*/
    pParamEditContext->TextLength = strlen(pLineContents[pDisplayContext->line_cursor].line_contents_A.pStr);
    pParamEditContext->CursorPosition     = pParamEditContext->TextLength;

    if(pParamEditContext->DisplayDataType==DISP_DATA_UINT)
        value=(float32)pParamEditContext->ParameterValue.IntValue;
    else
        value=pParamEditContext->ParameterValue.FloatValue;



    if( value< 10.0) pParamEditContext->MaximumDigit   = 1;
    else if(value < 100.0) pParamEditContext->MaximumDigit   = 2;
    else if(value < 1000.0) pParamEditContext->MaximumDigit   = 3;
    else if(value< 10000.0) pParamEditContext->MaximumDigit   = 4;


    pParamEditContext->EndPosition    = pParamEditContext->CursorPosition + pParamEditContext->MaximumDigit - 1;
    pParamEditContext->DotPosition    = pParamEditContext->CursorPosition + pParamEditContext->MaximumDigit;


    if(*pParamEditContext->pStep==0.0 || *pParamEditContext->pStep>=1.0)
        pParamEditContext->CursorPosition = pParamEditContext->EndPosition;
    else if(*pParamEditContext->pStep<0.1)
    {
        pParamEditContext->CursorPosition = pParamEditContext->DotPosition+2;
        pParamEditContext->EndPosition=pParamEditContext->CursorPosition;
    }
    else
    {
        pParamEditContext->CursorPosition = pParamEditContext->DotPosition+1;
        pParamEditContext->EndPosition=pParamEditContext->CursorPosition;
    }


    /*LCD x, y*/
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);
    /*LED Blink*/
    pLCD_Device->pfLCD_Control(CLCD_DISPLAY_CURSOR_BLINK);
}

void PageSearch(MmiDisplayContext* pDisplayContext, PageProperty PageProperty)
{
    uint16 i;
    for(i=0; i<PAGE_CONTENTS_SMALL_MAX_CNT; i++)
    {
        if(pDisplayContext->p_page_content->page_content_s[i].property == PageProperty)
        {
            pDisplayContext->CurrentPageProperty = PageProperty;
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_SMALL;
            pDisplayContext->p_latest_page_s     = &pDisplayContext->p_page_content->page_content_s[i];
            pDisplayContext->pLineContents       = &pDisplayContext->p_latest_page_s->line_content[0];
            pDisplayContext->CurrentLineMax      = pDisplayContext->p_latest_page_s->line_content_cnt;
            return;
        }
    }

    for(i=0; i<PAGE_CONTENTS_MEDIUM_MAX_CNT; i++)
    {
        if(pDisplayContext->p_page_content->page_content_m[i].property == PageProperty)
        {
            pDisplayContext->CurrentPageProperty = PageProperty;
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_MEDIUM;
            pDisplayContext->p_latest_page_m     = &pDisplayContext->p_page_content->page_content_m[i];
            pDisplayContext->pLineContents       = &pDisplayContext->p_latest_page_m->line_content[0];
            pDisplayContext->CurrentLineMax      = pDisplayContext->p_latest_page_m->line_content_cnt;

            return;
        }
    }

    for(i=0; i<PAGE_CONTENTS_LARGE_MAX_CNT; i++)
        {
            if(pDisplayContext->p_page_content->page_content_l[i].property == PageProperty)
            {
                pDisplayContext->CurrentPageProperty = PageProperty;
                pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_LARGE;
                pDisplayContext->p_latest_page_l     = &pDisplayContext->p_page_content->page_content_l[i];
                pDisplayContext->pLineContents       = &pDisplayContext->p_latest_page_l->line_content[0];
                pDisplayContext->CurrentLineMax      = pDisplayContext->p_latest_page_l->line_content_cnt;
                return;
            }
        }
}

void MmiMenu_Scroll(MmiDisplayContext* pDisplayContext, LineContents* pLineContents, uint16 StrIndex)
{
    uint16 i,Len;
    char* pStr;
    char Buf[21];

    LineProperty Lineproperty;
    LineContentsType LineContentsType;
    TagData* pTagData;

    void*  pData;

    pLineContents+=StrIndex;

    for(i=1; i<=3; i++)
    {
        pStr = pLineContents->line_contents_A.pStr;
        LineContentsType = pLineContents->type;

        snprintf(Buf, sizeof(Buf), "%-20s", pStr); //string line print
        Len = strlen(pStr);


        uint16 paramCount = (LineContentsType == LINE_CONTENTS_TYPE_A) ? 1 : 2;
        uint16 j=0;

        for(j=0;j<paramCount;j++)
        {
            Lineproperty = pLineContents->line_contents_B.LineParameter[j].property;
            pTagData = &pLineContents->line_contents_B.LineParameter[j].TagParam;
            pData = TagDataAddr_Get(pTagData);

            Len+=LineString_Make(Lineproperty, Buf+Len, pData);

            if(paramCount>1)
            {
                Buf[Len]=' ';
                Len++;

            }
        }


        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }

        Mmi_Goto(i, 0);
        Mmi_Printf("%s", Buf);

        pLineContents++;

    }

    if(pDisplayContext->CurrentLineMax<=3)
    {
        uint16 DeleteLineCount = 4-pDisplayContext->CurrentLineMax;
        int DeleteLine=3;
        while(DeleteLineCount)
        {
            Mmi_Goto(DeleteLine, 0);
            Mmi_Printf("                    ");

            DeleteLineCount--;
            DeleteLine--;
        }
    }
}




void MmiEdit_Scroll(MmiDisplayContext* pDisplayContext, LineContents* pLineContents, uint16 StrIndex)
{
    uint16 i,j,Len;

    ParamEditContext* pParamEditContext =&pDisplayContext->param_edit_ctx_;
    SettingContext*   pSettingContext = &pDisplayContext->SettingContext;

    TagData*      pTagData;
    LineProperty    LineProperty;

    char Buf[21];
    char* pStr   = NULL;
    void*  pData = pParamEditContext->pData;

    pLineContents+=StrIndex;
    for(i=1; i<=2; i++)
    {

        pStr = pLineContents->line_contents_A.pStr;
        LineProperty =  pLineContents->line_contents_A.LineParameter.property;
        pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;
        ParamDescContents_Search(&pDisplayContext->param_edit_ctx_, pTagData);

        /*Copy line string to buffer*/
        Len = snprintf(Buf, sizeof(Buf), "%s", pStr);

        TagData  EditTagData;

        EditTagData.TagIndex=pTagData->TagIndex;
        EditTagData.TagGroup=pTagData->TagGroup;

        if(isLS_TagData(pTagData->TagGroup))
        {
            SetLSGroupTagData(pParamEditContext->GroupNumber,&EditTagData);
        }
        pParamEditContext->pData = TagDataAddr_Get(&EditTagData);

        //isExistingSettingData
        for(j=0;j<COMMAND_BUF_SIZE;j++)
        {
            if(isEqualTagData(&EditTagData,&pSettingContext->TempData[j].TagData))
            {
                if(pSettingContext->TempData[j].DisplayDataType==DISP_DATA_UINT)
                    pData=&pSettingContext->TempData[j].ParameterValue.IntValue;
                else
                    pData=&pSettingContext->TempData[j].ParameterValue.FloatValue;
                break;
            }
            else
                pData=pDisplayContext->param_edit_ctx_.pData;

        }
        //isExistingSettingData

        Len += DataLine_Print(&pDisplayContext->param_edit_ctx_, LineProperty, Buf+Len, pData);

        if(Len < 20) {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }

        Mmi_Goto(i, 0);
        Mmi_Printf("%s", Buf);

        pLineContents++;

    }
}

void ListPage_Print(MmiDisplayContext* pDisplayContext)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;

    uint16 offset = pDisplayContext->view_cursor - 1;
    uint16 StrIndex = pDisplayContext->line_cursor - offset;

    char Buf[21] = {0}; // ��� ����

      //Title print
      snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
      Mmi_Goto(0, 0);
      Mmi_Printf("%s", Buf);

      MmiMenu_Scroll(pDisplayContext, pLineContents, StrIndex);

      Mmi_Goto(pDisplayContext->view_cursor, 0);
      Mmi_Printf(">");
}

void SavePage_Print(MmiDisplayContext* pDisplayContext)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;

    uint16 offset = pDisplayContext->view_cursor - 1;
    uint16 StrIndex = pDisplayContext->line_cursor - offset;

    char Buf[21] = {0}; // ��� ����

      //Title print
      snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
      Mmi_Goto(0, 0);
      Mmi_Printf("%s", Buf);

      MmiMenu_Scroll(pDisplayContext, pLineContents, StrIndex);

}

uint16 LsGroupName_Get(TagData* pTagData,char* pBuf)
{
    uint16 Len;

    if(pTagData->TagIndex>=512)
    {
        Len = snprintf(pBuf, 20, "LS1_");
        pTagData->TagIndex -= 512;
    }
    else if(pTagData->TagIndex>=256)
    {
        Len = snprintf(pBuf, 20, "LS0_");
        pTagData->TagIndex -= 256;
    }
    else
    {
        Len = snprintf(pBuf, 20, "LS_");
    }

    return Len;
}


void SequentialEventPage_Print(MmiDisplayContext* pDisplayContext)
{
    SequentialEventContext*  pSequentialEventContext  = &pDisplayContext->SequentialEventContext;
    SeqEvtFormat*            pSequentialEventData     = pSequentialEventContext->pBuf;
    Mmi_TimeStamp            EventOccurTime;
    uint16 Len;

    char Buf[21] = {0}; // ��� ����

    //Title print
    snprintf(Buf, sizeof(Buf), "%-20s", pDisplayContext->pLineContents->line_contents_A.pStr);
    Mmi_Goto(0, 0);
    Mmi_Printf("%s", Buf);

    if(pSequentialEventContext->maxcount==0)
    {
        Mmi_Goto(1, 0);
        Mmi_Printf("                    ");
        Mmi_Goto(2, 0);
        Mmi_Printf("       EMPTY        ");
        Mmi_Goto(3, 0);
        Mmi_Printf("                    ");
        return;
    }

    pSequentialEventData+=pSequentialEventContext->currntindex;
    ConvertHMISToMmiTimeStamp(&pSequentialEventData->TimeData,&EventOccurTime);


    //current index & event time (year/month/day) print
    Len=snprintf(Buf, sizeof(Buf), "%02d/%02d     %02d.%02d.%02d",
                 pSequentialEventContext->currntindex+1,
                 pSequentialEventContext->maxcount,
                 EventOccurTime.Year,
                 EventOccurTime.Month,
                 EventOccurTime.Day);

    if(Len < 20)
    {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
    }

    Mmi_Goto(1, 0);
    Mmi_Printf("%s", Buf);

    //event time (hour/min/sec/msec) print
    Len=snprintf(Buf, sizeof(Buf), "%02d:%02d:%02d:%02d",
                 EventOccurTime.Hour,
                 EventOccurTime.Min,
                 EventOccurTime.Sec,
                 EventOccurTime.msec);

    if(Len < 20)
    {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); //
    }

    Mmi_Goto(2, 0);
    Mmi_Printf("%s", Buf);

    //Tag Name   status :  print

    memset(Buf,0,sizeof(Buf));
    TagData EventTagData;
    uint16 GroupName_Len=0;
    TagData_Extract(&EventTagData,pSequentialEventData->TagID);
    if(EventTagData.TagGroup==8)
    {
        GroupName_Len = LsGroupName_Get(&EventTagData,Buf);
    }
    TagDataName_Get(&EventTagData,Buf+GroupName_Len);

    Len = strlen(Buf);
    if(Len < 20)
    {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
    }
    Len+=snprintf(Buf+12, sizeof(Buf)-12, "status:%0d",pSequentialEventData->Value);



    Mmi_Goto(3, 0);
    Mmi_Printf("%s", Buf);

}

void FaultEventPage_Print(MmiDisplayContext* pDisplayContext)
{
    FaultEventContext*       pFaultEventContext  = &pDisplayContext->FaultEventContext;
    FltEvtFormat*            pFaultEventData     = pFaultEventContext->pBuf;
    Mmi_TimeStamp            EventOccurTime;

    uint16 Len;


    char Buf[21] = {0}; // ��� ����

    //Title print
    snprintf(Buf, sizeof(Buf), "%-20s", pDisplayContext->pLineContents->line_contents_A.pStr);
    Mmi_Goto(0, 0);
    Mmi_Printf("%s", Buf);

    if(pFaultEventContext->maxcount==0)
    {
        Mmi_Goto(1, 0);
        Mmi_Printf("                    ");
        Mmi_Goto(2, 0);
        Mmi_Printf("       EMPTY        ");
        Mmi_Goto(3, 0);
        Mmi_Printf("                    ");
        return;
    }

    pFaultEventData+=pFaultEventContext->currntindex;
    ConvertHMISToMmiTimeStamp(&pFaultEventData->TimeData,&EventOccurTime);


    if(pFaultEventContext->scrollflag%2==0)
    {
        //current index & event time (year/month/day) print
        Len=snprintf(Buf, sizeof(Buf), "%02d/%02d     %02d.%02d.%02d",
                     pFaultEventContext->currntindex+1,
                     pFaultEventContext->maxcount,
                     EventOccurTime.Year,
                     EventOccurTime.Month,
                     EventOccurTime.Day);
        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }
        Mmi_Goto(1, 0);
        Mmi_Printf("%s", Buf);

        //event time (hour/min/sec/msec) print
        Len=snprintf(Buf, sizeof(Buf), "%02d:%02d:%02d:%02d",
                     EventOccurTime.Hour,
                     EventOccurTime.Min,
                     EventOccurTime.Sec,
                     EventOccurTime.msec);

        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }

        Mmi_Goto(2, 0);
        Mmi_Printf("%s", Buf);


        //IA: A VA:  kV
        Len=snprintf(Buf, sizeof(Buf), "IA:%4.0fA  VA:%4.1fkV",pFaultEventData->IB_RMS,pFaultEventData->VB_RMS);

        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }

        Mmi_Goto(3, 0);
        Mmi_Printf("%s", Buf);
    }

    else if(pFaultEventContext->scrollflag%2==1)
    {
        //IB: A VB:  kV
        Len=snprintf(Buf, sizeof(Buf), "IB:%4.0fA   VB:%4.1fkV",pFaultEventData->IB_RMS,pFaultEventData->VB_RMS);
        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }
        Mmi_Goto(1, 0);
        Mmi_Printf("%s", Buf);

        //IC: A VC:  kV
        Len=snprintf(Buf, sizeof(Buf), "IC:%4.0fA   VC:%4.1fkV",pFaultEventData->IC_RMS,pFaultEventData->VC_RMS);
        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }
        Mmi_Goto(2, 0);
        Mmi_Printf("%s", Buf);

        //IN:   A
        Len=snprintf(Buf, sizeof(Buf), "IN:%4.0fA",pFaultEventData->IN_RMS);
        if(Len < 20)
        {
            snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
        }
        Mmi_Goto(3, 0);
        Mmi_Printf("%s", Buf);
    }

}

void FaultWaveEventPage_Print(MmiDisplayContext* pDisplayContext)
{
    FaultWaveEventContext*    pFaultWaveEventContext  = &pDisplayContext->FaultWaveEventContext;

    char Buf[21] = {0}; // ��� ����

    //Title print
    snprintf(Buf, sizeof(Buf), "%-20s", pDisplayContext->pLineContents->line_contents_A.pStr);
    Mmi_Goto(0, 0);
    Mmi_Printf("%s", Buf);

    if(pFaultWaveEventContext->eventflag)
    {
        Mmi_Goto(1, 0);
        Mmi_Printf("                    ");
        Mmi_Goto(2, 0);
        Mmi_Printf("   EVENT HAPPENED   ");
        Mmi_Goto(3, 0);
        Mmi_Printf("                    ");
        return;
    }
    else
    {
        Mmi_Goto(1, 0);
        Mmi_Printf("                    ");
        Mmi_Goto(2, 0);
        Mmi_Printf("       EMPTY        ");
        Mmi_Goto(3, 0);
        Mmi_Printf("                    ");
        return;
    }


}

void TimePage_Print(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    LineContents* pLineContents  = pDisplayContext->pLineContents;
    Mmi_TimeStamp* pCurrentTime  = pDisplayContext->pTime;
    Mmi_TimeStamp*  SettingTime   = &pDisplayContext->SettingTime;


    if(pDisplayContext->mode==MMI_MODE_DISPLAY)
    {
        SettingTime->Year  =pCurrentTime->Year;
        SettingTime->Month =pCurrentTime->Month;
        SettingTime->Day   =pCurrentTime->Day;
        SettingTime->Hour  =pCurrentTime->Hour;
        SettingTime->Min   =pCurrentTime->Min;
        SettingTime->Sec   =pCurrentTime->Sec;
    }


    char Buf[21] = {0}; // ��� ����

    //Title print
    snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
    Mmi_Goto(0, 0);
    Mmi_Printf("%s", Buf);
    pLineContents++;

    //Time print
    snprintf(Buf+1, sizeof(Buf), "%04d/%02d/%02d %02d:%02d:%02d",
             pCurrentTime->Year + 1900,
             pCurrentTime->Month,
             pCurrentTime->Day,
             pCurrentTime->Hour,
             pCurrentTime->Min,
             pCurrentTime->Sec);
    Mmi_Goto(1, 0);
    Mmi_Printf("%s", Buf);

    //Setting Time print
    pLineContents++;
    snprintf(Buf, sizeof(Buf), "%-20s", pLineContents->line_contents_A.pStr);
    Mmi_Goto(2, 0);
    Mmi_Printf("%s", Buf);

    Buf[0]='>';
    snprintf(Buf+1, sizeof(Buf), "%04d/%02d/%02d %02d:%02d:%02d",
             SettingTime->Year + 1900,
             SettingTime->Month,
             SettingTime->Day,
             SettingTime->Hour,
             SettingTime->Min,
             SettingTime->Sec);
    Mmi_Goto(3, 0);
    Mmi_Printf("%s", Buf);

    if(pDisplayContext->mode==MMI_MODE_EDIT)
    {
        Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);
    }
}


void BatteryTestPage_Print(MmiDisplayContext* pDisplayContext,uint16 sec)
{
    Page_Search(pDisplayContext,BATTERY_TEST);

    LineContents* pLineContents = pDisplayContext->pLineContents;

    uint16 i=0,Len=0;
    void* dataAddr = NULL;

    TagData*      pTagData;
    LineProperty    LineProperty;

    char* pStr   = NULL;
    char Buf[21] = {0}; // ��� ����

      //Title print
      snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
      Mmi_Goto(0, 0);
      Mmi_Printf("%s", Buf);

      //Second line print
      pLineContents++;
      snprintf(Buf, sizeof(Buf), "%-20s", pLineContents->line_contents_A.pStr);
      Mmi_Goto(1, 0);
      Mmi_Printf("%s", Buf);

      //Third line print
      pLineContents++;
      pStr = pLineContents->line_contents_A.pStr;
      pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;

      void* pData = TagDataAddr_Get(pTagData);
      float32 value = *((float32*)pData);

      Len = snprintf(Buf, sizeof(Buf), "%s", pStr);
      Len += snprintf(Buf+Len, sizeof(Buf)-Len, "%.1f", value);

      if(Len < 20) {
          snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
      }

      Mmi_Goto(2, 0);
      Mmi_Printf("%s", Buf);


      //4th line print
      pLineContents++;
      if(sec<5)
      {
          pStr = pLineContents->line_contents_A.pStr;
          Len = snprintf(Buf, sizeof(Buf), "%s", pStr);

          for(i=0;i<=sec;i++)
          {
              Buf[i*3+1]=0x31+i;
          }
      }
      else
      {
          LineProperty =  pLineContents->line_contents_A.LineParameter.property;
          pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;
          dataAddr=   TagDataAddr_Get(pTagData);

          Len = 1;

          if((*(uint16*)dataAddr)==1)
          {
              Len += snprintf(Buf+1, sizeof(Buf), "Battery Trouble");

          }
          else
          {
              Len += snprintf(Buf+1, sizeof(Buf), "Battery Ok");
          }


      }

      if(Len < 20) {
          snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, "");
      }

      Mmi_Goto(3, 0);
      Mmi_Printf("%s", Buf);


}

void SystemInformationPage_Print(MmiDisplayContext* pDisplayContext,PageProperty Pagetype)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;

     char* pStr   = NULL;
     char Buf[21] = {0}; // ��� ����

       //Title print
       snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
       Mmi_Goto(0, 0);
       Mmi_Printf("%s", Buf);

       Mmi_Goto(1, 0);
       Mmi_Printf("                    ");

       SystemInformation* pSystemInfo = SystemInfoFile_Get();
       uint16 Len=0;

       switch(Pagetype)
       {
       case PAGE_PRT_HW_INFO:
           Len = snprintf(Buf, SYSTEM_INFO_MAX, ">%s", pSystemInfo->SerialNumber);
           break;
       case PAGE_PRT_MODEL_NUM:
           Len = snprintf(Buf, SYSTEM_INFO_MAX, ">%s", pSystemInfo->ModelNumber);
           break;
       case PAGE_PRT_IDENTIFIER:
           Len = snprintf(Buf, SYSTEM_INFO_MAX, ">%s", pSystemInfo->Identifier);
           break;
       }
       if(Len < 20) {
           snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, "");
       }
       Mmi_Goto(2, 0);
       Mmi_Printf("%s", Buf);

       Mmi_Goto(3, 0);
       Mmi_Printf("                    ");
}

void FW_VersionPage_Print(MmiDisplayContext* pDisplayContext)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;

    char* pStr   = NULL;
    char Buf[21] = {0}; // ��� ����

      //Title print
      snprintf(Buf, sizeof(Buf), "%-20s", pLineContents[0].line_contents_A.pStr);
      Mmi_Goto(0, 0);
      Mmi_Printf("%s", Buf);

      Mmi_Goto(1, 0);
      Mmi_Printf("                    ");

      pLineContents++;
      TagData* pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;

      void* pData = TagDataAddr_Get(pTagData);
      uint16 value = *((uint16*)pData);

      uint16 Major = (value & 0xF000) >> 12;
      uint16 Minor = (value & 0x0F00) >> 8;
      uint16 Patch = value & 0x00FF;

      uint16 Len = snprintf(Buf, sizeof(Buf), ">%d.%d.%d", Major,Minor,Patch);
      if(Len < 20) {
          snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, "");
      }

      Mmi_Goto(2, 0);
      Mmi_Printf("%s", Buf);

      Mmi_Goto(3, 0);
      Mmi_Printf("                    ");

}

uint16 DataLine_Print(ParamEditContext* pParamEditContext, LineProperty LineProperty, char* pBuf, void* pData)
{
    uint16 Len = 0;
    const char* IntFormat[5]    = {"%04d",   "%03d",   "%02d",   "%01d",   "%d"};
    const char* FloatFormat[3]  = {"%.0f", "%.1f", "%.2f"};
    uint16 FormatIndex = 0;

    bool FloatFlag = 1;
    uint16  IntValue=*(uint16*)pData;
    float32 FloatValue;


    switch(pParamEditContext->param_desc_type)
    {
    case PARAM_DESC_TYPE_NONE:
    case PARAM_DESC_RANGE_TYPE:
    case PARAM_DESC_RANGE_DUAL_TYPE:
    case PARAM_DESC_RANGE_OFF_TYPE:
    case PARAM_DESC_RANGE_CURSOR_TYPE:
    {
        switch(LineProperty)
        {
            case LINE_PRT_DISPLAY_U:
            case LINE_PRT_SETTING_U:
                if(IntValue >= 1000)             FormatIndex = 0;
                else if(IntValue >= 100)         FormatIndex = 1;
                else if(IntValue >= 10)          FormatIndex = 2;
                else                        FormatIndex = 3;
                Len = Mmi_Vsprintf(pBuf, IntFormat[FormatIndex],   IntValue);
                break;
            case LINE_PRT_SETTING_F_0:
            case LINE_PRT_SETTING_F_1:
            case LINE_PRT_SETTING_F_2:
                FormatIndex = LineProperty-LINE_PRT_SETTING_F_0;
                FloatValue = *(float32*)pData;
                Len = Mmi_Vsprintf(pBuf, FloatFormat[FormatIndex], FloatValue);
                break;
            case LINE_PRT_DISPLAY_F_0:
            case LINE_PRT_DISPLAY_F_1:
            case LINE_PRT_DISPLAY_F_2:
                FormatIndex = LineProperty-LINE_PRT_DISPLAY_F_0;
                FloatValue = *(float32*)pData;
                Len = Mmi_Vsprintf(pBuf, FloatFormat[FormatIndex], FloatValue);
                break;
       }
    }
    break;
    case PARAM_DESC_SELECT_TYPE:
    {
        FloatFlag = 0;
        FormatIndex = 2;
        Len = Mmi_Vsprintf(pBuf, IntFormat[FormatIndex],   IntValue);
    }
    break;
    case PARAM_DESC_SELECT_NAME_TYPE:
    {
        float32* pDescValue = &pParamEditContext->p_select_name_type->val[0];
        char**   pDescStr   = &pParamEditContext->p_select_name_type->val_name[0];
        uint16   Index      = SelectNameTypeValue_Check(LineProperty, pDescValue, pData);
        Len = Mmi_Vsprintf(pBuf, pDescStr[Index]);
    }
    break;
    case PARAM_DESC_NAME_TYPE:
        Len = NameType_Print(pParamEditContext,pBuf);
        break;
    }

    if(pParamEditContext->pUnit != NULL)        Len += Mmi_Vsprintf(pBuf+Len, "%s", pParamEditContext->pUnit);

    return Len;
}

void EditLine_Data_Set(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext*  pParamEditContext = &pDisplayContext->param_edit_ctx_;
    SettingContext* pSettingContext=&pDisplayContext->SettingContext;

    uint16 j;

    uint16 Cursor = pDisplayContext->line_cursor;
    LineContents* pLineContents = &pDisplayContext->pLineContents[Cursor];

    LineProperty LineProperty =  pLineContents->line_contents_A.LineParameter.property;
    TagData* pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;

    ParamDescContents_Search(pParamEditContext, pTagData);

    TagData  EditTagData;

    EditTagData.TagIndex=pTagData->TagIndex;
    EditTagData.TagGroup=pTagData->TagGroup;

    if(isLS_TagData(pTagData->TagGroup))
    {
        SetLSGroupTagData(pParamEditContext->GroupNumber,&EditTagData);
    }

    pParamEditContext->pData = TagDataAddr_Get(&EditTagData);
    pParamEditContext->Current_TagData.TagGroup=EditTagData.TagGroup;
    pParamEditContext->Current_TagData.TagIndex=EditTagData.TagIndex;

    for(j=0;j<pDisplayContext->SettingLastIndex;j++)
    {
        if(isEqualTagData(&EditTagData,&pSettingContext->TempData[j].TagData))
        {
            pParamEditContext->pData=&pDisplayContext->SettingContext.TempData[j].ParameterValue.IntValue;
            break;
        }
    }


    if(LineProperty==LINE_PRT_SETTING_U)
        pParamEditContext->ParameterValue.IntValue=*(uint16*)pParamEditContext->pData;
    else
        pParamEditContext->ParameterValue.FloatValue=*(float32*)pParamEditContext->pData;


    //Test
    if(pParamEditContext->param_desc_type==PARAM_DESC_NAME_TYPE)
        pParamEditContext->ParameterValue.IntValue=4096;

}

void SequentialPage_Set(MmiDisplayContext* pDisplayContext)
{
    SequentialEventContext* pSequentialEventContext = &pDisplayContext->SequentialEventContext;
    //Display Data Init
    pSequentialEventContext->currntindex=0;

    //Load Event File
    pSequentialEventContext->maxcount = SequentialEventFile_Load(pSequentialEventContext->pBuf);
}

void FaultPage_Set(MmiDisplayContext* pDisplayContext)
{
    FaultEventContext*   pFaultEventContext = &pDisplayContext->FaultEventContext;
    //Display Data Init
    pFaultEventContext->currntindex=0;
    pFaultEventContext->scrollflag=0;

    //Load Event File
    pFaultEventContext->maxcount = FaultEventFile_Load(pFaultEventContext->pBuf);
}

void FaultWavePage_Set(MmiDisplayContext* pDisplayContext)
{
    FaultWaveEventContext* pFaultWaveEventContext = &pDisplayContext->FaultWaveEventContext;
    //Display Data Init
    pFaultWaveEventContext->eventflag=0;

    //Load Event File
    pFaultWaveEventContext->eventflag = FaultWaveEventFile_Check();
}

void EditPage_Print(MmiDisplayContext* pDisplayContext)
{
    char Buf[21];
    const char* pSpace = "                    ";
    char* pStr   = NULL;
    void*  pData = pDisplayContext->param_edit_ctx_.pData;

    TagData* pTagData;
    LineProperty    LineProperty;
    uint16 j, Len;
    uint16 Cursor = pDisplayContext->line_cursor;
    uint16 LineMax = pDisplayContext->CurrentLineMax;
    LineContents* pLineContents = pDisplayContext->pLineContents;
    SettingContext* pSettingContext=&pDisplayContext->SettingContext;
    ParamEditContext* pParamEditContext=&pDisplayContext->param_edit_ctx_;
    /*Print Title line*/
    memset(Buf, 0, sizeof(Buf));
    pStr = pLineContents[0].line_contents_A.pStr;
    Len = strlen(pStr);

    snprintf(Buf, sizeof(Buf), "%s%*s", pStr, 20 - Len > 0 ? 20 - Len : 0, "");

    Mmi_Goto(0, 0);
    Mmi_Printf("%s", Buf);


    /*Fine setting line 1*/
    pLineContents+=Cursor;

    pStr = pLineContents->line_contents_A.pStr;
    LineProperty =  pLineContents->line_contents_A.LineParameter.property;
    pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;
    ParamDescContents_Search(pParamEditContext, pTagData);

    Len = snprintf(Buf, sizeof(Buf), "%s", pStr);

    TagData  EditTagData;

    EditTagData.TagIndex=pTagData->TagIndex;
    EditTagData.TagGroup=pTagData->TagGroup;

    if(isLS_TagData(pTagData->TagGroup))
    {
        SetLSGroupTagData(pParamEditContext->GroupNumber,&EditTagData);
    }
    pParamEditContext->pData = TagDataAddr_Get(&EditTagData);

    //isExistingSettingData
    pData=pDisplayContext->param_edit_ctx_.pData;

    for(j=0;j<COMMAND_BUF_SIZE;j++)
    {
        if(isEqualTagData(&EditTagData,&pSettingContext->TempData[j].TagData))
        {
            if(pSettingContext->TempData[j].DisplayDataType==DISP_DATA_UINT)
                pData=&pSettingContext->TempData[j].ParameterValue.IntValue;
            else
                pData=&pSettingContext->TempData[j].ParameterValue.FloatValue;
            break;
        }

    }
    //isExistingSettingData

    /*Make setting line string*/
    Len += DataLine_Print(&pDisplayContext->param_edit_ctx_, LineProperty, Buf+Len, pData);
    if(Len < 20) {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, "");
    }

    Buf[0] = '>';
    Mmi_Goto(1, 0);
    Mmi_Printf("%s", Buf);

    /*PrintParameter Info */
    ParamDescLine_Print(&pDisplayContext->param_edit_ctx_);

    /*Fine setting line 2*/
    if(LineMax < 3)
    {
        Mmi_Goto(2, 0);
        Mmi_Printf("%s", pSpace);
        return ;
    }

    pLineContents++;

    pStr = pLineContents->line_contents_A.pStr;
    LineProperty =  pLineContents->line_contents_A.LineParameter.property;
    pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;
    ParamDescContents_Search(&pDisplayContext->param_edit_ctx_, pTagData);

    /*Copy line string to buffer*/
    Len = snprintf(Buf, sizeof(Buf), "%s", pStr);

    EditTagData.TagIndex=pTagData->TagIndex;
    EditTagData.TagGroup=pTagData->TagGroup;

    if(isLS_TagData(pTagData->TagGroup))
    {
        SetLSGroupTagData(pParamEditContext->GroupNumber,&EditTagData);
    }
    pParamEditContext->pData = TagDataAddr_Get(&EditTagData);

    //isExistingSettingData
    for(j=0;j<COMMAND_BUF_SIZE;j++)
    {
        if(isEqualTagData(&EditTagData,&pSettingContext->TempData[j].TagData))
        {
            if(pSettingContext->TempData[j].DisplayDataType==DISP_DATA_UINT)
                pData=&pSettingContext->TempData[j].ParameterValue.IntValue;
            else
                pData=&pSettingContext->TempData[j].ParameterValue.FloatValue;
            break;
        }
        else
            pData=pDisplayContext->param_edit_ctx_.pData;

    }
    //isExistingSettingData

    /*Make setting line string*/
    Len += DataLine_Print(&pDisplayContext->param_edit_ctx_, LineProperty, Buf+Len, pData);

    if(Len < 20) {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", 20 - Len, ""); // ���� �߰�
    }

    Mmi_Goto(2, 0);
    Mmi_Printf("%s", Buf);

}

void ParamDescLine_Print(ParamEditContext* pParamEditContext)
{
    char PrintBuf[CLCD_LINE_TEXT_MAX+1]; // ��� ���� ����
    char Buf[CLCD_LINE_TEXT_MAX]; // ������ ������ ���� ����

    uint16 RangeLineLen = ParamDescLine_Make(pParamEditContext, Buf);

    if (RangeLineLen >= CLCD_LINE_TEXT_MAX - 2) {
        RangeLineLen = CLCD_LINE_TEXT_MAX - 2;
    }

    int padding = (CLCD_LINE_TEXT_MAX - 2 - RangeLineLen) / 2; // ���� �е� ���
    snprintf(PrintBuf, sizeof(PrintBuf), "[%*s%s%*s]",
             padding, "", // ���� �е�
             Buf, // ���� ����
             CLCD_LINE_TEXT_MAX - 2 - RangeLineLen - padding, ""); // ������ �е�

    Mmi_Goto(3, 0);
    Mmi_Printf("%s", PrintBuf);

}

static uint16 ParamDescLine_Make(ParamEditContext*   pParamEditContext, char* pLineBuf)
{
    uint16 StrLen = 0;
    float32 MinValue = 0.0,  MaxValue = 0.0;

    DisplayDataType DisplayDataType;

    switch(pParamEditContext->param_desc_type)
    {
        case PARAM_DESC_RANGE_TYPE:
            MinValue = pParamEditContext->p_range_type->min_val;
            MaxValue = pParamEditContext->p_range_type->max_val;
            DisplayDataType = pParamEditContext->p_range_type->data_type;
            break;
        case PARAM_DESC_RANGE_DUAL_TYPE:
            MinValue = pParamEditContext->p_range_dual_type->min_val_positive;
            MaxValue = pParamEditContext->p_range_dual_type->max_val_positive;
            DisplayDataType = pParamEditContext->p_range_dual_type->data_type;
            StrLen = Mmi_Vsprintf(pLineBuf, "+-");
            break;
        case PARAM_DESC_RANGE_OFF_TYPE:
            MinValue = pParamEditContext->p_range_off_type->min_val;
            MaxValue = pParamEditContext->p_range_off_type->max_val;
            DisplayDataType = pParamEditContext->p_range_off_type->data_type;
            StrLen = Mmi_Vsprintf(pLineBuf, "OFF(0),");
            break;
        case PARAM_DESC_RANGE_CURSOR_TYPE:
            MinValue = pParamEditContext->p_range_cursor_type->min_val;
            MaxValue = pParamEditContext->p_range_cursor_type->max_val;
            DisplayDataType = pParamEditContext->p_range_cursor_type->data_type;
            break;
        case PARAM_DESC_SELECT_TYPE:
        {
            uint16 SelectCnt      = pParamEditContext->p_select_type->max_buf_cnt;
            float32* pSelectValue = &pParamEditContext->p_select_type->val[0];

            while(SelectCnt--)
            {
                switch(pParamEditContext->p_select_type->data_type)
                {
                    case DISP_DATA_UINT:
                        StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%ld", (uint32)*pSelectValue++);
                        break;
                    case DISP_DATA_FLOAT_0:
                        StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.0f", *pSelectValue++);
                        break;
                    case DISP_DATA_FLOAT_1:
                        StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.1f", *pSelectValue++);
                        break;
                    case DISP_DATA_FLOAT_2:
                        StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.2f", *pSelectValue++);
                        break;
                }
                if(SelectCnt != 0)          StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "/");
            }
        }
        goto UNIT;
        case PARAM_DESC_SELECT_NAME_TYPE:
        {
            char **pName = (char**)&pParamEditContext->p_select_name_type->val_name[0];

            if(*pName != NULL)                  StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%s",  *pName++);

            if(*pName != NULL)                  StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "/%s",   *pName++);

            if(*pName != NULL)                  StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "/%s",   *pName++);

        }
        goto UNIT;
        case PARAM_DESC_NAME_TYPE:
            StrLen = Mmi_Vsprintf(pLineBuf, "CP/IEC/US/USER/DEF");
            goto UNIT;
    }

    switch(DisplayDataType)
    {
        case DISP_DATA_UINT:
            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%ld-%ld", (uint32)MinValue, (uint32)MaxValue);
            /*Check Step*/
            if(pParamEditContext->pStep != NULL)
            {
                uint16 TempStep = (uint16)*pParamEditContext->pStep;
                StrLen += Mmi_Vsprintf(pLineBuf+StrLen, ":%d", TempStep);
            }
            break;
        case DISP_DATA_FLOAT_0:
            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.0f-%.0f",    MinValue, MaxValue);

            if(pParamEditContext->pStep != NULL)            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, ":%.0f", *pParamEditContext->pStep);
            break;
        case DISP_DATA_FLOAT_1:
            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.1f-%.1f",    MinValue, MaxValue);

            if(pParamEditContext->pStep != NULL)            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, ":%.1f", *pParamEditContext->pStep);
            break;
        case DISP_DATA_FLOAT_2:
            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, "%.2f-%.2f",    MinValue, MaxValue);

            if(pParamEditContext->pStep != NULL)            StrLen += Mmi_Vsprintf(pLineBuf+StrLen, ":%.2f", *pParamEditContext->pStep);
            break;
    }
UNIT:
    /*Check Unit String*/
    if(pParamEditContext->pUnit != NULL)
    {
        strcat(pLineBuf+StrLen, pParamEditContext->pUnit);
        StrLen += strlen(pParamEditContext->pUnit);
    }

    return StrLen;
}
void Page_Search(MmiDisplayContext* pDisplayContext,uint32 PageCode)
{
    uint16 i;
    PageContents* pPageContents = pDisplayContext->p_page_content;

    pDisplayContext->p_latest_page_s     = NULL;
    pDisplayContext->p_latest_page_l     = NULL;
    pDisplayContext->p_latest_page_m     = NULL;

    for(i=0; i<PAGE_CONTENTS_SMALL_MAX_CNT; i++)
    {
        if(pPageContents->page_content_s[i].page_code == PageCode)
        {
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_SMALL;
            pDisplayContext->CurrentPageCode     = pPageContents->page_content_s[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_s[i].property;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_s[i].line_content_cnt;
            pDisplayContext->p_latest_page_s     = &pPageContents->page_content_s[i];
        }
    }
    for(i=0; i<PAGE_CONTENTS_MEDIUM_MAX_CNT; i++)
    {
        if(pPageContents->page_content_m[i].page_code == PageCode)
        {
            pDisplayContext->current_page_type = PAGE_CTNS_TYPE_MEDIUM;
            pDisplayContext->CurrentPageCode = pPageContents->page_content_m[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_m[i].property;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_m[i].line_content_cnt;
            pDisplayContext->p_latest_page_m = &pPageContents->page_content_m[i];
        }
    }

    for(i=0; i<PAGE_CONTENTS_LARGE_MAX_CNT; i++)
    {
        if(pPageContents->page_content_l[i].page_code == PageCode)
        {
            pDisplayContext->current_page_type = PAGE_CTNS_TYPE_LARGE;
            pDisplayContext->CurrentPageCode = pPageContents->page_content_l[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_l[i].property;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_l[i].line_content_cnt;
            pDisplayContext->p_latest_page_l = &pPageContents->page_content_l[i];
        }
    }

    LineInfo_Update(pDisplayContext);

    return;

}

void GroupNumberCheck(uint16* pGroupNumber,uint32 ChildPageCode)
{
    if(ChildPageCode==CB_GROUP1||ChildPageCode==VIT_GROUP1)
        *pGroupNumber=1;
    else if(ChildPageCode==CB_GROUP2||ChildPageCode==VIT_GROUP2)
        *pGroupNumber=2;
}


void ChildPage_Search(MmiDisplayContext* pDisplayContext)
{
    uint16 i;

    PageContents* pPageContents = pDisplayContext->p_page_content;
    LineContents* pLineContents = pDisplayContext->pLineContents;

    uint32 ChildPageCode = 0;

    switch(pLineContents->type)
    {
        case LINE_CONTENTS_TYPE_A:
            ChildPageCode = pLineContents[pDisplayContext->line_cursor].line_contents_A.LineParameter.ChildPageCode;
            break;
        case LINE_CONTENTS_TYPE_B:
            ChildPageCode = pLineContents[pDisplayContext->line_cursor].line_contents_B.LineParameter[0].ChildPageCode;
            break;
        case LINE_CONTENTS_TYPE_C:
            ChildPageCode = pLineContents[pDisplayContext->line_cursor].line_contents_C.LineParameter[0].ChildPageCode;
            break;
    }

    pDisplayContext->p_latest_page_s     = NULL;
    pDisplayContext->p_latest_page_m     = NULL;
    pDisplayContext->p_latest_page_l     = NULL;

    GroupNumberCheck(&pDisplayContext->param_edit_ctx_.GroupNumber,ChildPageCode);

    for(i=0; i<PAGE_CONTENTS_SMALL_MAX_CNT; i++)
    {
        if(pPageContents->page_content_s[i].page_code == ChildPageCode)
        {
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_SMALL;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_s[i].property;
            pDisplayContext->CurrentPageCode     = pPageContents->page_content_s[i].page_code;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_s[i].line_content_cnt;
            pDisplayContext->p_latest_page_s     = &pPageContents->page_content_s[i];
            goto LINE_INFO_UPDATE;
        }
    }

    for(i=0; i<PAGE_CONTENTS_MEDIUM_MAX_CNT; i++)
    {
        if(pPageContents->page_content_m[i].page_code == ChildPageCode)
        {
            if(pPageContents->page_content_m[i].property == PAGE_PRT_MEASURE)     continue;
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_MEDIUM;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_m[i].property;
            pDisplayContext->CurrentPageCode     = pPageContents->page_content_m[i].page_code;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_m[i].line_content_cnt;
            pDisplayContext->p_latest_page_m     = &pPageContents->page_content_m[i];
            goto LINE_INFO_UPDATE;
        }
    }

    for(i=0; i<PAGE_CONTENTS_LARGE_MAX_CNT; i++)
    {
        if(pPageContents->page_content_l[i].page_code == ChildPageCode)
        {
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_LARGE;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_l[i].property;
            pDisplayContext->CurrentPageCode     = pPageContents->page_content_l[i].page_code;
            pDisplayContext->CurrentLineMax      = pPageContents->page_content_l[i].line_content_cnt;
            pDisplayContext->p_latest_page_l     = &pPageContents->page_content_l[i];
            goto LINE_INFO_UPDATE;
        }
    }
    return;
LINE_INFO_UPDATE:
    switch(pDisplayContext->CurrentPageLevel++)
    {
        case 1:
            pDisplayContext->LineCursorLevel1 = pDisplayContext->line_cursor;
            pDisplayContext->ViewCursorLevel1 = pDisplayContext->view_cursor;
            break;
        case 2:
            pDisplayContext->LineCursorLevel2 = pDisplayContext->line_cursor;
            pDisplayContext->ViewCursorLevel2 = pDisplayContext->view_cursor;
            break;
        case 3:
            pDisplayContext->LineCursorLevel3 = pDisplayContext->line_cursor;
            pDisplayContext->ViewCursorLevel3 = pDisplayContext->view_cursor;
            break;
        case 4:
            pDisplayContext->LineCursorLevel4 = pDisplayContext->line_cursor;
            pDisplayContext->ViewCursorLevel4 = pDisplayContext->view_cursor;
            break;
        case 5:
            pDisplayContext->LineCursorLevel5 = pDisplayContext->line_cursor;
            pDisplayContext->ViewCursorLevel5 = pDisplayContext->view_cursor;
            break;

    }
    LineInfo_Update(pDisplayContext);
}
void ParentPage_Search(MmiDisplayContext* pDisplayContext)
{
    uint16 i;
    PageContents* pPageContents = pDisplayContext->p_page_content;
    uint32 ParentPageCode = 0;

    switch(pDisplayContext->current_page_type)
    {
        case PAGE_CTNS_TYPE_SMALL:
            ParentPageCode =  pDisplayContext->p_latest_page_s->parent_page_code;
            break;
        case PAGE_CTNS_TYPE_MEDIUM:
            ParentPageCode = pDisplayContext->p_latest_page_m->parent_page_code;
            break;
        case PAGE_CTNS_TYPE_LARGE:
            ParentPageCode = pDisplayContext->p_latest_page_l->parent_page_code;
            break;
    }

    pDisplayContext->p_latest_page_s     = NULL;
    pDisplayContext->p_latest_page_l     = NULL;
    pDisplayContext->p_latest_page_m     = NULL;

    if(ParentPageCode==CB_GROUP1&&pDisplayContext->param_edit_ctx_.GroupNumber==2)
        ParentPageCode=CB_GROUP2;

    if(ParentPageCode==VIT_GROUP1&&pDisplayContext->param_edit_ctx_.GroupNumber==2)
        ParentPageCode=VIT_GROUP2;

    for(i=0; i<PAGE_CONTENTS_SMALL_MAX_CNT; i++)
    {
        if(pPageContents->page_content_s[i].page_code == ParentPageCode)
        {
            pDisplayContext->current_page_type   = PAGE_CTNS_TYPE_SMALL;
            pDisplayContext->CurrentPageCode     = pPageContents->page_content_s[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_s[i].property;
            pDisplayContext->p_latest_page_s     = &pPageContents->page_content_s[i];
            goto LINE_INFO_UPDATE;
        }
    }
    for(i=0; i<PAGE_CONTENTS_MEDIUM_MAX_CNT; i++)
    {
        if(pPageContents->page_content_m[i].page_code == ParentPageCode)
        {
            pDisplayContext->current_page_type = PAGE_CTNS_TYPE_MEDIUM;
            pDisplayContext->CurrentPageCode = pPageContents->page_content_m[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_m[i].property;
            pDisplayContext->p_latest_page_m = &pPageContents->page_content_m[i];
            goto LINE_INFO_UPDATE;
        }
    }

    for(i=0; i<PAGE_CONTENTS_LARGE_MAX_CNT; i++)
    {
        if(pPageContents->page_content_l[i].page_code == ParentPageCode)
        {
            pDisplayContext->current_page_type = PAGE_CTNS_TYPE_LARGE;
            pDisplayContext->CurrentPageCode = pPageContents->page_content_l[i].page_code;
            pDisplayContext->CurrentPageProperty = pPageContents->page_content_l[i].property;
            pDisplayContext->p_latest_page_l = &pPageContents->page_content_l[i];
            goto LINE_INFO_UPDATE;
        }
    }
    return;

LINE_INFO_UPDATE:
    LineInfo_Update(pDisplayContext);
}
static void LineInfo_Update(MmiDisplayContext* pDisplayContext)
{
    /*Update Current Page Info*/
    switch(pDisplayContext->current_page_type)
    {
        case PAGE_CTNS_TYPE_SMALL:
            pDisplayContext->CurrentLineContentsType = pDisplayContext->p_latest_page_s->line_content[0].type;
            pDisplayContext->CurrentLineMax          = pDisplayContext->p_latest_page_s->line_content_cnt;
            pDisplayContext->pLineContents           = &pDisplayContext->p_latest_page_s->line_content[0];
            break;
        case PAGE_CTNS_TYPE_MEDIUM:
            pDisplayContext->CurrentLineContentsType = pDisplayContext->p_latest_page_m->line_content[0].type;
            pDisplayContext->CurrentLineMax          = pDisplayContext->p_latest_page_m->line_content_cnt;
            pDisplayContext->pLineContents           = &pDisplayContext->p_latest_page_m->line_content[0];
            break;
        case PAGE_CTNS_TYPE_LARGE:
            pDisplayContext->CurrentLineContentsType = pDisplayContext->p_latest_page_l->line_content[0].type;
            pDisplayContext->CurrentLineMax          = pDisplayContext->p_latest_page_l->line_content_cnt;
            pDisplayContext->pLineContents           = &pDisplayContext->p_latest_page_l->line_content[0];
            break;
    }
}


static uint16 Mmi_Vsprintf(char* pBuf, char *fmt, ...)
{
    uint16  len = 0;
    va_list args;

    va_start(args, fmt);

    len = vsnprintf(pBuf, MMI_PRINTF_BUFFER_SIZE, fmt, args);

    va_end(args);

    return len;
}

static void Mmi_Printf(char *fmt, ...)
{
    char buf[MMI_PRINTF_BUFFER_SIZE];

    va_list args;

    va_start(args, fmt);

    vsnprintf(buf, MMI_PRINTF_BUFFER_SIZE, fmt, args);

    va_end(args);

    pLCD_Device->pfLCD_String(buf);
}


MmiDisplayContext* MmiDisplayContext_Create(void* pMmiBlock4)
{

    memset(&MmiDisplayContextObject, 0, sizeof(MmiDisplayContext));
    memset(&TagPointerObject,        0, sizeof(TagPointer));

    MmiDisplayContextObject.pBlank                = pBlank;
    MmiDisplayContextObject.p_page_content        = (PageContents*)&mmi_display_contents;
    MmiDisplayContextObject.p_group_data_content  = (GroupDataContents*)&mmi_group_param_contents;
    MmiDisplayContextObject.param_edit_ctx_.pParamDescContents = (ParamDescContents*)&mmi_display_param_contents;


    MmiDisplayContextObject.CurrentPageLevel = 1;
    MmiDisplayContextObject.view_cursor = 1;
    MmiDisplayContextObject.line_cursor = 1;


    TAG_DB* pTagDb = TagDB_Get();

    TagPointerObject.pTAG_AI = &pTagDb->AI.AI[0];
    TagPointerObject.pTAG_DI = &pTagDb->DI.DI[0];
    TagPointerObject.pTAG_DO = &pTagDb->DO.DO[0];
    TagPointerObject.pTAG_BV = &pTagDb->BV.BV[0];

    TagPointerObject.pTAG_NMV_UI = &pTagDb->NMV.NMV_UI[0];
    TagPointerObject.pTAG_NMV_F  = &pTagDb->NMV.NMV_F[0];

    TagPointerObject.pTAG_NVV_UI = &pTagDb->NVV.NVV_UI[0];
    TagPointerObject.pTAG_NVV_F  = &pTagDb->NVV.NVV_F[0];

    TagPointerObject.pTAG_RCM = &pTagDb->RCM.RCM[0];

    TagPointerObject.pTAG_LS_UI = &pTagDb->LS.LS_INTERNAL.LS_UI[0];
    TagPointerObject.pTAG_LS_F  = &pTagDb->LS.LS_INTERNAL.LS_F[0];

    TagPointerObject.pTAG_SC_UI = &pTagDb->SC.SC_UI[0];
    TagPointerObject.pTAG_SC_F  = &pTagDb->SC.SC_F[0];

    TagPointerObject.pTAG_SIM_DI         = &pTagDb->SIM.SIM_DI[0];
    TagPointerObject.pTAG_SIM_RMS        = &pTagDb->SIM.SIM_RMS[0];
    TagPointerObject.pTAG_SIM_ANGLE      = &pTagDb->SIM.SIM_ANG[0];

    TagPointerObject.pTAG_DG             = &pTagDb->DG.DG_UI[0];

    TagPointerObject.pTAG_MMI            = &pTagDb->MMI[0];

    pLCD_Device = CLCDHandle_Get(pMmiBlock4);

    return &MmiDisplayContextObject;
}


/*
 * Interface Function
 */


static uint16 LineString_Make(LineProperty LineProperty, char* pBuf, void* pData)
{
    uint16 IntData = 0;
    float32 FloatData = 0.0;
    switch(LineProperty)
    {
        /*Need to Unit String*/
        case LINE_PRT_TITLE:
        case LINE_PRT_SELECT:
            break;
//            return Mmi_Vsprintf(pBuf, "%s", pData);
        case LINE_PRT_SETTING_U:
        case LINE_PRT_DISPLAY_U:
            IntData = *(uint16*)pData;
            if(IntData < 10.0)              return Mmi_Vsprintf(pBuf, "000%d", IntData);

            else if(IntData < 100.0)        return Mmi_Vsprintf(pBuf, "00%d",  IntData);

            else if(IntData < 1000.0)       return Mmi_Vsprintf(pBuf, "0%d", IntData);

            return Mmi_Vsprintf(pBuf, "%d", IntData);
        case LINE_PRT_SETTING_F_0:
        case LINE_PRT_DISPLAY_F_0:
            FloatData = *(float32*)pData;
            if(FloatData < 10.0)            return Mmi_Vsprintf(pBuf, "000%.0f", FloatData);

            else if(FloatData < 100.0)      return Mmi_Vsprintf(pBuf, "00%.0f", FloatData);

            else if(FloatData < 1000.0)     return Mmi_Vsprintf(pBuf, "0%.0f", FloatData);

            return Mmi_Vsprintf(pBuf, "%.0f", FloatData);
        case LINE_PRT_SETTING_F_1:
        case LINE_PRT_DISPLAY_F_1:
            FloatData = *(float32*)pData;
            if(FloatData < 10.0)            return Mmi_Vsprintf(pBuf, "0%.1f", FloatData);

            return Mmi_Vsprintf(pBuf, "%.1f", FloatData);
        case LINE_PRT_SETTING_F_2:
        case LINE_PRT_DISPLAY_F_2:
            FloatData = *(float32*)pData;

            return Mmi_Vsprintf(pBuf, "%.2f", FloatData);
        default:
            return 0;
    }
}
void EditData_Save(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    SettingContext*   pSettingContext   = &pDisplayContext->SettingContext;

    uint16 i=0,find_flag=0,current_index=0;
    void* pData = TagDataAddr_Get(&pParamEditContext->Current_TagData);

        for(i=0;i<pDisplayContext->SettingLastIndex;i++)
        {
            if(isEqualTagData(&pParamEditContext->Current_TagData,&pSettingContext->TempData[i].TagData))
            {
                find_flag=1;
                break;
            }
        }

        if(find_flag)
            current_index=i;
        else
            current_index=pDisplayContext->SettingLastIndex++;

        pSettingContext->TempData[current_index].TagData.TagGroup=pParamEditContext->Current_TagData.TagGroup;
        pSettingContext->TempData[current_index].TagData.TagIndex=pParamEditContext->Current_TagData.TagIndex;
        pSettingContext->TempData[current_index].DisplayDataType=pParamEditContext->DisplayDataType;

        if(pSettingContext->TempData[current_index].DisplayDataType==DISP_DATA_UINT)
            pSettingContext->TempData[current_index].ParameterValue.IntValue=pParamEditContext->ParameterValue.IntValue;
        else
            pSettingContext->TempData[current_index].ParameterValue.FloatValue=pParamEditContext->ParameterValue.FloatValue;

        if(pDisplayContext->SettingLastIndex>COMMAND_BUF_SIZE)
            pDisplayContext->SettingLastIndex=0;

}
void Setting_Cancel(MmiDisplayContext* pDisplayContext)
{
    memset(&pDisplayContext->SettingContext, 0, sizeof(SettingContext));
    memset(&pDisplayContext->param_edit_ctx_.Password_Setting_Context.setting_pw.password, 0x30, sizeof(MmiPassword));

    pDisplayContext->param_edit_ctx_.Password_Setting_Context.setting_flag = 0;
    pDisplayContext->SettingLastIndex=0;
    MoveToMainMenuPage(pDisplayContext);
}
void EditMode_Exit(MmiDisplayContext* pDisplayContext)
{
    pDisplayContext->mode = MMI_MODE_DISPLAY;
    /*LED Blink Off*/
    pLCD_Device->pfLCD_Control(CLCD_DISPLAY_NORMAL);
}

void MainView_FirstPage_Print(MmiDisplayContext* pDisplayContext)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;
    uint16 i, j, ParamCnt, Len = 0;

    char Buf[20];
    char* pStr;
    const char* pSpace = pDisplayContext->pBlank;

    LineProperty LineProperty[3];
    TagData* pTagData[3];
    void* pData = NULL;

    for(i=0; i<4; i++)
    {
        switch(pLineContents->type)
        {
            case LINE_CONTENTS_TYPE_A:
                pStr            = pLineContents->line_contents_A.pStr;
                LineProperty[0] = pLineContents->line_contents_A.LineParameter.property;
                pTagData[0]     = &pLineContents->line_contents_A.LineParameter.TagParam;
                ParamCnt        = 1;
                break;
            case LINE_CONTENTS_TYPE_C:
                pStr            = pLineContents->line_contents_C.pStr;
                LineProperty[0] = pLineContents->line_contents_C.LineParameter[0].property;
                LineProperty[1] = pLineContents->line_contents_C.LineParameter[1].property;
                LineProperty[2] = pLineContents->line_contents_C.LineParameter[2].property;
                pTagData[0]     = &pLineContents->line_contents_C.LineParameter[0].TagParam;
                pTagData[1]     = &pLineContents->line_contents_C.LineParameter[1].TagParam;
                pTagData[2]     = &pLineContents->line_contents_C.LineParameter[2].TagParam;
                ParamCnt        = 3;
                break;
        }

        strcpy(Buf, pStr);
        Len = strlen(Buf);

        switch(ParamCnt)
        {
            case 1:
                pData = TagDataAddr_Get(pTagData[0]);

                if(pData != NULL)               Len += LineString_Make(LineProperty[0], Buf+Len, pData);

                strcat(Buf+Len, "A [ABC/RST]");
                Len += 11;
                break;
            case 3:
                for(j=0; j<ParamCnt; j++)
                {
                    pData = TagDataAddr_Get(pTagData[j]);

                    if(pData != NULL)               Len += LineString_Make(LineProperty[j], Buf+Len, pData);

                    switch(j)
                    {
                        case 0:
                            strcat(Buf+Len, "A ");
                            Len += 2;
                            break;
                        case 1:
                            strcat(Buf+Len, "/");
                            Len++;
                            break;
                        case 2:
                            strcat(Buf+Len, "kV");
                            Len += 2;
                            break;
                    }
                }
                break;
        }


        if(Len < 20)                        strncat(Buf, pSpace, 20-Len);

        Mmi_Goto(i, 0);

        Mmi_Printf("%s", Buf);

        pLineContents++;

    }
}

void MainView_SecondPage_Print(MmiDisplayContext* pDisplayContext)
{
    LineContents* pLineContents = pDisplayContext->pLineContents;
    uint16 i, Len = 0;

    char Buf[20];
    char* pStr;
    const char* pSpace = pDisplayContext->pBlank;

    LineProperty LineProperty;
    TagData* pTagData;
    void* pData = NULL;

    pLineContents+=4;

    for(i=0; i<4; i++)
    {
        pStr         = pLineContents->line_contents_A.pStr;
        LineProperty = pLineContents->line_contents_A.LineParameter.property;
        pTagData     = &pLineContents->line_contents_A.LineParameter.TagParam;


        strcpy(Buf, pStr);
        Len = strlen(Buf);


        pData = TagDataAddr_Get(pTagData);


        if(pData != NULL)               Len += LineString_Make(LineProperty, Buf+Len, pData);



        if(Len < 20)                        strncat(Buf, pSpace, 20-Len);

        Mmi_Goto(i, 0);
        Mmi_Printf("%s", Buf);

        pLineContents++;

    }
}

void MainView_Display(MmiDisplayContext* pDisplayContext)
{
    if(pDisplayContext->MainView_Scroll_Flag)
        MainView_SecondPage_Print(pDisplayContext);
    else
        MainView_FirstPage_Print(pDisplayContext);
}


static void Digit_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    RangeCursorTypeDesc* pRangeCursorTypeDesc = pParamEditContext->p_range_cursor_type;

    DisplayDataType     DisplayDataType = pRangeCursorTypeDesc->data_type;
    /*Digit*/
    int16  Digit = pParamEditContext->DotPosition-pParamEditContext->CursorPosition;

    float32 MaxValue = pRangeCursorTypeDesc->max_val;

    uint16  LCD_DisplayIntValue = 0;
    float32 LCD_DisplayFloatValue = 0.0;
    bool    FloatingFlag = 0;

    switch(DisplayDataType)
     {
         case DISP_DATA_UINT:
             LCD_DisplayIntValue = pParamEditContext->ParameterValue.IntValue;
             break;
         case DISP_DATA_FLOAT_0:
         case DISP_DATA_FLOAT_1:
         case DISP_DATA_FLOAT_2:
             LCD_DisplayFloatValue = pParamEditContext->ParameterValue.FloatValue;

             FloatingFlag = 1;
             break;
     }

    switch(Digit)
    {
        case -2:
            LCD_DisplayFloatValue += 0.01;
            LCD_DisplayFloatValue = round(LCD_DisplayFloatValue*1000)/1000;

            if(LCD_DisplayFloatValue <= MaxValue)       pParamEditContext->ParameterValue.FloatValue = LCD_DisplayFloatValue;

            break;
        case -1:
            LCD_DisplayFloatValue += 0.1;
            LCD_DisplayFloatValue = round(LCD_DisplayFloatValue*100)/100;

            if(LCD_DisplayFloatValue <= MaxValue)       pParamEditContext->ParameterValue.FloatValue = LCD_DisplayFloatValue;

            break;
        case 1:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue + 1 <= MaxValue)
                {
                    pParamEditContext->ParameterValue.IntValue += 1;
                }
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue + 1.0 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.FloatValue += 1.0;
                }
            }
            break;
        case 2:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue + 10 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.IntValue += 10;
                }
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue + 10.0 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.FloatValue += 10.0;
                }
            }
            break;
        case 3:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue + 100 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.IntValue += 100;
                }
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue + 100.0 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.FloatValue += 100.0;
                }
            }
            break;
        case 4:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue + 1000 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.IntValue += 1000;
                }
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue + 1000.0 <= MaxValue)
                {

                    pParamEditContext->ParameterValue.FloatValue += 1000.0;
                }
            }
            break;
    }

    char Buf[21] = {0};
    int Len=0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);


    if(FloatingFlag == 0)
    {
        Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pParamEditContext->pUnit);


    }
    else
    {
        switch(DisplayDataType)
        {
            case DISP_DATA_FLOAT_0:
                Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);
                break;
            case DISP_DATA_FLOAT_1:
                Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);

                break;
            case DISP_DATA_FLOAT_2:
                Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);
                break;
        }
    }
    if (Len+pParamEditContext->TextLength< sizeof(Buf) - 1) {
        snprintf(Buf + Len, sizeof(Buf) - Len - pParamEditContext->TextLength, "%*s", (int)(sizeof(Buf) - Len -  pParamEditContext->TextLength), "");
    }
    Mmi_Printf("%s", Buf);

    ParamCursorSet(pDisplayContext);
    pParamEditContext->CursorPosition=pParamEditContext->DotPosition-Digit;
    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->CursorPosition);

}
static void Digit_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    RangeCursorTypeDesc* pRangeCursorTypeDesc = pParamEditContext->p_range_cursor_type;
    DisplayDataType     DisplayDataType = pRangeCursorTypeDesc->data_type;
    /*Digit*/
    int16  Digit = pParamEditContext->DotPosition-pParamEditContext->CursorPosition;

    float32 MinValue = pRangeCursorTypeDesc->min_val;

    uint16  LCD_DisplayIntValue = 0;
    float32 LCD_DisplayFloatValue = 0.0;
    bool    FloatingFlag = 0, LCDUpdateFlag = 1;

    switch(pParamEditContext->p_range_cursor_type->data_type)
     {
         case DISP_DATA_UINT:
             LCD_DisplayIntValue = pParamEditContext->ParameterValue.IntValue;
             break;
         case DISP_DATA_FLOAT_0:
         case DISP_DATA_FLOAT_1:
         case DISP_DATA_FLOAT_2:
             LCD_DisplayFloatValue = pParamEditContext->ParameterValue.FloatValue;
             FloatingFlag = 1;
             break;
     }
    switch(Digit)
    {
        case -2:
            LCD_DisplayFloatValue -= 0.01;
            LCD_DisplayFloatValue = round(LCD_DisplayFloatValue*1000)/1000;

            if(LCD_DisplayFloatValue >= MinValue)       pParamEditContext->ParameterValue.FloatValue = LCD_DisplayFloatValue;

            break;
        case -1:
            LCD_DisplayFloatValue -= 0.1;
            LCD_DisplayFloatValue = round(LCD_DisplayFloatValue*100)/100;

            if(LCD_DisplayFloatValue >= MinValue)       pParamEditContext->ParameterValue.FloatValue = LCD_DisplayFloatValue;

            break;
        case 1:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue - 1 >= MinValue)
                {

                    pParamEditContext->ParameterValue.IntValue -= 1;
                }
                else    LCDUpdateFlag = 0;
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue - 1.0 >= MinValue)
                {

                    pParamEditContext->ParameterValue.FloatValue -= 1.0;
                }
                else    LCDUpdateFlag = 0;
            }
            break;
        case 2:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue - 10 >= MinValue)
                {

                    pParamEditContext->ParameterValue.IntValue -= 10;
                }
                else    LCDUpdateFlag = 0;
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue - 10.0 >= MinValue)
                {

                    pParamEditContext->ParameterValue.FloatValue -= 10;
                }
                else    LCDUpdateFlag = 0;
            }
            break;
        case 3:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue - 100 >= MinValue)
                {

                    pParamEditContext->ParameterValue.IntValue -= 100;
                }
                else    LCDUpdateFlag = 0;
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue - 100.0 >= MinValue)
                {

                    pParamEditContext->ParameterValue.FloatValue -= 100;
                }
                else    LCDUpdateFlag = 0;
            }
            break;
        case 4:
            if(FloatingFlag == 0)
            {
                if(pParamEditContext->ParameterValue.IntValue - 1000 >= MinValue)
                {

                    pParamEditContext->ParameterValue.IntValue -= 1000;
                }
                else    LCDUpdateFlag = 0;
            }
            else
            {
                if(pParamEditContext->ParameterValue.FloatValue + 1000.0 >= MinValue)
                {

                    pParamEditContext->ParameterValue.FloatValue -= 1000;
                }
                else    LCDUpdateFlag = 0;
            }
            break;
    }

    char Buf[21] = {0};
    int Len=0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);


    if(FloatingFlag == 0)
    {
        Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pParamEditContext->pUnit);
    }
    else
    {
        switch(DisplayDataType)
        {
            case DISP_DATA_FLOAT_0:
                Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);
                break;
            case DISP_DATA_FLOAT_1:
                Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);

                break;
            case DISP_DATA_FLOAT_2:
                Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pParamEditContext->pUnit);
                break;
        }
    }
    if (Len+pParamEditContext->TextLength< sizeof(Buf) - 1) {
        snprintf(Buf + Len, sizeof(Buf) - Len - pParamEditContext->TextLength, "%*s", (int)(sizeof(Buf) - Len -  pParamEditContext->TextLength), "");
    }
    Mmi_Printf("%s", Buf);

    ParamCursorSet(pDisplayContext);
    pParamEditContext->CursorPosition=pParamEditContext->DotPosition-Digit;
    if(pParamEditContext->CursorPosition<pParamEditContext->TextLength)
        pParamEditContext->CursorPosition=pParamEditContext->TextLength;
    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->CursorPosition);
}

static uint16 SelectNameTypeValue_Check(LineProperty LineProperty, float32* pDescValue, void* pData)
{
   uint16 i = 0;
    switch(LineProperty)
   {
       case LINE_PRT_SETTING_U:
       case LINE_PRT_DISPLAY_U:
       {
           float32 Temp = (float32)*(uint16*)pData;
           while(i<3)
           {
               if(pDescValue[i] == Temp)        return i;

               i++;
           }
       }
           break;
       case LINE_PRT_SETTING_F_0:
       case LINE_PRT_SETTING_F_1:
       case LINE_PRT_SETTING_F_2:
       case LINE_PRT_DISPLAY_F_0:
       case LINE_PRT_DISPLAY_F_1:
       case LINE_PRT_DISPLAY_F_2:
       {
           float32 Temp = *(float32*)pData;
           while(i<3)
           {
               if(pDescValue[i] == Temp)        return i;

               i++;
           }
       }
           break;
   }
    return 0;
}


void copyGroupData(TagData* sourceGroup, TagData* targetGroup, int count) {
    int i=0;

    for(i = 0; i < count; i++)
    {

        void* sourceDataAddr = TagDataAddr_Get(&sourceGroup[i]);
        void* targetDataAddr = TagDataAddr_Get(&targetGroup[i]);

        if(sourceGroup[i].TagGroup == TAG_GRP_LS0_UI || sourceGroup[i].TagGroup == TAG_GRP_LS1_UI)
        {
            *(uint16*)targetDataAddr = *(uint16*)sourceDataAddr;
        }
        else
        {
            *(float32*)targetDataAddr = *(float32*)sourceDataAddr;
        }

        FRAM_TagIntDataWrite(targetGroup[i].TagGroup, targetGroup[i].TagIndex);
    }
}

uint16 handleGroupCopy(MmiDisplayContext* pDisplayContext,PageCode ParentPageCode, uint16 lineCursor)
{
    switch(ParentPageCode)
    {
    case CB:
        {
            TagData* group1 = &pDisplayContext->p_group_data_content->Cb1;
            TagData* group2 = &pDisplayContext->p_group_data_content->Cb2;
            int count = CB_MAX_CNT;

            if(lineCursor == 1)
            {
                copyGroupData(group1, group2, count);
            }
            else if(lineCursor == 2)
            {
                copyGroupData(group2, group1, count);
            }
        }
        break;
    case VIT_MODE:
        {
            TagData* group1 = &pDisplayContext->p_group_data_content->Vit1;
            TagData* group2 = &pDisplayContext->p_group_data_content->Vit2;
            int count = VIT_MAX_CNT;

            if(lineCursor == 1)
            {
                copyGroupData(group1, group2, count);
            }
            else if(lineCursor == 2)
            {
                copyGroupData(group2, group1, count);
            }
        }
        break;
    }

    return 1;
}


uint16 MmiTagData_AllSet(MmiDisplayContext* pDisplayContext)
{
    SettingContext* pSettingContext=&pDisplayContext->SettingContext;
    TagData* pTagData;

    uint16 i =0;
    void* dataAddr = NULL;

    for(i=0;i<COMMAND_BUF_SIZE;i++)
    {
        if(&pSettingContext->TempData[i].TagData)
        {
            pTagData=&pSettingContext->TempData[i].TagData;
            dataAddr=TagDataAddr_Get(pTagData);
            if(pSettingContext->TempData[i].DisplayDataType==DISP_DATA_UINT)
            {
                *(uint16*)dataAddr=pSettingContext->TempData[i].ParameterValue.IntValue;
                //FRAM_TagIntDataWrite(pTagData->TagGroup, pTagData->TagIndex);
                FramTagEvt_Push(pTagData->TagGroup, pTagData->TagIndex);
            }
            else
            {
                *(float32*)dataAddr=pSettingContext->TempData[i].ParameterValue.FloatValue;
                //FRAM_TagFloatDataWrite(pTagData->TagGroup, pTagData->TagIndex);
                FramTagEvt_Push(pTagData->TagGroup, pTagData->TagIndex);
            }
        }
    }
    memset(pSettingContext, 0, sizeof(*pSettingContext));

    return 1;
}

uint16 MmiPassword_Set(MmiDisplayContext* pDisplayContext)
{
    FileDescriptor*     pPasswordFileDescriptor;
    PasswordSettingCtx* pPasswordContext = &pDisplayContext->param_edit_ctx_.Password_Setting_Context;
    char*               pPassword = &pDisplayContext->PasswordInfo.password;

    pPasswordFileDescriptor=File_Open(FILE_MMI_PASSWORD,MODE_WRITE);

    if(pPasswordFileDescriptor==NULL) return 0;

    File_Write(pPasswordFileDescriptor,pPassword, 16);

    File_Close(pPasswordFileDescriptor);

    memset(&pPasswordContext->setting_pw.password, 0x30, 16);
    pPasswordContext->setting_flag=0;

    return 1;

}

uint16 isEqualTagData(TagData* data1,TagData* data2)
{
    return (data1->TagGroup == data2->TagGroup) && (data1->TagIndex == data2->TagIndex);
}

void updateGroupTagValue(SettingContext* pSettingContext, TagData* groupArray, size_t groupSize)
{
    TagData* pTagData;
    uint16 i,j;
    for (i = 0; i < COMMAND_BUF_SIZE; i++)
    {
        if (&pSettingContext->TempData[i].TagData)
        {
            pTagData=&pSettingContext->TempData[i].TagData;

            for ( j = 0; j < groupSize; j++)
            {
                if (isEqualTagData(&pSettingContext->TempData[i].TagData, &groupArray[j]))
                {
                    void* dataAddr = TagDataAddr_Get(&pSettingContext->TempData[i].TagData);

                    if (pSettingContext->TempData[i].DisplayDataType == DISP_DATA_UINT)
                    {
                        *(uint16*)dataAddr = pSettingContext->TempData[i].ParameterValue.IntValue;
                        FRAM_TagIntDataWrite(pTagData->TagGroup, pTagData->TagIndex);
                    }
                    else
                    {
                        *(float32*)dataAddr = pSettingContext->TempData[i].ParameterValue.FloatValue;
                        FRAM_TagFloatDataWrite(pTagData->TagGroup, pTagData->TagIndex);
                    }
                    break;
                }
            }
        }
    }
}


uint16* MmiTagPointer_Get(void)
{
    if(TagPointerObject.pTAG_MMI == NULL)       return NULL;

    return TagPointerObject.pTAG_MMI;
}

uint16* BvTagPointer_Get(void)
{
    if(TagPointerObject.pTAG_BV == NULL)       return NULL;

    return TagPointerObject.pTAG_BV;
}

static uint16 Format_Print(DisplayDataType DisplayType, char* pBuf, void* pData)
{
    uint16 IntData;
    float32 FloatData;
    uint16 Len = 0;
    switch(DisplayType)
    {
       case DISP_DATA_UINT:
           IntData = *(uint16*)pData;
           Len = Mmi_Vsprintf(pBuf, "%d", IntData);
           break;
       case DISP_DATA_FLOAT_0:
           FloatData = *(float32*)pData;
           Len = Mmi_Vsprintf(pBuf, "%.0f", FloatData);
           break;
       case DISP_DATA_FLOAT_1:
           FloatData = *(float32*)pData;
           Len = Mmi_Vsprintf(pBuf, "%.1f", FloatData);
           break;
       case DISP_DATA_FLOAT_2:
           FloatData = *(float32*)pData;
           Len = Mmi_Vsprintf(pBuf, "%.2f", FloatData);
           break;
    }
    return Len;
}
static void RangeType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeTypeDesc* pRangeTypeDesc = pParamEditContext->p_range_type;

    float32 MaxValue = pRangeTypeDesc->max_val;
    float32 Step     = pRangeTypeDesc->Step;

    char Buf[21] = {0};
    int Len=0;

    float32 newValue = 0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    switch(pRangeTypeDesc->data_type)
    {
        case DISP_DATA_UINT:
            newValue = pParamEditContext->ParameterValue.IntValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.IntValue =(uint16)newValue;
            Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pRangeTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_0:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_1:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_2:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);

            break;
    }

    memset(Buf + Len, ' ', 20-pParamEditContext->TextLength-Len);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
static void RangeType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeTypeDesc* pRangeTypeDesc = pParamEditContext->p_range_type;

    float32 MinValue = pRangeTypeDesc->min_val;
    float32 Step     = pRangeTypeDesc->Step;

    char Buf[21] = {0};
    int Len=0;

    float32 newValue = 0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    switch(pRangeTypeDesc->data_type)
    {
        case DISP_DATA_UINT:
            newValue = pParamEditContext->ParameterValue.IntValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.IntValue =(uint16)newValue;
            Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pRangeTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_0:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue = newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);
            break;
        case DISP_DATA_FLOAT_1:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue -= Step;
            Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);
            break;
        case DISP_DATA_FLOAT_2:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue -= Step;
            Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pRangeTypeDesc->pUnit);
            break;
    }

    memset(Buf + Len, ' ', 20-pParamEditContext->TextLength-Len);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
void RangeTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
        case LCD_UP:
            RangeType_Increase(pDisplayContext);
            break;
        case LCD_DOWN:
            RangeType_Decrease(pDisplayContext);
            break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}
static void RangeDualType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeDualTypeDesc* pRangeDualTypeDesc = pParamEditContext->p_range_dual_type;
    float32 CurrentValue=pParamEditContext->ParameterValue.FloatValue;

    CurrentValue+=pRangeDualTypeDesc->Step;

    if(pRangeDualTypeDesc->Step>0)
    {
    if(CurrentValue>pRangeDualTypeDesc->max_val_positive)
        CurrentValue=pRangeDualTypeDesc->min_val_negative;
    if(CurrentValue==0)
        CurrentValue=pRangeDualTypeDesc->min_val_positive;
    }
    else
    {
        if(CurrentValue<pRangeDualTypeDesc->max_val_negative)
            CurrentValue=pRangeDualTypeDesc->min_val_negative;
    }
    pParamEditContext->ParameterValue.FloatValue=CurrentValue;

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf), "%.1f%s", CurrentValue, pRangeDualTypeDesc->pUnit);
    Len+=pParamEditContext->TextLength;
    if (Len < sizeof(Buf) - 1) {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", (int)(sizeof(Buf) - 1 - Len), "");
    }

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
static void RangeDualType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeDualTypeDesc* pRangeDualTypeDesc = pParamEditContext->p_range_dual_type;
    float32 CurrentValue=pParamEditContext->ParameterValue.FloatValue;

    CurrentValue-=pRangeDualTypeDesc->Step;

    if(pRangeDualTypeDesc->Step>0)
    {
    if(CurrentValue==0)
        CurrentValue=pRangeDualTypeDesc->max_val_negative;
    if(CurrentValue<pRangeDualTypeDesc->min_val_negative)
        CurrentValue=pRangeDualTypeDesc->max_val_positive;
    }
    else
    {
        if(CurrentValue>pRangeDualTypeDesc->min_val_negative)
            CurrentValue=pRangeDualTypeDesc->max_val_negative;
    }
    pParamEditContext->ParameterValue.FloatValue=CurrentValue;

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf), "%.1f%s", CurrentValue, pRangeDualTypeDesc->pUnit);
    Len+=pParamEditContext->TextLength;
    if (Len < sizeof(Buf) - 1) {
        snprintf(Buf + Len, sizeof(Buf) - Len, "%*s", (int)(sizeof(Buf) - 1 - Len), "");
    }

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
void RangeDualTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
        case LCD_UP:
            RangeDualType_Increase(pDisplayContext);
            break;
        case LCD_DOWN:
            RangeDualType_Decrease(pDisplayContext);
            break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}
static void RangeOffType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeOffTypeDesc* pRangeOffTypeDesc = pParamEditContext->p_range_off_type;

    float32 MaxValue = pRangeOffTypeDesc->max_val;
    float32 Step     = pRangeOffTypeDesc->Step;

    char Buf[21] = {0};
    int Len=0;

    float32 newValue = 0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    switch(pRangeOffTypeDesc->data_type)
    {
        case DISP_DATA_UINT:
            newValue = pParamEditContext->ParameterValue.IntValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.IntValue =(uint16)newValue;
            Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pRangeOffTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_0:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_1:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_2:
            newValue = pParamEditContext->ParameterValue.FloatValue+Step;
            if(newValue <= MaxValue)
                pParamEditContext->ParameterValue.FloatValue =newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);

            break;
    }

    memset(Buf + Len, ' ', 20-pParamEditContext->TextLength-Len);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
static void RangeOffType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    RangeOffTypeDesc* pRangeOffTypeDesc = pParamEditContext->p_range_off_type;

    float32 MinValue = pRangeOffTypeDesc->min_val;
    float32 Step     = pRangeOffTypeDesc->Step;

    char Buf[21] = {0};
    int Len=0;

    float32 newValue = 0;

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    switch(pRangeOffTypeDesc->data_type)
    {
        case DISP_DATA_UINT:
            newValue = pParamEditContext->ParameterValue.IntValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.IntValue =(uint16)newValue;
            Len = snprintf(Buf, sizeof(Buf), "%d%s", pParamEditContext->ParameterValue.IntValue, pRangeOffTypeDesc->pUnit);

            break;
        case DISP_DATA_FLOAT_0:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue = newValue;
            Len = snprintf(Buf, sizeof(Buf), "%.0f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);
            break;
        case DISP_DATA_FLOAT_1:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue -= Step;
            Len = snprintf(Buf, sizeof(Buf), "%.1f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);
            break;
        case DISP_DATA_FLOAT_2:
            newValue = pParamEditContext->ParameterValue.FloatValue-Step;
            if(newValue >= MinValue)
                pParamEditContext->ParameterValue.FloatValue -= Step;
            Len = snprintf(Buf, sizeof(Buf), "%.2f%s", pParamEditContext->ParameterValue.FloatValue, pRangeOffTypeDesc->pUnit);
            break;
    }

    memset(Buf + Len, ' ', 20-pParamEditContext->TextLength-Len);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);
}
void RangeOffTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
    case LCD_UP:
        RangeOffType_Increase(pDisplayContext);
        break;
    case LCD_DOWN:
        RangeOffType_Decrease(pDisplayContext);
        break;;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}
void RangeCursorTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    RangeCursorTypeDesc* pRangeCursorTypeDesc = pParamEditContext->p_range_cursor_type;

    switch(Command)
    {
        case LCD_LEFT:
            pParamEditContext->CursorPosition--;
            if(pParamEditContext->CursorPosition >= pParamEditContext->TextLength)
            {
                switch(pRangeCursorTypeDesc->data_type)
                {
                    case DISP_DATA_FLOAT_1:
                    case DISP_DATA_FLOAT_2:
                        if(pParamEditContext->CursorPosition == pParamEditContext->DotPosition)
                            {
                                pParamEditContext->CursorPosition--;
                            }
                        break;
                }
                Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->CursorPosition);
            }
            else pParamEditContext->CursorPosition++;
            break;
        case LCD_RIGHT:
            pParamEditContext->CursorPosition++;
            if(pParamEditContext->CursorPosition <= pParamEditContext->EndPosition)
            {
                switch(pRangeCursorTypeDesc->data_type)
                {
                case DISP_DATA_FLOAT_1:
                case DISP_DATA_FLOAT_2:
                    if((pParamEditContext->CursorPosition) == pParamEditContext->DotPosition)
                    {
                        pParamEditContext->CursorPosition++;
                    }
                    break;
                }
                Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->CursorPosition);
            }
            else  pParamEditContext->CursorPosition--;
            break;
        case LCD_UP:
            Digit_Increase(pDisplayContext);
            break;
        case LCD_DOWN:
            Digit_Decrease(pDisplayContext);
            break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}
static void SelectType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    SelectTypeDesc* pSelectTypeDesc = pParamEditContext->p_select_type;

    int current_idx = 0;
    int  i = 0;
    for (i = 0; i < 5; ++i) {
        if (pParamEditContext->ParameterValue.IntValue == (uint16)pSelectTypeDesc->val[i]) {
            current_idx = i;
            break;
        }
    }

    current_idx = (current_idx + 1) % 5;
    pParamEditContext->ParameterValue.IntValue = (uint16)pSelectTypeDesc->val[current_idx];

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf)- pParamEditContext->TextLength, "%d%s", pParamEditContext->ParameterValue.IntValue, pSelectTypeDesc->pUnit);
    snprintf(Buf + Len, sizeof(Buf) - Len- pParamEditContext->TextLength, "%*s", 20 - Len -pParamEditContext->TextLength, "");

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
static void SelectType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    SelectTypeDesc* pSelectTypeDesc = pParamEditContext->p_select_type;

    int current_idx = 0;
    int  i = 0;
    for (i = 0; i < 5; ++i) {
        if (pParamEditContext->ParameterValue.IntValue == (uint16)pSelectTypeDesc->val[i]) {
            current_idx = i;
            break;
        }
    }

    current_idx = (current_idx - 1 + 5) % 5;
    pParamEditContext->ParameterValue.IntValue = (uint16)pSelectTypeDesc->val[current_idx];

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf)- pParamEditContext->TextLength, "%d%s", pParamEditContext->ParameterValue.IntValue, pSelectTypeDesc->pUnit);
    snprintf(Buf + Len, sizeof(Buf) - Len- pParamEditContext->TextLength, "%*s", 20 - Len -pParamEditContext->TextLength, "");

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
void SelectTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
        case LCD_UP:
            SelectType_Increase(pDisplayContext);
            break;
        case LCD_DOWN:
            SelectType_Decrease(pDisplayContext);
            break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}

static void SelectNameType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    SelectNameTypeDesc* pSelectNameTypeDesc=pParamEditContext->p_select_name_type;

    int current_idx = 0;
    int  i = 0;
    for (i = 0; i < 3; ++i) {
        if (pParamEditContext->ParameterValue.IntValue == (uint16)pSelectNameTypeDesc->val[i]) {
            current_idx = i;
            break;
        }
    }

    if(pSelectNameTypeDesc->val_name[2]==N_A)
        current_idx = (current_idx + 1) % 2;
    else
        current_idx = (current_idx + 1) % 3;

    pParamEditContext->ParameterValue.IntValue = (uint16)pSelectNameTypeDesc->val[current_idx];

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf)-pParamEditContext->TextLength, "%s%s", pSelectNameTypeDesc->val_name[current_idx], pSelectNameTypeDesc->pUnit);
    snprintf(Buf + Len, sizeof(Buf) - Len- pParamEditContext->TextLength, "%*s", 20 - Len -pParamEditContext->TextLength, "");

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
static void SelectNameType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    SelectNameTypeDesc* pSelectNameTypeDesc=pParamEditContext->p_select_name_type;

    int current_idx = 0;
    int  i = 0;
    for (i = 0; i < 3; ++i) {
        if (pParamEditContext->ParameterValue.IntValue == (uint16)pSelectNameTypeDesc->val[i]) {
            current_idx = i;
            break;
        }
    }

    if(pSelectNameTypeDesc->val_name[2]==N_A)
        current_idx = (current_idx - 1 + 2) % 2;
    else
        current_idx = (current_idx - 1 + 3) % 3;


    pParamEditContext->ParameterValue.IntValue = (uint16)pSelectNameTypeDesc->val[current_idx];

    char Buf[21] = {0};
    int Len = snprintf(Buf, sizeof(Buf)-pParamEditContext->TextLength, "%s%s", pSelectNameTypeDesc->val_name[current_idx], pSelectNameTypeDesc->pUnit);
    snprintf(Buf + Len, sizeof(Buf) - Len- pParamEditContext->TextLength, "%*s", 20 - Len -pParamEditContext->TextLength, "");

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
void SelectNameTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
        case LCD_UP:
            SelectNameType_Increase(pDisplayContext);
            break;
        case LCD_DOWN:
            SelectNameType_Decrease(pDisplayContext);
            break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }



}
static int NameType_Print(ParamEditContext* pParamEditContext,char* pBuf)
{
    TccCurveType CurrentTccType=pParamEditContext->ParameterValue.IntValue;
    int Len=0;

    if(CurrentTccType>=TCCCVT_COOPER_101 && CurrentTccType<=TCCCVT_COOPER_107)
        Len = snprintf(pBuf, 20, "%s", "CP_10");
    else if(CurrentTccType>=TCCCVT_COOPER_111 && CurrentTccType<=TCCCVT_COOPER_165)
        Len = snprintf(pBuf, 20, "%s", "CP_1");
    else if(CurrentTccType>=TCCCVT_IEC_C1 && CurrentTccType<=TCCCVT_IEC_C5)
        Len = snprintf(pBuf, 20, "%s", "IEC_C");
    else if(CurrentTccType>=TCCCVT_US_U1 && CurrentTccType<=TCCCVT_US_U5)
        Len = snprintf(pBuf, 20, "%s", "US_U");
    else if(CurrentTccType==TCCCVT_USER)
        Len = snprintf(pBuf, 20, "%s", "USER");
    else if(CurrentTccType==TCCCVT_DEF)
        Len = snprintf(pBuf, 20, "%s", "DEF");
    else
        Len = snprintf(pBuf, 20, "%s", "ERROR");

    return Len;
}
static void NameType_Increase(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    NameTypeDesc* pNameTypeDesc=pParamEditContext->p_name_type;
    TccCurveType CurrentTccType=pParamEditContext->ParameterValue.IntValue;

    char Buf[21] = {0};
    int Len=0;

    CurrentTccType++;

    if(CurrentTccType==TCCCVT_COOPER_107+1)
        CurrentTccType=TCCCVT_COOPER_111;

    if(CurrentTccType==TCCCVT_COOPER_165+1)
        CurrentTccType=TCCCVT_IEC_C1;

    if(CurrentTccType==TCCCVT_IEC_C5+1)
        CurrentTccType=TCCCVT_US_U1;

    if(CurrentTccType==TCCCVT_US_U5+1)
        CurrentTccType=TCCCVT_USER;

    if(CurrentTccType==TCCCVT_USER+1)
        CurrentTccType=TCCCVT_DEF;

    if(CurrentTccType>pNameTypeDesc->max_val)
        CurrentTccType=pNameTypeDesc->max_val;

    pParamEditContext->ParameterValue.IntValue=CurrentTccType;
    Len=NameType_Print(pParamEditContext,Buf);
    snprintf(Buf + Len, sizeof(Buf) -Len-pParamEditContext->TextLength, "%*s", 20 - Len-pParamEditContext->TextLength, "");

    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
static void NameType_Decrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext *pParamEditContext=&pDisplayContext->param_edit_ctx_;
    NameTypeDesc* pNameTypeDesc=pParamEditContext->p_name_type;
    TccCurveType CurrentTccType=pParamEditContext->ParameterValue.IntValue;

    char Buf[21] = {0};
    int Len=0;

    CurrentTccType--;

    if(CurrentTccType==TCCCVT_COOPER_111-1)
        CurrentTccType=TCCCVT_COOPER_107;

    if(CurrentTccType==TCCCVT_IEC_C1-1)
        CurrentTccType=TCCCVT_COOPER_165;

    if(CurrentTccType==TCCCVT_US_U1-1)
        CurrentTccType=TCCCVT_IEC_C5;

    if(CurrentTccType==TCCCVT_USER-1)
        CurrentTccType=TCCCVT_US_U5;

    if(CurrentTccType==TCCCVT_DEF-1)
        CurrentTccType=TCCCVT_USER;

    if(CurrentTccType<pNameTypeDesc->min_val)
        CurrentTccType=pNameTypeDesc->min_val;

    pParamEditContext->ParameterValue.IntValue=CurrentTccType;
    Len= NameType_Print(pParamEditContext,Buf);
    snprintf(Buf + Len, sizeof(Buf) -Len-pParamEditContext->TextLength, "%*s", 20 - Len-pParamEditContext->TextLength, "");


    Mmi_Goto(pParamEditContext->EditLine, pParamEditContext->TextLength);
    Mmi_Printf("%s", Buf);
    ParamCursorSet(pDisplayContext);

}
void NameTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    switch(Command)
    {
    case LCD_UP:
        NameType_Increase(pDisplayContext);
        break;
    case LCD_DOWN:
        NameType_Decrease(pDisplayContext);
        break;
        case LCD_MENU:
            EditMode_Exit(pDisplayContext);
            break;
        case LCD_ENTER:
            EditData_Save(pDisplayContext);
            EditMode_Exit(pDisplayContext);
            break;
    }
}
int IsLeapYear(int year)
{
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int GetMaxDayOfMonth(int year, int month)
{
    int daysOfMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month == 2 && IsLeapYear(year)) {
        return 29;
    }
    return daysOfMonth[month - 1];
}
void TimeTypeIncrease(MmiDisplayContext *pDisplayContext)
{
    ParamEditContext* pParamEditContext=&pDisplayContext->param_edit_ctx_;
    switch(pParamEditContext->CursorPosition)
    {
        case MMI_YEAR_ONE:
            pDisplayContext->SettingTime.Year = (pDisplayContext->SettingTime.Year + 1) % 10000;
            break;
        case MMI_MONTH_ONE:
            if (++pDisplayContext->SettingTime.Month > 12) pDisplayContext->SettingTime.Month = 1;
            break;
        case MMI_DAY_ONE:
            if (pDisplayContext->SettingTime.Day >= GetMaxDayOfMonth(pDisplayContext->SettingTime.Year, pDisplayContext->SettingTime.Month))
                pDisplayContext->SettingTime.Day = 1;
            else
                pDisplayContext->SettingTime.Day++;
            break;
        case MMI_HOUR_ONE:
            if (++pDisplayContext->SettingTime.Hour > 23) pDisplayContext->SettingTime.Hour = 0;
            break;
        case MMI_MIN_ONE:
            if (++pDisplayContext->SettingTime.Min > 59) pDisplayContext->SettingTime.Min = 0;
            break;
        case MMI_SEC_ONE:
            if (++pDisplayContext->SettingTime.Sec > 59) pDisplayContext->SettingTime.Sec = 0;
            break;
    }
}
void TimeTypeDecrease(MmiDisplayContext *pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;

    switch(pParamEditContext->CursorPosition) {
        case MMI_YEAR_ONE:
            pDisplayContext->SettingTime.Year = (pDisplayContext->SettingTime.Year + 9999) % 10000;
            break;
        case MMI_MONTH_ONE:
            pDisplayContext->SettingTime.Month = (pDisplayContext->SettingTime.Month + 12) % 13;
            break;
        case MMI_DAY_ONE:
            pDisplayContext->SettingTime.Day = (pDisplayContext->SettingTime.Day == 1)
                ? GetMaxDayOfMonth(pDisplayContext->SettingTime.Year, pDisplayContext->SettingTime.Month)
                : pDisplayContext->SettingTime.Day - 1;
            break;
        case MMI_HOUR_ONE:
            pDisplayContext->SettingTime.Hour = (pDisplayContext->SettingTime.Hour + 23) % 24;
            break;
        case MMI_MIN_ONE:
            pDisplayContext->SettingTime.Min = (pDisplayContext->SettingTime.Min + 59) % 60;
            break;
        case MMI_SEC_ONE:
            pDisplayContext->SettingTime.Sec = (pDisplayContext->SettingTime.Sec + 59) % 60;
            break;
    }
}

void TimeTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;

    switch(Command)
    {
    case LCD_UP:
        TimeTypeIncrease(pDisplayContext);
        break;
    case LCD_DOWN:
        TimeTypeDecrease(pDisplayContext);
        break;
    case LCD_LEFT:
        if(pParamEditContext->CursorPosition>=MMI_YEAR_ONE)
            pParamEditContext->CursorPosition=pParamEditContext->CursorPosition-MmiTimeOffset;
        break;
    case LCD_RIGHT:
        if(pParamEditContext->CursorPosition<=MMI_SEC_ONE)
            pParamEditContext->CursorPosition=pParamEditContext->CursorPosition+MmiTimeOffset;
        break;
    case LCD_MENU:
        EditMode_Exit(pDisplayContext);
        return;
    case LCD_ENTER:
        Mmi_TimeSet(&pDisplayContext->SettingTime);
        EditMode_Exit(pDisplayContext);
        break;
    }
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);
}

void PasswordTypeIncrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    PasswordSettingCtx* pPasswordSettingContext = &pParamEditContext->Password_Setting_Context;

    pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12]++;
    //9->A
    if(pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] == 0x3A)
        pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] = 0x41;
    //Z->0
    if(pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] == 0x5B)
        pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] = 0x30;
}

void PasswordTypeDecrease(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    PasswordSettingCtx* pPasswordSettingContext = &pParamEditContext->Password_Setting_Context;

    pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12]--;
    //A->9
    if(pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] == 0x40)
        pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] = 0x39;
    //0->Z
    if(pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] == 0x2F)
        pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12] = 0x5A;
}
void Password_Save(MmiDisplayContext* pDisplayContext)
{
    char*        pPassword = &pDisplayContext->PasswordInfo.password;
    PasswordSettingCtx* pPasswordSettingContext   = &pDisplayContext->param_edit_ctx_.Password_Setting_Context;

    if(memcmp(pPassword, &pPasswordSettingContext->setting_pw.password, sizeof(pDisplayContext->PasswordInfo.password)))
    {
        pPasswordSettingContext->setting_flag=1;
        memcpy(pPassword, &pPasswordSettingContext->setting_pw.password, sizeof(pDisplayContext->PasswordInfo.password));
    }
}
void PasswordTypeHandler(MmiDisplayContext* pDisplayContext, LCD_BUTTON_TYPE Command)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;
    PasswordSettingCtx* pPasswordSettingContext = &pParamEditContext->Password_Setting_Context;

    switch(Command)
    {
    case LCD_UP:
        PasswordTypeIncrease(pDisplayContext);
        break;
    case LCD_DOWN:
        PasswordTypeDecrease(pDisplayContext);
        break;
    case LCD_LEFT:
        Mmi_Printf("*");
        if(pParamEditContext->CursorPosition>12)
            pParamEditContext->CursorPosition--;

        break;
    case LCD_RIGHT:
        Mmi_Printf("*");
        if(pParamEditContext->CursorPosition<15)
            pParamEditContext->CursorPosition++;
        break;
    case LCD_MENU:
        Mmi_Printf("*");
        EditMode_Exit(pDisplayContext);
        return;
    case LCD_ENTER:
        Mmi_Printf("*");
        Password_Save(pDisplayContext);
        EditMode_Exit(pDisplayContext);
        return;
    }

    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);
    Mmi_Printf("%c", pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12]);
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);

}

void TimeEditSet(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;

    pDisplayContext->mode = MMI_MODE_EDIT;
    pParamEditContext->CursorPosition=MMI_YEAR_ONE;
    pParamEditContext->param_desc_type=PARAM_TIME_TYPE;
    pDisplayContext->view_cursor=3;
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);

    /*LED Blink*/
    pLCD_Device->pfLCD_Control(CLCD_DISPLAY_CURSOR_BLINK);
}

void PWEditSet(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext*   pParamEditContext         = &pDisplayContext->param_edit_ctx_;
    PasswordSettingCtx* pPasswordSettingContext   = &pParamEditContext->Password_Setting_Context;

    pDisplayContext->mode = MMI_MODE_EDIT;
    pParamEditContext->CursorPosition=12;
    pParamEditContext->param_desc_type=PARAM_PASSWORD_TYPE;
    pDisplayContext->view_cursor=1;
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);

    switch(pDisplayContext->CurrentPageCode)
    {
    case VIEWER:
        pPasswordSettingContext->setting_pw_level = PW_LEVEL_1;
        break;
    case OPERATOR:
        pPasswordSettingContext->setting_pw_level = PW_LEVEL_2;
        break;
    case ENGINEER:
        pPasswordSettingContext->setting_pw_level = PW_LEVEL_3;
        break;
    case ADMIN:
        pPasswordSettingContext->setting_pw_level = PW_LEVEL_4;
        break;
    }

    Mmi_Printf("%c", pPasswordSettingContext->setting_pw.password[pPasswordSettingContext->setting_pw_level][pParamEditContext->CursorPosition-12]);
    Mmi_Goto(pDisplayContext->view_cursor, pParamEditContext->CursorPosition);
    /*LED Blink*/
    pLCD_Device->pfLCD_Control(CLCD_DISPLAY_CURSOR_BLINK);
}

void LoadPassword(MmiDisplayContext* pDisplayContext)
{
    FileDescriptor*     pPasswordFileDescriptor;

    PasswordSettingCtx* pPasswordSettingContext   = &pDisplayContext->param_edit_ctx_.Password_Setting_Context;
    MmiPassword*        pPassword = &pDisplayContext->PasswordInfo.password;


    if(!pPasswordSettingContext->setting_flag)
    {
    pPasswordFileDescriptor=File_Open(FILE_MMI_PASSWORD,MODE_READ);

    if(pPasswordFileDescriptor==NULL) return 0;

    File_Read(pPasswordFileDescriptor,pPassword, 16);

    File_Close(pPasswordFileDescriptor);

    memcpy(&pPasswordSettingContext->setting_pw.password, pPassword, sizeof(MmiPassword));
    }
}
