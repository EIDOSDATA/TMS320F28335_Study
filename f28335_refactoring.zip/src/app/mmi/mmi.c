/*
 * Mmi_.c
 *
 *  Created on: 2024. 1. 23.
 *      Author: ShinSung Industrial Electric
 */
#include <src/app/mmi/mmi_display.h>
#include <src/app/mmi/mmi_macro.h>
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "src/port/clcd.h"
#include "src/port/decoder.h"

#define COUNTS_PER_SEC 20
#define MMI_BUTTON_COUNT            1
#define MMI_WRITE_BLOCK_MAX         6

#define EVENTFILEMAX                9

#define OFFSET_ADDR                 0x200400

#define LED_BLOCK0_ADDR             0
#define LED_BLOCK1_ADDR             1
#define LED_BLOCK2_ADDR             2
#define LED_BLOCK3_ADDR             3
#define LED_BLOCK4_ADDR             4
#define LED_BLOCK6_ADDR             6

#define LED_BLOCK_WRITE(block, data)      *((volatile uint16 *)(OFFSET_ADDR + block)) = data
#define LED_BLOCK_READ(block, data)       data= *((volatile uint16 *)(OFFSET_ADDR + block))



#pragma DATA_SECTION(MmiCtx, "ZONE6DATA")
#pragma DATA_SECTION(SequentialEventFileBuffer, "ZONE6DATA")
#pragma DATA_SECTION(FaultEventFileBuffer, "ZONE6DATA")


typedef enum
{
    STATUS_BUTTON,
    LCD_BUTTON,

} MMI_OPERATION;
typedef enum
{
    /*BUTTON BLOCK0*/
    MMI_BUTTON_SEQENCE_TRIP_TEST    = 0xFE,
    MMI_BUTTON_TARGET_RESET         = 0xFD,
    MMI_BUTTON_BATTERY_TEST         = 0xFB,
    MMI_BUTTON_PROTECTION_ENABLED   = 0xF7,
    MMI_BUTTON_RECLOSE_ENABLED      = 0xEF,
    MMI_BUTTON_GROUND_ENABLED       = 0xDF,
    MMI_BUTTON_FAST_CURVE_ENABLED   = 0xBF,
    MMI_BUTTON_REMOTE_ENABLED       = 0x7F,

} MMI_BUTTON0_TYPE;
typedef enum
{
    /*BUTTON BLOCK1*/
    MMI_BUTTON_EVENT_MENU               = 0xFE,
    MMI_BUTTON_CLOSE                    = 0xFD,
    MMI_BUTTON_HOT_LINE_TAG             = 0xFB,
    MMI_BUTTON_SEF_ENABLED              = 0xF7,
    MMI_BUTTON_SEQUENCE_COORDINATION    = 0xEF,
    MMI_BUTTON_COLD_LOAD_PICK_UP        = 0xDF,
    MMI_BUTTON_SET_GROUP1               = 0xBF,
    MMI_BUTTON_SET_GROUP2               = 0x7F,

} MMI_BUTTON1_TYPE;

typedef enum
{
    /*BUTTON BLOCK2*/
    MMI_BUTTON_TRIP = 0x7E,             // 126
    MMI_BUTTON_LCD_LEFT = 0x7D,         //  125
    MMI_BUTTON_LCD_RIGHT = 0x7B,        // 123
    MMI_BUTTON_LCD_UP = 0x77,       /*0111 0111*/       // 77
    MMI_BUTTON_LCD_DOWN = 0x6F,     /*0110 1111*/       // 111
    MMI_BUTTON_LCD_MENU = 0x5F,                         // 95
    MMI_BUTTON_LCD_ENTER = 0x3F,                        // 63

} MMI_BUTTON2_TYPE;


typedef enum
{
    MMI_NO_COMMAND,
    /*Block 0*/
    MMI_SEQENCE_TRIP_TEST,
    MMI_TARGET_RESET,
    MMI_BATTERY_TEST,
    MMI_PROTECTION_ENABLED,
    MMI_RECLOSE_ENABLED,
    MMI_GROUND_ENABLED,
    MMI_FAST_CURVE_ENABLED,
    MMI_REMOTE_ENABLED,
    /*Block 1*/
    MMI_EVENT_MENU,
    MMI_CLOSE,
    MMI_HOT_LINE_TAG,
    MMI_SEF_ENABLED,
    MMI_SEQUENCE_COORDINATION,
    MMI_COLD_LOAD_PICK_UP,
    MMI_SET_GROUP1,
    MMI_SET_GROUP2,

    /*Block 2*/
    MMI_TRIP,
    MMI_LCD_LEFT,
    MMI_LCD_RIGHT,
    MMI_LCD_UP,
    MMI_LCD_DOWN,
    MMI_LCD_MENU,
    MMI_LCD_ENTER,

} MMI_COMMAND_TYPE;



typedef enum
{
    MMI_BUTTON_NULL,
    MMI_BUTTON_BLOCK0,
    MMI_BUTTON_BLOCK1,
    MMI_BUTTON_BLOCK2,

    MMI_BUTTON_BLOCK_MAX = 3,

} MMI_BUTTON_BLOCK;

typedef enum
{
    MEASURE_MODE,
    MENU_MODE,
    EDIT_MODE,

} DISPLAY_MODE;

typedef struct
{
    DISPLAY_MODE            DisplayMode;

    MmiDisplayContext*      pMmiDisplayContext;

    TAG_DB*                 pTagDb;

    uint8*                  MmiWriteBlock[MMI_WRITE_BLOCK_MAX];

    bool                    MmiOperation;

    /*Button*/
    uint16                  MmiPushButton[MMI_BUTTON_BLOCK_MAX];
    uint16                  MmiButtonCnt;

/*
 * Block 0
 * Bit Number : Bit7             Bit6        Bit5           Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : C-PHASE         B-PHASE     A-PHASE         79LO        79CY            79RS            CONTROL ENALBED     AC POWER
 * Color      : Green           Green       Green
 * ALIAS      : LEDFLTC         LEDFLTB     LEDFLTA         LED79LO     LED79CY         LED79RS         LEDCPU              LEDAC
 *
 * Block 1
 * Bit Number : Bit7            Bit6        Bit5            Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : OPEN_CONDUCTOR  UVR         BUMP_PREVENTION LOAD_SIDE   HANDLE_LOCK     BAT_NOK         SEF/HIF             GND_PHASE
 * Color      :
 * ALIAS      : LEDOC           LEDABC      LEDBUMP         LEDLOAD     LEDHLOCK        LEDBATTB        LEDFLTSEF           LEDFLTN
 *
 * Block 2
 * Bit Number : Bit7            Bit6        Bit5            Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : PROTECTION_LED  OVR         SOURCE_SIDE     LOV         AUX1            81              HIGH                SPARE1
 * Color      :
 * ALIAS      : LEDPROT         LEDCBA      LEDSOURCE       LEDLOV      LEDSCH          LEDDIAGNOSFAIL  LED81               LEDHIGH
 *
 * Block 3
 * Bit Number : Bit7            Bit6        Bit5            Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : RAD_NC_LED      HOTLINE_TAG CLOSE           DELAY       REMOTE          SEF/HIF         GROUND              RECLOSING
 * Color      :
 * ALIAS      : LEDRNC          LEDHT       LEDCLOSE        LEDCLP      LEDRT           LEDSEF          LEDGND              LEDRC
 *
 * Block 4
 * Bit Number : Bit7            Bit6        Bit5            Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : LCD_E           LCD_BL      LCD_A0          TRIP_LED    RST_ABC_LED     ABC_RST_LED     LOOP_NO_LED         LOOP_NC_LED
 * Color      :
 * ALIAS      :                                             LEDTRIP     LEDR2A          LEDA2R          LEDLNO              LEDLNC
 *
 * Block 6
 * Bit Number : Bit7            Bit6        Bit5            Bit4        Bit3            Bit2            Bit1                Bit0
 * Net Name   : AUX2            SG3         SG2             SG1         GND_PICKUP      C_PICKUP        B_PICKUP            A_PICKUP
 * Color      :                                                         Red             Red             Red                 Red
 * ALIAS      : LEDV79CY        LEDV79RS    LEDSG2          LEDSG1      LEDFLTN_Y       LEDFLTC_Y       LEDFLTB_Y           LEDFLTA_Y
 */

    uint16                  MmiBlock0;
    uint16                  MmiBlock1;
    uint16                  MmiBlock2;
    uint16                  MmiBlock3;
    uint16                  MmiBlock4;
    uint16                  MmiBlock6;

    /*Tag Pointer*/
    uint16*                 pMmiTag;
    uint16*                 pBvTag;

    uint16                  TestModeSecCount;

} MmiContext;

static MmiContext MmiCtx;
SeqEvtFormat SequentialEventFileBuffer[SEQ_EVT_DATA_MAX];  //1word= 16bit = 2byte
FltEvtFormat FaultEventFileBuffer[FLT_EVT_DATA_MAX];

Mmi_TimeStamp MmiTimeStamp;


static void MmiLedData_Write(MmiContext* pContext, uint16* pTAG_MMI);

static void MmiLedInit(MmiContext* pContext);
static MMI_COMMAND_TYPE Mmi_ButtonBlock0(uint16  Button);
static MMI_COMMAND_TYPE Mmi_ButtonBlock1(uint16  Button);
static MMI_COMMAND_TYPE Mmi_ButtonBlock2(uint16  Button);


static void UpButtonClick(MmiDisplayContext* pDisplayContext)
{
    switch(pDisplayContext->CurrentPageProperty)
    {
        case PAGE_PRT_MEASURE:
        pDisplayContext->MainView_Scroll_Flag^=1;
        break;
        case PAGE_PRT_DEFAULT:
        case PAGE_PRT_GRP_COPY:
            MmiCursorMoveUp(pDisplayContext);
            break;
        case PAGE_PRT_SETTING:
            MmiEditPageCursorMoveUp(pDisplayContext);
            EditLine_Data_Set(pDisplayContext);
            ParamDescLine_Print(&pDisplayContext->param_edit_ctx_);
            break;
        case PAGE_PRT_SEQ_EVENT:
            if(pDisplayContext->SequentialEventContext.currntindex>0)
                pDisplayContext->SequentialEventContext.currntindex--;
            SequentialEventPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_FLT_EVENT:
            if(pDisplayContext->FaultEventContext.scrollflag -1 >= 0)
            {
                pDisplayContext->FaultEventContext.scrollflag--;
                if(pDisplayContext->FaultEventContext.scrollflag%2==1)
                    pDisplayContext->FaultEventContext.currntindex--;
            }
            FaultEventPage_Print(pDisplayContext);
            break;

    }
}
static void DownButtonClick(MmiDisplayContext* pDisplayContext)
{
    switch(pDisplayContext->CurrentPageProperty)
    {
    case PAGE_PRT_MEASURE:
    pDisplayContext->MainView_Scroll_Flag^=1;
    break;
    case PAGE_PRT_DEFAULT:
    case PAGE_PRT_GRP_COPY:
        MmiCursorMoveDown(pDisplayContext);
        break;
    case PAGE_PRT_SETTING:
        MmiEditPageCursorMoveDown(pDisplayContext);
        EditLine_Data_Set(pDisplayContext);
        ParamDescLine_Print(&pDisplayContext->param_edit_ctx_);
        break;
    case PAGE_PRT_SEQ_EVENT:
        if(pDisplayContext->SequentialEventContext.currntindex < pDisplayContext->SequentialEventContext.maxcount-1)
            pDisplayContext->SequentialEventContext.currntindex++;
        SequentialEventPage_Print(pDisplayContext);
        break;
    case PAGE_PRT_FLT_EVENT:
        if(pDisplayContext->FaultEventContext.scrollflag + 1 < pDisplayContext->FaultEventContext.maxcount*2)
        {
            pDisplayContext->FaultEventContext.scrollflag++;
            if(pDisplayContext->FaultEventContext.scrollflag%2==0)
            {
                pDisplayContext->FaultEventContext.currntindex++;
            }
        }
        FaultEventPage_Print(pDisplayContext);
        break;

    }
}
static void LeftButtonClick(MmiDisplayContext* pDisplayContext)
{
    switch(pDisplayContext->CurrentPageProperty)
    {
    case PAGE_PRT_SEQ_EVENT:
        if(pDisplayContext->SequentialEventContext.currntindex - 10 > 0)
            pDisplayContext->SequentialEventContext.currntindex -= 10;

        SequentialEventPage_Print(pDisplayContext);
        break;
    }
}
static void RightButtonClick(MmiDisplayContext* pDisplayContext)
{
    switch(pDisplayContext->CurrentPageProperty)
    {
    case PAGE_PRT_SEQ_EVENT:
        if(pDisplayContext->SequentialEventContext.currntindex + 10 < pDisplayContext->SequentialEventContext.maxcount-1)
            pDisplayContext->SequentialEventContext.currntindex += 10;

        SequentialEventPage_Print(pDisplayContext);
        break;
    }
}

static void MenuButtonClick(MmiDisplayContext* pDisplayContext)
{
    switch(pDisplayContext->CurrentPageProperty)
    {
        case PAGE_PRT_MEASURE:
            ParentPage_Search(pDisplayContext);
            pDisplayContext->MainView_Scroll_Flag=0;
            break;
        case PAGE_PRT_SAVE_SETTING:
            Setting_Cancel(pDisplayContext);
            break;
        case PAGE_PRT_DEFAULT:
        case PAGE_PRT_SETTING:
        case PAGE_PRT_GRP_COPY:
        case PAGE_PRT_TIME:
        case PAGE_PRT_SEQ_EVENT:
        case PAGE_PRT_FLT_EVENT:
        case PAGE_PRT_FLTWV_EVENT:
        case PAGE_PRT_HW_INFO:
        case PAGE_PRT_MODEL_NUM:
        case PAGE_PRT_IDENTIFIER:
        case PAGE_PRT_VERSION:
        case PAGE_PRT_SETTING_PASSWORD:
            /*Search Parent Page*/
            ParentPage_Search(pDisplayContext);
            switch(pDisplayContext->CurrentPageLevel)
            {
                case 1:
                    pDisplayContext->line_cursor = 1;
                    pDisplayContext->view_cursor = 1;
                    break;
                case 2:
                    pDisplayContext->CurrentPageLevel--;
                    pDisplayContext->line_cursor = pDisplayContext->LineCursorLevel1;
                    pDisplayContext->view_cursor = pDisplayContext->ViewCursorLevel1;
                    break;
                case 3:
                    pDisplayContext->CurrentPageLevel--;
                    pDisplayContext->line_cursor = pDisplayContext->LineCursorLevel2;
                    pDisplayContext->view_cursor = pDisplayContext->ViewCursorLevel2;
                    break;
                case 4:
                    pDisplayContext->CurrentPageLevel--;
                    pDisplayContext->line_cursor = pDisplayContext->LineCursorLevel3;
                    pDisplayContext->view_cursor = pDisplayContext->ViewCursorLevel3;
                    break;
                case 5:
                    pDisplayContext->CurrentPageLevel--;
                    pDisplayContext->line_cursor = pDisplayContext->LineCursorLevel4;
                    pDisplayContext->view_cursor = pDisplayContext->ViewCursorLevel4;
                    break;
                case 6:
                    pDisplayContext->CurrentPageLevel--;
                    pDisplayContext->line_cursor = pDisplayContext->LineCursorLevel5;
                    pDisplayContext->view_cursor = pDisplayContext->ViewCursorLevel5;
                    break;
            }
            break;
    }
    /*Page Processing*/

    if (pDisplayContext->CurrentPageLevel == 2 && (pDisplayContext->SettingLastIndex > 0 || pDisplayContext->param_edit_ctx_.Password_Setting_Context.setting_flag ==1))
    {
        PageSearch(pDisplayContext, PAGE_PRT_SAVE_SETTING);
        pDisplayContext->line_cursor = 1;
        pDisplayContext->view_cursor = 1;
    }

   switch(pDisplayContext->CurrentPageProperty)
   {
       case PAGE_PRT_DEFAULT:
       case PAGE_PRT_SETTING:
       case PAGE_PRT_GRP_COPY:
           ListPage_Print(pDisplayContext);
           break;
       case PAGE_PRT_SAVE_SETTING:
           SavePage_Print(pDisplayContext);
           break;
       case PAGE_PRT_MEASURE:
           break;
       case PAGE_PRT_PASSWORD:
           break;

   }
}


static void EnterButtonClick(MmiDisplayContext* pDisplayContext)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;

    switch(pDisplayContext->CurrentPageProperty)
    {
        case PAGE_PRT_DEFAULT:
            ChildPage_Search(pDisplayContext);
            pDisplayContext->view_cursor = 1;
            pDisplayContext->line_cursor = 1;
            break;
        case PAGE_PRT_SETTING:
        {
            EditLine_Data_Set(pDisplayContext);
            ParamCursorSet(pDisplayContext);
            pParamEditContext->EditLine = pDisplayContext->view_cursor;
            pDisplayContext->mode = MMI_MODE_EDIT;
        }
            return;
        case PAGE_PRT_SAVE_SETTING:
        {
            uint16 CompleteFlag=0;
            CompleteFlag=MmiTagData_AllSet(pDisplayContext);
            CompleteFlag=MmiPassword_Set(pDisplayContext);
            if(CompleteFlag)
            {
                pDisplayContext->SettingLastIndex=0;
                MoveToMainMenuPage(pDisplayContext);
            }
        }
        return;
        case PAGE_PRT_GRP_COPY:
        {
            uint16 CompleteFlag=0;

            uint16 ParentPageCode=GetParentpageCode(pDisplayContext);
            CompleteFlag=handleGroupCopy(pDisplayContext,ParentPageCode,pDisplayContext->line_cursor);

            if(CompleteFlag)
                MoveToMainMenuPage(pDisplayContext);
        }
            return;
        case PAGE_PRT_TIME:
            TimeEditSet(pDisplayContext);
            return;
        case PAGE_PRT_SETTING_PASSWORD:
            LoadPassword(pDisplayContext);
            PWEditSet(pDisplayContext);
            return;
    }

    /*Print Page*/
    switch(pDisplayContext->CurrentPageProperty)
    {
        case PAGE_PRT_DEFAULT:
        case PAGE_PRT_GRP_COPY:
        case PAGE_PRT_SETTING_PASSWORD:
            ListPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_SAVE_SETTING:
            SavePage_Print(pDisplayContext);
            break;
        case PAGE_PRT_SETTING:
            EditPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_TIME:
            TimePage_Print(pDisplayContext);
            break;
        case PAGE_PRT_SEQ_EVENT:
            SequentialPage_Set(pDisplayContext);
            SequentialEventPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_FLT_EVENT:
            FaultPage_Set(pDisplayContext);
            FaultEventPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_FLTWV_EVENT:
            FaultWavePage_Set(pDisplayContext);
            FaultWaveEventPage_Print(pDisplayContext);
            break;
        case PAGE_PRT_HW_INFO:
            SystemInformationPage_Print(pDisplayContext,PAGE_PRT_HW_INFO);
            break;
        case PAGE_PRT_MODEL_NUM:
            SystemInformationPage_Print(pDisplayContext,PAGE_PRT_MODEL_NUM);
            break;
        case PAGE_PRT_IDENTIFIER:
            SystemInformationPage_Print(pDisplayContext,PAGE_PRT_IDENTIFIER);
            break;
        case PAGE_PRT_VERSION:
            FW_VersionPage_Print(pDisplayContext);
            break;

    }
}
void MmiCommandTagSet(MMI_COMMAND_TYPE MmiCommand,MmiContext* pContext)
{
    switch(MmiCommand)
    {
    /*Block 0*/
    case MMI_SEQENCE_TRIP_TEST:
        pContext->pMmiTag[ALS_MMI_PBLRS] = 1;
        break;
    case MMI_TARGET_RESET:
        pContext->pMmiTag[ALS_MMI_PBTARR] = 1;
        break;
    case MMI_BATTERY_TEST:
        pContext->pMmiTag[ALS_MMI_PBBATTEST] = 1;
        break;
    case MMI_PROTECTION_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBPT]^= 1;
        break;
    case MMI_RECLOSE_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBRC]^= 1;
        break;
    case MMI_GROUND_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBGND]^= 1;
        break;
    case MMI_FAST_CURVE_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBSEF]^= 1;
        break;
    case MMI_REMOTE_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBRT]^= 1;
        break;
        /*Block 1*/
    case MMI_EVENT_MENU: //CLOSE/TRIP DELAY BUTTON
        pContext->pMmiTag[ALS_MMI_PBCLP]^= 1;
        break;
    case MMI_CLOSE:
        pContext->pMmiTag[ALS_MMI_PBCL]^= 1;
        break;
    case MMI_HOT_LINE_TAG:
        pContext->pMmiTag[ALS_MMI_PBHT]^= 1;
        break;
    case MMI_SEF_ENABLED:
        pContext->pMmiTag[ALS_MMI_PBRNC]^= 1;
        break;
    case MMI_SEQUENCE_COORDINATION:
        pContext->pMmiTag[ALS_MMI_PBLNC]^= 1;
        break;
    case MMI_COLD_LOAD_PICK_UP:
        pContext->pMmiTag[ALS_MMI_PBLNO]^= 1;
        break;
    case MMI_SET_GROUP1:
        pContext->pMmiTag[ALS_MMI_PBA2R]^= 1;
        break;
    case MMI_SET_GROUP2:
        pContext->pMmiTag[ALS_MMI_PBR2A]^= 1;
        break;
    case MMI_TRIP:
        pContext->pMmiTag[ALS_MMI_PBTR]^= 1;
        break;




    }

}

static MMI_COMMAND_TYPE Mmi_ButtonPressCheck(MmiContext* pContext)
{
    uint16 ReadData;

    MMI_COMMAND_TYPE Rtn = MMI_NO_COMMAND;

    /*Block0*/

    ReadData = ButtonBlock_Read(0);

    if(ReadData != 0xFF)
    {
        /*Push Button Block0 detected*/
        if(pContext->MmiPushButton[0] == ReadData)
        {
                if(pContext->MmiButtonCnt<MMI_BUTTON_COUNT)        pContext->MmiButtonCnt++;

                else
                {
                    if(pContext->MmiOperation == 0)
                    {
                        pContext->MmiOperation = 1;
                        Rtn = Mmi_ButtonBlock0(ReadData);
                    }
                }
        }

        else    pContext->MmiPushButton[0] = ReadData;
    }
    /*Push Button Block0 not dectected*/
    else
    {
        pContext->MmiPushButton[0] = ReadData;

        /*Block1*/
        ReadData = ButtonBlock_Read(1);

        if(ReadData != 0xFF)
        {
            /*Push Button Block1 detected*/
            if(pContext->MmiPushButton[1] == ReadData)
            {
                if(pContext->MmiButtonCnt<MMI_BUTTON_COUNT)        pContext->MmiButtonCnt++;

                else
                {
                    if(pContext->MmiOperation == 0)
                    {
                        pContext->MmiOperation = 1;
                        return Mmi_ButtonBlock1(ReadData);
                    }
                }
            }

            else    pContext->MmiPushButton[1] = ReadData;
        }
        else
        {
            pContext->MmiPushButton[1] = ReadData;

            /*Block2*/
            ReadData = ButtonBlock_Read(2);

            if(ReadData != 0x7F)
            {
                if(pContext->MmiPushButton[2] == ReadData)
                {
                    if(pContext->MmiButtonCnt<MMI_BUTTON_COUNT)        pContext->MmiButtonCnt++;

                    else
                    {
                        if(pContext->MmiOperation == 0)
                        {
                            pContext->MmiOperation = 1;
                            return Mmi_ButtonBlock2(ReadData);
                        }
                    }

                }

                else    pContext->MmiPushButton[2] = ReadData;
            }

            else
            {
                pContext->MmiPushButton[2] = ReadData;
                pContext->MmiButtonCnt = 0;
                pContext->MmiOperation = 0;
            }
        }
    }
    return Rtn;
}

static void Mmi_Init(MmiContext* pContext)
{
    uint16* pMmiTag = NULL;
    uint16* pBvTag = NULL;

    memset(pContext, 0, sizeof(MmiContext));
    memset(&SequentialEventFileBuffer, 0, sizeof(SequentialEventFileBuffer));
    memset(&FaultEventFileBuffer, 0, sizeof(FaultEventFileBuffer));


    pContext->pMmiDisplayContext = MmiDisplayContext_Create(&pContext->MmiBlock4);

    pContext->pMmiDisplayContext->SequentialEventContext.pBuf =&SequentialEventFileBuffer;
    pContext->pMmiDisplayContext->FaultEventContext.pBuf      =&FaultEventFileBuffer;


    pMmiTag =  MmiTagPointer_Get();
    pBvTag =  BvTagPointer_Get();

    Mmi_TimeStamping(&MmiTimeStamp);


    if(pMmiTag != NULL)         pContext->pMmiTag = pMmiTag;
    if(pBvTag != NULL)         pContext->pBvTag = pBvTag;
    else
    {
        DEBUG_Msg("[MMI] Fail to load Mmi Tag ");
    }
    if(&MmiTimeStamp != NULL)         pContext->pMmiDisplayContext->pTime = &MmiTimeStamp;


    PageSearch(pContext->pMmiDisplayContext, PAGE_PRT_MEASURE);
}

static void MmiDisplayMode(MmiDisplayContext* pDisplayContext, MMI_COMMAND_TYPE EventType)
{
    switch(EventType)
    {
        case MMI_LCD_ENTER:
            EnterButtonClick(pDisplayContext);
            break;
        case MMI_LCD_MENU:
            MenuButtonClick(pDisplayContext);
            break;
        case MMI_LCD_UP:
            UpButtonClick(pDisplayContext);
            break;
        case MMI_LCD_DOWN:
            DownButtonClick(pDisplayContext);
            break;
        case MMI_LCD_LEFT:
            LeftButtonClick(pDisplayContext);
            break;
        case MMI_LCD_RIGHT:
            RightButtonClick(pDisplayContext);
            break;
    }
}

static void MmiEditMode(MmiDisplayContext* pDisplayContext, MMI_COMMAND_TYPE EventType)
{
    ParamEditContext* pParamEditContext = &pDisplayContext->param_edit_ctx_;

    LCD_BUTTON_TYPE LCD_Button = (LCD_BUTTON_TYPE)(EventType - MMI_LCD_LEFT);

    switch(pParamEditContext->param_desc_type)
    {
        case PARAM_DESC_RANGE_TYPE:
            RangeTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_DESC_RANGE_DUAL_TYPE:
            RangeDualTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_DESC_RANGE_OFF_TYPE:
            RangeOffTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_DESC_RANGE_CURSOR_TYPE:
            RangeCursorTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_DESC_SELECT_TYPE:
            SelectTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_DESC_SELECT_NAME_TYPE:
            SelectNameTypeHandler(pDisplayContext,LCD_Button);
            break;
        case PARAM_DESC_NAME_TYPE:
            NameTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_TIME_TYPE:
            TimeTypeHandler(pDisplayContext, LCD_Button);
            break;
        case PARAM_PASSWORD_TYPE:
            PasswordTypeHandler(pDisplayContext, LCD_Button);
            break;

    }
}
static void MmiAllLedWrite(uint16 data)
{
    uint16 BLOCK4_Data=data;
    BLOCK4_Data &= 0x7f;
    BLOCK4_Data |= 0x40;

    Zone7BusTake(MMI_WRITE);

    LED_BLOCK_WRITE(0, data);
    LED_BLOCK_WRITE(1, data);
    LED_BLOCK_WRITE(2, data);
    LED_BLOCK_WRITE(3, data);
    LED_BLOCK_WRITE(4, BLOCK4_Data);
    LED_BLOCK_WRITE(6, data);

    Zone7BusRelease();
}
static void MmiLampTestMode(MmiContext* pContext)
{
    MmiDisplayContext* pDisplayContext = pContext->pMmiDisplayContext;
    uint16 Sec = pContext->TestModeSecCount/COUNTS_PER_SEC;

    uint16 data = ((Sec %2)== 1) ? ~0x0 : 0x0;

    MmiAllLedWrite(data);

    if(Sec == 11)
    {
        pDisplayContext->mode=MMI_MODE_DISPLAY;
        pContext->TestModeSecCount=0;
        pContext->pMmiTag[ALS_MMI_PBTARR] = 0;
    }

}

static void MmiBatteryTestMode(MmiContext* pContext)
{
    MmiDisplayContext* pDisplayContext = pContext->pMmiDisplayContext;
    uint16 Sec = pContext->TestModeSecCount/COUNTS_PER_SEC;

    BatteryTestPage_Print(pDisplayContext,Sec);

    if(Sec==10)
    {
        pContext->TestModeSecCount=0;
        pDisplayContext->mode=MMI_MODE_DISPLAY;
        MoveToMainMenuPage(pDisplayContext);
        pContext->pMmiTag[ALS_MMI_PBBATTEST] = 0;
        memset(&pDisplayContext->SettingContext, 0, sizeof(SettingContext));
    }
}

/*
 * Complete
 */
static MMI_COMMAND_TYPE Mmi_ButtonBlock0(uint16  Button)
{
    MMI_COMMAND_TYPE Rtn = MMI_NO_COMMAND;

    switch(Button)
    {
        case MMI_BUTTON_SEQENCE_TRIP_TEST:
            Rtn = MMI_SEQENCE_TRIP_TEST;
            break;
        case MMI_BUTTON_TARGET_RESET:
              Rtn = MMI_TARGET_RESET;
              break;
        case MMI_BUTTON_BATTERY_TEST:
            Rtn = MMI_BATTERY_TEST;
            break;
        case MMI_BUTTON_PROTECTION_ENABLED:
            Rtn = MMI_PROTECTION_ENABLED;
            break;
        case MMI_BUTTON_RECLOSE_ENABLED:
            Rtn = MMI_RECLOSE_ENABLED;
            break;
        case MMI_BUTTON_GROUND_ENABLED:
            Rtn = MMI_GROUND_ENABLED;
            break;
        case MMI_BUTTON_FAST_CURVE_ENABLED:
            Rtn = MMI_FAST_CURVE_ENABLED;
            break;
        case MMI_BUTTON_REMOTE_ENABLED:
            Rtn = MMI_REMOTE_ENABLED;
            break;
    }
  return Rtn;
}

static MMI_COMMAND_TYPE Mmi_ButtonBlock1(uint16  Button)
{
    MMI_COMMAND_TYPE Rtn = MMI_NO_COMMAND;

    switch(Button)
    {
        case MMI_BUTTON_EVENT_MENU:
            Rtn = MMI_EVENT_MENU;
            break;
        case MMI_BUTTON_CLOSE:
            Rtn = MMI_CLOSE;
            break;
        case MMI_BUTTON_HOT_LINE_TAG:
            Rtn = MMI_HOT_LINE_TAG;
            break;
        case MMI_BUTTON_SEF_ENABLED:
            Rtn = MMI_SEF_ENABLED;
            break;
        case MMI_BUTTON_SEQUENCE_COORDINATION:
            Rtn = MMI_SEQUENCE_COORDINATION;
            break;
        case MMI_BUTTON_COLD_LOAD_PICK_UP:
            Rtn = MMI_COLD_LOAD_PICK_UP;
            break;
        case MMI_BUTTON_SET_GROUP1:
            Rtn = MMI_SET_GROUP1;
            break;
        case MMI_BUTTON_SET_GROUP2:
            Rtn = MMI_SET_GROUP2;
            break;
    }
 return Rtn;
}

static MMI_COMMAND_TYPE Mmi_ButtonBlock2(uint16  Button)
{
    MMI_COMMAND_TYPE Rtn = MMI_NO_COMMAND;

    switch(Button)
    {
        case MMI_BUTTON_TRIP:
            Rtn = MMI_TRIP;
            break;
        case MMI_BUTTON_LCD_LEFT:
            Rtn = MMI_LCD_LEFT;
            break;
        case MMI_BUTTON_LCD_RIGHT:
            Rtn = MMI_LCD_RIGHT;
            break;
        case MMI_BUTTON_LCD_UP:
            Rtn = MMI_LCD_UP;
            break;
        case MMI_BUTTON_LCD_DOWN:
            Rtn = MMI_LCD_DOWN;
            break;
        case MMI_BUTTON_LCD_MENU:
            Rtn = MMI_LCD_MENU;
            break;
        case MMI_BUTTON_LCD_ENTER:
            Rtn = MMI_LCD_ENTER;
            break;
    }
    return Rtn;
}
/*
 * TEST....
 */
static void MmiLedInit(MmiContext* pContext)
{
    uint16 InitValue = 0x1F;
    Zone7BusTake(MMI_WRITE);

    LED_BLOCK_WRITE(4, InitValue);

    Zone7BusRelease();
}
#if 1
static void MmiLedData_Write(MmiContext* pContext, uint16* pTAG_MMI)
{
    /*For write block 4, associated with LCD control lines*/
    MMI_BLOCK0_GET(pContext->MmiBlock0, pTAG_MMI);
    MMI_BLOCK1_GET(pContext->MmiBlock1, pTAG_MMI);

    pContext->pMmiTag[ALS_MMI_BLK_LED0]  = ~pContext->MmiBlock0;
    pContext->pMmiTag[ALS_MMI_BLK_LED0] |= (~pContext->MmiBlock1)<<8;

    MMI_BLOCK2_GET(pContext->MmiBlock2, pTAG_MMI);
    MMI_BLOCK3_GET(pContext->MmiBlock3, pTAG_MMI);

    pContext->pMmiTag[ALS_MMI_BLK_LED1]  = ~pContext->MmiBlock2;
    pContext->pMmiTag[ALS_MMI_BLK_LED1] |= (~pContext->MmiBlock3)<<8;

    MMI_BLOCK4_GET(pContext->MmiBlock4, pTAG_MMI);
    pContext->pMmiTag[ALS_MMI_BLK_LED2]  = ~pContext->MmiBlock4;
    pContext->MmiBlock4 &= 0x7f;
    pContext->MmiBlock4 |= 0x40;

    MMI_BLOCK6_GET(pContext->MmiBlock6, pTAG_MMI);
    pContext->pMmiTag[ALS_MMI_BLK_LED2] |= (~pContext->MmiBlock6)<<8;

    uint16 MMI_LED_TAG = 0x00;
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCWF)  <<1);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCFB)  <<2);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCOCT) <<3);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCPT)  <<4);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCTT)  <<5);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDIPT)  <<6);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDEMOL) <<7);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDMODEM)<<8);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDOPFB) <<9);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDCPFB) <<10);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDMODFB)<<11);
    MMI_LED_TAG |= (*(pTAG_MMI + ALS_MMI_LEDPOLY) <<12);
    pContext->pMmiTag[ALS_MMI_BLK_LED3] = MMI_LED_TAG;

    Zone7BusTake(MMI_WRITE);
    LED_BLOCK_WRITE(0, pContext->MmiBlock0);
    LED_BLOCK_WRITE(1, pContext->MmiBlock1);
    LED_BLOCK_WRITE(2, pContext->MmiBlock2);
    LED_BLOCK_WRITE(3, pContext->MmiBlock3);
    LED_BLOCK_WRITE(4, pContext->MmiBlock4);
    LED_BLOCK_WRITE(6, pContext->MmiBlock6);
    Zone7BusRelease();
}
#else
static void MmiLedData_Write(MmiContext* pContext, uint16* pTAG_MMI)
{
    /*For write block 4, associated with LCD control lines*/

    Zone7BusTake(MMI_WRITE);

    MMI_BLOCK0_GET(pContext->MmiBlock0, pTAG_MMI);
    MMI_BLOCK1_GET(pContext->MmiBlock1, pTAG_MMI);
    MMI_BLOCK2_GET(pContext->MmiBlock2, pTAG_MMI);
    MMI_BLOCK3_GET(pContext->MmiBlock3, pTAG_MMI);
    MMI_BLOCK4_GET(pContext->MmiBlock4, pTAG_MMI);

    pContext->MmiBlock4 &= 0x7f;
    pContext->MmiBlock4 |= 0x40;
    MMI_BLOCK6_GET(pContext->MmiBlock6, pTAG_MMI);


    LED_BLOCK_WRITE(0, pContext->MmiBlock0);
    LED_BLOCK_WRITE(1, pContext->MmiBlock1);
    LED_BLOCK_WRITE(2, pContext->MmiBlock2);
    LED_BLOCK_WRITE(3, pContext->MmiBlock3);
    LED_BLOCK_WRITE(4, pContext->MmiBlock4);
    LED_BLOCK_WRITE(6, pContext->MmiBlock6);

    Zone7BusRelease();
}
#endif

void Mmi_Task(UArg arg0, UArg arg1)
{
    MmiContext* pContext = &MmiCtx;

    Mmi_Init(pContext);

    MMI_COMMAND_TYPE MmiCommand = MMI_NO_COMMAND;
    MmiDisplayContext* pMmiDisplayContext = pContext->pMmiDisplayContext;

    uint16 Count = 0;
    MmiLedInit(pContext);


    while(1)
    {
          TASK_SLEEP(50);

          //Time Sync
          Mmi_TimeStamping(&MmiTimeStamp);


          /*Check Button Press*/
          MmiCommand = Mmi_ButtonPressCheck(pContext);
          MmiCommandTagSet(MmiCommand,pContext);

          if(pContext->pBvTag[ALS_BV_LAMPTEST])
              pMmiDisplayContext->mode=MMI_MODE_LAMP_TEST;

          if(pContext->pBvTag[ALS_BV_BATTEST])
              pMmiDisplayContext->mode=MMI_MODE_BAT_TEST;


          if(MmiCommand==MMI_NO_COMMAND)
          {
              if(Count == 10)
              {
                  if(pMmiDisplayContext->CurrentPageProperty == PAGE_PRT_MEASURE)
                  {
                      MainView_Display(pMmiDisplayContext);
                  }
                  if(pMmiDisplayContext->CurrentPageProperty == PAGE_PRT_TIME)
                  {
                      TimePage_Print(pMmiDisplayContext);
                  }

                  Count = 0;
                  if(pMmiDisplayContext->mode!=MMI_MODE_LAMP_TEST)
                      MmiLedData_Write(pContext, pContext->pMmiTag);
              }
              else  Count++;
          }
          else
          {

              switch(pMmiDisplayContext->mode)
              {
              case MMI_MODE_DISPLAY:
                  MmiDisplayMode(pMmiDisplayContext, MmiCommand);
                  break;
              case MMI_MODE_EDIT:
                  MmiEditMode(pMmiDisplayContext, MmiCommand);
                  break;
              }

          }



          if(pMmiDisplayContext->mode==MMI_MODE_BAT_TEST)
          {
              pContext->TestModeSecCount++;
              MmiBatteryTestMode(pContext);
              continue;
          }


          if(pMmiDisplayContext->mode==MMI_MODE_LAMP_TEST)
          {
              pContext->TestModeSecCount++;
              MmiLampTestMode(pContext);
              continue;
          }
          TagData output;
          uint16 TagID = 44;
          TagData_Extract(&output,TagID);

    }
}
